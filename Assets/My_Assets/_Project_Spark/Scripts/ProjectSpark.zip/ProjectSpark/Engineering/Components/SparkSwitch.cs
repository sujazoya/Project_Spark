using UnityEngine;
using UnityEngine.Events;

namespace ProjectSpark.Gameplay
{
    public enum SparkSwitchState
    {
        Open,
        Closed
    }

    [DisallowMultipleComponent]
    public sealed class SparkSwitch :
        SparkElectricalComponent,
        ISparkConductiveDevice
    {
        #region Inspector

        [Header("Switch")]
        [SerializeField]
        private SparkSwitchState state =
            SparkSwitchState.Open;

        [Header("Terminals")]
        [SerializeField]
        private SparkTerminal inputTerminal;

        [SerializeField]
        private SparkTerminal outputTerminal;

        [Header("Electrical")]
        [SerializeField, Min(0f)]
        private float closedResistance = 0.1f;

        [SerializeField, Min(0f)]
        private float openResistance = 1000000000f;

        [SerializeField, Min(0f)]
        private float voltageThreshold = 0.001f;

        [SerializeField, Min(0f)]
        private float currentThreshold = 0.001f;

        [Header("Runtime Polarity")]
        [SerializeField, Min(0.000001f)]
        private float runtimePolarityThreshold = 0.001f;
        public void RefreshRuntimePolarity()
{
    UpdateRuntimeTerminalPolarity();
}

        #endregion


        #region Basic Switch State

        public SparkSwitchState State =>
            state;

        public bool IsClosed =>
            state == SparkSwitchState.Closed;

        public bool IsOpen =>
            state == SparkSwitchState.Open;

        public bool IsConducting =>
            IsClosed &&
            ElectricalEnabled;

        public bool IsConfiguredToConduct =>
            IsClosed &&
            ElectricalEnabled;

        public bool IsSolverConducting =>
            ElectricalState.Conduction ==
            SparkConductionState.Conducting;

        public bool IsActuallyConducting =>
            IsConfiguredToConduct &&
            IsSolverConducting;

        #endregion

        // ============================================================
// VISUAL STATE EVENT
// ============================================================

/// <summary>
/// Raised whenever the switch electrical/visual status
/// changes in a way that can affect SparkSwitchVisual.
///
/// This is visual notification only.
/// It does not modify the electrical solver.
/// </summary>
public event System.Action VisualStateChanged;

private int lastVisualState = -1;


        #region Resistance

        public float Resistance =>
            IsClosed
                ? closedResistance
                : openResistance;

        public float ClosedResistance =>
            closedResistance;

        public float OpenResistance =>
            openResistance;

        #endregion


        #region Terminals

        public SparkTerminal InputTerminal =>
            inputTerminal;

        public SparkTerminal OutputTerminal =>
            outputTerminal;

        #endregion


        #region Input Electrical State

        public float InputVoltage =>
            inputTerminal != null
                ? inputTerminal.ElectricalState.Voltage
                : 0f;

        public float InputCurrent =>
            inputTerminal != null
                ? inputTerminal.ElectricalState.Current
                : 0f;

        public float InputPower =>
            inputTerminal != null
                ? inputTerminal.ElectricalState.Power
                : 0f;

        public bool InputHasPower =>
            inputTerminal != null &&
            Mathf.Abs(InputVoltage) >=
            voltageThreshold;

        #endregion


        #region Output Electrical State

        public float OutputVoltage =>
            outputTerminal != null
                ? outputTerminal.ElectricalState.Voltage
                : 0f;

        public float OutputCurrent =>
            outputTerminal != null
                ? outputTerminal.ElectricalState.Current
                : 0f;

        public float OutputPower =>
            outputTerminal != null
                ? outputTerminal.ElectricalState.Power
                : 0f;

        public bool OutputHasPower =>
            outputTerminal != null &&
            Mathf.Abs(OutputVoltage) >=
            voltageThreshold;

        #endregion


        #region Runtime Polarity

        public SparkTerminalPolarity InputPolarity =>
            GetRuntimePolarity(InputVoltage);

        public SparkTerminalPolarity OutputPolarity =>
            GetRuntimePolarity(OutputVoltage);

        public SparkTerminalPolarity RuntimePolarity
        {
            get
            {
                if (!IsClosed ||
                    !ElectricalEnabled)
                {
                    return SparkTerminalPolarity.None;
                }

                SparkTerminalPolarity input =
                    InputPolarity;

                if (input !=
                    SparkTerminalPolarity.None)
                {
                    return input;
                }

                return OutputPolarity;
            }
        }

        private SparkTerminalPolarity GetRuntimePolarity(
            float voltage)
        {
            if (voltage >
                runtimePolarityThreshold)
            {
                return SparkTerminalPolarity.Positive;
            }

            if (voltage <
                -runtimePolarityThreshold)
            {
                return SparkTerminalPolarity.Negative;
            }

            return SparkTerminalPolarity.None;
        }

      private void UpdateRuntimeTerminalPolarity()
{
    if (inputTerminal == null ||
        outputTerminal == null)
    {
        return;
    }

    if (!ElectricalEnabled || !IsClosed)
    {
        outputTerminal.ClearRuntimePolarity();
        return;
    }

    // Polarity comes from each terminal's solved voltage.
    SparkTerminalPolarity inputPolarity =
        GetRuntimePolarity(InputVoltage);

    SparkTerminalPolarity outputPolarity =
        GetRuntimePolarity(OutputVoltage);

    inputTerminal.SetRuntimePolarity(inputPolarity);
    outputTerminal.SetRuntimePolarity(outputPolarity);
}
        #endregion


        #region Connection State

        public bool HasInputConnection =>
            inputTerminal != null &&
            inputTerminal.ConnectionCount > 0;

        public bool HasOutputConnection =>
            outputTerminal != null &&
            outputTerminal.ConnectionCount > 0;

        public bool HasBothConnections =>
            HasInputConnection &&
            HasOutputConnection;

        public int InputConnectionCount =>
            inputTerminal != null
                ? inputTerminal.ConnectionCount
                : 0;

        public int OutputConnectionCount =>
            outputTerminal != null
                ? outputTerminal.ConnectionCount
                : 0;

        #endregion


        #region Component Electrical State

        public float Voltage =>
            ElectricalState.Voltage;

        public float Current =>
            ElectricalState.Current;

        public float Power =>
            ElectricalState.Power;

        public SparkConductionState Conduction =>
            ElectricalState.Conduction;

        public bool HasVoltage =>
            Mathf.Abs(Voltage) >=
            voltageThreshold;

        public bool HasCurrent =>
            Mathf.Abs(Current) >=
            currentThreshold;

        public bool IsElectricallyConducting =>
            Conduction ==
            SparkConductionState.Conducting;

        public bool IsClosedAndConducting =>
            IsClosed &&
            IsElectricallyConducting;

        public bool HasPowerFlow =>
            IsClosedAndConducting &&
            HasCurrent;

        public bool IsPoweredAndClosed =>
            IsClosed &&
            (
                HasVoltage ||
                HasCurrent ||
                Mathf.Abs(Power) >=
                voltageThreshold *
                currentThreshold
            );

        public bool IsReadyForOutput =>
            IsClosedAndConducting;

        public bool CanProvideOutput =>
            ElectricalEnabled &&
            IsClosed;

        public bool HasReadyOutput =>
            HasOutputConnection &&
            IsReadyForOutput;

        #endregion


        #region Conduction

        public bool CanConductBetween(
            SparkTerminal from,
            SparkTerminal to)
        {
            if (!ElectricalEnabled ||
                !IsClosed)
            {
                return false;
            }

            if (from == null ||
                to == null)
            {
                return false;
            }

            if (inputTerminal == null ||
                outputTerminal == null)
            {
                return false;
            }

            return
                (from == inputTerminal &&
                 to == outputTerminal) ||

                (from == outputTerminal &&
                 to == inputTerminal);
        }

        #endregion


        #region Electrical Solver Integration

        /// <summary>
        /// Applies the electrical state calculated
        /// by the solver.
        ///
        /// The base class stores the authoritative
        /// electrical state.
        ///
        /// Runtime polarity is then synchronized
        /// from the solved terminal voltages.
        /// </summary>
      public override void ApplyElectricalState(
    in SparkElectricalState solvedState)
{
    // Store authoritative solver result.
    base.ApplyElectricalState(solvedState);

    // Update runtime polarity using the latest terminal data.
    UpdateRuntimeTerminalPolarity();

    // Electrical values can change even when the
    // mechanical switch position remains unchanged.
    NotifyVisualStateChanged();
}
        #endregion


        #region Switch Control

        public void ToggleState()
        {
            SetState(
                state ==
                SparkSwitchState.Open
                    ? SparkSwitchState.Closed
                    : SparkSwitchState.Open);
        }

         
public void SetState(SparkSwitchState newState)
{
    if (state == newState)
        return;

    SparkSwitchState previousState = state;

    state = newState;

    // Immediately invalidate the previous output polarity.
    // Do not propagate old solver data.
    if (!IsClosed || !ElectricalEnabled)
    {
        if (outputTerminal != null)
            outputTerminal.ClearRuntimePolarity();
    }

    // Request a fresh electrical calculation.
    NotifyElectricalConfigurationChanged();

    // Notify mechanical state listeners immediately.
    VisualStateChanged?.Invoke();

    Debug.Log(
        $"[SPARK SWITCH] {name}: " +
        $"{previousState} -> {state}",
        this);
}

        public SparkResult Toggle(
            in SparkInteractionContext context)
        {
            if (!CanInteract(
                    context,
                    out string reason))
            {
                return SparkResult.Rejected(reason);
            }

            ToggleState();

            return SparkResult.Success();
        }

        public override SparkResult BeginInteraction(
            in SparkInteractionContext context)
        {
            if (context.InteractionType ==
                SparkInteractionType.Toggle)
            {
                return Toggle(context);
            }

            return base.BeginInteraction(context);
        }

        #endregion


        #region Validation

        private void OnValidate()
        {
            closedResistance =
                Mathf.Max(
                    0f,
                    closedResistance);

            openResistance =
                Mathf.Max(
                    closedResistance,
                    openResistance);

            voltageThreshold =
                Mathf.Max(
                    0f,
                    voltageThreshold);

            currentThreshold =
                Mathf.Max(
                    0f,
                    currentThreshold);

            runtimePolarityThreshold =
                Mathf.Max(
                    0.000001f,
                    runtimePolarityThreshold);
        }
        

        #endregion

        private int GetVisualState()
{
    // 2 = Closed / Green
    if (IsClosed)
        return 2;

    // 1 = Open but voltage/current exists / Red
    if (HasVoltage ||
        HasCurrent ||
        InputHasPower ||
        OutputHasPower)
    {
        return 1;
    }

    // 0 = No voltage/current / Grey
    return 0;
}

private void NotifyVisualStateChanged()
{
    lastVisualState = GetVisualState();

    VisualStateChanged?.Invoke();
}
[ContextMenu("Debug Switch Electrical State")]
private void DebugSwitchElectricalState()
{
    Debug.Log(
        $"[SWITCH ELECTRICAL DEBUG] {name} | " +
        $"State={State} | " +
        $"IsConducting={IsConducting} | " +
        $"ElectricalEnabled={ElectricalEnabled} | " +
        $"InputVoltage={InputVoltage:F3} V | " +
        $"OutputVoltage={OutputVoltage:F3} V | " +
        $"Voltage={Voltage:F3} V | " +
        $"Current={Current:F6} A | " +
        $"Conduction={Conduction}",
        this);
}
    }
}
