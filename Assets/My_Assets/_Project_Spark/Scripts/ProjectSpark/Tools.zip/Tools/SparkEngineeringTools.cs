using ProjectSpark.Gameplay;
using ProjectSpark.Measurement;
using ProjectSpark.Scan;
using UnityEngine;

namespace ProjectSpark.Tools
{
    // ============================================================
    // SELECT
    // ============================================================

    public sealed class SparkSelectTool : SparkTool
    {
        protected override SparkToolType GetToolType()
        {
            return SparkToolType.Select;
        }

        protected override SparkResult OnBegin(SparkToolContext context)
        {
            if (context.TargetHit.Target == null)
                return SparkResult.Invalid("No component selected.");

            context.TargetHit.Target.SetSelected(true);

            return SparkResult.Success("Component selected.");
        }
    }


    // ============================================================
    // INSPECT
    // ============================================================

    public sealed class SparkInspectTool : SparkTool
    {
        protected override SparkToolType GetToolType()
        {
            return SparkToolType.Inspect;
        }

        protected override SparkResult OnBegin(SparkToolContext context)
        {
            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Inspect);

            return context.TargetHit.Target.Inspect(
                interactionContext);
        }
    }


    // ============================================================
    // MOVE
    // ============================================================

    public sealed class SparkMoveTool : SparkTool
    {
        protected override SparkToolType GetToolType()
        {
            return SparkToolType.Move;
        }

        private SparkTransformManipulable GetManipulator(
            SparkToolContext context)
        {
            if (context.TargetHit.Target == null)
                return null;

            return context.TargetHit.Target
                .GetComponentInChildren<SparkTransformManipulable>();
        }

        protected override SparkResult OnBegin(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
            {
                return SparkResult.Unavailable(
                    "Component has no SparkTransformManipulable.");
            }

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Move);

            return manipulator.BeginMove(
                interactionContext);
        }

        protected override SparkResult OnUpdate(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
                return SparkResult.Unavailable(
                    "Move controller is missing.");

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Move);

            return manipulator.UpdateMove(
                interactionContext);
        }

        protected override SparkResult OnEnd(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
                return SparkResult.Unavailable(
                    "Move controller is missing.");

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Move);

            return manipulator.EndMove(
                interactionContext);
        }

        protected override SparkResult OnCancel(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
                return SparkResult.Cancelled();

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Move);

            return manipulator.CancelMove(
                interactionContext);
        }
    }


    // ============================================================
    // ROTATE
    // ============================================================

    public sealed class SparkRotateTool : SparkTool
    {
        protected override SparkToolType GetToolType()
        {
            return SparkToolType.Rotate;
        }

        private SparkTransformManipulable GetManipulator(
            SparkToolContext context)
        {
            if (context.TargetHit.Target == null)
                return null;

            return context.TargetHit.Target
                .GetComponentInChildren<SparkTransformManipulable>();
        }

        protected override SparkResult OnBegin(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
            {
                return SparkResult.Unavailable(
                    "Component has no SparkTransformManipulable.");
            }

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Rotate);

            return manipulator.BeginRotate(
                interactionContext);
        }

        protected override SparkResult OnUpdate(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
                return SparkResult.Unavailable(
                    "Rotate controller is missing.");

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Rotate);

            return manipulator.UpdateRotate(
                interactionContext);
        }

        protected override SparkResult OnEnd(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
                return SparkResult.Unavailable(
                    "Rotate controller is missing.");

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Rotate);

            return manipulator.EndRotate(
                interactionContext);
        }

        protected override SparkResult OnCancel(
            SparkToolContext context)
        {
            SparkTransformManipulable manipulator =
                GetManipulator(context);

            if (manipulator == null)
                return SparkResult.Cancelled();

            SparkInteractionContext interactionContext =
                context.Gameplay.CreateInteractionContext(
                    context.TargetHit,
                    SparkInteractionType.Rotate);

            return manipulator.CancelRotate(
                interactionContext);
        }
    }


    // ============================================================
    // MEASURE
    // ============================================================

    public sealed class SparkMeasureTool : SparkTool
    {
        [SerializeField]
        private SparkMeasurementSystem measurementSystem;

        [SerializeField]
        private SparkMeasurementType measurementType =
            SparkMeasurementType.Voltage;

        public SparkMeasurementReading LastReading
        {
            get;
            private set;
        }

        protected override SparkToolType GetToolType()
        {
            return SparkToolType.Measure;
        }

        protected override SparkResult OnBegin(
            SparkToolContext context)
        {
            if (measurementSystem == null)
            {
                return SparkResult.Unavailable(
                    "Measurement system is not configured.");
            }

            SparkTerminal terminal =
                context.TargetHit.Target
                    .GetComponentInParent<SparkTerminal>();

            if (terminal == null)
            {
                return SparkResult.Invalid(
                    "Target has no measurement terminal.");
            }

            SparkResult result =
                measurementSystem.TryMeasureTerminal(
                    terminal,
                    measurementType,
                    out SparkMeasurementReading reading);

            if (result.Succeeded)
                LastReading = reading;

            return result;
        }
    }


    // ============================================================
    // SCAN
    // ============================================================

    public sealed class SparkScanTool : SparkTool
    {
        [SerializeField]
        private SparkScanSystem scanSystem;

        public SparkScanReport LastReport
        {
            get;
            private set;
        }

        protected override SparkToolType GetToolType()
        {
            return SparkToolType.Scan;
        }

        protected override SparkResult OnBegin(
            SparkToolContext context)
        {
            if (scanSystem == null)
            {
                return SparkResult.Unavailable(
                    "Scan system is not configured.");
            }

            SparkResult result =
                scanSystem.TryScan(
                    context.TargetHit.Target,
                    out SparkScanReport report);

            if (result.Succeeded)
                LastReport = report;

            return result;
        }
    }


    // ============================================================
    // COMPONENT TRANSFORM CONTROLLER
    // ============================================================

    public sealed class SparkTransformManipulable :
        MonoBehaviour,
        ISparkMovable,
        ISparkRotatable
    {
        [Header("Move")]
        [SerializeField]
        private bool allowMove = true;

        [SerializeField, Min(0f)]
        private float moveSnap = 0f;

        [Header("Rotate")]
        [SerializeField]
        private bool allowRotate = true;

        [SerializeField]
        private Vector3 rotationAxis = Vector3.up;

        [SerializeField, Min(0f)]
        private float rotationDegreesPerPixel = 0.25f;

        [SerializeField, Min(0f)]
        private float rotationSnap = 0f;

        private Camera activeCamera;
        private Plane movementPlane;

        private Vector3 startPosition;
        private Quaternion startRotation;

        private Vector3 grabOffset;
        private Vector2 startPointer;

        // --------------------------------------------------------
        // MOVE
        // --------------------------------------------------------

        public bool CanMove(
            in SparkInteractionContext context,
            out string reason)
        {
            if (!allowMove)
            {
                reason = "Movement is disabled.";
                return false;
            }

            reason = null;
            return true;
        }

        public SparkResult BeginMove(
            in SparkInteractionContext context)
        {
            if (!CanMove(context, out string reason))
                return SparkResult.Rejected(reason);

            activeCamera = Camera.main;

            if (activeCamera == null)
            {
                return SparkResult.Unavailable(
                    "No interaction camera found.");
            }

            startPosition = transform.position;

            movementPlane = new Plane(
                activeCamera.transform.forward,
                context.HitPosition);

            if (!TryProjectPointer(
                    context.ScreenPosition,
                    out Vector3 projectedPoint))
            {
                return SparkResult.Rejected(
                    "Pointer cannot be projected.");
            }

            grabOffset =
                transform.position - projectedPoint;

            return SparkResult.Success(
                "Move started.");
        }

        public SparkResult UpdateMove(
            in SparkInteractionContext context)
        {
            if (activeCamera == null)
            {
                return SparkResult.Unavailable(
                    "Move camera is unavailable.");
            }

            if (!TryProjectPointer(
                    context.ScreenPosition,
                    out Vector3 projectedPoint))
            {
                return SparkResult.Rejected(
                    "Pointer cannot be projected.");
            }

            Vector3 target =
                projectedPoint + grabOffset;

            if (moveSnap > 0f)
            {
                target.x =
                    Mathf.Round(
                        target.x / moveSnap) * moveSnap;

                target.y =
                    Mathf.Round(
                        target.y / moveSnap) * moveSnap;

                target.z =
                    Mathf.Round(
                        target.z / moveSnap) * moveSnap;
            }

            transform.position = target;

            return SparkResult.Success();
        }

        public SparkResult EndMove(
            in SparkInteractionContext context)
        {
            activeCamera = null;

            return SparkResult.Success(
                "Move completed.");
        }

        public SparkResult CancelMove(
            in SparkInteractionContext context)
        {
            transform.position = startPosition;

            activeCamera = null;

            return SparkResult.Cancelled(
                "Move cancelled.");
        }

        // --------------------------------------------------------
        // ROTATE
        // --------------------------------------------------------

        public bool CanRotate(
            in SparkInteractionContext context,
            out string reason)
        {
            if (!allowRotate)
            {
                reason = "Rotation is disabled.";
                return false;
            }

            reason = null;
            return true;
        }

        public SparkResult BeginRotate(
            in SparkInteractionContext context)
        {
            if (!CanRotate(context, out string reason))
                return SparkResult.Rejected(reason);

            startRotation =
                transform.rotation;

            startPointer =
                context.ScreenPosition;

            return SparkResult.Success(
                "Rotation started.");
        }

        public SparkResult UpdateRotate(
            in SparkInteractionContext context)
        {
            Vector2 delta =
                context.ScreenPosition -
                startPointer;

            float rotationInput =
                delta.x - delta.y;

            float angle =
                rotationInput *
                rotationDegreesPerPixel;

            if (rotationSnap > 0f)
            {
                angle =
                    Mathf.Round(
                        angle / rotationSnap) *
                    rotationSnap;
            }

            Vector3 axis =
                rotationAxis.sqrMagnitude > 0.000001f
                    ? rotationAxis.normalized
                    : Vector3.up;

            transform.rotation =
                startRotation *
                Quaternion.AngleAxis(
                    angle,
                    axis);

            return SparkResult.Success();
        }

        public SparkResult EndRotate(
            in SparkInteractionContext context)
        {
            return SparkResult.Success(
                "Rotation completed.");
        }

        public SparkResult CancelRotate(
            in SparkInteractionContext context)
        {
            transform.rotation =
                startRotation;

            return SparkResult.Cancelled(
                "Rotation cancelled.");
        }

        // --------------------------------------------------------
        // POINTER → WORLD
        // --------------------------------------------------------

        private bool TryProjectPointer(
            Vector2 screenPosition,
            out Vector3 worldPosition)
        {
            Ray ray =
                activeCamera.ScreenPointToRay(
                    screenPosition);

            if (movementPlane.Raycast(
                    ray,
                    out float distance))
            {
                if (distance >= 0f)
                {
                    worldPosition =
                        ray.GetPoint(distance);

                    return true;
                }
            }

            worldPosition = default;
            return false;
        }
    }
}