# Project Spark Level 109 layout upgrade. Preserves existing generator and earlier levels.
# Usage: powershell -ExecutionPolicy Bypass -File .\Install_Level109_AutoLayout.ps1 -UnityProjectPath 'D:\YourUnityProject'
param([Parameter(Mandatory=$true)][string]$UnityProjectPath)
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath $UnityProjectPath).Path
$assets = Join-Path $project 'Assets'
if (-not (Test-Path (Join-Path $project 'ProjectSettings/ProjectVersion.txt')) -or -not (Test-Path $assets)) {
    throw "UnityProjectPath must be your Unity project root (Assets and ProjectSettings present)."
}
$scriptHits = @(Get-ChildItem -LiteralPath $assets -Recurse -File -Filter 'SparkAutoLevelRuntime.cs' -ErrorAction SilentlyContinue)
if ($scriptHits.Count -ne 1) {
    throw "Expected exactly one installed Universal Generator V2 runtime SparkAutoLevelRuntime.cs; found $($scriptHits.Count). Install generator V2 first or remove duplicate copies."
}
$generator = Split-Path -Parent (Split-Path -Parent $scriptHits[0].FullName)
$editorFolder = Join-Path $generator 'Editor'
$runtimeFolder = Join-Path $generator 'Runtime'
New-Item -ItemType Directory -Force -Path $editorFolder,$runtimeFolder | Out-Null
function Copy-Upgrade($source, $destination) {
    if (Test-Path -LiteralPath $destination) {
        Copy-Item -LiteralPath $destination -Destination ($destination + '.before_l109_upgrade.bak') -Force
    }
    Copy-Item -LiteralPath $source -Destination $destination -Force
    Write-Host "Installed: $destination"
}
Copy-Upgrade (Join-Path $PSScriptRoot 'GeneratorUpgrade/Editor/SparkAutoL109FullLayoutBuilder.cs') (Join-Path $editorFolder 'SparkAutoL109FullLayoutBuilder.cs')
Copy-Upgrade (Join-Path $PSScriptRoot 'GeneratorUpgrade/Runtime/SparkAutoL109LayoutRecord.cs') (Join-Path $runtimeFolder 'SparkAutoL109LayoutRecord.cs')
Copy-Upgrade (Join-Path $PSScriptRoot 'GeneratorUpgrade/Runtime/SparkAutoL109WorkshopFit.cs') (Join-Path $runtimeFolder 'SparkAutoL109WorkshopFit.cs')
# Choose the existing Level 109 import location if one exists; do not duplicate imported assets.
$manifests = @(Get-ChildItem -LiteralPath $assets -Recurse -File -Filter 'L109_Models_160.csv' -ErrorAction SilentlyContinue)
if ($manifests.Count -gt 1) { throw "Multiple Level 109 source manifests found. Consolidate them before installing." }
if ($manifests.Count -eq 1) {
    $sourceRoot = Split-Path -Parent (Split-Path -Parent $manifests[0].FullName)
    Write-Host "Using existing L109 asset folder: $sourceRoot"
} else {
    $sourceRoot = Join-Path $assets 'ProjectSpark/Level109'
    Write-Host "Creating L109 asset folder: $sourceRoot"
}
$packageAssets = Join-Path $PSScriptRoot 'SourceAssets/Level109'
$copied = 0; $skipped = 0
Get-ChildItem -LiteralPath $packageAssets -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($packageAssets.Length).TrimStart([char]'\',[char]'/')
    $dest = Join-Path $sourceRoot $relative
    if (Test-Path -LiteralPath $dest) { $script:skipped++; return }
    $parentDir = Split-Path -Parent $dest
    New-Item -ItemType Directory -Force -Path $parentDir | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $dest
    $script:copied++
}
$recipeMatches = @(Get-ChildItem -LiteralPath $assets -Recurse -File -Filter 'Level109_TRX17.recipe.json' -ErrorAction SilentlyContinue)
if ($recipeMatches.Count -gt 1) { throw 'Multiple Level109_TRX17.recipe.json files found. Keep one and retry.' }
if ($recipeMatches.Count -eq 1) {
    $recipePath = $recipeMatches[0].FullName
    Copy-Item -LiteralPath $recipePath -Destination ($recipePath + '.before_l109_upgrade.bak') -Force
} else {
    $recipeFolder = Join-Path $generator 'Recipes'
    New-Item -ItemType Directory -Force -Path $recipeFolder | Out-Null
    $recipePath = Join-Path $recipeFolder 'Level109_TRX17.recipe.json'
}
$recipe = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'GeneratorUpgrade/Recipes/Level109_TRX17.recipe.json') -Raw | ConvertFrom-Json
$sourceRelative = $sourceRoot.Substring($project.Length).TrimStart([char]'\',[char]'/').Replace('\','/')
$recipe.sourceAssetsFolder = $sourceRelative
$recipe | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $recipePath -Encoding UTF8
Write-Host "Installed recipe: $recipePath"
Write-Host "Copied new files: $copied | Kept existing files: $skipped"
Write-Host 'Open Unity and run: Tools > Project Spark > Automatic Level Generator > 109 > 1. Build FULL Level_109_Layout'
Write-Host 'Then select your tabletop and run: ... > 109 > 2. Place Level 109 on SELECTED tabletop'
Write-Host 'Generated layout art and authoring nodes require real Project Spark electrical/gameplay service binding.'
