# Project Spark | AAA Automatic Level System — v1.0 source kit

**Scope:** a working-at-source-level Unity editor generator and runtime campaign presentation foundation, authored for Unity 6.3 URP/uGUI/TMP. Unity and Windows PowerShell were not available for execution during packaging. This is not an independently verified, fully integrated gameplay replacement.

## Start here

1. Back up the Unity project (including .meta files). Close Unity. Extract the complete ZIP outside `Assets`.
2. Run in Windows PowerShell 5.1:

```powershell
powershell -ExecutionPolicy Bypass -File ".\Install_Spark_AAA_Level_System.ps1" -UnityProjectPath "D:\Project_Spark_Master_Project\Project_Spark" -DryRun
powershell -ExecutionPolicy Bypass -File ".\Install_Spark_AAA_Level_System.ps1" -UnityProjectPath "D:\Project_Spark_Master_Project\Project_Spark"
```

`-ReplaceExisting` is required for differing installed source files. Installer checks source hashes, backs up differing files outside Assets, preserves .meta files, and attempts rollback on copy failure. It never copies into earlier level directories. Do not run it against a symbolic-link/reparse-point redirected installation folder.

3. Open Unity, compile. Import TMP Essential Resources if needed (`Window > TextMeshPro > Import TMP Essential Resources`). uGUI and TMP must be present. The preview scene adds the New Input System UI module when its type is available; otherwise legacy StandaloneInputModule. Verify the project's Active Input Handling and the UI action asset in Play Mode.
4. `Tools > Project Spark > AAA Level Architect > Open Master Architect`.
5. Audit & Refresh Campaign, then Build Complete AAA Presentation. Confirm regeneration. Close the generated preview scene before rebuilding. Generated files are owned by the generator; put custom variants outside the Generated directory.
6. Validate Generated Assets; open generated preview scene; enter Play Mode. Verify search/filter/page/theme/selection. Gameplay start remains intentionally disabled without an approved bridge.
7. Enable automatic catalog refresh for future `.asset` imports if desired. This refreshes catalog only, not prefabs, at edit time. Use `Level_131.asset` or corresponding `Level_131` asset name for future discovery. Existing 1–130 slots are kept even if absent; future gaps are not invented.

## Source-derived audit

123 source definitions, 690 raw targets, seven missing slots (89, 90, 91, 92, 93, 96, 113). Level 32 is Optical Quality Sorter. Level 95 has legacy ID `level_102` and is blocked pending identity review. Levels 4–6 differ in required vs configured counts, Level 3 repeats a target ID. Raw enum values and counts are never reinterpreted. The editor scans your **actual project**; counts can differ from the supplied archive. SourceArchiveAudit.json / Validate_SourceArchive.py are offline source audit artifacts, not imported into Unity.

## Generated files

`Assets/ProjectSpark/AAAArchitecture/Generated/`

- `SparkCampaignCatalog.asset`: source references with canonical presentation keys, GUIDs, raw metadata, targets, chapter classifications, diagnostics.
- `Prefabs/SparkLevelButton.prefab`: reusable uGUI/TMP card, selection/status, progress, thumbnail, hover transition.
- `Prefabs/SparkLevelSelectionPanel.prefab`: adaptive three-column/compact detail UI, campaign statistics, search, filters, chapter navigation, 24-card pool, six theme choices, briefing and launch affordance.
- `Scenes/SparkMissionControl.unity`: standalone menu preview with Canvas and EventSystem (not added to Build Settings).
- `CampaignAudit.txt`: source mapping warnings, duplicate/missing source report.
- `Thumbnails/PS-L001.png` etc.: optional approved artwork. Import as single Sprite. Master Architect can capture a Unity asset preview from an explicitly assigned hardware prefab. No claim of actual 3D level renders where source prefab references are missing.

No scenes, legacy level assets, player save data, original prefabs or Build Settings are modified by default. Generated files are rewritten by explicit build/refresh; keep backups or version control. Generator uses the installed TMP default font, not a supplied custom font. Layout uses pixel-space uGUI geometry; AAA visual polish, custom shaders, real previews and visual QA remain release tasks.

## Connecting to existing gameplay (mandatory release gate)

Read `Assets/ProjectSpark/AAAArchitecture/Documentation/INTEGRATION_AND_TESTS.md`.

The generator discovers original `ProjectSpark.Gameplay.SparkLevelDefinition` via AssetDatabase; it does not compile against guessed fields or redefine the class. `SparkAAAMissionGateway` is a contract for your existing selector and progression provider. `SparkAAAEventGateway` accepts main-thread authoritative progress snapshots and one Inspector-wired dynamic `ScriptableObject` launch callback. The callback must resolve to the real existing selector/manager and re-check access. Approval alone does not unlock a mission. Successful request means request sent, not scene ready. Call ReleaseLaunchGate on failure/return. No new electrical solver, objective completion mechanism, XP or save ledger is fabricated.

The package does **not** supply the actual pre-existing C# scripts, scene bindings, solver implementation, progression persistence, Spark AI or domain controllers. Their integration must be implemented/tested against the local repository before gameplay release. The source kit makes selection/briefing creation automatic; it does not automatically author scientifically valid new levels from a file name.
