"""Level 50: Zero Defect Factory / precision production line AAA-inspired visual asset kit.
Exports actual triangulated FBX 7.4 binary and GLB geometry via spark_model_core.
Mesh assets only; live electrical wiring and gameplay objective logic belong to Unity.
"""
from __future__ import annotations
import csv, math, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb
ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models'
PALETTE.update({
 'ice':(220,244,250,255), 'nickel':(147,173,190,255), 'aluminum':(170,196,208,255),
 'polished':(213,226,233,255), 'coal':(10,20,31,255), 'carbon':(19,34,49,255),
 'darksteel':(34,52,69,255), 'aqua':(45,222,244,255), 'mint':(53,248,184,255),
 'neonblue':(44,137,248,255),'scarlet':(247,65,83,255),'safety':(253,178,54,255),
 'amberlit':(255,193,78,255),'whitewarm':(230,226,208,255), 'ink':(25,97,117,255),
 'glassblue':(105,198,230,72), 'glassedge':(102,222,237,255),
 'screenback':(11,40,53,255), 'rubberblue':(28,46,56,255),'bronze':(181,113,54,255),
 'webwhite':(230,239,234,255), 'tealshade':(26,118,131,255),
 'goodbin':(20,110,81,255),'badbin':(133,44,53,255),
 'beam':(60,235,245,95), 'clearfilm':(206,237,244,100), 'vividblue':(37,151,240,255)
})

def txt(m,name,label,x,y,z,size=.17,mat='ice',width=None,group='Static'):
 m.text(name,label,size,x,y,z,mat,maxwidth=width,group=group)

def bolt(m,k,x,y,z,r=.067):
 m.cyl(k+'_Head',r,.025,(x,y,z),'chrome','y',14)
 m.box(k+'_ToolSlot',(.075,.008,.015),(x,y+.018,z),'carbon')

def lamp(m,k,x,y,z,mat='mint',group=None):
 group=group or k+'_STATUS_LAMP'
 m.cyl(k+'_Bezel',.132,.045,(x,y,z),'polished','z',28,group=group)
 m.cyl(k+'_Lens',.094,.051,(x,y,z-.05),mat,'z',24,group=group)
 m.torus(k+'_LitHalo',.13,.015,(x,y,z-.065),mat,'z',32,7,group=group)
 m.group_pivots[group]=(x,y,z)

def jack(m,k,sid,label,x,y,z,mat='aqua'):
 g='SOCKET_'+sid
 m.cyl(k+'_'+sid+'_SocketRim',.16,.059,(x,y,z),'chrome','z',30,group=g)
 m.cyl(k+'_'+sid+'_SocketRing',.127,.061,(x,y,z-.032),mat,'z',30,group=g)
 m.cyl(k+'_'+sid+'_SocketBore',.088,.070,(x,y,z-.081),'void','z',28,group=g)
 m.cyl(k+'_'+sid+'_GoldPlugContact',.028,.031,(x,y,z-.140),'gold','z',12,group=g)
 m.torus(k+'_'+sid+'_Accent',.156,.013,(x,y,z-.09),mat,'z',30,6,group=g)
 txt(m,k+'_'+sid+'_Legend',label,x,y+.217,z-.152,.105,'ice',1.22)
 if sid in m.anchors:raise RuntimeError('duplicate anchor '+sid)
 m.anchors[sid]=(round(x,5),round(y,5),round(z-.169,5))

def panel(m,t,title,w=5.0,d=2.7,h=1.8,sub='',accent='aqua'):
 m.base(t,w,d,h)
 front=-d/2-.093
 m.box(t+'_MilledHeaderPlate',(w-.32,.32,.04),(0,.32+h*.80,front-.025),'coal')
 txt(m,t+'_Title',title,0,.32+h*.80,front-.063,.21,'ice',w-.45)
 if sub:txt(m,t+'_Subtitle',sub,0,.32+h*.63,front-.06,.12,accent,w-.42)
 m.box(t+'_Lightbar',(w-.50,.045,.045),(0,.32+h+.089,-d/2+.18),accent)
 for x in (-w/2+.24,w/2-.24):
  for z in (-d/2+.26,d/2-.26):bolt(m,t+f'_LidBolt_{x:.2f}_{z:.2f}',x,.32+h+.10,z,.048)
 return front

def rail(m,t,length=8.4,z=0,y=.84):
 for dz in (-.75,.75):
  m.box(t+f'_LinearRail_{dz}',(length,.20,.24),(0,y,dz+z),'chrome')
  m.box(t+f'_RailSupport_{dz}',(length+.15,.15,.36),(0,y-.15,dz+z),'darksteel')
  for x in np.linspace(-length*.44,length*.44,7):bolt(m,t+f'_RailBolt_{x:.1f}_{dz:.1f}',float(x),y+.12,dz+z,.037)

def machine_plinth(m,t,w=5.7,d=5.7,accent='aqua'):
 m.bevel(t+'_VibrationMount',(w+.25,.18,d+.23),(0,.13,0),'rubber',.10)
 m.bevel(t+'_BaseMetal',(w,.36,d),(0,.38,0),'darksteel',.11)
 m.bevel(t+'_TopChromeTrim',(w-.17,.082,d-.20),(0,.605,0),'nickel',.07)
 m.box(t+'_AccentFace',(w-.40,.05,.065),(0,.62,-d/2-.07),accent)
 for x in (-w/2+.28,w/2-.28):
  for z in (-d/2+.28,d/2-.28):bolt(m,t+f'_MachineFoot_{x:.2f}_{z:.2f}',x,.66,z,.055)

def make_frame():
 m=Model('00_L50_IndustrialFrame');t='L50_CHASSIS'
 m.bevel(t+'_ElastomerIsolator',(50.0,.18,26.7),(0,.11,0),'rubber',.20)
 m.bevel(t+'_SteelFoundation',(49.6,.48,26.4),(0,.40,0),'graphite',.24)
 m.box(t+'_GroundPlaneInset',(47.0,.07,21.0),(0,.68,.35),'darksteel')
 for x in (-24.1,24.1):
  m.box(t+f'_MachinedSideProfile_{x:+.1f}',(.30,.44,25.0),(x,.85,0),'nickel')
  m.box(t+f'_BlueFiberEdge_{x:+.1f}',(.058,.038,24.5),(x,1.09,0),'aqua')
  for z in np.linspace(-12,12,13):bolt(m,t+f'_Lug_{x:.1f}_{z:.2f}',x,1.09,float(z),.05)
 for z in (-12.1,12.1):
  m.box(t+f'_CrossBrace_{z}',(47.8,.25,.31),(0,.82,z),'nickel')
  m.box(t+f'_SignalStripe_{z}',(46.7,.026,.05),(0,.965,z),'mint' if z>0 else 'safety')
 # player-facing breadboard hole grid
 for r,z in enumerate((-11.13,-10.60,-10.07)):
  for i,x in enumerate(np.linspace(-22.7,22.7,77)):
   m.cyl(t+f'_Perforation_{r}_{i:02d}',.035,.013,(float(x),.718,z),'void','y',8)
 for x in (-23.35,23.35):
  for z in (-11.8,11.8):m.bevel(t+f'_MachineRubberFeet_{x:+.1f}_{z:+.1f}',(1.38,.30,1.1),(x,.15,z),'rubber',.10)
 txt(m,t+'_Name','ZERO DEFECT FACTORY  /  LEVEL 50',0,1.04,-12.48,.32,'ice',22)
 for x,col in [(-16,'aqua'),(-8,'mint'),(0,'safety'),(8,'aqua'),(16,'mint')]:
  m.box(t+f'_StationUnderlight_{x}',(5.3,.033,.05),(x,.78,3.50),col)
 return m

def make_web():
 m=Model('01_L50_WebTransport');t='L50_WEB';g='WEB_ADVANCE_X'
 m.bevel(t+'_ConveyorChassis',(45.0,.74,4.90),(0,.99,0),'carbon',.18)
 m.box(t+'_SatinConveyorBed',(44.6,.08,4.10),(0,1.42,0),'nickel')
 m.box(t+'_MovingSubstrateStrip',(44.0,.056,3.17),(0,1.50,0),'webwhite',group=g)
 m.group_pivots[g]=(0,1.50,0)
 for i,x in enumerate(np.linspace(-20.4,20.4,26)):
  m.box(t+f'_OpticalRegMark_{i:02d}',(.11,.020,1.42),(float(x),1.544,-.45),'ink',group=g)
  if i%2==0:
   xx=float(x+.55)
   m.box(t+f'_PrintedProductLabel_{i:02d}',(.70,.022,.94),(xx,1.557,.43),'white',group=g)
   m.box(t+f'_ColorPatch_{i:02d}',(.62,.023,.13),(xx,1.575,.10),'aqua' if i%4 else 'safety',group=g)
 for k,x in enumerate(np.linspace(-21.7,21.7,23)):
  m.cyl(t+f'_Idler_{k:02d}',.194,4.10,(float(x),1.10,0),'rubberblue','z',26,group='UNDERBED_ROLLER_ROTATION')
 for z in (-2.32,2.32):
  m.box(t+f'_StainlessSideGuard_{z}',(44.3,.24,.16),(0,1.57,z),'chrome')
  m.box(t+f'_SideGlow_{z}',(43.7,.036,.033),(0,1.35,z),'aqua')
  for x in (-21,-10.5,0,10.5,21):m.box(t+f'_SidePost_{x}_{z}',(.21,.64,.22),(x,1.0,z),'steel')
 for x in (-22.2,22.2):
  m.cyl(t+f'_EntryEndRoller_{x}',.60,4.6,(x,1.25,0),'rubberblue','z',42,group='WEB_END_ROLLER_ROTATION')
  m.cyl(t+f'_EntryShaft_{x}',.13,5.3,(x,1.25,0),'chrome','z',24,group='WEB_END_ROLLER_ROTATION')
 return m

def make_encoder():
 m=Model('02_L50_MeasuringEncoder');t='L50_ENCODER';g='ENCODER_DISC_ROTATE_Z'
 machine_plinth(m,t,2.8,3.0,'mint')
 m.cyl(t+'_ContactRoller',.54,3.1,(0,1.54,0),'rubberblue','z',52,group='MEASURE_ROLLER_ROTATE_Z')
 for dz in np.linspace(-1.35,1.35,9):m.torus(t+f'_GripLine_{dz:.2f}',.542,.014,(0,1.54,float(dz)),'steel','z',48,6,group='MEASURE_ROLLER_ROTATE_Z')
 m.cyl(t+'_StainlessShaft',.14,3.8,(0,1.54,0),'chrome','z',24,group='MEASURE_ROLLER_ROTATE_Z')
 for z in (-1.72,1.72):
  m.cyl(t+f'_Bearing_{z}',.65,.25,(0,1.54,z),'polished','z',28)
  m.box(t+f'_Holder_{z}',(1.0,.89,.33),(0,.94,z),'darksteel')
 m.cyl(t+'_80CountEncoderDisc',.85,.08,(0,1.54,-2.05),'coal','z',64,group=g)
 m.torus(t+'_EncoderOuterLED',.77,.035,(0,1.54,-2.1),'mint','z',64,6,group=g)
 for i in range(80):
  theta=2*math.pi*i/80
  m.box(t+f'_EncoderTick_{i:02d}',(.028,.07,.016),(.695*math.sin(theta),1.54+.695*math.cos(theta),-2.115),'ice' if i%5==0 else 'aqua',group=g)
 m.group_pivots[g]=(0,1.54,-2.05)
 m.group_pivots['MEASURE_ROLLER_ROTATE_Z']=(0,1.54,0)
 m.box(t+'_OptoReadSensor',(1.3,.30,.29),(0,2.47,-2.17),'nickel')
 lamp(m,t+'_EncoderPulseIndicator',.46,2.42,-2.38,'mint')
 m.bevel(t+'_SignalDock',(2.9,.85,.78),(0,.60,-2.28),'carbon',.08)
 jack(m,t,'ENC_A','A',-.57,.65,-2.74,'aqua')
 jack(m,t,'ENC_B','B',.57,.65,-2.74,'mint')
 return m

def make_mark_sensor():
 m=Model('03_L50_MarkSensor');t='L50_MARK';face=panel(m,t,'MARK REGISTRATION',4.8,2.8,1.75,'PHOTOELECTRIC  /  CYAN','aqua')
 for x in (-1.18,1.18):m.box(t+f'_Upright_{x}',(.28,2.7,.41),(x,2.55,.32),'nickel')
 m.bevel(t+'_ScannerBridge',(3.06,.37,.67),(0,3.98,.32),'polished',.08)
 m.cyl(t+'_OpticalLensOuter',.48,.22,(0,3.73,.32),'chrome','y',32)
 m.cyl(t+'_CyanLens',.28,.09,(0,3.56,.32),'aqua','y',32)
 m.torus(t+'_LightCircle',.315,.032,(0,3.52,.32),'mint','y',40,7)
 m.cyl(t+'_ScanRay',.022,1.40,(0,2.82,.32),'beam','y',12,group='SCANNER_BEAM_ENABLE')
 m.group_pivots['SCANNER_BEAM_ENABLE']=(0,3.55,.32)
 m.box(t+'_DetectionBlackFace',(2.6,.40,.024),(0,1.60,face-.09),'screenback')
 txt(m,t+'_ReadyStatus','MARK FOUND',0,1.60,face-.123,.155,'mint',2.3)
 lamp(m,t+'_DetectionLamp',1.80,1.60,face-.07,'mint')
 for sid,caption,x,col in [('MARK_PLUS','+5V',-1.38,'red'),('MARK_GND','GND',0,'void'),('MARK_OUT','OUT',1.38,'mint')]:jack(m,t,sid,caption,x,.73,face,col)
 return m

def make_print():
 m=Model('04_L50_PrintStation');t='L50_PRINT';machine_plinth(m,t,5.6,5.6,'mint')
 for x in (-2.3,2.3):
  m.box(t+f'_PrintColumn_{x}',(.35,3.75,.48),(x,2.54,.15),'nickel')
  m.box(t+f'_CornerGuard_{x}',(.08,3.3,.12),(x,2.7,-.17),'mint')
 m.bevel(t+'_PrecisionPrintBridge',(5.2,.49,1.05),(0,4.53,.19),'polished',.11)
 m.box(t+'_TopMotorEnclosure',(1.65,1.12,1.35),(0,5.26,.18),'darksteel')
 for x in np.linspace(-.56,.56,7):m.box(t+f'_MotorCoolingSlot_{x:.2f}',(.06,.03,.96),(float(x),5.835,.17),'coal')
 m.cyl(t+'_DriveShaft',.24,1.03,(0,4.08,.13),'chrome','y',24,group='PRINT_HEAD_STROKE_Y')
 m.bevel(t+'_InkCartridge',(2.0,.78,.82),(0,3.55,.10),'carbon',.10,group='PRINT_HEAD_STROKE_Y')
 m.bevel(t+'_InkCartridgeColorBand',(1.80,.12,.86),(0,3.39,.12),'safety',.025,group='PRINT_HEAD_STROKE_Y')
 m.box(t+'_StampPlate',(1.54,.15,1.24),(0,2.98,.10),'bronze',group='PRINT_HEAD_STROKE_Y')
 m.group_pivots['PRINT_HEAD_STROKE_Y']=(0,3.8,.1)
 m.bevel(t+'_PrintingAnvil',(3.4,.19,2.0),(0,1.55,.15),'chrome',.06)
 for x in (-1.9,1.9):
  m.rod(t+f'_PrintPiston_{x}',(x,3.4,.11),(x,4.24,.11),.105,'chrome')
 m.box(t+'_LabelNamePlate',(3.8,.32,.042),(0,1.06,-2.85),'coal')
 txt(m,t+'_Label','SMART PRINT HEAD',0,1.07,-2.89,.18,'ice',3.5)
 m.bevel(t+'_ControlDock',(2.35,.78,.63),(0,.57,-3.29),'carbon',.06)
 jack(m,t,'PRINT_HEAD_TRIG','TRIG',0,.69,-3.69,'mint')
 lamp(m,t+'_PrintReadyLamp',1.8,1.1,-2.88,'mint')
 return m

def make_cutter():
 m=Model('05_L50_FlyingCutter');t='L50_SHEAR';machine_plinth(m,t,6.1,5.2,'safety')
 rail(m,t,5.3,z=0,y=.99)
 g='CUTTER_CARRIAGE_SLIDE_X'
 m.bevel(t+'_FloatingCutterCarriage',(2.75,.42,2.92),(0,1.48,0),'nickel',.12,group=g)
 m.bevel(t+'_CarriageArmoredHead',(2.14,.86,1.34),(0,2.13,0),'darksteel',.09,group=g)
 for x in (-.87,.87):
  m.cyl(t+f'_CarriagePiston_{x}',.12,1.26,(x,3.0,0),'chrome','y',20,group=g)
 m.bevel(t+'_UpperActuator',(2.62,.69,1.85),(0,3.66,0),'polished',.12,group=g)
 m.bevel(t+'_ShearBladeCarrier',(1.86,.35,.61),(0,2.54,0),'safety',.04,group='CUTTER_BLADE_STROKE_Y')
 m.box(t+'_TrainingBladeEdge',(1.67,.18,.052),(0,2.27,-.24),'chrome',group='CUTTER_BLADE_STROKE_Y')
 m.group_pivots['CUTTER_BLADE_STROKE_Y']=(0,2.52,0)
 m.group_pivots[g]=(0,1.48,0)
 m.cyl(t+'_BallScrew',.12,5.55,(0,1.15,.03),'chrome','x',24,group='CUTTER_LEAD_SCREW_ROTATE_X')
 for k,x in enumerate(np.linspace(-2.5,2.5,29)):
  m.torus(t+f'_LeadThread_{k:02d}',.127,.015,(float(x),1.15,.03),'steel','x',20,5,group='CUTTER_LEAD_SCREW_ROTATE_X')
 m.group_pivots['CUTTER_LEAD_SCREW_ROTATE_X']=(0,1.15,.03)
 # visible safe guard frame, front transparent enough to see cutter
 for x in (-2.78,2.78):
  m.box(t+f'_ProtectionPillar_{x}',(.14,3.20,.16),(x,2.35,-2.48),'chrome')
 for y in (.90,3.88):m.box(t+f'_GuardTopBottom_{y}',(5.56,.15,.14),(0,y,-2.48),'polished')
 m.box(t+'_TransparentShield',(5.25,2.74,.06),(0,2.36,-2.43),'glassblue')
 m.box(t+'_MachineName',(4.3,.34,.05),(0,.97,-2.75),'coal')
 txt(m,t+'_Label','SYNCHRONIZED CUT',0,.97,-2.79,.165,'ice',4)
 m.bevel(t+'_CutterTriggerDock',(2.16,.77,.66),(0,.56,-3.12),'carbon',.08)
 jack(m,t,'CUT_HEAD_TRIG','CUT TRIG',0,.67,-3.51,'safety')
 lamp(m,t+'_SafeLight',2.18,1.23,-2.65,'mint')
 return m

def make_vision():
 m=Model('06_L50_VisionInspection');t='L50_VISION';machine_plinth(m,t,5.75,5.35,'aqua')
 for x in (-2.36,2.36):
  m.box(t+f'_CNC_Upright_{x}',(.33,3.52,.43),(x,2.43,.30),'nickel')
  m.box(t+f'_LEDStripe_{x}',(.050,2.46,.050),(x,2.35,-.07),'aqua')
 m.bevel(t+'_VisionBridge',(5.35,.51,1.11),(0,4.36,.34),'chrome',.10)
 m.cyl(t+'_CameraBody',.51,.77,(0,3.89,.34),'carbon','y',36)
 m.cyl(t+'_OuterFocusRing',.45,.14,(0,3.37,.34),'chrome','y',42)
 m.cyl(t+'_OpticalGlass',.28,.06,(0,3.24,.34),'neonblue','y',36)
 m.torus(t+'_RingLight',.55,.073,(0,3.23,.34),'ice','y',50,10,group='VISION_RINGLIGHT')
 m.group_pivots['VISION_RINGLIGHT']=(0,3.23,.34)
 for k in range(12):
  ang=2*math.pi*k/12
  m.cyl(t+f'_InspectionLED_{k:02d}',.069,.02,(.53*math.cos(ang),3.18,.34+.53*math.sin(ang)),'aqua','y',12,group='VISION_RINGLIGHT')
 m.box(t+'_InspectionWindow',(3.80,.045,2.85),(0,1.56,.1),'glassblue')
 for x in (-1.85,1.85):m.box(t+f'_SideSafetyPanel_{x}',(.058,2.38,3.55),(x,2.55,.10),'glassblue')
 m.box(t+'_CameraLabel',(3.80,.31,.046),(0,1.08,-2.78),'coal')
 txt(m,t+'_InspectionText','AI QUALITY INSPECTION',0,1.08,-2.83,.173,'ice',3.52)
 m.bevel(t+'_VisionPortDock',(5.20,.84,.73),(0,.57,-3.13),'carbon',.07)
 for (sid,cap,col),x in zip([('VISION_PLUS','+5V','red'),('VISION_GND','GND','void'),('VISION_PASS','PASS','mint'),('VISION_FAIL','FAIL','scarlet')],[-1.76,-.60,.60,1.76]):
  jack(m,t,sid,cap,x,.71,-3.57,col)
 lamp(m,t+'_PassLamp',-1.40,1.19,-2.79,'mint')
 lamp(m,t+'_FailLamp',1.40,1.19,-2.79,'scarlet')
 return m

def make_diverter():
 m=Model('07_L50_SortDiverter');t='L50_SORT_GATE';machine_plinth(m,t,5.4,5.6,'safety')
 m.cyl(t+'_PivotAxle',.28,1.08,(0,1.50,.0),'chrome','y',32)
 g='SORTING_ARM_PIVOT_Y'
 m.bevel(t+'_SortingFork',(3.12,.21,.54),(1.3,1.65,0),'nickel',.08,group=g)
 m.box(t+'_AmberTip',(.41,.26,.64),(2.67,1.67,0),'safety',group=g)
 m.cyl(t+'_ArmHub',.65,.28,(0,1.68,0),'darksteel','y',34,group=g)
 m.torus(t+'_ArmIlluminatedGimbal',.58,.045,(0,1.86,0),'aqua','y',48,8,group=g)
 m.group_pivots[g]=(0,1.65,0)
 for z,col in ((-1.65,'mint'),(1.65,'scarlet')):
  m.box(t+f'_SortRamp_{z}',(4.4,.12,.86),(0,1.06,z),'nickel')
  m.box(t+f'_SortLight_{z}',(3.9,.029,.06),(0,1.16,z),col)
 for x in (-2.25,2.25):m.box(t+f'_SupportShield_{x}',(.09,1.12,4.3),(x,1.33,0),'glassblue')
 m.box(t+'_SortingSign',(4.23,.30,.045),(0,.89,-2.93),'coal')
 txt(m,t+'_GateTitle','PASS / REJECT DIVERT',0,.89,-2.99,.156,'ice',4.0)
 m.bevel(t+'_HomeDetector',(1.21,.73,.75),(1.66,.68,-2.88),'darksteel',.07)
 jack(m,t,'DIVERTER_HOME_OUT','HOME',1.70,.68,-3.32,'mint')
 lamp(m,t+'_DiverterReady',-1.79,1.22,-3.01,'mint')
 return m

def make_motor():
 m=Model('08_L50_DiverterMotor');t='L50_SORT_MOTOR';machine_plinth(m,t,4.15,4.20,'safety')
 m.cyl(t+'_DCMotorBody',.93,2.57,(0,1.67,.16),'nickel','x',52)
 m.cyl(t+'_Endbell',1.0,.32,(1.42,1.67,.16),'carbon','x',42)
 m.torus(t+'_RearLight',.86,.041,(1.61,1.67,.16),'safety','x',48,8)
 m.cyl(t+'_FrontFlange',1.02,.28,(-1.41,1.67,.16),'chrome','x',42)
 for i in range(17):
  ang=2*math.pi*i/17
  m.rod(t+f'_MotorExtrudedCoolingFin_{i:02d}',(-1.20,1.67+.90*math.cos(ang),.16+.90*math.sin(ang)),(1.2,1.67+.90*math.cos(ang),.16+.90*math.sin(ang)),.031,'steel',10)
 g='SORT_MOTOR_SHAFT_ROTATE_X'
 m.cyl(t+'_Shaft',.18,1.52,(-2.05,1.67,.16),'chrome','x',28,group=g)
 m.cyl(t+'_GearCoupler',.40,.29,(-2.69,1.67,.16),'bronze','x',28,group=g)
 m.group_pivots[g]=(-2.10,1.67,.16)
 m.bevel(t+'_MotorDock',(3.65,.78,.66),(0,.57,-2.32),'carbon',.07)
 jack(m,t,'DIVERTER_MOTOR_PLUS','M+',-.75,.65,-2.72,'red')
 jack(m,t,'DIVERTER_MOTOR_MINUS','M-',.75,.65,-2.72,'void')
 return m

def make_bin(key,color,label,sensorid):
 m=Model(key);t=key.replace('09_','L50_').replace('10_','L50_');g='BIN_ITEM_DROP_Y'
 m.bevel(t+'_BinRubberBase',(5.4,.18,6.3),(0,.11,0),'rubber',.09)
 m.bevel(t+'_BinBottom',(5.23,.24,5.98),(0,.31,0),color,.08)
 # hollow-looking open-top collection tub: four walls with thin chrome edge
 for x in (-2.52,2.52):
  m.box(t+f'_SideWall_{x}',(.15,2.25,5.95),(x,1.54,0),color)
  m.box(t+f'_BrightLip_{x}',(.15,.095,5.95),(x,2.73,0),'chrome')
 for z in (-2.92,2.92):
  m.box(t+f'_EndWall_{z}',(5.00,2.25,.14),(0,1.54,z),color)
  m.box(t+f'_EndLip_{z}',(5.11,.10,.15),(0,2.73,z),'chrome')
 for i in range(5):
  m.bevel(t+f'_DetectedProduct_{i}',(1.36,.095,.79),(-1.38+(i%3)*1.35,.54+.14*(i//3),-.5+(i%2)*1.1),'webwhite',.05,group=g)
  m.box(t+f'_ProductTag_{i}',(.88,.017,.14),(-1.38+(i%3)*1.35,.602+.14*(i//3),-.65+(i%2)*1.1),'ink',group=g)
 m.group_pivots[g]=(0,.65,0)
 m.box(t+'_FrontPlate',(4.5,.43,.06),(0,1.68,-3.02),'coal')
 txt(m,t+'_BinLabel',label,0,1.68,-3.065,.26,'ice',4.2)
 m.bevel(t+'_CountSensorDock',(1.62,.69,.72),(0,.59,-3.18),'carbon',.05)
 jack(m,t,sensorid,'COUNT OUT',0,.66,-3.61,'mint' if 'GOOD' in sensorid else 'scarlet')
 lamp(m,t+'_BinStatusIndicator',1.91,2.23,-3.00,'mint' if 'GOOD' in sensorid else 'scarlet')
 return m

def make_goodbin():return make_bin('09_L50_GoodCollectionBin','goodbin','GOOD PRODUCTS','GOOD_COUNT_OUT')
def make_rejectbin():return make_bin('10_L50_RejectCollectionBin','badbin','REJECT PRODUCTS','REJECT_COUNT_OUT')

def make_controller():
 m=Model('11_L50_FactoryController');t='L50_FACTORY_CTRL';w=15.3;h=2.85;d=3.55
 face=panel(m,t,'FACTORY MASTER CONTROLLER',w,d,h,'ENCODER TRACKING / 5 STATION PIPELINE','aqua')
 # large blank TMP screen above connectors
 m.bevel(t+'_UltrawideScreenFrame',(9.9,.84,.065),(0,2.36,face-.080),'polished',.035)
 m.box(t+'_LiveScreenFace',(9.55,.63,.022),(0,2.36,face-.118),'screenback',group='FACTORY_RUNTIME_DISPLAY_FACE')
 m.group_pivots['FACTORY_RUNTIME_DISPLAY_FACE']=(0,2.36,face-.13)
 for i in range(11):m.box(t+f'_DisplayGuideLine_{i}',(.011,.58,.014),(-4.43+i*.89,2.36,face-.142),'tealshade')
 # main controls stand apart from the blank central display
 for name,x,col in [('AUTO',-6.48,'mint'),('STOP',-5.47,'scarlet'),('RESET',5.47,'safety'),('START',6.48,'mint')]:
  g='BUTTON_'+name+'_PRESS_Z'
  m.cyl(t+'_'+name+'_MetalSwitchRing',.21,.06,(x,2.40,face-.046),'chrome','z',26,group=g)
  m.cyl(t+'_'+name+'_SwitchCap',.16,.06,(x,2.40,face-.113),col,'z',26,group=g)
  txt(m,t+'_'+name+'_Caption',name,x,2.79,face-.112,.127,'ice',.79)
  m.group_pivots[g]=(x,2.4,face-.12)
 ids=[
  ('CTRL_PLUS','+5V','red'),('CTRL_GND','GND','void'),('CTRL_MARK_IN','MARK','aqua'),
  ('CTRL_ENC_A','ENC A','aqua'),('CTRL_ENC_B','ENC B','mint'),('CTRL_PRINT_TRIG','PRINT','mint'),
  ('CTRL_CUT_TRIG','CUT','safety'),('CTRL_PASS_IN','PASS','mint'),('CTRL_FAIL_IN','FAIL','scarlet'),
  ('CTRL_SORT_CMD','SORT','safety'),('CTRL_DIVERTER_HOME','HOME','aqua'),
  ('CTRL_GOOD_COUNT','GOOD','mint'),('CTRL_REJECT_COUNT','REJECT','scarlet'),
  ('CTRL_SAFETY_IN','SAFE','safety')]
 for idx,(sid,cap,col) in enumerate(ids):
  row=idx//7;colid=idx%7;x=-5.91+colid*1.97;y=.68+row*.73
  jack(m,t,sid,cap,x,y,face,col)
 for idx,(name,col) in enumerate([('POWER','mint'),('READY','mint'),('SYNC','aqua'),('WARN','safety'),('FAULT','scarlet')]):
  lamp(m,t+f'_{name}',-3.0+idx*1.5,3.03,face-.08,col)
 return m

def make_driver():
 m=Model('12_L50_SortDriver');t='L50_SORT_DRIVER';face=panel(m,t,'SERVO SORT DRIVER',7.25,3.0,1.95,'DUAL POLARITY / AUTO DIVERT','safety')
 for i in range(15):m.box(t+f'_HeatsinkFin_{i}',(.09,.32,1.37),(-2.73+i*.39,2.53,.20),'nickel')
 m.bevel(t+'_DriverLabelDisplay',(3.72,.33,.032),(0,1.58,face-.083),'screenback',.03)
 txt(m,t+'_ReadyText','SORT DRIVER READY',0,1.58,face-.12,.12,'mint',3.5)
 ports=[('DRIVER_PLUS','+5V','red'),('DRIVER_GND','GND','void'),('DRIVER_SORT_CMD','CMD','safety'),('DRIVER_MOTOR_PLUS','M+','red'),('DRIVER_MOTOR_MINUS','M-','void')]
 for (sid,cap,col),x in zip(ports,np.linspace(-2.80,2.80,5)):jack(m,t,sid,cap,float(x),.69,face,col)
 lamp(m,t+'_Status',2.84,1.80,face-.085,'mint')
 return m

def make_dashboard():
 m=Model('13_L50_QualityDashboard');t='L50_QUALITY';face=panel(m,t,'LIVE PRODUCTION ANALYTICS',11.9,3.3,2.67,'PRODUCT TRACKING / CUT QUALITY / ACCEPTANCE','mint')
 m.bevel(t+'_WideScreenAluminumBezel',(11.3,1.67,.076),(0,2.06,face-.075),'polished',.055)
 m.box(t+'_BlankTMRPScreen',(10.92,1.40,.025),(0,2.06,face-.13),'screenback',group='DASHBOARD_RUNTIME_TMP_FACE')
 m.group_pivots['DASHBOARD_RUNTIME_TMP_FACE']=(0,2.06,face-.15)
 # physical bezel column dividers; screen itself remains blank
 for x in (-1.65,2.02):m.box(t+f'_LightColumnDivider_{x}',(.022,1.18,.016),(x,2.06,face-.16),'tealshade')
 for k in range(10):
  g=f'QUALITY_HISTORY_BAR_{k:02d}'
  m.box(t+f'_QualityHistory_{k:02d}',(.65,.11,.03),(-4.52+k, .80,face-.145),'mint' if k<7 else 'safety',group=g)
  m.group_pivots[g]=(-4.52+k,.80,face-.15)
 lamp(m,t+'_GoodIndicator',-4.9,2.96,face-.08,'mint')
 lamp(m,t+'_BadIndicator',4.9,2.96,face-.08,'scarlet')
 return m

def make_safety():
 m=Model('14_L50_SafetyInterlock');t='L50_SAFETY';face=panel(m,t,'SAFETY INTERLOCK',5.0,2.9,1.93,'NORMALLY CLOSED / E-STOP','scarlet')
 m.cyl(t+'_BigMushroomChromeStem',.55,.16,(0,1.78,face-.09),'chrome','z',30,group='ESTOP_BUTTON_PRESS_Z')
 m.cyl(t+'_BigRedMushroom',.43,.21,(0,1.78,face-.23),'scarlet','z',38,group='ESTOP_BUTTON_PRESS_Z')
 m.torus(t+'_MushroomYellowRing',.55,.042,(0,1.78,face-.18),'safety','z',42,8,group='ESTOP_BUTTON_PRESS_Z')
 m.group_pivots['ESTOP_BUTTON_PRESS_Z']=(0,1.78,face-.24)
 txt(m,t+'_StopLegend','EMERGENCY STOP',0,2.28,face-.10,.135,'ice',3.3)
 jack(m,t,'SAFETY_NC_OUT','NC OUT',0,.69,face,'scarlet')
 lamp(m,t+'_SafeGreen',-1.62,1.68,face-.08,'mint')
 lamp(m,t+'_UnsafeRed',1.62,1.68,face-.08,'scarlet')
 return m

def make_supply():
 m=Model('15_L50_5VSupply');t='L50_SUPPLY';face=panel(m,t,'5V REGULATED SUPPLY',5.12,2.90,1.88,'LOW VOLTAGE CONTROL POWER','aqua')
 m.box(t+'_PowerDisplay',(2.85,.49,.024),(0,1.52,face-.083),'screenback')
 txt(m,t+'_Nominal','5.00 V',0,1.52,face-.122,.26,'mint',2.55)
 lamp(m,t+'_PowerLED',1.91,1.48,face-.08,'mint')
 jack(m,t,'SUPPLY_PLUS','+5V',-1.01,.73,face,'red')
 jack(m,t,'SUPPLY_RETURN','RETURN',1.01,.73,face,'void')
 for i in range(11):m.box(t+f'_RoofCoolingVent_{i:02d}',(.090,.022,1.19),(-1.82+i*.36,2.65,.32),'coal')
 return m

BUILDERS=[make_frame,make_web,make_encoder,make_mark_sensor,make_print,make_cutter,
          make_vision,make_diverter,make_motor,make_goodbin,make_rejectbin,
          make_controller,make_driver,make_dashboard,make_safety,make_supply]

POS={
 '00_L50_IndustrialFrame':(0,0,0),
 '01_L50_WebTransport':(0,0,0),
 '02_L50_MeasuringEncoder':(-18.9,0,0.0),
 '03_L50_MarkSensor':(-16.0,0,0.5),
 '04_L50_PrintStation':(-8.0,0,.05),
 '05_L50_FlyingCutter':(0,0,.05),
 '06_L50_VisionInspection':(8.0,0,.05),
 '07_L50_SortDiverter':(16.5,0,.05),
 '08_L50_DiverterMotor':(21.1,0,5.65),
 '09_L50_GoodCollectionBin':(20.15,0,-4.90),
 '10_L50_RejectCollectionBin':(20.15,0,5.35),
 '11_L50_FactoryController':(-10.6,0,-8.20),
 '12_L50_SortDriver':(1.4,0,-8.25),
 '13_L50_QualityDashboard':(0,0,8.9),
 '14_L50_SafetyInterlock':(17.60,0,-8.30),
 '15_L50_5VSupply':(-20.0,0,-8.20),
}
# Camera-facing layout: x-reversed so MARK / PRINT / CUT / VISION / SORT read left-to-right from -Z.
POS = {k:(-v[0],v[1],v[2]) for k,v in POS.items()}

WIRES=[
 ('W01','SUPPLY_PLUS','CTRL_PLUS','Supply +5 V -> Factory Controller +5 V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply RETURN -> Factory Controller GND'),
 ('W03','SUPPLY_PLUS','MARK_PLUS','Supply +5 V -> Mark Sensor +5 V'),
 ('W04','SUPPLY_RETURN','MARK_GND','Supply RETURN -> Mark Sensor GND'),
 ('W05','SUPPLY_PLUS','VISION_PLUS','Supply +5 V -> Vision Sensor +5 V'),
 ('W06','SUPPLY_RETURN','VISION_GND','Supply RETURN -> Vision Sensor GND'),
 ('W07','SUPPLY_PLUS','DRIVER_PLUS','Supply +5 V -> Sort Driver +5 V'),
 ('W08','SUPPLY_RETURN','DRIVER_GND','Supply RETURN -> Sort Driver GND'),
 ('W09','MARK_OUT','CTRL_MARK_IN','Mark Sensor OUT -> Controller MARK IN'),
 ('W10','ENC_A','CTRL_ENC_A','Encoder A -> Controller ENC A'),
 ('W11','ENC_B','CTRL_ENC_B','Encoder B -> Controller ENC B'),
 ('W12','CTRL_PRINT_TRIG','PRINT_HEAD_TRIG','Controller PRINT TRIG -> Print Head TRIG'),
 ('W13','CTRL_CUT_TRIG','CUT_HEAD_TRIG','Controller CUT TRIG -> Cutter TRIG'),
 ('W14','VISION_PASS','CTRL_PASS_IN','Vision PASS OUT -> Controller PASS IN'),
 ('W15','VISION_FAIL','CTRL_FAIL_IN','Vision FAIL OUT -> Controller FAIL IN'),
 ('W16','CTRL_SORT_CMD','DRIVER_SORT_CMD','Controller SORT CMD -> Sort Driver CMD'),
 ('W17','DRIVER_MOTOR_PLUS','DIVERTER_MOTOR_PLUS','Sort Driver M+ -> Diverter Motor +'),
 ('W18','DRIVER_MOTOR_MINUS','DIVERTER_MOTOR_MINUS','Sort Driver M- -> Diverter Motor -'),
 ('W19','DIVERTER_HOME_OUT','CTRL_DIVERTER_HOME','Diverter HOME OUT -> Controller HOME'),
 ('W20','GOOD_COUNT_OUT','CTRL_GOOD_COUNT','Good Bin Sensor OUT -> Controller GOOD COUNT'),
 ('W21','REJECT_COUNT_OUT','CTRL_REJECT_COUNT','Reject Bin Sensor OUT -> Controller REJECT COUNT'),
 ('W22','SAFETY_NC_OUT','CTRL_SAFETY_IN','Safety NC OUT -> Controller SAFETY IN'),
]

def build():
 models=[]
 for maker in BUILDERS:
  m=maker();models.append(m)
  f=MODELS/(m.key+'.fbx');g=MODELS/(m.key+'.glb')
  export_fbx(f,[m]);export_glb(g,[m]);assert f.read_bytes().startswith(b'Kaydara FBX Binary  \0')
  assert len(trimesh.load_scene(g).geometry)>0
  print('MODEL',m.key,'TRIS',sum(len(p.mesh.faces) for p in m.parts),'PARTS',len(m.parts),'SOCKETS',len(m.anchors),flush=True)
 assert len(models)==16
 sockets=[s for m in models for s in m.anchors]
 assert len(sockets)==len(set(sockets))==38,(len(sockets),sockets)
 endpoint_ids={s for _,a,b,_ in WIRES for s in (a,b)}
 assert len(WIRES)==22 and endpoint_ids==set(sockets),(len(endpoint_ids),set(sockets)^endpoint_ids)
 assert set(POS)=={m.key for m in models}
 show='Level50_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(show+'.fbx'),models,positions=POS)
 export_glb(MODELS/(show+'.glb'),models,positions=POS)
 assert len(trimesh.load_scene(MODELS/(show+'.glb')).geometry)>0
 manifest={m.key:{'fbx':m.key+'.fbx','glb':m.key+'.glb','triangles':sum(len(p.mesh.faces) for p in m.parts),
       'mesh_part_count':len(m.parts),'art_sockets_local_xyz':m.anchors,'animation_groups':m.group_pivots} for m in models}
 total=sum(x['triangles'] for x in manifest.values())
 obj={'level':50,'display_name':'Zero Defect Factory','subtitle':'Smart Manufacturing Master Challenge',
      'type':'VISUAL ASSETS ONLY: NO FUNCTIONAL ELECTRICAL SYSTEM/LEVEL OBJECTIVES IMPLEMENTED',
      'models_count':16,'wires_count':22,'art_sockets_count':38,'triangles':total,
      'assembled_fbx':show+'.fbx','model_entries':manifest,'showcase_placements_xyz':POS,
      'wiring':WIRES,'coordinates':'Y up; front -Z; model units relative art units, not actual breadboard hole positions',
      'signals':'All modeled plugs are visual; attach real SparkTerminal components and validated signal interfaces in Unity',
      'safety':'SAFETY_NC_OUT -> CTRL_SAFETY_IN; actual safety interlock must be implemented in Level 50',
      'screen':'Controller/dashboard are blank for live TMP overlays; visual labels are static mesh lettering'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(obj,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBXModel','ArtSocketID','LocalX','LocalY','LocalZ','Notes'])
  for m in models:
   for name,xyz in m.anchors.items():w.writerow([m.key+'.fbx',name,*xyz,'Art socket only: align actual SparkTerminal to breadboard hole'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBXModel','ArtSocketID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for name,xyz in m.anchors.items():w.writerow([m.key+'.fbx',name,*[round(a+b,5) for a,b in zip(xyz,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBXModel','AnimationGroup','LocalPivotX','LocalPivotY','LocalPivotZ','RuntimeDrive'])
  for m in models:
   for group,xyz in m.group_pivots.items():w.writerow([m.key+'.fbx',group,*xyz,'Visual only: wire to authoritative Level 50 gameplay state'])
 (ROOT/'VALIDATION.txt').write_text(f'LEVEL 50 / ZERO DEFECT FACTORY\n16 individual FBX + 16 individual GLB, assembled FBX + GLB.\n38 unique art sockets / 22 wires, {total:,} triangles total.\nAll wiring endpoints match socket IDs; FBX header and GLB mesh decoding checked.\nUnity materials, rig hierarchy, electrical behavior and Play Mode NOT TESTED.\n')
 print('SUCCESS Level 50',total,'triangles',len(sockets),'sockets',flush=True)
 return models

if __name__=='__main__': build()
