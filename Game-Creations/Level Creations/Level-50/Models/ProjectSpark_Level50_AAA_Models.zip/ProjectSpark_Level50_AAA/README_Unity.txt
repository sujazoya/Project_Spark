PROJECT SPARK — LEVEL 50: ZERO DEFECT FACTORY
AAA-STYLE PROCEDURAL 3D ART / UNITY IMPORT GUIDE
================================================

WHAT THIS IS
This package contains 16 individual Autodesk FBX 7.4 binary art assets,
16 matching GLBs, and one complete FBX/GLB showcase assembly (34 3D files).
Art models are based on the approved Level 50 concept: Mark > Print > Cut >
Vision > Sort. The supply is 5 V. The proposed exercise requires 22 player
wires, 38 unique socket endpoints, and six authoritative objectives.

THIS IS NOT A PLAYABLE LEVEL OR ELECTRICAL SYSTEM.
All sockets are modeled 3D references. You must attach actual SparkTerminal
components to the real breadboard, configure scene bindings and real signal
interfaces, and implement motors, print/cut logic, product IDs, inspection,
sorting, safety and level objective evaluation in your Unity project.

UNITY IMPORT
1. Extract ZIP; copy Models/*.fbx into:
   Assets/My_Assets/_Project_Spark/Models/Level_50/
2. Let Unity import models; keep hierarchy and animation groups intact.
3. Use individually named FBX assets under Level_50_Layout; the complete
   ArtKit_Showcase FBX is a reference, NOT a second copy to instantiate.
4. Read Model_Manifest.json showcase_placements_xyz for positioning. The
   showcase is arranged from -Z-facing camera with material flow LEFT TO RIGHT.
5. Units are ART UNITS (Y up; sockets face -Z). Fit the entire machine
   to your actual bench; adjust real terminal anchors to breadboard holes.
6. Read Terminal_Anchors.csv and World_Terminal_Anchors.csv. These are visual
   reference coordinates, not automatic runtime SparkTerminal IDs.
7. Build 22 player wires according to Exact_Wiring.csv. Shared SUPPLY_PLUS
   and SUPPLY_RETURN terminals each accept four wires. Confirm that the actual
   circuit graph and signal architecture matches, not merely the visual wires.
8. Connect real electrical and safety systems; preinstalled subsystems must
   be valid and powered through the existing architecture. No physical signal
   behavior is supplied by these FBX meshes.
9. Add live TMPro surfaces on named RUNTIME_DISPLAY_FACE and
   DASHBOARD_RUNTIME_TMP_FACE groups for product counts, conveyor movement,
   position, print/cut error, acceptance/rejection and fault/status text.
10. Optionally use Unity_Optional/SparkLevel50VisualRig.cs and assign named
    Transform groups from Animation_Rigs.csv. Feed it real runtime positions.
    It changes only visible meshes and never completes a level objective.
11. For animated models and textured/shader polish, use URP/HDRP materials
    after import; FBX contains per-part material colors and GLB backups.

ASSET HIERARCHY / PLACEMENT
  00 Industrial Frame — wide board chassis
  01 Web Transport — moving registered film/conveyor center
  02 Measuring Encoder — encoder roller before the mark sensor
  03 Mark Sensor — optical registration scanner
  04 Print Station — stamped product labels
  05 Flying Cutter — moving cutting head
  06 Vision Inspection — quality-check head + PASS/FAIL sockets
  07 Sort Diverter — moving pass/reject fork with HOME sensor
  08 Diverter Motor — separate gearmotor and terminals
  09 GOOD Collection Bin — green accept tray + counter sensor
  10 REJECT Collection Bin — red reject tray + counter sensor
  11 Factory Controller — full 14-terminal front panel
  12 Sort Driver — 5-terminal motor driver
  13 Quality Dashboard — large blank production display
  14 Safety Interlock — red E-stop and safety output
  15 5 V Supply — shared power + RETURN terminals

PHYSICAL ANIMATION GROUPS
  WEB_ADVANCE_X — continuous material visual motion
  MEASURE_ROLLER_ROTATE_Z — measuring roller rotation
  ENCODER_DISC_ROTATE_Z — 80-count encoder disc
  PRINT_HEAD_STROKE_Y — printing actuator down/up
  CUTTER_CARRIAGE_SLIDE_X — cutting carriage movement
  CUTTER_BLADE_STROKE_Y — cutting head actuator
  CUTTER_LEAD_SCREW_ROTATE_X — lead screw
  VISION_RINGLIGHT — optical inspection indicator ring
  SORTING_ARM_PIVOT_Y — reject/accept gate
  SORT_MOTOR_SHAFT_ROTATE_X — diverter motor
  ESTOP_BUTTON_PRESS_Z — emergency stop cap
  FACTORY_RUNTIME_DISPLAY_FACE / DASHBOARD_RUNTIME_TMP_FACE — live TMP overlay hosts

PROPOSED SIX OBJECTIVES (NOT IMPLEMENTED)
  1/6 Build all 22 connections and validate safety/power.
  2/6 Calibrate two registration marks and station offsets.
  3/6 Produce three consecutive good products at 30 RPM.
  4/6 Route two good and two defective items correctly at 60 RPM.
  5/6 Maintain product IDs over speed change and reject a false mark.
  6/6 Trip the safety interlock; recover, reset and produce four good items.

SAFETY AND AUTHORITATIVE PROGRESSION
- Implement NC interlock from SAFETY_NC_OUT to CTRL_SAFETY_IN. The meshes
  do not enforce emergency stop. Signal faults must stop actuators correctly.
- Keep product IDs associated with encoder positions across all five stations.
- The real SparkLevelEvaluator and LevelGamePlayManager must own objectives.
- Do not fake measured voltage, encoder motion or 6/6 target states.

VALIDATION
The individual FBXs and showcase use FBX 7.4 binary with named material
sections and independent Transform groups. GLBs were decoded with trimesh.
All 22 wire endpoints match the 38 unique art socket IDs.
Unity compilation, material rendering, physics and Play Mode NOT tested.
