using UnityEngine;
using UnityEngine.UI;

namespace ProjectSpark.Gameplay
{
    public sealed class SparkLevel74Trend : MaskableGraphic
    {
        private readonly SparkLevel74Plant.FieldState[] states=new SparkLevel74Plant.FieldState[16];
        private readonly int[] doses=new int[16];
        private bool hasPosition;

        public void Show(SparkLevel74Plant.Field[] fields,bool valid)
        {
            bool redraw=hasPosition!=valid;
            hasPosition=valid;
            for(int i=0;i<16;i++)
            {
                int dose=Mathf.Clamp(Mathf.RoundToInt((float)fields[i].Dose*25),0,25);
                var state=fields[i].State;
                redraw|=states[i]!=state||doses[i]!=dose;
                states[i]=state;doses[i]=dose;
            }
            if(redraw)SetVerticesDirty();
        }
        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            mesh.Clear();
            Rect rect=rectTransform.rect;
            void Tile(float x,float y,float w,float h,Color32 color)
            {
                int index=mesh.currentVertCount;
                float l=rect.xMin+x*rect.width, b=rect.yMin+y*rect.height;
                float r=l+w*rect.width, top=b+h*rect.height;
                mesh.AddVert(new Vector3(l,b),color,Vector2.zero);
                mesh.AddVert(new Vector3(l,top),color,Vector2.zero);
                mesh.AddVert(new Vector3(r,top),color,Vector2.zero);
                mesh.AddVert(new Vector3(r,b),color,Vector2.zero);
                mesh.AddTriangle(index,index+1,index+2);
                mesh.AddTriangle(index,index+2,index+3);
            }
            Tile(0,0,1,1,new Color32(8,20,33,242));
            Tile(.035f,.937f,.93f,.023f,hasPosition?new Color32(66,218,211,255):new Color32(238,93,82,255));
            for(int i=0;i<16;i++)
            {
                float x=.041f+(i%4)*.234f, y=.064f+(3-i/4)*.211f;
                Color32 color=states[i] switch
                {
                    SparkLevel74Plant.FieldState.Scanning=>new Color32(226,172,69,255),
                    SparkLevel74Plant.FieldState.Reject=>new Color32(213,61,76,255),
                    SparkLevel74Plant.FieldState.Exposed=>new Color32(54,151,203,255),
                    SparkLevel74Plant.FieldState.Developed=>new Color32(87,106,214,255),
                    SparkLevel74Plant.FieldState.Verified=>new Color32(52,190,145,255),
                    _=>new Color32(53,82,105,255)
                };
                Tile(x,y,.213f,.188f,color);
                Tile(x+.006f,y+.012f,.201f,.164f,new Color32((byte)(color.r/3),(byte)(color.g/3),(byte)(color.b/3),255));
                Tile(x+.014f,y+.035f,.184f*doses[i]/25,.035f,color);
                if(states[i]==SparkLevel74Plant.FieldState.Verified||states[i]==SparkLevel74Plant.FieldState.Exposed)
                {
                    Tile(x+.024f,y+.111f,.063f,.018f,color);
                    Tile(x+.106f,y+.111f,.078f,.018f,color);
                }
            }
        }
    }
}
