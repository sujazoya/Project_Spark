#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.EditorTools
{
    /// <summary>Level 68 procedural HD geometry placement ONLY. No gameplay terminals, wiring, heat simulation or objectives.</summary>
    public static class SparkLevel68ArtPlacementEditor
    {
        private const string ArtRoot = "L68_HD_VISUAL_ART";
        private static readonly string[] Models = {
            "00_L68_IndustrialThermalProcessBase",
            "01_L68_RegenerativePlateHeatExchanger",
            "02_L68_HeatExchangerPlateStack",
            "03_L68_SecondaryTrimHeatExchanger",
            "04_L68_InsulatedHeatingTank",
            "05_L68_ColdWaterReservoir",
            "06_L68_ThermalBufferTank",
            "07_L68_ProductHoldingChamber",
            "08_L68_FinishedProductOutletModule",
            "09_L68_HotWaterCirculationPump",
            "10_L68_ColdWaterCirculationPump",
            "11_L68_ProductTransferPump",
            "12_L68_HotLoopPumpMotor",
            "13_L68_ColdLoopPumpMotor",
            "14_L68_ProductPumpMotor",
            "15_L68_ElectricHeatingElementBank",
            "16_L68_HeatingPowerController",
            "17_L68_VariableFrequencyDriveBank",
            "18_L68_HotWaterControlValve",
            "19_L68_CoolingWaterControlValve",
            "20_L68_ThreeWayMixingValve",
            "21_L68_RegenerativeBypassValve",
            "22_L68_ProductIsolationValve",
            "23_L68_TransparentThermalPipelineNetwork",
            "24_L68_ProductInletTemperatureSensor",
            "25_L68_ProductOutletRTDTemperatureSensor",
            "26_L68_HotWaterTemperatureSensor",
            "27_L68_ColdWaterTemperatureSensor",
            "28_L68_ThermalBufferTemperatureSensor",
            "29_L68_ThermalFlowMeterBank",
            "30_L68_DifferentialPressureTransmitter",
            "31_L68_HeatFluxMeasurementModule",
            "32_L68_RegenerativeEfficiencyAnalyzer",
            "33_L68_CascadeTemperaturePIDController",
            "34_L68_ThermalEnergyManagementController",
            "35_L68_HeatExchangerFoulingSimulator",
            "36_L68_InletTemperatureDisturbanceModule",
            "37_L68_OvertemperatureProtectionRelay",
            "38_L68_IndustrialThermalPLC",
            "39_L68_ThermalDigitalIOModule",
            "40_L68_HolographicThermalSCADAMonitor",
            "41_L68_EmergencyThermalShutdownStation",
            "42_L68_TransparentThermalSafetyEnclosure",
            "43_L68_Regulated5VControlSupply",
        };
        [MenuItem("Tools/Project Spark/Levels/68/Place HD Art Under Selected Layout")]
        public static void Place()
        {
            GameObject destination = Selection.activeGameObject;
            if (destination == null)
            {
                EditorUtility.DisplayDialog("Level 68 Art", "Select your existing Level 68 layout root first.", "OK");
                return;
            }
            GameObject[] prefabs = new GameObject[Models.Length];
            for (int i = 0; i < Models.Length; i++)
            {
                string exact = null;
                foreach (string guid in AssetDatabase.FindAssets(Models[i] + " t:Model"))
                {
                    string candidate = AssetDatabase.GUIDToAssetPath(guid);
                    if (Path.GetExtension(candidate).Equals(".fbx", StringComparison.OrdinalIgnoreCase)
                        && Path.GetFileNameWithoutExtension(candidate).Equals(Models[i], StringComparison.Ordinal))
                    { exact = candidate; break; }
                }
                if (exact == null || (prefabs[i] = AssetDatabase.LoadAssetAtPath<GameObject>(exact)) == null)
                {
                    EditorUtility.DisplayDialog("Missing Level 68 Model", Models[i] + ".fbx missing. Import all 44 first; no changes made.", "OK");
                    return;
                }
            }
            Transform previous = destination.transform.Find(ArtRoot);
            if (previous != null && !EditorUtility.DisplayDialog("Replace generated Level 68 art?",
                "Replace only " + ArtRoot + " below the selected layout?", "Replace", "Cancel")) return;
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Place Level 68 HD Art");
            if (previous != null) Undo.DestroyObjectImmediate(previous.gameObject);
            GameObject root = new GameObject(ArtRoot);
            Undo.RegisterCreatedObjectUndo(root, "Create Level 68 art root");
            root.transform.SetParent(destination.transform, false);
            root.transform.localPosition = Vector3.zero;
            root.transform.localRotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;
            for (int i = 0; i < prefabs.Length; i++)
            {
                GameObject placed = PrefabUtility.InstantiatePrefab(prefabs[i], root.transform) as GameObject;
                if (placed == null) throw new InvalidOperationException("Failed to instantiate " + Models[i]);
                Undo.RegisterCreatedObjectUndo(placed, "Place Level 68 model");
                placed.name = Models[i];
                placed.transform.localPosition = Vector3.zero;
                placed.transform.localRotation = Quaternion.identity;
                placed.transform.localScale = Vector3.one;
            }
            Undo.CollapseUndoOperations(undoGroup);
            Selection.activeGameObject = root;
            Debug.Log("[LEVEL 68 ART] Placed 44 independent FBX models under " + ArtRoot + ". ART ONLY: no SparkTerminals, 78 wires, 122 sockets, thermal simulation or objectives.", root);
        }
    }
}
#endif
