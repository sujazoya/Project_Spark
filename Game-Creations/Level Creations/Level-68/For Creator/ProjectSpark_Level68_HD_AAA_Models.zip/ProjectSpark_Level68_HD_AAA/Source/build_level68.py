from pathlib import Path
import importlib.util, json, csv, math, numpy as np
sp=importlib.util.spec_from_file_location('base','/mnt/data/build_level67.py');b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
R=Path('/mnt/data/ProjectSpark_Level68_HD_AAA')
for d in ['Models','GLB','Previews','Unity_Optional','Source']:(R/d).mkdir(parents=True,exist_ok=True)
NAMES=['IndustrialThermalProcessBase','RegenerativePlateHeatExchanger','HeatExchangerPlateStack','SecondaryTrimHeatExchanger','InsulatedHeatingTank','ColdWaterReservoir','ThermalBufferTank','ProductHoldingChamber','FinishedProductOutletModule','HotWaterCirculationPump','ColdWaterCirculationPump','ProductTransferPump','HotLoopPumpMotor','ColdLoopPumpMotor','ProductPumpMotor','ElectricHeatingElementBank','HeatingPowerController','VariableFrequencyDriveBank','HotWaterControlValve','CoolingWaterControlValve','ThreeWayMixingValve','RegenerativeBypassValve','ProductIsolationValve','TransparentThermalPipelineNetwork','ProductInletTemperatureSensor','ProductOutletRTDTemperatureSensor','HotWaterTemperatureSensor','ColdWaterTemperatureSensor','ThermalBufferTemperatureSensor','ThermalFlowMeterBank','DifferentialPressureTransmitter','HeatFluxMeasurementModule','RegenerativeEfficiencyAnalyzer','CascadeTemperaturePIDController','ThermalEnergyManagementController','HeatExchangerFoulingSimulator','InletTemperatureDisturbanceModule','OvertemperatureProtectionRelay','IndustrialThermalPLC','ThermalDigitalIOModule','HolographicThermalSCADAMonitor','EmergencyThermalShutdownStation','TransparentThermalSafetyEnclosure','Regulated5VControlSupply']
b.C.update({'hotwater':(248,112,37,125),'coolwater':(20,157,249,120),'productwater':(155,85,234,120),'redhot':(252,78,30,255),'iceblue':(43,199,249,255),'violet':(159,93,218,255),'insulation':(87,107,115,255)})
box=b.box;cyl=b.cyl;pipe=b.pipe;ring=b.ring;panel=b.panel;support=b.support;sensor=b.sensor;leds=b.leds;frame_panel=b.frame_panel

def tank(x,z,r=0.64,h=2.1,bot=1.38,fill=.60,liquid='hotwater',label='Tank',heater=False,buffer=False):
 ring((x,bot+h/2,z),r+.025,r-.03,h-.12,'y','glass',36,'TransparentTankShell')
 for yy in [bot+.035,bot+h-.04]: ring((x,yy,z),r+.085,r-.025,.11,'y','chrome',36,'Flange')
 cyl((x,bot+h*fill/2,z),r*.91,h*fill,'y',liquid,36,'LiquidVolumeArt')
 cyl((x,bot+h+.04,z),r+.095,.105,'y','steel',32,'TankTopCap')
 for a in range(0,360,90):
  t=math.radians(a);xx=x+(r+.115)*math.cos(t);zz=z+(r+.115)*math.sin(t)
  pipe((xx,bot+.04,zz),(xx,bot+h-.04,zz),.031,'silver',10,'TankFrame')
 for yy in np.linspace(bot+.25,bot+h-.24,7):box((x+r+.105,float(yy),z),(.04,.022,.15),'white','LevelTick')
 for dx in [-.36,.36]:
  for dz in [-.36,.36]:support(x+dx,z+dz,bot-.48)
 if heater:
  for j in range(5):
   theta=j*math.pi/2; y=bot+.23+j*.17
   ring((x,y,z),r*.68,r*.60,.085,'y','orange',22,'ImmersionHeaterCoil')
  box((x,bot+1.16,z+r+.12),(.46,.37,.25),'yellow','HotWarning')
 if buffer:
  for j in range(5):ring((x,bot+.24+j*.32,z),r+.08,r+.025,.058,'y','insulation',30,'InsulationBand')

def hx(x,z,plate_count=24,w=2.2,trim=False):
 y=2.3
 box((x,y,z),(.24,2.25,1.34),'blue','FrameFixedHead')
 box((x+w,y,z),(.22,2.25,1.34),'blue','FrameMovingHead')
 for j in range(plate_count):
  xx=x+.16+(w-.32)*(j+.5)/plate_count
  box((xx,y,z),(.041,1.9,1.15),'steel' if j%3 else 'chrome','CorrugatedHeatTransferPlate')
  for zz in [z-.43,z+.43]:
   for yy in [y-.70,y+.70]:cyl((xx,yy,zz),.09,.05,'x','orange' if (j%2==0) else 'cyan',12,'ChannelPort')
 for yy in [y-.9,y+.9]:
  for zz in [z-.50,z+.50]:pipe((x-.21,yy,zz),(x+w+.21,yy,zz),.046,'chrome',12,'CompressionTieRod')
 for xx in [x,x+w]:
  for yy in [y-.72,y+.72]:
   for zz in [z-.42,z+.42]:cyl((xx-.15 if xx==x else xx+.15,yy,zz),.15,.22,'x','chrome',16,'PortFlange')
 for xx in [x+.08,x+w-.08]:box((xx,1.03,z),(.21,.38,1.18),'dark','ExchangerFoot')
 box((x+w/2,3.50,z),(w+.28,.11,1.35),'silver','TopNameplate')
 if trim:
  for yy in [1.38,3.20]:box((x+w/2,yy,z+.74),(w*.82,.065,.08),'violet','TrimAccent')

def pump(x,z,pivot):
 y=1.08
 box((x,y-.47,z),(1.1,.12,.78),'dark','PumpSkid')
 cyl((x-.20,y,z),.30,.45,'x','steel',28,'Volute')
 cyl((x-.45,y,z),.25,.065,'x','chrome',24,'ServiceCover')
 cyl((x-.49,y,z),.18,.06,'x','gold',20,'Impeller',pivot)
 for j in range(7):
  t=j*math.tau/7;pipe((x-.49,y,z),(x-.49,y+.17*math.cos(t),z+.17*math.sin(t)),.025,'gold',8,'ImpellerBlade',pivot)
 cyl((x+.3,y,z),.29,.67,'x','blue',26,'MotorHousing')
 for j in range(14):
  t=j*math.tau/14;box((x+.32,y+.30*math.cos(t),z+.30*math.sin(t)),(.52,.055,.055),'silver','CoolingFin')
 cyl((x+.65,y,z),.31,.07,'x','navy',20,'MotorCap')
 pipe((x-.48,y+.16,z),(x-.48,y+.60,z),.12,'copper',14,'PumpDischarge')
 pipe((x-.75,y,z),(x-.48,y,z),.125,'cyan',14,'PumpSuction')
 b.pivots[pivot]=(x-.49,y,z)

def mot(x,z,pivot):
 y=1.05
 cyl((x,y,z),.30,.72,'x','blue',28,'MotorBody')
 for j in range(18):
  t=j*math.tau/18;box((x,y+.31*math.cos(t),z+.31*math.sin(t)),(.55,.052,.050),'steel','MotorRib')
 cyl((x-.4,y,z),.11,.31,'x','chrome',18,'Shaft',pivot)
 cyl((x+.38,y,z),.31,.10,'x','dark',24,'RearCover')
 box((x,y-.38,z),(.65,.14,.55),'navy','Mount');b.pivots[pivot]=(x-.4,y,z)

def valve(x,z,pivot,c='orange'):
 y=1.76
 pipe((x-.28,y,z),(x+.28,y,z),.115,'steel',16,'FlowBody')
 cyl((x,y+.07,z),.20,.17,'y','chrome',20,'ValveBonnet')
 cyl((x,y+.28,z),.058,.36,'y','silver',12,'ActuatorStem',pivot)
 cyl((x,y+.52,z),.26,.09,'y',c,24,'ActuatorWheel',pivot)
 for j in range(6):
  t=j*math.tau/6;pipe((x,y+.52,z),(x+.23*math.cos(t),y+.52,z+.23*math.sin(t)),.018,'chrome',8,'Spoke',pivot)
 box((x+.23,y+.26,z),(.3,.32,.26),'dark','ServoGearBox');b.pivots[pivot]=(x,y+.43,z)

def instrument(x,y,z,c='cyan',kind='RTD'):
 box((x,y,z),(.35,.42,.32),'dark',kind+'Body')
 box((x,y+.055,z+.18),(.25,.18,.026),'screen','SensorScreen')
 box((x,y+.06,z+.202),(.19,.027,.010),c,'Readout')
 cyl((x,y-.31,z),.04,.24,'y','chrome',10,'Stem')
 for xx in [-.09,.0,.09]:cyl((x+xx,y-.11,z+.20),.025,.028,'z','green',8,'StatusLED')

def cabinet(x,y,z,w=1.05,h=.92):
 frame_panel(x,y,z,w,h,.44)
 for dx in [-w*.27,0,w*.27]:box((x+dx,y-.28,z+.255),(.10,.06,.025),'green','RelayLED')

def pipe_route(pts,col='orange',radius=.065):
 for p,q in zip(pts,pts[1:]):pipe(p,q,radius,col,12,'ProcessLine')
 for q in pts[1:-1]:b.sphere(q,radius*1.23,'chrome',1,'ElbowFitting')

def make(i):
 b.parts=[];b.pivots={}
 if i==0:
  box((0,.28,0),(14.4,.42,6.7),'navy','WorkbenchBase')
  box((0,.52,0),(14.15,.07,6.42),'steel','MetalTop')
  box((0,.58,3.13),(13.9,.045,.045),'cyan','FrontIllumination')
  for x in [-6.6,6.6]:
   for z in [-2.8,2.8]:box((x,.10,z),(.50,.19,.50),'dark','IndustrialFoot')
  for z in [-2.85,2.9]:
   for x in np.linspace(-6.7,6.7,26):box((float(x),.57,z),(.05,.025,.06),'chrome','BenchRivet')
  box((0,.68,-1.2),(12.4,.22,3.1),'dark','MechanicalEquipmentPlatform')
  box((5.15,.75,2.12),(2.4,.14,1.35),'navy','ControlHMIBase')
 elif i==1: hx(-1.35,-1.28,32,2.6)
 elif i==2:
  for j in range(26):box((-.93+ j*.075,2.27,.30),(.048,1.62,1.06),'chrome' if j%3 else 'copper','IndependentPlate')
  for yy in [1.47,3.0]:pipe((-1.3,yy,.30),(1.0,yy,.30),.04,'silver',10,'PlateTieRod')
  box((-.1,1.34,.30),(2.4,.08,1.23),'dark','PlateDisplayBase')
 elif i==3:hx(1.45,-1.43,15,1.5,True)
 elif i==4:tank(-5.4,-1.5,.73,2.55,1.40,.69,'hotwater',heater=True)
 elif i==5:tank(-5.25,1.16,.64,1.68,1.37,.58,'coolwater')
 elif i==6:tank(4.45,-1.55,.69,2.15,1.39,.60,'hotwater',buffer=True)
 elif i==7:tank(4.52,.50,.62,2.05,1.37,.53,'productwater')
 elif i==8:
  box((5.80,1.35,1.10),(1.40,.60,.60),'dark','OutletSkid')
  pipe_route([(4.7,1.49,.8),(5.55,1.49,.8),(5.55,1.60,1.22),(6.3,1.60,1.22)],'violet',.08)
  for x in [5.3,6.15]:ring((x,1.60,1.22),.16,.09,.055,'x','chrome',20,'OutletFlange')
 elif i in [9,10,11]:
  x,z=[(-4.0,1.1),(-1.7,1.10),(1.85,1.12)][i-9]
  pump(x,z,['ANIM_HOT_PUMP_IMPELLER','ANIM_COLD_PUMP_IMPELLER','ANIM_PRODUCT_PUMP_IMPELLER'][i-9])
 elif i in [12,13,14]:
  x,z=[(-3.55,1.72),(-1.27,1.73),(2.30,1.73)][i-12]
  mot(x,z,['ANIM_HOT_MOTOR','ANIM_COLD_MOTOR','ANIM_PRODUCT_MOTOR'][i-12])
 elif i==15:
  box((-5.4,2.5,-1.5),(.47,1.5,.58),'steel','HeatingBank')
  for j in range(7):
   yy=1.84+j*.20
   ring((-5.40,yy,-1.5),.31,.25,.075,'y','orange',24,'ElectricHeatingCoil')
  box((-5.40,3.30,-1.5),(.62,.15,.64),'yellow','SafetyCover')
 elif i in [16,17,33,34,37,38,39]:
  p={16:(-6.45,1.6,2.18),17:(-5.2,1.6,2.18),33:(-3.95,1.6,2.18),34:(-2.7,1.6,2.18),37:(-1.45,1.6,2.18),38:(-.20,1.6,2.18),39:(1.05,1.6,2.18)}[i]
  cabinet(*p)
 elif i in [18,19,20,21,22]:
  x,z=[(-3.35,-.5),(-1.9,-.45),(2.3,.18),(3.65,-.5),(5.45,1.3)][i-18]
  valve(x,z,['ANIM_HOT_VALVE','ANIM_COOLING_VALVE','ANIM_THREE_WAY_VALVE','ANIM_REGEN_BYPASS','ANIM_PRODUCT_ISOLATION'][i-18],['orange','cyan','violet','gold','red'][i-18])
 elif i==23:
  routes=[([(-5.4,1.65,-.76),(-4.0,1.65,-.76),(-4.0,2.90,-.76),(-1.35,2.90,-.76)],'orange'),([(-.0,1.72,-.65),(1.2,1.72,-.65),(1.2,2.47,-.65),(2.25,2.47,-.65)],'violet'),([(-5.25,1.55,1.17),(-1.7,1.55,1.17),(-1.7,2.65,1.17),(1.95,2.65,1.17)],'cyan'),([(2.7,1.72,-1.4),(4.45,1.72,-1.4),(4.45,2.33,.40)],'orange'),([(1.95,1.67,.52),(4.52,1.67,.52),(4.52,2.12,.52)],'violet')]
  for seq,c in routes:pipe_route(seq,c)
 elif i in [24,25,26,27,28]:
  pos=[(-.70,1.83,1.85),(5.43,1.92,1.77),(-4.3,2.12,1.6),(-1.53,2.13,1.58),(4.8,2.13,-.53)][i-24]
  instrument(*pos,c=['cyan','violet','orange','cyan','gold'][i-24],kind='RTD')
 elif i==29:
  box((2.63,.94,2.11),(1.65,.18,.69),'dark','FlowMeterRack')
  for x in [2.08,2.63,3.18]:
   cyl((x,1.30,2.11),.20,.37,'y','chrome',20,'TurbineMeter')
   box((x,1.54,2.13),(.27,.22,.27),'dark','DisplayHead')
   box((x,1.55,2.29),(.19,.10,.012),'screen','RateDisplay')
 elif i==30:
  instrument(3.8,2.05,1.55,c='yellow',kind='DeltaPressure')
  pipe((3.67,1.70,1.56),(3.67,1.89,1.56),.035,'red',10,'HighSide')
  pipe((3.93,1.70,1.56),(3.93,1.89,1.56),.035,'cyan',10,'LowSide')
 elif i in [31,32]:
  instrument([-.85,.15][i-31],2.11,1.52,c=['orange','green'][i-31],kind=['HeatFlux','RecoveryAnalyzer'][i-31])
 elif i==35:
  box((.4,3.20,-1.20),(.70,.46,.45),'dark','FoulingTestChamber')
  for j in range(8):cyl((.1+j*.085,3.22,-.94),.028,.04,'z','rust',10,'FoulingDeposit')
  leds(.20,3.1,-.94,4,.12)
 elif i==36:
  cabinet(2.23,2.48,2.25,.84,.82)
  cyl((2.23,3.05,2.25),.20,.15,'y','cyan',16,'ColdInletInjector')
 elif i==40:
  x,y,z=5.5,3.12,-.20
  box((x,y,z),(2.82,1.8,.26),'navy','SCADAMonitor')
  box((x,y,z+.15),(2.61,1.55,.025),'screen','MonitorScreen')
  for j in range(3):
   yj=3.48-j*.35
   for k in range(6):box((x-.67+k*.18,yj+(.03*math.sin(k*1.3+j)),z+.17),(.14,.027,.012),['orange','cyan','violet'][j],'Trend')
  for j in range(5):box((x+1.02,3.66-j*.25,z+.17),(.30,.10,.013),'green','ProcessStatus')
  box((x,2.03,z),(.17,.44,.23),'steel','MonitorStand');b.pivots['ANIM_THERMAL_SCADA']=(x,y,z)
 elif i==41:
  box((5.95,1.20,2.34),(.95,.75,.53),'yellow','SafetyConsole')
  cyl((5.95,1.42,2.64),.18,.17,'z','red',24,'EmergencyStop','ANIM_EMERGENCY_STOP')
  box((5.7,1.01,2.63),(.22,.10,.04),'black','ResetButton');b.pivots['ANIM_EMERGENCY_STOP']=(5.95,1.42,2.64)
 elif i==42:
  for x in [-6.55,6.55]:
   for z in [-2.8,2.4]:box((x,2.46,z),(.09,3.45,.09),'chrome','SafetyPost')
  for z in [-2.8,2.4]:
   box((0,4.2,z),(13.2,.09,.09),'chrome','GuardRail')
   box((0,2.43,z),(13.0,3.25,.037),'glass','PolycarbonatePanel')
  box((6.55,2.43,-.05),(.045,3.22,4.7),'glass','SlidingSafetyDoor','ANIM_SAFETY_DOOR');b.pivots['ANIM_SAFETY_DOOR']=(6.55,2.43,-.05)
 elif i==43:
  cabinet(-6.50,1.12,2.25,.89,.84)
  box((-6.5,1.62,2.25),(.66,.075,.47),'green','ControlPowerLED')
 return list(b.parts),dict(b.pivots)

if __name__=='__main__':
 allparts=[];entries=[];pivots=[]
 for i,name in enumerate(NAMES):
  p,rig=make(i)
  allparts+=p
  fb=f'{i:02d}_L68_{name}.fbx';gl=f'{i:02d}_L68_{name}.glb'
  b.fbx_export(p,rig,R/'Models'/fb,'L68_'+name)
  b.glb_export(p,rig,R/'GLB'/gl)
  count=sum(len(k.mesh.faces) for k in p)
  entries.append({'file':fb,'glb':gl,'name':'L68_'+name,'triangle_count':count,'mesh_parts':len(p),'animation_pivots':{k:list(v) for k,v in rig.items()}})
  for n,xyz in rig.items():pivots.append([name,n,*xyz,'Visual pivot follows authoritative physical state; rig verification required'])
  print(f'{i+1:02d} {name:38s} {count:6d} tris',flush=True)
 manifest={'level_id':'level_68','display_name':'Tame the Heat','asset_kind':'procedural 3D art only, no gameplay','individual_models':44,'planned_player_wires':78,'planned_unique_sockets':122,'real_terminals_included':False,'physics_included':False,'coordinate_system':'X=workbench width; Y=up; Z=front; length scale 1 unit=1 meter','models':entries,'triangle_count':sum(x['triangle_count'] for x in entries)}
 (R/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
 with (R/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['model','pivot_name','world_x','world_y','world_z','usage']);w.writerows(pivots)
 b.fbx_export(allparts,{},R/'Models'/'Level68_Complete_ArtKit_Showcase.fbx','L68_Complete_ArtKit_Showcase')
 b.glb_export(allparts,{},R/'GLB'/'Level68_Complete_ArtKit_Showcase.glb')
 print('TOTAL',manifest['triangle_count'],'PIVOTS',len(pivots),flush=True)
