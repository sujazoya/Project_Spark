from pathlib import Path
import json,csv,zipfile,struct,shutil
import trimesh
R=Path('/mnt/data/ProjectSpark_Level68_HD_AAA')
manifest=json.loads((R/'Model_Manifest.json').read_text());names=manifest['models'];pivots=list(csv.DictReader((R/'Animation_Rigs.csv').open()))
assert len(names)==44 and len(pivots)==14
cs='''#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.EditorTools
{
    /// <summary>Level 68 procedural HD geometry placement ONLY. No gameplay terminals, wiring, heat simulation or objectives.</summary>
    public static class SparkLevel68ArtPlacementEditor
    {
        private const string ArtRoot = "L68_HD_VISUAL_ART";
        private static readonly string[] Models = {
'''
cs+=''.join('            "'+Path(n['file']).stem+'",\n' for n in names)
cs+='''        };
        [MenuItem("Tools/Project Spark/Levels/68/Place HD Art Under Selected Layout")]
        public static void Place()
        {
            GameObject destination = Selection.activeGameObject;
            if (destination == null)
            {
                EditorUtility.DisplayDialog("Level 68 Art", "Select your existing Level 68 layout root first.", "OK");
                return;
            }
            GameObject[] prefabs = new GameObject[Models.Length];
            for (int i = 0; i < Models.Length; i++)
            {
                string exact = null;
                foreach (string guid in AssetDatabase.FindAssets(Models[i] + " t:Model"))
                {
                    string candidate = AssetDatabase.GUIDToAssetPath(guid);
                    if (Path.GetExtension(candidate).Equals(".fbx", StringComparison.OrdinalIgnoreCase)
                        && Path.GetFileNameWithoutExtension(candidate).Equals(Models[i], StringComparison.Ordinal))
                    { exact = candidate; break; }
                }
                if (exact == null || (prefabs[i] = AssetDatabase.LoadAssetAtPath<GameObject>(exact)) == null)
                {
                    EditorUtility.DisplayDialog("Missing Level 68 Model", Models[i] + ".fbx missing. Import all 44 first; no changes made.", "OK");
                    return;
                }
            }
            Transform previous = destination.transform.Find(ArtRoot);
            if (previous != null && !EditorUtility.DisplayDialog("Replace generated Level 68 art?",
                "Replace only " + ArtRoot + " below the selected layout?", "Replace", "Cancel")) return;
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Place Level 68 HD Art");
            if (previous != null) Undo.DestroyObjectImmediate(previous.gameObject);
            GameObject root = new GameObject(ArtRoot);
            Undo.RegisterCreatedObjectUndo(root, "Create Level 68 art root");
            root.transform.SetParent(destination.transform, false);
            root.transform.localPosition = Vector3.zero;
            root.transform.localRotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;
            for (int i = 0; i < prefabs.Length; i++)
            {
                GameObject placed = PrefabUtility.InstantiatePrefab(prefabs[i], root.transform) as GameObject;
                if (placed == null) throw new InvalidOperationException("Failed to instantiate " + Models[i]);
                Undo.RegisterCreatedObjectUndo(placed, "Place Level 68 model");
                placed.name = Models[i];
                placed.transform.localPosition = Vector3.zero;
                placed.transform.localRotation = Quaternion.identity;
                placed.transform.localScale = Vector3.one;
            }
            Undo.CollapseUndoOperations(undoGroup);
            Selection.activeGameObject = root;
            Debug.Log("[LEVEL 68 ART] Placed 44 independent FBX models under " + ArtRoot + ". ART ONLY: no SparkTerminals, 78 wires, 122 sockets, thermal simulation or objectives.", root);
        }
    }
}
#endif
'''
(R/'Unity_Optional'/'SparkLevel68ArtPlacementEditor.cs').write_text(cs)
readme=f'''PROJECT SPARK — LEVEL 68: TAME THE HEAT
HD PROCEDURAL MODULAR 3D ASSETS — UNITY IMPORT GUIDE

CONTENTS
 Models/ 44 individual binary FBX 7.4 objects + assembled showcase FBX
 GLB/ 44 individual GLB backups + assembled showcase GLB
 Previews/ isometric geometry hero and 44-item contact sheet
 Model_Manifest.json 44 exact filenames, triangle counts, pivots
 Animation_Rigs.csv {len(pivots)} verified reference pivot mappings
 Unity_Optional/SparkLevel68ArtPlacementEditor.cs art-only placement
 Source/ procedural generation and preview scripts
 Verification_Report.json integrity report

UNITY IMPORT
 1. Extract archive. Copy Models/*.fbx to Assets/ProjectSpark/Levels/Level68/Art/Models/.
 2. Place SparkLevel68ArtPlacementEditor.cs inside a Unity Editor folder.
 3. Inspect model import Scale Factor 1 and axis orientation; source X width, Y up, Z front.
 4. Select existing Level 68 layout root in Unity Hierarchy.
 5. Run Tools > Project Spark > Levels > 68 > Place HD Art Under Selected Layout.
 6. 44 individual prefabs are placed under L68_HD_VISUAL_ART at common origin.
 7. Do NOT also instantiate Level68_Complete_ArtKit_Showcase.fbx: it duplicates geometry.
 8. Reassign transparent/PBR materials appropriate to project's render pipeline if needed.

ANIMATION / ART LIMITATIONS
 Pivot coordinates are references, NOT complete gameplay rigging or authored animations.
 Reparent moving plate doors, pump impellers, valve handles and other geometry as needed.
 Liquid visuals/temperature trends must be driven by your authoritative Unity simulation.
 Art quality: genuine procedural HD/AAA-inspired triangulated geometry and material colors;
 NOT handmade final AAA PBR textured artwork. No authored texture sets are bundled.

GAMEPLAY NOT INCLUDED
 No SparkTerminal registrations; no 78 player wires; no 122 functional sockets.
 No heat-transfer dynamics, exchanger effectiveness, PID, sensor faults, safety or 6 objectives.
 No Level_68.asset / Level_68_Layout.prefab. Unity Play Mode/import not tested.

EXPORT CHECKS
 See Verification_Report.json. Binary FBX structural offsets, GLB mesh/triangle counts,
 pivot CSV, and archive integrity are checked programmatically.
'''
(R/'README_Unity.txt').write_text(readme)
MAGIC=b'Kaydara FBX Binary  \x00\x1a\x00'
def fbx_parse(path):
 d=path.read_bytes();assert d.startswith(MAGIC) and struct.unpack_from('<I',d,23)[0]==7400
 stats={'nodes':0,'geometry_nodes':0,'model_nodes':0,'material_nodes':0}
 def walk(off,limit,level):
  assert level<24
  while off+13<=limit:
   if level==0 and off>=len(d)-260:return off
   end,num,proplen,nlen=struct.unpack_from('<IIIb',d,off)
   if end==0:return off+13
   assert end>off and end<=limit and end<=len(d),(path,off,end,limit)
   name=d[off+13:off+13+nlen].decode('utf8','ignore')
   stats['nodes']+=1
   if name in ('Geometry','Model','Material'):stats[name.lower()+'_nodes']+=1
   payload=off+13+nlen+proplen;assert payload<=end
   if payload<end:assert walk(payload,end,level+1)<=end
   off=end
  return off
 walk(27,len(d)-200,0)
 assert stats['geometry_nodes']>=1 and stats['model_nodes']>=2
 return stats
assert len(list((R/'Models').glob('*.fbx')))==45
assert len(list((R/'GLB').glob('*.glb')))==45
stats={};tris=0
for item in names:
 fp=R/'Models'/item['file'];gp=R/'GLB'/item['glb'];assert fp.is_file() and gp.is_file()
 stats[item['file']]=fbx_parse(fp)
 scene=trimesh.load(gp,force='scene');num=sum(len(m.faces) for m in scene.geometry.values())
 assert num==item['triangle_count'],(item['name'],num,item['triangle_count']);tris+=num
stats['Level68_Complete_ArtKit_Showcase.fbx']=fbx_parse(R/'Models'/'Level68_Complete_ArtKit_Showcase.fbx')
scene=trimesh.load(R/'GLB'/'Level68_Complete_ArtKit_Showcase.glb',force='scene')
assert sum(len(m.faces) for m in scene.geometry.values())==tris
assert tris==manifest['triangle_count']
assert 'Levels/68/Place HD Art' in cs
assert (R/'Previews'/'Level68_Hero_3D_Preview.png').is_file()
assert (R/'Previews'/'Level68_44_Models_ContactSheet.png').is_file()
report={'level_id':'level_68','art_kind':'procedural 3D geometry only','individual_fbx':44,'individual_glb':44,'assembled_fbx':1,'assembled_glb':1,'triangles':tris,'animation_pivots':len(pivots),'binary_fbx_header_and_tree_validated':45,'glb_loaded_and_triangle_count_matched':45,'correct_unity_editor_menu':'Tools/Project Spark/Levels/68/Place HD Art Under Selected Layout','functional_terminals_included':False,'thermal_simulation_included':False,'authored_pbr_textures_included':False,'unity_import_tested':False,'unity_play_mode_tested':False,'zip_integrity_passed':False,'fbx_tree_statistics':stats}
(R/'Verification_Report.json').write_text(json.dumps(report,indent=2))
for s in ['build_level68.py','render_level68.py','package_level68.py']:shutil.copy('/mnt/data/'+s,R/'Source'/s)
archive=Path('/mnt/data/ProjectSpark_Level68_HD_AAA_Models.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(R.rglob('*')):
  if f.is_file():z.write(f,arcname=str(Path(R.name)/f.relative_to(R)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 count=len(z.namelist());assert count>=95,count
report['zip_integrity_passed']=True;report['archive_entries']=count;report['archive_bytes']=archive.stat().st_size
(R/'Verification_Report.json').write_text(json.dumps(report,indent=2))
# repackage report with final archive validation states
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(R.rglob('*')):
  if f.is_file():z.write(f,arcname=str(Path(R.name)/f.relative_to(R)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({k:v for k,v in report.items() if k!='fbx_tree_statistics'},indent=2))
