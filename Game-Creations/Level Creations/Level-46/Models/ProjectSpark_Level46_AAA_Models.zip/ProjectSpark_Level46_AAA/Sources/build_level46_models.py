"""PROJECT SPARK | LEVEL 46 | KEEP IN STEP | polished procedural 3D meshes.
11 unique level-specific modules plus one reusable 5 V supply = 12 FBXs and one assembled FBX.
Y-up, art face toward local -Z, no scripts or fake electronics included.
Autodesk FBX 7.4 Binary + GLB via trimesh, each animation group with named FBX pivot.
"""
from __future__ import annotations
import math, csv, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model,PALETTE,export_fbx,export_glb

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models';PREV=ROOT/'Previews';
for d in (MODELS,PREV,ROOT/'Guides'):d.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'ice':(211,239,249,255), 'mint':(43,246,194,255), 'cyanlit':(24,234,254,255),
 'polished':(197,214,226,255), 'bronze':(163,102,51,255), 'brass':(222,164,71,255),
 'blue_dark':(16,51,108,255), 'motor_blue':(19,103,197,255),'ceramic':(228,227,211,255),
 'holo':(60,166,226,110),'darkglass':(22,84,111,120), 'orangehot':(255,125,48,255),
 'magenta':(221,76,207,255),'warningdark':(91,42,18,255), 'black':(7,13,25,255),
 'nickel':(161,182,196,255),'silver':(184,198,210,255), 'shadow':(9,20,33,255),
 'violet':(134,107,233,255),'lime':(118,250,110,255),'lightamber':(255,214,144,255),
 'coolgrey':(95,119,139,255),'fabric':(51,86,95,255),'fabriclight':(75,123,128,255),
 'insulation':(21,43,56,255), 'purple':(195,111,247,255), 'amberglass':(248,169,60,115)
})

def label(m,t,text,x,y,z,size=.16,color='ice',maxwidth=None,group='Static'):
 m.text(t,text,size,x,y,z,color,maxwidth=maxwidth,group=group)
def bolt(m,t,x,y,z,axis='y'):
 m.cyl(t+'_Head',.046,.026,(x,y,z),'chrome',axis=axis,sections=12)

def lamp(m,t,x,y,z,color='cyan',group=None):
 group=group or t+'_STATUS_LENS'
 m.cyl(t+'_Seat',.132,.050,(x,y,z),'chrome',sections=24,group=group)
 m.cyl(t+'_Light',.097,.044,(x,y+.033,z),color,sections=24,group=group)
 m.torus(t+'_Halo',.127,.014,(x,y+.050,z),color,axis='y',segments=24,tube_segs=6,group=group)
 m.group_pivots[group]=(x,y,z)

def port(m,t,sid,caption,x,y,z,kind='cyan',maxwidth=.8):
 m.cyl(t+'_'+sid+'_ChromeRim',.168,.080,(x,y,z),'chrome',axis='z',sections=28)
 m.cyl(t+'_'+sid+'_Insulator',.139,.095,(x,y,z-.049),kind,axis='z',sections=28)
 m.cyl(t+'_'+sid+'_Recess',.091,.096,(x,y,z-.103),'void',axis='z',sections=24)
 m.cyl(t+'_'+sid+'_InnerPin',.029,.027,(x,y,z-.147),'gold',axis='z',sections=14)
 m.torus(t+'_'+sid+'_BlueHalo',.152,.014,(x,y,z-.108),kind,axis='z',segments=26,tube_segs=7)
 label(m,t+'_'+sid+'_PortLabel',caption,x,y+.260,z-.147,.118,'ice',maxwidth)
 if sid in m.anchors:raise ValueError('duplicate socket id '+sid)
 m.anchors[sid]=[round(float(x),5),round(float(y),5),round(float(z-.167),5)]

def case(m,t,title,w=4,d=2.6,h=1.5,accent='cyan',subtitle=''):
 m.base(t,w,d,h)
 z=-d/2-.09
 m.bevel(t+'_FrontHeadingPlate',(w-.32,.42,.032),(0,.33+h*.77,z),'void',.027)
 label(m,t+'_MAIN_TITLE',title,0,.33+h*.77,z-.043,.207,'white',w-.50)
 if subtitle:label(m,t+'_Description',subtitle,0,.33+h*.56,z-.044,.111,accent,w-.39)
 m.box(t+'_NeonLidBlade',(w-.63,.027,.052),(0,.32+h+.117,-d/2+.26),accent)
 for x in (-w/2+.16,w/2-.16):
  m.box(t+f'_CaseAccent_{x:+.2f}',(.041,.39,.039),(x,.88,z),'orange')
  for q in (-d/2+.18,d/2-.18):bolt(m,t+f'_CapScrew_{x:.2f}_{q:.2f}',x,.32+h+.084,q)
 return z

def rod(m,t,a,b,r=.05,mat='chrome',group='Static',sections=12):
 m.rod(t,a,b,r,mat,sections=sections,group=group)

def make_supply():
 m=Model('00_L46_5V_Supply');t='L46_SUPPLY'
 z=case(m,t,'5 V REFERENCE',4.0,2.54,1.50,'cyan','REGULATED / SHARED POWER')
 port(m,t,'SUPPLY_PLUS_5V','+ 5 V',-.91,.53,z-.05,'red')
 port(m,t,'SUPPLY_RETURN','RETURN',.91,.53,z-.05,'blue')
 m.bevel(t+'_TopMonitorFrame',(2.61,.12,1.02),(0,2.0,.18),'deep_steel',.035)
 m.bevel(t+'_TopMonitorDisplay_Blank',(2.36,.028,.79),(0,2.080,.18),'screen',.035)
 lamp(m,t+'_PowerOn',1.61,1.88,.82,'green','PowerLamp_VISUAL')
 for i,x in enumerate(np.linspace(-.8,.8,8)):
  m.box(t+f'_VentSlit_{i}',(.09,.024,.22),(x,2.105,.98),'void')
 return m

# Twin brushed DC motors are concentric along +Z with their respective drive rollers.
def make_motor(which):
 master=which=='MASTER';accent='cyan' if master else 'amber';code='M' if master else 'F';prefix='01' if master else '02'
 m=Model(prefix+'_L46_'+which+'Motor');t='L46_'+which+'_MOTOR'
 mov=which+'_MotorShaft_ROTATE_Z';cy=2.20
 m.bevel(t+'_NeopreneShockMount',(3.1,.16,3.00),(0,.15,0),'rubber',.10)
 m.bevel(t+'_CastCradle',(2.98,.25,2.84),(0,.39,0),'mid_steel',.095)
 for x in (-.85,.85):
  m.bevel(t+f'_RibSupport_{x:.2f}',(.35,1.40,2.40),(x,1.12,0),'steel',.07)
  for zz in (-1.10,1.10):bolt(m,t+f'_FootScrew_{x:.2f}_{zz:.2f}',x,.46,zz)
 m.cyl(t+'_BrushedMotorCan',.78,2.35,(0,cy,0),'silver',axis='z',sections=64)
 m.cyl(t+'_RearDriveCap',.80,.29,(0,cy,-1.28),'motor_blue' if master else 'bronze',axis='z',sections=64)
 m.torus(t+'_RearRearHalo',.787,.033,(0,cy,-1.43),accent,axis='z',segments=64)
 m.cyl(t+'_FrontBearing',.65,.11,(0,cy,1.25),'chrome',axis='z',sections=64)
 m.torus(t+'_FrontSeal',.65,.038,(0,cy,1.31),accent,axis='z',segments=50)
 for i,zz in enumerate(np.linspace(-.97,1.05,15)):
  m.torus(t+f'_CoolingFin_{i:02d}',.805,.025,(0,cy,zz),'nickel' if i%3 else 'steel',axis='z',segments=48,tube_segs=7)
 m.cyl(t+'_OutputShaft',.144,1.85,(0,cy,2.05),'chrome',axis='z',sections=34,group=mov)
 m.cyl(t+'_SplinedCoupler',.244,.31,(0,cy,1.59),'nickel',axis='z',sections=28,group=mov)
 for j in range(6):
  a=math.tau*j/6
  m.box(t+f'_CouplerTooth_{j}',(.095,.084,.27),(.23*math.cos(a),cy+.23*math.sin(a),1.58),'gold',group=mov)
 m.group_pivots[mov]=(0,cy,1.25)
 # Front-facing electrical socket fascia is fixed and easy to select during wiring
 m.bevel(t+'_PortFace',(2.50,.60,.15),(0,.79,-1.50),'deep_steel',.05)
 port(m,t,code+'_MOTOR_PLUS','MOTOR +',-.60,.77,-1.60,'red')
 port(m,t,code+'_MOTOR_MINUS','MOTOR -',.60,.77,-1.60,'blue')
 label(m,t+'_RoleMark',which+' / 5 V',0,.38,-1.615,.155,accent,2.2)
 for k in range(4):
  m.bevel(t+f'_RearVentFin_{k}',(.095,.35,.06),(-.46+k*.30,cy,-1.49),'void',.015)
 return m

def make_roller(which):
 master=which=='MASTER';ac='cyan' if master else 'orange';prefix='03' if master else '04'
 m=Model(prefix+'_L46_'+which+'Roller');t='L46_'+which+'_ROLLER'
 g=which+'_Roller_ROTATE_Z';cy=2.20;z=0
 # two visible end-bearing pillow blocks, under the roller along Z
 m.bevel(t+'_BottomMachinedFoot',(2.76,.19,5.12),(0,.16,0),'rubber',.11)
 m.bevel(t+'_BearingBase',(2.65,.29,4.98),(0,.40,0),'mid_steel',.09)
 for zz in (-2.30,2.30):
  m.bevel(t+f'_PillowBearing_{zz:+.1f}',(1.85,1.63,.43),(0,1.19,zz),'steel',.12)
  m.cyl(t+f'_BearingRecess_{zz:+.1f}',.315,.11,(0,cy,zz),'void',axis='z',sections=40)
  m.torus(t+f'_BearingSeal_{zz:+.1f}',.365,.040,(0,cy,zz),'chrome',axis='z',segments=38)
  for x in (-.75,.75):bolt(m,t+f'_PillowBolt_{zz:+.1f}_{x:+.2f}',x,.57,zz)
 # rotor drum and traction surface independent rotation group
 m.cyl(t+'_CastAlloyRollerCore',.90,4.19,(0,cy,0),'silver',axis='z',sections=72,group=g)
 m.cyl(t+'_RubberizedDrum',.855,3.64,(0,cy,0),'insulation',axis='z',sections=72,group=g)
 for i,zz in enumerate(np.linspace(-1.70,1.70,32)):
  m.torus(t+f'_GripRib_{i:02d}',.861,.019,(0,cy,zz),'coolgrey' if i%4 else ac,axis='z',segments=42,tube_segs=6,group=g)
 for zz in (-1.94,1.94):
  m.torus(t+f'_BilletFlange_{zz:+.2f}',.929,.085,(0,cy,zz),'chrome',axis='z',segments=54,tube_segs=8,group=g)
  m.torus(t+f'_ColoredRim_{zz:+.2f}',.915,.041,(0,cy,zz),ac,axis='z',segments=52,tube_segs=8,group=g)
 m.cyl(t+'_ThroughAxle',.185,5.64,(0,cy,0),'chrome',axis='z',sections=32,group=g)
 m.group_pivots[g]=(0,cy,0)
 for i in (-1,1):
  m.bevel(t+f'_FrontNameBadge_{i}',(1.65,.32,.085),(0,.56,i*2.12),'void',.022)
 if master:
  label(m,t+'_RollerName','MASTER ROLLER',0,.56,-2.172,.135,'cyan',1.51)
 else:
  label(m,t+'_RollerName','FOLLOWER ROLLER',0,.56,-2.172,.130,'orange',1.51)
 return m

def make_web():
 m=Model('05_L46_TransportWeb');t='L46_WEB';g='TransportWeb_SCROLL_UV'
 # Two high-contrast belts forming one continuous-looking material strip around the two drums.
 m.box(t+'_UpperCarbonWeb',(11.45,.066,3.42),(0,3.09,0),'fabric',group=g)
 m.box(t+'_UpperFrostedWeave',(11.28,.016,3.27),(0,3.140,0),'fabriclight',group=g)
 m.box(t+'_LowerReturnWeb',(11.46,.060,3.44),(0,1.31,0),'insulation',group=g)
 for i,xx in enumerate(np.linspace(-5.2,5.2,34)):
  m.box(t+f'_Web_GripSeam_{i:02d}',(.064,.014,3.23),(xx,3.16,0),'steel' if i%5 else 'cyan',group=g)
 for zz in (-1.67,1.67):
  m.box(t+f'_RaisedEdgeLine_{zz:+.2f}',(11.28,.027,.055),(0,3.168,zz),'mint',group=g)
 for i in range(6):
  x=-4.70+i*1.84
  m.box(t+f'_InspectionStrip_{i}',(.52,.033,2.42),(x,3.177,0),'silver' if i%2 else 'titanium',group=g)
  for zz in (-.78,.78):
   m.box(t+f'_StripMarker_{i}_{zz}',(.08,.013,.17),(x,3.20,zz),'orange' if i>2 else 'cyan',group=g)
 m.group_pivots[g]=(0,0,0)
 # Stationary isolated clear guide rails: no false mechanical bridge
 for zz in (-1.89,1.89):
  m.box(t+f'_WebGuide_{zz:+.2f}',(11.80,.30,.10),(0,3.03,zz),'glass')
  m.box(t+f'_WebGuideCyanRail_{zz:+.2f}',(11.80,.035,.10),(0,3.21,zz),'cyan')
 return m

def make_encoders():
 m=Model('06_L46_EncoderPair');t='L46_ENCODERS';cy=2.20
 # Encoder discs sit on back ends of each roller; dual optical pickups remain fixed.
 for who,x,ac in [('MASTER',5.5,'cyan'),('FOLLOWER',-5.5,'orange')]:
  g=who+'_EncoderDisc_ROTATE_Z'
  m.cyl(t+'_'+who+'_EncoderDisc',.65,.11,(x,cy,2.71),'graphite',axis='z',sections=60,group=g)
  m.torus(t+'_'+who+'_DiscEdge',.647,.032,(x,cy,2.78),ac,axis='z',segments=60,group=g)
  m.torus(t+'_'+who+'_InnerRing',.439,.029,(x,cy,2.79),'chrome',axis='z',segments=48,group=g)
  for k in range(20):
   a=math.tau*k/20
   px=x+.54*math.cos(a);py=cy+.54*math.sin(a)
   m.cyl(t+f'_{who}_OpticalSlot_{k:02d}',.046,.012,(px,py,2.787),'ice' if k%2 else ac,axis='z',sections=10,group=g)
  for k in range(80):
   a=math.tau*k/80
   px=x+.625*math.cos(a);py=cy+.625*math.sin(a)
   m.cyl(t+f'_{who}_Graduation_{k:02d}',.009,.012,(px,py,2.788),'gold' if k%10==0 else 'cyan',axis='z',sections=6,group=g)
  m.cyl(t+'_'+who+'_SpinHub',.19,.17,(x,cy,2.81),'chrome',axis='z',sections=36,group=g)
  m.group_pivots[g]=(x,cy,2.70)
  # Fixed fork read head in front of optical disc; each has A/B indication
  m.bevel(t+'_'+who+'_SensorMount',(1.50,.45,.54),(x,.70,3.01),'mid_steel',.06)
  m.bevel(t+'_'+who+'_SensorUpright',(.22,1.62,.25),(x+.69,1.54,2.94),'polished',.035)
  m.bevel(t+'_'+who+'_OpticalFork',(.39,.25,.74),(x+.49,2.55,2.93),'deep_steel',.040)
  for side,yy in [('A',2.49),('B',2.64)]:
   m.cyl(t+'_'+who+'_'+side+'_SensorLight',.060,.06,(x+.43,yy,2.55),ac,axis='z',sections=18)
 # Front-facing 4-port distribution box positioned behind the web
 z=case(m,t+'_IO','ENCODER A/B FEEDBACK',6.25,1.8,1.35,'mint','80 COUNTS / REV     TWO CHANNEL PAIRS')
 # Move box back in Z to prevent intersection with belt (local z=4.7); move its geometry
 # Scene correction: original case geometry is at origin; relocate case-only parts +4.65Z
 for p in m.parts:
  if p.name.startswith(t+'_IO'):
   p.mesh.apply_translation((0,0,4.55))
 for k,sid,cap,ac in [(-2.22,'MASTER_ENC_A','MASTER A','cyan'),(-.74,'MASTER_ENC_B','MASTER B','mint'),(.74,'FOLLOWER_ENC_A','FOLLOW A','orange'),(2.22,'FOLLOWER_ENC_B','FOLLOW B','amber')]:
  port(m,t,sid,cap,k,.49,4.55+z-.075,ac,maxwidth=1.29)
 return m

def make_driver():
 m=Model('07_L46_DualMotorDriver');t='L46_DRIVER';z=case(m,t,'DUAL PWM H-BRIDGE',7.65,2.62,1.9,'orange','INDEPENDENT MASTER / FOLLOWER DRIVE')
 # six ports in two rows, with 3 per row
 for yy,data in [(1.03,[('DRIVER_MASTER_PWM','M PWM','cyan'),('DRIVER_MASTER_PLUS','M +','red'),('DRIVER_MASTER_MINUS','M -','blue')]),(.45,[('DRIVER_FOLLOWER_PWM','F PWM','orange'),('DRIVER_FOLLOWER_PLUS','F +','red'),('DRIVER_FOLLOWER_MINUS','F -','blue')])]:
  for x,(sid,lbl_,co) in zip((-2.32,0,2.32),data):port(m,t,sid,lbl_,x,yy,z-.075,co,maxwidth=1.36)
 for side,x,col in [('MASTER',-1.76,'cyan'),('FOLLOWER',1.76,'orange')]:
  m.bevel(t+'_'+side+'_HeatsinkFoot',(2.72,.14,1.61),(x,2.53,.02),'titanium',.03)
  for j,xx in enumerate(np.linspace(-1.10,1.1,10)):
   m.box(t+f'_{side}_AnodizedFin_{j}',(.105,.49,1.45),(x+xx,2.82,.03),'steel' if j%2 else 'nickel')
  lamp(m,t+'_'+side+'_LiveLamp',x,2.98,-.97,col,side+'_DRIVE_ON_LENS')
 return m

def make_controller():
 m=Model('08_L46_SyncController');t='L46_CTRL';z=case(m,t,'MASTER / FOLLOWER',9.85,3.19,1.90,'cyan','SYNC GOVERNOR   /   30 RPM   /   60 RPM')
 # 8 actual sockets: controller power +/-; 2 PWM out; 4 encoder inputs, 2 rows x 4 columns
 rows=[(1.04,[('CTRL_PLUS_5V','+ 5V','red'),('CTRL_MASTER_PWM','M PWM','cyan'),('CTRL_FOLLOWER_PWM','F PWM','orange'),('CTRL_GND','GND','blue')]),
       (.44,[('CTRL_MASTER_A','M A','mint'),('CTRL_MASTER_B','M B','cyan'),('CTRL_FOLLOWER_A','F A','orange'),('CTRL_FOLLOWER_B','F B','amber')])]
 for yy,ports in rows:
  for x,(sid,lab,co) in zip((-3.44,-1.14,1.14,3.44),ports):port(m,t,sid,lab,x,yy,z-.08,co,maxwidth=1.26)
 # blank top LCD faces intentionally ready for Unity live TextMeshPro, not static readings
 for s,x,co in [('MASTER',-2.37,'cyan'),('FOLLOWER',2.37,'orange')]:
  m.bevel(t+'_'+s+'_TopDisplayMount',(3.92,.17,1.26),(x,2.53,.23),'steel',.052)
  m.bevel(t+'_'+s+'_BlankLiveScreen',(3.65,.027,1.07),(x,2.63,.23),'screen',.047)
  m.box(t+'_'+s+'_TopScreenGlow',(3.57,.015,.044),(x,2.646,-.26),co)
  lamp(m,t+'_'+s+'_SyncOK',x-1.25,2.33,-1.14,'green',s+'_SYNC_OK_LENS')
 for x,cap,co in [(-.81,'30','cyan'),(.81,'60','orange')]:
  g='SET_'+cap+'_RPM_BUTTON_ANIMATE'
  m.cyl(t+'_Preset_'+cap+'_Bezel',.25,.12,(x,2.19,1.15),'chrome',sections=24)
  m.cyl(t+'_Preset_'+cap+'_PushCap',.20,.115,(x,2.27,1.15),co,sections=24,group=g)
  m.group_pivots[g]=(x,2.19,1.15)
 return m

def make_brake():
 m=Model('09_L46_FollowerBrake');t='L46_FOLLOWER_BRAKE'
 m.bevel(t+'_NeopreneMount',(3.12,.18,3.66),(0,.11,0),'rubber',.13)
 m.bevel(t+'_SteelStand',(2.91,.25,3.51),(0,.35,0),'mid_steel',.11)
 m.bevel(t+'_CaliperSupport',(.35,1.77,1.17),(.82,1.36,.61),'steel',.09)
 m.bevel(t+'_AcrylicHousing',(2.2,.28,2.7),(0,1.56,0),'deep_steel',.055)
 rotor='FollowerBrakeRotor_ROTATE_Z'; arm='FollowerBrakeArm_ROTATE_Y'; pad='FollowerBrakePad_TRANSLATE_X'
 m.cyl(t+'_RotatingBrakeDisc',.76,.24,(-.13,2.20,.36),'nickel',axis='z',sections=64,group=rotor)
 m.torus(t+'_BrakeDiscAmberEdge',.75,.044,(-.13,2.20,.52),'orange',axis='z',segments=62,group=rotor)
 for j in range(18):
  a=math.tau*j/18
  m.cyl(t+f'_BrakeVent_{j:02d}',.034,.014,(-.13+.55*math.cos(a),2.20+.55*math.sin(a),.502),'void',axis='z',sections=9,group=rotor)
 m.group_pivots[rotor]=(-.13,2.2,.36)
 m.bevel(t+'_BrakeActuatorBody',(.77,.73,.57),(.82,2.54,.25),'titanium',.07)
 m.box(t+'_MovableFrictionPad',(.21,.51,.68),(.47,2.28,.25),'ceramic',group=pad)
 m.box(t+'_OrangePadBack',(.11,.57,.73),(.61,2.28,.25),'orange',group=pad)
 m.group_pivots[pad]=(.58,2.28,.25)
 m.cyl(t+'_HandleAxle',.19,.28,(.92,2.99,-.25),'chrome',axis='x',sections=22)
 rod(m,t+'_BrakingLever',(.92,2.98,-.25),(.92,3.86,-.10),.075,'gold',group=arm)
 m.cyl(t+'_LoadGrip',.15,.34,(.92,3.90,-.10),'rubber',sections=24,group=arm)
 m.group_pivots[arm]=(.92,2.99,-.25)
 lamp(m,t+'_LoadWarning',-1.03,.81,-1.25,'orange','LoadBrakeWarning_VISUAL')
 label(m,t+'_ModelName','FOLLOWER LOAD BRAKE',0,.71,-1.87,.161,'white',2.6)
 return m

def make_tension():
 m=Model('10_L46_TensionMonitor');t='L46_TENSION';z=case(m,t,'WEB TENSION',5.35,2.60,1.9,'mint','SLACK  /  NOMINAL  /  OVER-TENSION')
 # decorative LED visual display, no electrical sockets
 m.bevel(t+'_TopMonitorFrame',(4.23,.13,1.33),(0,2.64,.15),'nickel',.042)
 m.bevel(t+'_BlankGaugeScreen',(3.96,.027,1.1),(0,2.728,.15),'screen',.032)
 for j in range(19):
  x=-1.67+j*.186
  m.box(t+f'_TensionBar_{j:02d}',(.12,.021,.11+.57*max(0,1-abs(j-9)/10)),(x,2.746,.13),'cyan' if j<11 else 'orange')
 for j,(lab,co) in enumerate([('SYNC','green'),('SLACK','amber'),('STOP','red')]):
  lamp(m,t+'_'+lab,-1.44+j*1.44,2.22,-.96,co,lab+'_WarningLens')
 label(m,t+'_Note','VISUAL ONLY / LIVE UI OVERLAY',0,1.05,z-.04,.124,'ice',4.6)
 return m

def make_frame():
 m=Model('11_L46_IndustrialFrame');t='L46_FRAME'
 # Only machine frame. Large workbench is a separate showcase helper.
 m.bevel(t+'_NeopreneShockMat',(18.65,.18,8.66),(0,.10,0),'rubber',.15)
 m.bevel(t+'_CastAlloyMachineBase',(18.48,.27,8.46),(0,.31,0),'steel',.12)
 m.bevel(t+'_CarbonMachinedDeck',(18.22,.115,8.23),(0,.54,0),'graphite',.12)
 for x in (-8.87,8.87):m.box(t+f'_SafetyStripe_{x:+.1f}',(.052,.055,8.08),(x,.615,0),'orange')
 for zz in (-4.00,4.00):m.box(t+f'_CyanEdgeStrip_{zz:+.1f}',(17.81,.046,.065),(0,.615,zz),'cyan')
 for x in (-7.40,7.40):
  for zz in (-3.4,3.4):bolt(m,t+f'_FoundationHexBolt_{x:.1f}_{zz:.1f}',x,.614,zz)
 for x in (-5.5,5.5):
  for zz in (-2.25,2.25):
   m.bevel(t+f'_IsolatedRollerMount_{x:+.1f}_{zz:+.1f}',(2.12,.15,.86),(x,.75,zz),'titanium',.05)
 # visible structural T-slots and fasteners are distinct from rolling web
 for zz in (-2.71,2.71):
  m.box(t+f'_MountingRail_{zz:+.1f}',(17.18,.12,.30),(0,.73,zz),'mid_steel')
  m.box(t+f'_TSlotBlack_{zz:+.1f}',(16.72,.018,.068),(0,.80,zz),'void')
 for xx in np.linspace(-7.5,7.5,14):
  m.box(t+f'_SkeletonCrossbeam_{xx:+.2f}',(.22,.11,5.88),(xx,.67,0),'steel')
 for x,lab,col in [(5.5,'MASTER','cyan'),(-5.5,'FOLLOWER','orange')]:
  m.bevel(t+'_'+lab+'_Nameplate',(3.06,.05,.36),(x,.811,-3.53),'void',.02)
  label(m,t+'_'+lab+'_RoleName',lab,x,.835,-3.75,.182,col,2.85)
 return m

def showcase_tray():
 m=Model('ART_ONLY_L46_ShowcaseBench');t='L46_BENCH'
 m.bevel(t+'_NeopreneBorder',(32.3,.18,21.8),(0,.10,0),'rubber',.13)
 m.bevel(t+'_ForgedAlloyWorkbench',(32.05,.23,21.55),(0,.28,0),'steel',.13)
 m.bevel(t+'_RibbedCarbonTable',(31.79,.07,21.29),(0,.44,0),'graphite',.105)
 for z in (-10.27,10.27):m.box(t+f'_FrontCyanRail_{z:.2f}',(30.98,.045,.059),(0,.491,z),'cyan')
 for x in (-15.38,15.38):m.box(t+f'_SideOrangeRail_{x:.2f}',(.055,.040,20.21),(x,.491,0),'orange')
 # empty sockets along the near edge are decorative; real player endpoints in manifests
 for j,xx in enumerate(np.linspace(-14.9,14.9,45)):
  for zz in (-9.51,-9.17,-8.83):
   m.cyl(t+f'_BreadboardHole_{j:02d}_{zz:.2f}',.022,.014,(xx,.496,zz),'void',sections=8)
 return m

BUILDERS=[make_supply,lambda:make_motor('MASTER'),lambda:make_motor('FOLLOWER'),
          lambda:make_roller('MASTER'),lambda:make_roller('FOLLOWER'),make_web,
          make_encoders,make_driver,make_controller,make_brake,make_tension,make_frame]
POS={
 'ART_ONLY_L46_ShowcaseBench':(0,0,0),
 '00_L46_5V_Supply':(-12.90,0,5.9),
 '01_L46_MASTERMotor':(5.5,0,-5.0),
 '02_L46_FOLLOWERMotor':(-5.5,0,-5.0),
 '03_L46_MASTERRoller':(5.5,0,0),
 '04_L46_FOLLOWERRoller':(-5.5,0,0),
 '05_L46_TransportWeb':(0,0,0),
 '06_L46_EncoderPair':(0,0,0),
 '07_L46_DualMotorDriver':(0,0,-7.75),
 '08_L46_SyncController':(3.8,0,7.38),
 '09_L46_FollowerBrake':(-7.65,0,.15),
 '10_L46_TensionMonitor':(-7.10,0,7.22),
 '11_L46_IndustrialFrame':(0,0,0)
}
WIRES=[
 ('W01','SUPPLY_PLUS_5V','CTRL_PLUS_5V','Power supply +5 V to sync controller +5 V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Power return to sync controller GND'),
 ('W03','CTRL_MASTER_PWM','DRIVER_MASTER_PWM','Controller master PWM to driver master PWM'),
 ('W04','CTRL_FOLLOWER_PWM','DRIVER_FOLLOWER_PWM','Controller follower PWM to driver follower PWM'),
 ('W05','DRIVER_MASTER_PLUS','M_MOTOR_PLUS','Driver master positive to master motor positive'),
 ('W06','DRIVER_MASTER_MINUS','M_MOTOR_MINUS','Driver master negative to master motor negative'),
 ('W07','DRIVER_FOLLOWER_PLUS','F_MOTOR_PLUS','Driver follower positive to follower motor positive'),
 ('W08','DRIVER_FOLLOWER_MINUS','F_MOTOR_MINUS','Driver follower negative to follower motor negative'),
 ('W09','MASTER_ENC_A','CTRL_MASTER_A','Master encoder A to controller master A'),
 ('W10','MASTER_ENC_B','CTRL_MASTER_B','Master encoder B to controller master B'),
 ('W11','FOLLOWER_ENC_A','CTRL_FOLLOWER_A','Follower encoder A to controller follower A'),
 ('W12','FOLLOWER_ENC_B','CTRL_FOLLOWER_B','Follower encoder B to controller follower B; last wire for A/B swap test')
]

def build():
 models=[fn() for fn in BUILDERS]
 assert len(models)==12
 ids=[sid for m in models for sid in m.anchors]
 assert len(ids)==24 and len(set(ids))==24,(len(ids), ids)
 assert len(WIRES)==12 and {n for _,a,b,_ in WIRES for n in (a,b)}==set(ids)
 assert len(POS)==13 and all(m.key in POS for m in models)
 report={}
 for i,m in enumerate(models):
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m])
  assert fbx.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  s=trimesh.load_scene(glb);assert len(s.geometry)>0
  tris=sum(len(p.mesh.faces) for p in m.parts)
  report[m.key]={'fbx':fbx.name,'glb':glb.name,'triangles':int(tris),'mesh_parts':len(m.parts),
                 'art_sockets':m.anchors,'animation_pivots':m.group_pivots,
                 'named_groups':list(dict.fromkeys(p.group for p in m.parts))}
  print('MODEL',i,m.key,'tri',tris,'meshes',len(m.parts),'sockets',len(m.anchors),flush=True)
 showcase=[showcase_tray()]+models
 name='Level46_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(name+'.fbx'),showcase,positions=POS)
 export_glb(MODELS/(name+'.glb'),showcase,positions=POS)
 loaded=trimesh.load_scene(MODELS/(name+'.glb'));assert len(loaded.geometry)>0
 total=int(sum(len(p.mesh.faces) for m in showcase for p in m.parts))
 manifest={'level':46,'title':'Keep in Step','subtitle':'Dual Motor Synchronization',
   'models_count':len(models),'unique_level_specific_models':11,'reusable_supply_models':1,
   'player_wires':12,'unique_electrical_sockets':24,'encoder_counts_per_revolution':80,
   'target_rpm':[30,60],'art_scale':'relative Unity units, Y up, -Z front; scale during prefab integration',
   'scope':'AAA-style semi-HD 3D visual assets only; no authoritative motor control/solver modifications',
   'models':report,'positions':POS,'showcase':{'name':name,'triangles':total},'wires':WIRES,
   'preinstalled_connections':'dual-driver electrical feed and both encoder sensor power are gameplay implementation dependencies, not additional player wires',
   'wiring_fault_order':'Connect W11 then W12 last, so Undo Last twice removes follower A/B for swap challenge'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['FBX model','ArtSocketID','LocalX','LocalY','LocalZ','Unity action'])
  for m in models:
   for sid,(x,y,z) in m.anchors.items():w.writerow([m.key+'.fbx',sid,x,y,z,'Move a real SparkTerminal to the proper hole in your layout; model meshes are visual-only'])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['wire','from_art_id','to_art_id','purpose']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['FBX model','VisualGroupName','PivotLocalX','PivotLocalY','PivotLocalZ','suggested motion'])
  for m in models:
   for name,(x,y,z) in m.group_pivots.items():
    hint=('rotate +Z' if ('Roller_ROTATE_Z' in name or 'EncoderDisc_ROTATE_Z' in name or 'MotorShaft_ROTATE_Z' in name or 'BrakeRotor_ROTATE_Z' in name)
         else 'position/color animation; see README')
    w.writerow([m.key+'.fbx',name,x,y,z,hint])
 summary=f'''PROJECT SPARK — LEVEL 46 / KEEP IN STEP\n\n{len(models)} individual binary FBX models, {len(models)} GLB alternatives, 1 assembled FBX + GLB.\n{total:,} total triangles (assembled showcase including decorative bench).\n{len(ids)} distinct player-terminal art positions / {len(WIRES)} exact wires.\n\nThe 5V supply is included as a reusable, matching Level45-style asset; 11 other models are Level46-specific.\nMotor, rollers, encoder discs and brake rotor have independent named rotation groups.\nNo electrical solver code or gameplay system is included.\n\nUnity wiring: W01-W12 in Exact_Wiring.csv. Add W11 and W12 last.\n\nShared power distribution of dual driver and encoder pair must be implemented with real fixed circuit connections.\nAll screens are art; assign real TMPro values from your game's simulation.\n'''
 (ROOT/'VALIDATION.txt').write_text(summary)
 print('COMPLETE',total,'triangles',len(ids),'sockets',len(WIRES),'wires',flush=True)
 return models,showcase

if __name__=='__main__':build()
