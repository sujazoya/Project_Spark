PROJECT SPARK / LEVEL 46 — KEEP IN STEP
AAA-INSPIRED POLISHED SEMI-HD UNITY ART PACK
====================================================

WHAT IS INCLUDED
----------------
12 individual FBX models + 12 matching GLB models:
- One reusable 5V reference supply
- Eleven unique Level 46 components
- One complete 3D showcase FBX/GLB (includes a decorative display bench)
Plus rendered previews, procedural source, manifests and a visual-only Unity helper.
All screens are blank ready for live TextMeshPro values.

INDIVIDUAL FBX ASSETS
---------------------
00_L46_5V_Supply.fbx                  reusable 5V power supply
01_L46_MASTERMotor.fbx                cyan master motor with rotating shaft
02_L46_FOLLOWERMotor.fbx              amber follower motor with rotating shaft
03_L46_MASTERRoller.fbx               master roller + rubber ribs, bearing blocks
04_L46_FOLLOWERRoller.fbx             follower roller + rubber ribs, bearing blocks
05_L46_TransportWeb.fbx               gripping/inspection transport web
06_L46_EncoderPair.fbx                two optical encoder discs, A/B read heads, 4 ports
07_L46_DualMotorDriver.fbx            6-port dual PWM H-bridge driver
08_L46_SyncController.fbx             8-port sync governor, dual blank screens
09_L46_FollowerBrake.fbx              movable follower brake with rotating rotor
10_L46_TensionMonitor.fbx             visual live tension indicator, no electrical sockets
11_L46_IndustrialFrame.fbx            machined mechanical frame and mounting skids

File `Level46_Complete_ArtKit_Showcase.fbx` is a REFERENCE ASSEMBLY.
Do not use both individual models and the showcase simultaneously in the game scene.

INSTALL INTO UNITY
------------------
1. Extract the ZIP into a staging folder on your computer.
2. Copy Models/*.fbx into:
   Assets/My_Assets/_Project_Spark/Models/Level46/
3. Choose one model in Unity > Model Inspector > Materials.
   Prefer Extract Materials or remap imported Phong materials to your URP/HDRP shader.
   Models use per-material color separation, but the FBX does not embed textures.
4. Create a new Level_46_Layout prefab with an empty 3D art group.
5. Position individual FBXs using `Model_Manifest.json` POSITIONS as a relative
   example, then scale and move everything to your real board coordinates.
6. Set rotation/pivots by locating the animated mesh groups in `Animation_Rigs.csv`.
7. Configure actual SparkTerminal components with your real circuit system.
   `Terminal_Anchors.csv` lists art-space socket centers, NOT registered aliases.
   Place each terminal flush on a breadboard hole, not floating inside the FBX.
8. Assign exact wire endpoints from `Exact_Wiring.csv` and level binding IDs.
   Use W11, W12 LAST, so Undo Last twice targets follower encoder A/B.
9. Add `SparkLevel46VisualRig` (optional) to the Level46 art root and assign
   the seven rotating transform groups, brake lever/pad, and TMP fields.
10. Feed the visual rig via ApplyReadings(...) from your authentic dual-motor
    simulator. This helper never writes solved electrical readings or objectives.

VISUAL MOTION GROUPS
--------------------
MASTER_MotorShaft_ROTATE_Z
FOLLOWER_MotorShaft_ROTATE_Z
MASTER_Roller_ROTATE_Z
FOLLOWER_Roller_ROTATE_Z
MASTER_EncoderDisc_ROTATE_Z
FOLLOWER_EncoderDisc_ROTATE_Z
FollowerBrakeRotor_ROTATE_Z
FollowerBrakeArm_ROTATE_Y
FollowerBrakePad_TRANSLATE_X
TransportWeb_SCROLL_UV  (surface graphics; needs a textured Unity shader for UV scroll)

The supply/driver/controller sockets remain FIXED even while animation runs.
Rotation groups all use local positive Z (shaft axis); do not rotate the entire FBX.
Master and follower motor +/− terminals are separate. Encoder A/B is always
reported by true simulation, not by the rendered spinning hardware.

SOCKETS / WIRING
----------------
12 exact player wires, 24 distinct art socket IDs.
See `Exact_Wiring.csv` and `Terminal_Anchors.csv` for the authoritative art map.
Reused power sockets are only those explicitly listed by your gameplay logic.
Dual driver power and encoder internal power are intended fixed/prewired
connections; this art pack does not create real internal electrical links.

SAFETY AND LIMITATIONS
----------------------
- This is a 3D visual asset pack, NOT a runnable electrical motor simulator.
- The game must provide two legitimate independent motor models, encoders,
  governor, speed/tension measurements and safety shutdown.
- Existing game objectives and level evaluator are NOT modified here.
- Models were exported and verified as 3D geometry; Unity project import,
  shaders, animations, and circuit wiring must be tested locally.
- FBX is Autodesk FBX binary v7.4; Y up, X across, negative Z is model front.
- 1 3D unit is relative: rescale to your level and hardware dimensions.

STYLE TIPS
----------
Choose URP Lit Metallic or HDRP Lit. Dark housing metallic 0.65, smoothness 0.70;
chrome metallic 0.95, smoothness 0.92; brushed aluminum 0.75/0.72;
cyan/amber status rings emit at 1.0-2.0 HDR intensity. Prefer a subtle bloom,
one area light and a 3-point product lighting setup. Keep displays blank behind
world-space TMPro canvases, and avoid excessive bloom hiding socket labels.

SOURCE AND PREVIEW FILES
------------------------
Sources/build_level46_models.py    reproducible procedural geometry + FBX/GLB
Sources/spark_model_core.py        direct binary FBX 7.4 export support
Sources/render_level46_previews.py actual geometry renders (VTK)
Previews/Level46_Complete_12Piece_Kit_Preview.png
Previews/Level46_All_12_Models_ContactSheet.png
Model_Manifest.json
Animation_Rigs.csv
Terminal_Anchors.csv
Exact_Wiring.csv
Unity_Optional/SparkLevel46VisualRig.cs
