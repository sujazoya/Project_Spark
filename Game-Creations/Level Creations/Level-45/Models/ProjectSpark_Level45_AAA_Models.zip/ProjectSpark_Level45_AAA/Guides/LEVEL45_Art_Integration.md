# Level 45 — Hold the Speed: Art Integration

This package contains **nine 3D art assets**, not the electrical solver or gameplay system. Use the **individual FBXs** for gameplay; the assembled FBX is a display/placement reference only.

## Assembly hierarchy

```text
Level_45_Layout
  MechanicalRig
    L45_IndustrialBase   [FixedMachineBed, DrivetrainAxle_ROTATE_X_ANIMATE]
    L45_DCMotor          [MotorShaft_ROTATE_X_ANIMATE]
    L45_EncoderFlywheel  [Flywheel_ROTATE_X_ANIMATE]
    L45_LoadBrake        [BrakeRotor_ROTATE_X_ANIMATE, BrakeArm_ROTATE_Y_ANIMATE, BrakePad_TRANSLATE_Z_ANIMATE]
    L45_OpticalReadHead  [Encoder_A_PULSE_VISUAL, Encoder_B_PULSE_VISUAL]
  ElectricalModules
    L45_5V_Supply        [+5V, GND art socket anchors]
    L45_SpeedController  [+5V, GND, ENC A, ENC B, PWM OUT]
    L45_MotorDriver      [+5V, GND, PWM IN, MOTOR+, MOTOR-]
    L45_RPMMonitor       [visual-only]
```

### Important links

- `Terminal_Anchors.csv` gives the **16** art socket centers in each individual model's local coordinates.
- `Exact_Wiring.csv` records the **nine** player connections, with shared +5V and GND ports.
- `Animation_Rigs.csv` gives FBX animation group names and pivots.
- `SparkLevel45VisualRig.cs` animates only the mesh. **Supply real measured RPM** from your actual encoder/controller.

### Status behaviors

- Running normally: controller/monitor display **TARGET 030/060**, **ACTUAL RPM**, **PWM**.
- Brake pressed: amber **LOAD** indicator, actual RPM initially falls, then the real controller regulates back.
- Encoder B removed: red **FAULT**, driver must be disabled by gameplay code, not by the animation script.
- Repair: reconnect encoder B, reset test as specified by Level45 observer, resume valid speed control.

Do not interpret the PNGs or FBXs as an electrical connection graph. Art does not create solver nodes.
