"""Project Spark — LEVEL 45 Hold the Speed.
Nine actual color-separated FBX 7.4 binary & GLB models: closed-loop motor speed governor.
AAA-inspired polished semi-HD procedural geometry. Y up, sockets face -Z, arbitrary Unity scale.
Motors, speed regulator and 9-wire loop are *ART ONLY*. Do not infer SparkTerminal bindings.
"""
from __future__ import annotations
import math, csv, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb

ROOT=Path(__file__).resolve().parents[1]; MODELS=ROOT/'Models';P=ROOT/'Previews'
for d in [MODELS,P,ROOT/'Guides']:d.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'ice':(211,241,250,255),'mint':(43,247,193,255),'cyanlit':(35,246,255,255),
 'polished':(211,225,235,255),'bronze':(165,103,47,255),'brass':(226,163,58,255),
 'blue_dark':(16,56,106,255),'motor_blue':(20,99,200,255),'ceramic':(223,227,214,255),
 'holo':(67,161,220,75),'darkglass':(22,77,103,120),'orangehot':(255,126,46,255),
 'magenta':(244,67,197,255),'warningdark':(101,45,16,255),'black':(7,14,26,255),
 'nickel':(146,176,194,255),'rubberblue':(20,42,60,255),'silver':(184,199,212,255),
 'shadow':(9,20,32,255), 'violet':(142,107,238,255),'lime':(110,250,108,255),
 'lightamber':(255,215,137,255), 'coolgrey':(91,113,132,255)
})

REV_COUNTS=80
SPEEDS=(30,60)

def lbl(m,tag,s,x,y,z,size=.16,col='white',width=None,group='Static'):
 m.text(tag,s,size,x,y,z,col,maxwidth=width,group=group)

def bolt(m,tag,x,y,z,axis='y'):
 m.cyl(tag+'_ScrewHead',.057,.027,(x,y,z),'chrome',axis=axis,sections=14)
 if axis=='y':m.box(tag+'_Slot',(.068,.005,.016),(x,y+.022,z),'mid_steel')
 else:m.box(tag+'_Slot',(.068,.011,.005),(x,y,z-.023),'mid_steel')

def top_lamp(m,t,x,y,z,col='cyan',group=None):
 g=group or (t+'_LAMP_VISUAL')
 m.cyl(t+'_Skirt',.155,.055,(x,y,z),'chrome',sections=28,group=g)
 m.cyl(t+'_Lens',.110,.065,(x,y+.035,z),col,sections=28,group=g)
 m.torus(t+'_Rim',.138,.014,(x,y+.061,z),'polished',axis='y',segments=28,tube_segs=6,group=g)
 return g

def socket(m,tag,id_,name,x,y,z,color='cyan',label_y=None):
 m.cyl(tag+'_'+id_+'_Socket_MetalThread',.183,.09,(x,y,z+.016),'chrome',axis='z',sections=32)
 m.cyl(tag+'_'+id_+'_Insulator',.146,.095,(x,y,z-.047),color,axis='z',sections=28)
 m.cyl(tag+'_'+id_+'_DarkBore',.098,.099,(x,y,z-.104),'void',axis='z',sections=30)
 m.cyl(tag+'_'+id_+'_Contact',.031,.03,(x,y,z-.147),'gold',axis='z',sections=16)
 m.torus(tag+'_'+id_+'_GlowRim',.158,.013,(x,y,z-.11),color,axis='z',segments=32,tube_segs=6)
 lbl(m,tag+'_'+id_+'_Socket_Label',name,x,(y+.29 if label_y is None else label_y),z-.16,.122,'ice',.80)
 if id_ in m.anchors:raise ValueError('Duplicate art anchor: '+id_)
 m.anchors[id_]=[round(x,4),round(y,4),round(z-.169,4)]

def case(m,t,name,w=4,d=2.55,h=1.60,accent='cyan',subtitle=''):
 m.base(t,w,d,h)
 f=-d/2-.08
 m.bevel(t+'_Inset_Title_Back',(w-.40,.41,.03),(0,.32+h*.73,f-.02),'void',.036)
 lbl(m,t+'_Title',name,0,.32+h*.73,f-.053,.22,'white',w-.57)
 if subtitle:lbl(m,t+'_Subtitle',subtitle,0,.32+h*.52,f-.054,.116,accent,w-.4)
 for x in (-w/2+.17,w/2-.17):
  m.box(t+f'_OrangeEdgeRail_{x:.2f}',(.052,.42,.047),(x,.94,f-.016),'orange')
  for z in (-d/2+.22,d/2-.22):bolt(m,t+f'_Lid_{x:.2f}_{z:.2f}',x,.32+h+.09,z)
 m.bevel(t+'_InsetTopTrim',(w-.78,.038,d-.40),(0,.32+h+.091,0),'steel',.018)
 m.box(t+'_NeonTopBlade',(w-.96,.025,.05),(0,.32+h+.12,-d/2+.27),accent)
 return f

def tube_between(m,t,a,b,r,mat,sections=16,group='Static'):
 return m.rod(t,a,b,r,mat,sections=sections,group=group)

def radial_graduations(m,t,axis,center,radius,count,group,mat='cyan',tick=0.17):
 cx,cy,cz=center
 for j in range(count):
  a=j*math.tau/count
  if axis=='x':
   p=(cx,cy+radius*math.cos(a),cz+radius*math.sin(a)); q=(cx,cy+(radius-tick*(1.5 if j%10==0 else 1))*math.cos(a),cz+(radius-tick*(1.5 if j%10==0 else 1))*math.sin(a))
  else:
   p=(cx+radius*math.cos(a),cy,cz+radius*math.sin(a));q=(cx+(radius-tick)*math.cos(a),cy,cz+(radius-tick)*math.sin(a))
  m.rod(t+f'_Tick_{j:02d}',p,q,.018 if j%10 else .030,'gold' if j%10==0 else mat,sections=7,group=group)


def build_supply():
 m=Model('01_L45_5V_Supply');t='L45_SUPPLY';f=case(m,t,'5 V REFERENCE',4.05,2.65,1.6,'cyan','REGULATED POWER / 5.0 V')
 socket(m,t,'SUPPLY_PLUS_5V','+ 5V',-.90,.52,f-.05,'red')
 socket(m,t,'SUPPLY_RETURN','GND',.90,.52,f-.05,'blue')
 m.bevel(t+'_TOP_LCD_Housing',(2.85,.12,1.12),(0,2.14,.04),'void',.045)
 m.bevel(t+'_TOP_LCD_Blank',(2.58,.037,.91),(0,2.224,.04),'screen',.04)
 for xx in [-1.18,1.18]:m.box(t+f'_LCD_Lightrail_{xx}',(.048,.03,.77),(xx,2.25,.04),'cyan')
 top_lamp(m,t+'_OutputStatus',1.61,2.13,.78,'green','PowerIndicator_VISUAL')
 for xx in np.linspace(-.85,.85,8):m.box(t+f'_Vent_{xx:+.2f}',(.081,.020,.29),(xx,2.16,.93),'void')
 m.group_pivots['PowerIndicator_VISUAL']=(1.61,2.13,.78)
 return m


def build_motor():
 m=Model('02_L45_DCMotor');t='L45_MOTOR';g='MotorShaft_ROTATE_X_ANIMATE'
 m.bevel(t+'_RubberFoot',(4.56,.14,2.62),(0,.14,0),'rubber',.13)
 m.bevel(t+'_ExtrudedSkid',(4.42,.23,2.56),(0,.32,0),'steel',.12)
 m.bevel(t+'_CradleCasting',(3.85,.31,2.30),(0,.60,0),'mid_steel',.11)
 for x in (-1.18,1.16):
  m.bevel(t+f'_MachinedMountStand_{x:+.1f}',(.44,1.50,1.55),(x,1.28,0),'titanium',.10)
  for z in (-.71,.71):bolt(m,t+f'_Mount_{x:.1f}_{z:.1f}',x,.68,z)
 # Actual motor body axis local X, centered at Y=2.2 (aligned to flywheel)
 m.cyl(t+'_MainBrushedNickelCan',.90,2.69,(0,2.20,0),'silver',axis='x',sections=72)
 m.cyl(t+'_RearBlueEndCap',.915,.31,(-1.48,2.20,0),'motor_blue',axis='x',sections=72)
 m.torus(t+'_RearSeal',.90,.035,(-1.59,2.20,0),'cyan',axis='x',segments=72,tube_segs=9)
 m.cyl(t+'_FrontBearingFace',.81,.17,(1.44,2.20,0),'polished',axis='x',sections=64)
 m.cyl(t+'_BearingInner',.27,.21,(1.59,2.20,0),'void',axis='x',sections=44)
 m.torus(t+'_FrontRing',.77,.043,(1.49,2.20,0),'cyan',axis='x',segments=62,tube_segs=9)
 for i,xx in enumerate(np.linspace(-1.18,1.20,18)):
  m.torus(t+f'_CoolingRib_{i:02d}',.927,.024,(xx,2.20,0),'chrome' if i%3 else 'titanium',axis='x',segments=55,tube_segs=7)
 for z in [-.37,.37]:
  m.bevel(t+f'_GoldTerminalMount_{z:+.1f}',(.34,.45,.24),(-1.53,2.22,z),'brass',.045)
  m.rod(t+f'_MotorContactPin_{z:+.1f}',(-1.68,2.23,z),(-1.93,2.23,z),.065,'gold')
 # Visually rotating motor shaft and scored coupling sleeve
 m.cyl(t+'_ChromeOutputShaft',.163,2.12,(2.46,2.20,0),'chrome',axis='x',sections=40,group=g)
 m.cyl(t+'_KeyedCoupler',.260,.43,(2.08,2.20,0),'titanium',axis='x',sections=30,group=g)
 m.box(t+'_ShaftKey',(1.70,.045,.060),(2.46,2.37,0),'gold',group=g)
 for xx in (1.85,2.47,3.10):m.torus(t+f'_ShaftScore_{xx}',.173,.014,(xx,2.20,0),'cyan',axis='x',segments=32,group=g)
 m.group_pivots[g]=(1.5,2.20,0)
 # Front bay with 2 socket terminals
 m.bevel(t+'_SocketFace',(2.25,.50,.14),(0,.77,-1.22),'deep_steel',.06)
 socket(m,t,'MOTOR_PLUS','MOTOR +',-.56,.74,-1.315,'red',label_y=1.05)
 socket(m,t,'MOTOR_MINUS','MOTOR -',.56,.74,-1.315,'blue',label_y=1.05)
 lbl(m,t+'_Name','5V DC MOTOR',0,.39,-1.363,.160,'ice',2.27)
 # curved ring of rear cooling vents
 for j in range(12):
  a=j*math.tau/12;y=2.20+.80*math.sin(a);z=.80*math.cos(a)
  m.cyl(t+f'_RearVent_{j:02d}',.055,.02,(-1.67,y,z),'void',axis='x',sections=10)
 return m


def build_flywheel():
 m=Model('03_L45_EncoderFlywheel');t='L45_FLYWHEEL';g='Flywheel_ROTATE_X_ANIMATE'
 cy=2.20;cx=0
 # balanced 80-count wheel: all disc geometry in rotation group
 m.cyl(t+'_HeavyMachinedRotor',1.80,.45,(cx,cy,0),'titanium',axis='x',sections=120,group=g)
 m.cyl(t+'_InertialDiscFace',1.61,.036,(cx+.245,cy,0),'graphite',axis='x',sections=112,group=g)
 m.torus(t+'_CyanRim',1.70,.060,(cx+.28,cy,0),'cyan',axis='x',segments=120,tube_segs=9,group=g)
 m.torus(t+'_BrassInertiaRing',1.77,.065,(cx-.04,cy,0),'gold',axis='x',segments=120,tube_segs=10,group=g)
 m.torus(t+'_MachinedInnerGroove',1.38,.028,(cx+.273,cy,0),'chrome',axis='x',segments=96,tube_segs=8,group=g)
 # 20 optical periods and 80 decoded marker ticks
 for j in range(20):
  a=j*math.tau/20;y=cy+1.51*math.sin(a);z=1.51*math.cos(a)
  m.cyl(t+f'_EncoderOpticalBand_{j:02d}',.086,.025,(.294,y,z),'ice' if j%2 else 'cyan',axis='x',sections=12,group=g)
 radial_graduations(m,t+'_80Decode','x',(.301,cy,0),1.76,80,g,mat='ice',tick=.10)
 for j in range(12):
  a=math.tau*j/12;yy=cy+1.09*math.sin(a);zz=1.09*math.cos(a)
  m.cyl(t+f'_MachinedBolt_{j:02d}',.069,.035,(.31,yy,zz),'chrome',axis='x',sections=15,group=g)
 m.cyl(t+'_SpindleHub',.45,.55,(cx+.32,cy,0),'nickel',axis='x',sections=54,group=g)
 m.cyl(t+'_HubBlueAccent',.27,.038,(cx+.63,cy,0),'blue',axis='x',sections=50,group=g)
 m.cyl(t+'_CenterSpinDimple',.12,.054,(cx+.67,cy,0),'void',axis='x',sections=36,group=g)
 m.group_pivots[g]=(0,cy,0)
 # Nonrotating rim cover bracket to make visual physically grounded
 m.bevel(t+'_SafetyStandLower',(2.30,.20,2.27),(0,.22,0),'rubber',.13)
 for zz in (-.92,.92):
  m.bevel(t+f'_LowerShaftSupport_{zz:.1f}',(.34,1.45,.25),(0,1.24,zz),'mid_steel',.055)
 m.torus(t+'_GuardRingTop',1.93,.046,(cx-.17,cy,0),'steel',axis='x',segments=96,tube_segs=9)
 return m


def build_readhead():
 m=Model('04_L45_OpticalReadHead');t='L45_READHEAD';f=case(m,t,'OPTICAL SPEED PICKUP',3.50,2.17,1.36,'cyan','A/B QUADRATURE / 80 COUNTS')
 socket(m,t,'ENCODER_A','ENC A',-.77,.46,f-.04,'mint')
 socket(m,t,'ENCODER_B','ENC B',.77,.46,f-.04,'cyan')
 # stationary twin photo-interrupter fork (optical encoder pickup)
 m.bevel(t+'_ScannerArm',(1.12,.30,.89),(0,1.62,1.18),'steel',.05)
 m.bevel(t+'_ForkSupport',(.36,1.13,.32),(0,2.02,1.61),'nickel',.048)
 for off,col in [(-.27,'mint'),(.27,'cyan')]:
  m.bevel(t+f'_OpticalForkFinger_{off:+.2f}',(.86,.14,.18),(0,2.64,1.65+off),'polished',.040)
  m.cyl(t+f'_OpticalDiode_{off:+.2f}',.067,.06,(.42,2.64,1.65+off),col,axis='x',sections=22)
 for i,(text_,col) in enumerate([('A','mint'),('B','cyan')]):
  xx=-.40+i*.8;top_lamp(m,t+'_PulseIndicator_'+text_,xx,1.88,-.30,col,'Encoder_'+text_+'_PULSE_VISUAL')
 lbl(m,t+'_SignalReadout','DIRECTION  /  SPEED',0,1.09,f-.06,.113,'ice',2.89)
 return m


def build_driver():
 m=Model('05_L45_MotorDriver');t='L45_DRIVER';f=case(m,t,'PWM MOTOR DRIVER',5.25,2.62,1.69,'amber','REVERSIBLE H-BRIDGE / 5 V')
 ports=[(-2.09,'DRIVER_PLUS_5V','+5V','red'),(-1.04,'DRIVER_GND','GND','blue'),(0,'DRIVER_PWM_IN','PWM IN','mint'),(1.04,'DRIVER_MOTOR_PLUS','M +','amber'),(2.09,'DRIVER_MOTOR_MINUS','M -','cyan')]
 for x,id_,text_,col in ports:socket(m,t,id_,text_,x,.49,f-.05,col)
 # sizable milled aluminum power heatsink with fins and orange copper windings
 m.bevel(t+'_DriverCopperPCB',(3.30,.13,1.34),(0,2.21,.25),'bronze',.035)
 m.bevel(t+'_BlackPowerIC',(2.64,.31,.76),(0,2.42,.22),'void',.05)
 for i,xx in enumerate(np.linspace(-1.25,1.25,13)):
  m.bevel(t+f'_AnodizedHeatsinkFin_{i:02d}',(.113,.52,.85),(xx,2.67,.19),'titanium',.022)
 for i,(s,c) in enumerate([('DRIVE','mint'),('LIMIT','amber'),('FAULT','red')]):
  xx=-1.32+i*1.32;top_lamp(m,t+'_'+s+'_STATUS',xx,2.23,-.81,c,'Driver_'+s+'_STATUS_VISUAL')
 m.torus(t+'_EMIShieldTrace',.62,.04,(1.78,2.31,.56),'copper',axis='y',segments=44,tube_segs=7)
 return m


def build_controller():
 m=Model('06_L45_SpeedController');t='L45_CONTROLLER';f=case(m,t,'CLOSED-LOOP GOVERNOR',5.78,3.34,1.90,'cyan','30 / 60 RPM  |  FEEDBACK PWM')
 # Five playable electrical sockets at front, labels below title
 ports=[(-2.28,'CONTROLLER_PLUS_5V','5V','red'),(-1.14,'CONTROLLER_GND','GND','blue'),(0,'CONTROLLER_A','ENC A','mint'),(1.14,'CONTROLLER_B','ENC B','cyan'),(2.28,'CONTROLLER_PWM_OUT','PWM OUT','amber')]
 for x,id_,text_,col in ports:socket(m,t,id_,text_,x,.49,f-.04,col)
 m.bevel(t+'_ScreenBezel',(4.56,.13,1.55),(0,2.53,.16),'steel',.054)
 m.bevel(t+'_BlankLiveTMP_Screen',(4.26,.035,1.35),(0,2.63,.16),'screen',.045)
 for x in (-1.92,1.92):m.box(t+f'_ScreenNeonEdge_{x}',(.035,.013,1.17),(x,2.66,.16),'cyan')
 # Pressable controls separate groups from static base
 for j,(key,text_,col) in enumerate([('PRESET_30','30 RPM','mint'),('PRESET_60','60 RPM','amber'),('START_STOP','RUN / STOP','red')]):
  xx=-1.47+j*1.47;g='Button_'+key+'_PRESS_ANIMATE'
  m.bevel(t+'_BtnBezel_'+key,(1.20,.10,.50),(xx,2.25,-1.18),'nickel',.05)
  m.bevel(t+'_BtnCap_'+key,(1.07,.18,.39),(xx,2.36,-1.18),col,.045,group=g)
  lbl(m,t+'_BtnLabel_'+key,text_,xx,1.10,f-.057,.105,'ice',1.40)
  m.group_pivots[g]=(xx,2.36,-1.18)
 for j,(key,col) in enumerate([('ERROR','red'),('LOCKED','green'),('FEEDBACK','cyan')]):
  xx=-1.16+j*1.16
  top_lamp(m,t+'_STATE_'+key,xx,2.28,1.15,col,'GOVERNOR_'+key+'_LENS_VISUAL')
 return m


def build_brake():
 m=Model('07_L45_LoadBrake');t='L45_LOAD_BRAKE';g='BrakeArm_ROTATE_Y_ANIMATE';p='BrakePad_TRANSLATE_Z_ANIMATE'
 m.bevel(t+'_Footpad',(3.69,.19,3.03),(0,.12,0),'rubber',.12)
 m.bevel(t+'_AlloyBrakeMount',(3.45,.34,2.88),(0,.39,0),'steel',.13)
 # brake rotor x-axis aligned to motor center
 rot='BrakeRotor_ROTATE_X_ANIMATE'
 m.cyl(t+'_RotorHeatSink',1.21,.28,(0,2.20,0),'nickel',axis='x',sections=90,group=rot)
 m.torus(t+'_RotorWarningOrangeRing',1.19,.045,(0.17,2.20,0),'orange',axis='x',segments=90,tube_segs=8,group=rot)
 for j in range(22):
  a=math.tau*j/22;yy=2.20+.84*math.sin(a);zz=.84*math.cos(a)
  m.cyl(t+f'_VentedBrakeRotor_{j:02d}',.067,.03,(.19,yy,zz),'void',axis='x',sections=12,group=rot)
 for zz in (-.86,.86):
  m.bevel(t+f'_AnchorPillar_{zz:.1f}',(.34,1.44,.46),(0,1.22,zz),'steel',.055)
 # robust caliper, movable amber pad, contact with rotor via Z translation
 m.bevel(t+'_CaliperFrame',(1.23,.63,1.66),(.10,2.33,-1.22),'deep_steel',.105)
 m.bevel(t+'_OrangeBrakePressurePad',(.67,.74,.25),(.10,2.23,-.95),'orange',.075,group=p)
 m.box(t+'_BrakeFrictionCeramic',(.62,.62,.06),(.10,2.23,-.77),'ceramic',group=p)
 m.group_pivots[p]=(.10,2.23,-.93)
 m.group_pivots[rot]=(0,2.20,0)
 m.cyl(t+'_LeverPivot',.24,.20,(-.85,2.58,-1.15),'chrome',axis='x',sections=32)
 m.rod(t+'_BrakeHandle',(-.85,2.55,-1.15),(-.85,3.30,-.60),.085,'brass',group=g)
 m.cyl(t+'_RubberHandleGrip',.18,.41,(-.85,3.39,-.54),'rubber',axis='y',sections=28,group=g)
 m.group_pivots[g]=(-.85,2.58,-1.15)
 m.bevel(t+'_LoadLabelPlate',(2.29,.39,.05),(0,.79,-1.49),'void',.04)
 lbl(m,t+'_LoadTitle','LOAD / BRAKE',0,.79,-1.523,.175,'ice',2.15)
 top_lamp(m,t+'_LoadWarn',1.21,1.03,-.84,'amber','Brake_LOAD_LENS_VISUAL')
 return m


def build_monitor():
 m=Model('08_L45_RPMMonitor');t='L45_RPM_MONITOR';f=case(m,t,'RPM / MOTOR HEALTH',5.12,2.85,1.91,'cyan','TARGET  /  ACTUAL /  ERROR')
 m.bevel(t+'_DisplayCantilever',(4.31,.13,1.64),(0,2.57,.11),'nickel',.06)
 m.bevel(t+'_BLANK_TMProDisplay',(4.00,.039,1.40),(0,2.66,.11),'screen',.06)
 for xx in [-1.81,1.81]:m.box(t+f'_LCD_CyanEdge_{xx}',(.05,.023,1.17),(xx,2.70,.11),'cyan')
 # Speedometer arc ~260deg on upper screen, made from radial ticks
 for i in range(25):
  a=math.radians(140-i*10.8)
  x=1.08*math.cos(a); z=.1+ .56*math.sin(a)
  m.box(t+f'_SpeedDialTick_{i:02d}',(.034,.018,.071),(x,2.698,z),'mint' if i<12 else 'orange')
 for j,(key,col) in enumerate([('SPEED_OK','green'),('LOAD','amber'),('FAULT','red')]):
  xx=-1.37+j*1.37;top_lamp(m,t+'_'+key,xx,2.24,-.98,col,'RPM_'+key+'_LENS_VISUAL')
 lbl(m,t+'_FrontNote','LIVE DISPLAY / NO ELECTRICAL PORTS',0,1.08,f-.058,.134,'ice',4.32)
 return m


def build_base():
 m=Model('09_L45_IndustrialBase');t='L45_BASE'
 # central *mechanical mounting plate* only, not the large showcase workbench
 m.bevel(t+'_ShockAbsorbingRubber',(16.64,.20,6.46),(0,.10,0),'rubber',.18)
 m.bevel(t+'_MachinedAlloyFrame',(16.51,.27,6.31),(0,.31,0),'steel',.16)
 m.bevel(t+'_CarbonRibbedDeck',(16.25,.12,6.07),(0,.54,0),'graphite',.13)
 for zz in (-2.84,2.84):
  m.box(t+f'_SapphireEdgeRail_{zz}',(15.79,.042,.045),(0,.63,zz),'cyan')
 for xx in (-7.75,7.75):
  m.box(t+f'_OrangeEdgeRail_{xx}',(.051,.052,5.55),(xx,.63,0),'orange')
 for xx in np.linspace(-7.45,7.45,12):
  for zz in (-2.40,2.40):
   bolt(m,t+f'_RailBolt_{xx:+.2f}_{zz:+.2f}',xx,.648,zz)
 # actual side-by-side machined skids for aligned motor-> flywheel -> brake
 for zz in (-1.40,1.40):
  m.bevel(t+f'_RaisedMachineTSlotRail_{zz:+.1f}',(15.30,.15,.37),(0,.73,zz),'titanium',.055)
  m.box(t+f'_TSlotVoid_{zz:+.1f}',(14.87,.014,.09),(0,.812,zz),'void')
 for xx in np.linspace(-6.8,6.8,10):
  m.box(t+f'_CrossRail_{xx:+.2f}',(.23,.090,3.13),(xx,.69,0),'mid_steel')
 # One continuously rotating drivetrain axle passing through motor, flywheel and brake
 axle='DrivetrainAxle_ROTATE_X_ANIMATE'
 m.rod(t+'_ContinuousChromeDriveAxle',(-7.28,2.20,0),(7.25,2.20,0),.12,'chrome',sections=20,group=axle)
 for ax in (-2.95,-2.02,2.15,3.51):
  m.torus(t+f'_DriveCollar_{ax:.2f}',.17,.027,(ax,2.20,0),'gold',axis='x',segments=36,tube_segs=7,group=axle)
 m.group_pivots[axle]=(0,2.20,0)
 for x in (-7.20,7.20):
  m.bevel(t+f'_TaperedSupport_{x:+.1f}',(.77,.76,1.89),(x,.98,0),'mid_steel',.09)
  m.torus(t+f'_Bearing_Protective_OilSeal_{x:+.1f}',.29,.040,(x,2.20,0),'black',axis='x',segments=38)
 # electronics ground plane signal artwork, strictly decorative
 m.box(t+'_Nameplate',(4.8,.07,.60),(0,.69,-2.32),'void')
 lbl(m,t+'_Name','PRECISION DRIVE TEST RIG',0,.72,-2.64,.22,'ice',4.2)
 m.group_pivots['FixedMachineBed']=(0,0,0)
 return m


def build_showcase_tray():
 m=Model('00_L45_ArtOnly_ShowcaseBench');t='L45_DISPLAY'
 m.bevel(t+'_PerimeterRubber',(27.75,.23,19.85),(0,.10,0),'rubber',.18)
 m.bevel(t+'_CastAlloyTray',(27.51,.24,19.60),(0,.33,0),'steel',.16)
 m.bevel(t+'_TexturedWorkbench',(27.30,.095,19.37),(0,.51,0),'graphite',.12)
 for z in (-9.43,9.43):m.box(t+f'_CyanPerimeter_{z}',(26.8,.051,.059),(0,.575,z),'cyan')
 for x in (-13.29,13.29):m.box(t+f'_CyanPerimeter_{x}',(.058,.051,18.9),(x,.575,0),'cyan')
 # front row exposed for wiring; no pre-installed wires
 for x in np.linspace(-12.9,12.9,48):
  for z in [-8.70,-8.32,-7.94]:
   m.cyl(t+f'_BreadboardHole_{x:+.2f}_{z:+.2f}',.025,.012,(x,.575,z),'void',sections=7)
 m.box(t+'_FrontPowerBus_VisualOnly',(25.45,.015,.038),(0,.592,-7.49),'red')
 m.box(t+'_FrontReturnBus_VisualOnly',(25.45,.015,.038),(0,.593,-7.21),'blue')
 return m

BUILDERS=[build_supply,build_motor,build_flywheel,build_readhead,build_driver,
          build_controller,build_brake,build_monitor,build_base]
POSITIONS={
 '00_L45_ArtOnly_ShowcaseBench':(0,0,0),
 '01_L45_5V_Supply':(-10.43,0,-4.17),
 '02_L45_DCMotor':(-5.68,0,0.18),
 '03_L45_EncoderFlywheel':(-1.80,0,.18),
 '04_L45_OpticalReadHead':(-1.78,0,4.53),
 '05_L45_MotorDriver':(8.38,0,-4.18),
 '06_L45_SpeedController':(-7.42,0,6.13),
 '07_L45_LoadBrake':(3.86,0,.18),
 '08_L45_RPMMonitor':(5.48,0,6.04),
 '09_L45_IndustrialBase':(0,0,.18)
}
# 9 distinct wires, 16 unique socket meshes (supply plus and return are shared by W01/W03 W02/W04).
WIRES=[
 ('W01','SUPPLY_PLUS_5V','CONTROLLER_PLUS_5V','Supply +5V to controller'),
 ('W02','SUPPLY_RETURN','CONTROLLER_GND','Supply return to controller'),
 ('W03','SUPPLY_PLUS_5V','DRIVER_PLUS_5V','Supply +5V to driver'),
 ('W04','SUPPLY_RETURN','DRIVER_GND','Supply return to driver'),
 ('W05','ENCODER_A','CONTROLLER_A','Quadrature A feedback'),
 ('W06','ENCODER_B','CONTROLLER_B','Quadrature B feedback / fault test'),
 ('W07','CONTROLLER_PWM_OUT','DRIVER_PWM_IN','PWM speed command'),
 ('W08','DRIVER_MOTOR_PLUS','MOTOR_PLUS','Motor positive'),
 ('W09','DRIVER_MOTOR_MINUS','MOTOR_MINUS','Motor negative')
]


def build():
 models=[fn() for fn in BUILDERS];assert len(models)==9
 allids=[sid for m in models for sid in m.anchors]
 assert len(allids)==len(set(allids))==16,(len(allids),allids)
 assert len(WIRES)==9
 assert set(allids)=={q for _,a,b,_ in WIRES for q in (a,b)}
 report={}
 for idx,m in enumerate(models,1):
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m])
  assert fbx.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  scene=trimesh.load_scene(glb)
  assert len(scene.geometry)>2, m.key
  t=sum(len(p.mesh.faces) for p in m.parts)
  report[m.key]={ 'fbx':fbx.name,'glb':glb.name,'triangles':int(t),'mesh_parts':len(m.parts),
    'art_sockets':m.anchors,'animation_pivots':m.group_pivots,
    'named_groups':list(dict.fromkeys(p.group for p in m.parts))}
  print('MODEL',idx,m.key,'tri',t,'parts',len(m.parts),'sockets',len(m.anchors),flush=True)
 showcase=[build_showcase_tray()]+models
 name='Level45_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(name+'.fbx'),showcase,positions=POSITIONS)
 export_glb(MODELS/(name+'.glb'),showcase,positions=POSITIONS)
 assert trimesh.load_scene(MODELS/(name+'.glb')).geometry
 showtri=int(sum(len(p.mesh.faces) for m in showcase for p in m.parts))
 manifest={'level':45,'name':'Hold the Speed','style':'AAA-inspired polished semi-HD industrial governor',
   'models_count':9,'art_socket_count':16,'wire_count':9,'decoded_counts_per_revolution':80,
   'allowed_presets_rpm':[30,60], 'visual_units':'relative; Unity Y up, front -Z; assembled tray art only',
   'status':'Art-model pack only; no motor solver or feedback code.',
   'sockets_shared_by_two_wires':['SUPPLY_PLUS_5V','SUPPLY_RETURN'],
   'models':report,'showcase':{'name':name,'triangles':showtri},
   'positions':POSITIONS,'wiring':WIRES,
   'setup_notes':[
     'Move art sockets to your real 3D breadboard holes in Level45; add actual SparkTerminal components and correct runtime bindings.',
     'Y up. Motor shaft and encoder flywheel both rotate around their local X axis. Separate FBX rotation group pivots are included.',
     'Optical head A/B output sockets are real gameplay wiring; flywheel has no additional player sockets.',
     'Motor driver provides +5V, GND, PWM IN, MOTOR+, MOTOR- sockets. Controller provides +5V, GND, ENCODER A/B, PWM OUT.',
     'Encoder pickup uses internal power, per your Level45 design. No extra wires hidden in these meshes.',
     'W06 is intended to disconnect and restore for feedback fault; do not repurpose as generic power line.',
     'No electrical solve, PWM regulation, trip detection, or completion logic included.',
     'Blank top screens are intended for live TextMeshPro Canvas and your existing code.',
     'The IndustrialBase is mechanical only; showcase tray is decorative and separate from 9 models.']}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  wr=csv.writer(f);wr.writerow(['Model FBX','ArtSocketID','X','Y','Z','Unity note'])
  for m in models:
   for id_,coord in m.anchors.items():wr.writerow([m.key+'.fbx',id_,*coord,'Art-only; snap actual SparkTerminal to a breadboard hole. Not a binding definition.'])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
  wr=csv.writer(f);wr.writerow(['Wire','From Art ID','To Art ID','Purpose'])
  for w,a,b,purpose in WIRES:wr.writerow([w,a,b,purpose])
 with (ROOT/'Animation_Rigs.csv').open('w',newline='',encoding='utf-8') as f:
  wr=csv.writer(f);wr.writerow(['Model','FBX Child Group','Local Pivot X','Y','Z','Behavior'])
  for m in models:
   for g in list(dict.fromkeys(p.group for p in m.parts if p.group!='Static')):
    x,y,z=m.group_pivots.get(g,(0,0,0))
    if 'ROTATE_X' in g:how='Rotate around local +X from current motor/encoder angle; do not generate fake electrical speed'
    elif 'ROTATE_Y' in g:how='Rotate brake lever around Y from load setting'
    elif 'TRANSLATE_Z' in g:how='Translate brake pad toward disc under approved load setting'
    elif 'Button_' in g:how='Move cap -0.05 along local Y on click; gameplay controller handles action'
    else:how='Turn light material emission / VFX on or off; visual-only'
    wr.writerow([m.key+'.fbx',g,x,y,z,how])
 print('SHOWCASE',showtri,'TRIANGLES; ASSETS',len(report),flush=True)
 return models

if __name__=='__main__':build()
