PROJECT SPARK — LEVEL 45 / HOLD THE SPEED
AAA-INSPIRED POLISHED SEMI-HD FBX/GLB MODEL COLLECTION
========================================================

WHAT IS INCLUDED
----------------
9 separate visual Unity FBXs with GLB backups, 1 assembled showcase FBX+GLB.
Actual rendered mesh previews (not AI mockups), generated source code, model manifest.
Exact_Wiring.csv (W01-W09), Terminal_Anchors.csv (16 unique positions),
Animation_Rigs.csv (rotating and moving group names), optional Unity visual C#.

INDIVIDUAL FBX MODELS
---------------------
01_L45_5V_Supply.fbx              5 V regulated source; shared + and GND art ports
02_L45_DCMotor.fbx                Ribbed brushed-metal motor, animated X shaft, 2 ports
03_L45_EncoderFlywheel.fbx       80-count engraved disc, rotating X-axis group
04_L45_OpticalReadHead.fbx       Dual A/B sensor pickup and 2 output ports
05_L45_MotorDriver.fbx           H-bridge driver, power/PWM/motor ports (5)
06_L45_SpeedController.fbx       Target/actual governor module, 3 buttons, 5 ports
07_L45_LoadBrake.fbx             Caliper, separate rotating disc/pad/lever
08_L45_RPMMonitor.fbx            Decorative display, no circuit terminal
09_L45_IndustrialBase.fbx        Two precision guides, mechanical support, rotating axle
Level45_Complete_ArtKit_Showcase.fbx  assembled art-only presentation

GAMEPLAY INTENT
---------------
LEVEL 45: HOLD THE SPEED — regulate a motor at 30/60 RPM using 80 decoded
quadrature counts per revolution. Observe speed droop under brake load, recover
automatically, and fail safe on encoder B disconnect.
The gameplay controller and solver, not the meshes, must decide actual speed,
PWM drive, load response, fault conditions and 6/6 completion.

PLAYER WIRING — 9 WIRES / 16 UNIQUE VISUAL SOCKETS
---------------------------------------------------
W01 Supply +5V  -> Controller +5V
W02 Supply GND  -> Controller GND
W03 Supply +5V  -> Driver +5V
W04 Supply GND  -> Driver GND
W05 Encoder A   -> Controller A
W06 Encoder B   -> Controller B        (feedback fault exercise)
W07 Controller PWM OUT -> Driver PWM IN
W08 Driver MOTOR+ -> Motor+
W09 Driver MOTOR- -> Motor-

Two wires connect to each supply port. The 9 wires have 18 endpoints but only
16 distinct sockets. Your actual Project Spark wiring tool must support these
shared-net connections; use real SparkTerminals with correct runtime binding IDs.
Encoder readhead power is preinstalled/internal as proposed in the design.
DO NOT invent a separate player power wire for the optical sensor.

UNITY SETUP
-----------
1. Extract the package. Import Models/*.fbx to:
   Assets/My_Assets/_Project_Spark/Models/Level45/
2. For quick staging use Level45_Complete_ArtKit_Showcase.fbx, or build your
   real level from the nine independent FBXs. Showcase includes an extra ART
   bench and is not meant to replace the Project Spark workbench layout.
3. Keep each model transform at default local scale until you decide a common
   scale for your workbench. Models use relative units, Y up, front faces -Z.
4. Add SparkTerminal components to the 16 visible art socket positions.
   Use Terminal_Anchors.csv; after positioning, SNAP those anchors onto real
   breadboard holes. Modeled socket rings alone are NOT a circuit connection.
5. Map the art socket IDs to your ACTUAL Level45 scene-binding identifiers.
   The names in the CSV are suggestions, not verified Unity binding IDs.
6. Wires W01–W09 must be installed by the PLAYER using your existing wire tool.
   The art FBXs deliberately contain NO pre-installed circuit wires.
7. Put real TextMeshPro canvases on the blank LCD faces for target RPM,
   actual RPM, speed error, PWM duty and feedback-fault status.
8. Assign real 5 V source/motor electrical components, controller & driver
   scripts, and measured encoder outputs without changing shared solver code.
9. Use appropriately emissive URP Lit/HDRP Lit material variants for cyan,
   green, orange, red lights; use metallic 0.75–1.0 on polished chassis.
10. Create simple BoxCollider / MeshCollider on static pieces separately;
    avoid colliders on small decorative text, screws, and LED lenses.

ANIMATION PIVOTS
----------------
MotorShaft_ROTATE_X_ANIMATE             local X; inside motor FBX
Flywheel_ROTATE_X_ANIMATE               local X; inside flywheel FBX
DrivetrainAxle_ROTATE_X_ANIMATE         local X; inside industrial base FBX
BrakeRotor_ROTATE_X_ANIMATE             local X; inside brake FBX
BrakeArm_ROTATE_Y_ANIMATE               local Y; optional load lever
BrakePad_TRANSLATE_Z_ANIMATE            local Z; move friction pad toward disc
Button_PRESET_30_PRESS_ANIMATE          animate local Y on 30 RPM selection
Button_PRESET_60_PRESS_ANIMATE          animate local Y on 60 RPM selection
Button_START_STOP_PRESS_ANIMATE         animate local Y on run/stop

All four rotating groups should follow the SAME measured RPM (angle / second
= RPM * 6). The optional SparkLevel45VisualRig.cs can animate these groups,
but NEVER generates encoder events, measured RPM or motor feedback itself.
Feed it real values from your Level45 gameplay logic via SetMeasuredRpm()
and SetBrakeLoad(). This visual script does not touch any solver or targets.

EDITOR VISUAL QUALITY / PERFORMANCE
-----------------------------------
Models: polished, separate-color meshes and 3D text, not PBR-baked textures.
The display is intentionally blank so TextMeshPro can show LIVE measured data.
For mobile, consider mesh-combining static bolts/ribs and reducing redundant
screens, or generate a lower-poly LOD while keeping pivot submeshes separate.

VERIFICATION
------------
FBXs generated as Autodesk FBX 7.4 binary with nested named model groups.
Each paired GLB parsed successfully through trimesh.
The Python geometry generator and mesh renderer are included in Sources/.
No hands-on Unity import / material shader / rig / electrical gameplay test was
possible here. Inspect pivots and FBX import scale in your Unity Inspector.
