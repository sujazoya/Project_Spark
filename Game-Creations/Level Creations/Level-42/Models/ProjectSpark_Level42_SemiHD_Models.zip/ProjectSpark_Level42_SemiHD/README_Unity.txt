PROJECT SPARK — LEVEL 42 / READ THE ANALOG SIGNAL
POLISHED SEMI-HD 3D ART PACK / 3-BIT SUCCESSIVE-APPROXIMATION ADC
================================================================

GAMEPLAY BRIEF
---------------
Level 42 reuses the 3-bit R-2R DAC from Level 41, adding a sensor
voltage source, differential comparator, and trial-code ADC monitor.
This package supplies ART ONLY. It does not modify Unity scripts,
solver, component logic, evaluation targets or wiring topology.

INCLUDED
--------
* 13 individual Autodesk FBX 7.4 binary meshes
* 13 individual GLB alternatives for viewing/conversion
* 1 assembled showcase FBX and 1 assembled showcase GLB
* 13 rendered component previews + 1 complete preview + contact sheet
* Terminal_Anchors.csv — exactly 19 player-facing terminal locations
* DAC_Ladder_Reference_Routing.csv — reference from Level 41, NOT an
  authoritative Level 42 wiring plan
* Model_Manifest.json — all anchors, names, groups and triangle counts
* Sources/ three editable Python generator/renderer scripts

13 INDIVIDUAL MODULES
---------------------
01_Reference_5V.fbx            REF             | 1 socket: RET
02_BitDriver_B2.fbx            B2              | 1 socket: B2
03_BitDriver_B1.fbx            B1              | 1 socket: B1
04_BitDriver_B0.fbx            B0              | 1 socket: B0
05_Branch_B2_20k.fbx           20 kOhm B2       | 2 sockets: B2_IN, B2_OUT
06_Branch_B1_20k.fbx           20 kOhm B1       | 2 sockets: B1_IN, B1_OUT
07_Branch_B0_20k.fbx           20 kOhm B0       | 2 sockets: B0_IN, B0_OUT
08_Link21_10k.fbx              10 kOhm link     | 2 sockets: LINK21_IN/OUT
09_Link10_10k.fbx              10 kOhm link     | 2 sockets: LINK10_IN/OUT
10_Termination_20k.fbx         20 kOhm terminal | 2 sockets: TERM_IN, TERM_OUT
11_Sensor_Source.fbx           SENSOR          | 1 socket: SENSOR_OUT
12_Comparator.fbx              COMPARATOR      | 2 sockets: SENSOR_PLUS, DAC_MINUS
13_ADC_Monitor.fbx             ADC MONITOR     | NO sockets (display-only)
                                      TOTAL: 19 PLAYER SOCKETS

COMPONENT APPEARANCE / ANIMATION GROUPS
----------------------------------------
* Reference supply: separate reference LED / reference display art.
* 3 driver rockers: BitSelector_TOGGLE_ANIMATE with a centered FBX pivot;
  HighStateLamp_VISUAL independently controllable. Use the actual
  bit-driver state from gameplay to update both.
* 20 kOhm and 10 kOhm resistor branches: 3D ringed resistor bodies and
  separate metal leads/guard rails. B1_OUT/B0_OUT may have more than one
  user wire; keep generous visual clearance near these sockets.
* Termination: TerminationLink_LEVER_ANIMATE has a dedicated FBX pivot;
  TerminationClosedLamp_VISUAL can be toggled OPEN/CLOSED by gameplay.
* Sensor source: SensorSelector_ROTATE_ANIMATE with centered dial pivot,
  separate Sensor_A_Lamp_VISUAL, Sensor_B_Lamp_VISUAL and
  Sensor_TEST_Lamp_VISUAL. The front OLED is BLANK for dynamic TextMeshPro.
* Comparator: distinct mint SENSOR + and violet DAC - socket rings.
  Comparator_ABOVE_Lamp_VISUAL and Comparator_BELOW_Lamp_VISUAL groups are
  separate. The result screen is BLANK; comparator output goes to your
  in-game monitor internally, not through a third player socket.
* ADC monitor: blank screen, angled toward the game camera, with three
  text areas (TRIAL CODE, DAC VOLTAGE, COMPARISON). Eight separate
  SweepCode_000_BAR_VISUAL to SweepCode_111_BAR_VISUAL parts. No
  hard-coded readings and no extra power/socket terminals.

UNITY ART IMPORT
----------------
1) Extract the ZIP; copy Models/*.fbx into an art folder, for example:
   Assets/My_Assets/_Project_Spark/Models/Level42/
2) Select individual FBX assets, adjust Model Import Scale Factor to
   match your existing workbench. Model-space Y is up, front is local -Z.
3) Use the individual FBX as an art CHILD of each existing game object.
   Do not replace SparkElectricalComponent, SparkShelfItem, bindings,
   or existing SparkTerminal GameObjects with the mesh objects.
4) Add/position real SparkTerminal components at the coordinates in
   Terminal_Anchors.csv. The rings are VISUAL geometry, not terminals.
5) In Play Mode, verify every relevant binding ID using your existing
   SparkLevelSceneBindings and smart-slot bridge diagnostics.
6) Bit rocker, sensor dial, termination lever and state lamps should
   respond to the existing level controller. Do not animate the root
   electrical component to fake a circuit state.
7) Create world-space TextMeshPro or UI meshes on the Sensor, Comparator
   and ADC Monitor blank faces; attach their values to real measurements.
8) The 13-part SHOWCASE is an arranged visual board. Import it only for
   inspection/cinematic presentation, never as a pre-wired gameplay prefab.

IMPORTANT ELECTRICAL / LEVEL 42 NOTES
--------------------------------------
* This request did not provide the official Level 42 per-wire mapping.
  DAC_Ladder_Reference_Routing.csv therefore contains the familiar
  Level 41 DAC ladder routing, plus clearly marked logical sensor and
  comparator suggestions. DO NOT treat it as official Level 42 Wxx wiring.
* The bit-driver 5 V feed and return are INTERNAL as provided.
* The 3-bit DAC ideally produces 0.625 V/step:
    000 0.000 V ; 001 0.625 V ; 010 1.250 V ; 011 1.875 V
    100 2.500 V ; 101 3.125 V ; 110 3.750 V ; 111 4.375 V.
* Sensor A = 3.200 V, expected code 101.
* Sensor B = 1.100 V, expected code 001.
* The comparator reports sensor ABOVE DAC when sensor >= DAC,
  and BELOW when sensor < DAC; wire polarities matter.
* A swapped-comparator-input test is an objective; preserve real
  connections and don't force visual states based on a static reading.
* The eight-bar sweep is visual only. Your level gameplay must control
  the verification sequence and evaluator targets.

GEOMETRY / VALIDATION
---------------------
* 13 individual FBX and GLB files, plus 2 showcase files.
* 19 unique socket IDs and zero sockets on the standalone monitor.
* FBX 7.4 binary file structure is checked by generator pointer parser.
* GLB geometry loaded and inspected via trimesh.
* Semi-HD polygonal art with machine housings, chrome and copper details,
  resistor band materials, named LED groups and acrylic railings.
* Preview PNGs are generated by rendering the actual triangle geometry,
  not AI concept art.
* Materials are approximate standard FBX/GLTF materials. After Unity
  import use URP/HDRP metallic, emission, or glass shaders as appropriate.
* NOT yet imported or validated within your particular Unity project.

EDITABLE SOURCE
---------------
Sources/build_level42_models.py         Level 42 modules and manifest
Sources/level42_dac_reused_geometry.py  Reusable Level 41 ladder art generator
Sources/spark_model_core.py            Mesh builder + binary FBX/GLB exporters
Sources/render_level42_previews.py      Actual geometry renders (VTK)

No compiled font files are included; texts are triangle meshes.
