"""Project Spark Level 42 — Read the Analog Signal.
13 distinct game art models, precisely 19 player-facing socket anchors.
R–2R geometry is adapted from the bundled Level 41 art generator.
Pure visualization; no electrical topology, voltage or ADC simulation is created.
Dependencies: numpy, trimesh, shapely, matplotlib.
"""
from __future__ import annotations
import csv, json, math
from pathlib import Path
import numpy as np
import trimesh
import level42_dac_reused_geometry as dac
from spark_model_core import Model, PALETTE, export_fbx, export_glb

ROOT = Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models'; PREV=ROOT/'Previews'
MODELS.mkdir(parents=True,exist_ok=True); PREV.mkdir(parents=True,exist_ok=True)

# Existing source, drivers, R/2R resistor links and termination use the Level41
# model geometry. Port engravings are adjusted to the Level42 notation.
dac.PORTS['01_5V_DAC_Reference']=[('RET','RET','blue')]
dac.PORTS['02_B2_Bit_Driver']=[('B2','B2','warm')]
dac.PORTS['03_B1_Bit_Driver']=[('B1','B1','warm')]
dac.PORTS['04_B0_Bit_Driver']=[('B0','B0','warm')]

RENAME = {
 '01_5V_DAC_Reference':'01_Reference_5V',
 '02_B2_Bit_Driver':'02_BitDriver_B2',
 '03_B1_Bit_Driver':'03_BitDriver_B1',
 '04_B0_Bit_Driver':'04_BitDriver_B0',
 '05_B2_20kOhm_Resistor':'05_Branch_B2_20k',
 '06_B1_20kOhm_Resistor':'06_Branch_B1_20k',
 '07_B0_20kOhm_Resistor':'07_Branch_B0_20k',
 '08_Link21_10kOhm':'08_Link21_10k',
 '09_Link10_10kOhm':'09_Link10_10k',
 '10_20kOhm_Termination':'10_Termination_20k',
}

# The provided Level42 design specifies module types, socket count, SAR
# sequence and readings, but NOT a new official wire list. We deliberately do
# not invent official W01–Wxx labels for Level42. All physical sockets are
# enumerated and the user can connect them to authoritative Unity bindings.
EXPECTED_CODES={'000':0.0,'001':.625,'010':1.25,'011':1.875,
                '100':2.5,'101':3.125,'110':3.75,'111':4.375}


def base_dac_models():
 build=[dac.source,
  lambda:dac.driver('B2','02_B2_Bit_Driver'),
  lambda:dac.driver('B1','03_B1_Bit_Driver'),
  lambda:dac.driver('B0','04_B0_Bit_Driver'),
  lambda:dac.resistor('05_B2_20kOhm_Resistor','B2  /  20 kOhm',20000),
  lambda:dac.resistor('06_B1_20kOhm_Resistor','B1  /  20 kOhm',20000),
  lambda:dac.resistor('07_B0_20kOhm_Resistor','B0  /  20 kOhm',20000),
  lambda:dac.resistor('08_Link21_10kOhm','LINK 21  /  10 kOhm',10000),
  lambda:dac.resistor('09_Link10_10kOhm','LINK 10  /  10 kOhm',10000),
  dac.termination]
 models=[fn() for fn in build]
 for m in models:
  m.key=RENAME[m.key]
  if 'BitDriver' in m.key:
   # FBX has a real centered mechanical group pivot for rocking the selector.
   m.group_pivots['BitSelector_TOGGLE_ANIMATE']=(0,1.875,.08)
   t='L42_'+m.key[3:]
   m.cyl(t+'_HighStateLamp_Bezel',.115,.058,(.95,1.67,-.33),'chrome',axis='z',sections=28,group='HighStateLamp_VISUAL')
   m.cyl(t+'_HighStateLamp_Emission',.076,.073,(.95,1.67,-.37),'green',axis='z',sections=27,group='HighStateLamp_VISUAL')
  if m.key=='10_Termination_20k':
   add_termination_controls(m)
 return models


def add_termination_controls(m:Model):
 # Mechanical link/arm may be rotated by Unity. Independent lamp can be toggled.
 t='L42_TERMLINK'; pivot=(1.02,1.97,.46)
 m.bevel(t+'_Mount',(0.62,.14,.62),(1.02,1.93,.46),'chrome',.04)
 m.cyl(t+'_Hinge_Brass',.145,.10,pivot,'brass',axis='x',sections=26)
 m.rod(t+'_MovingContact_LEVER',(1.02,1.97,.46),(1.02,2.37,.17),.065,'chrome',group='TerminationLink_LEVER_ANIMATE')
 m.cyl(t+'_Handle_Grip',.098,.13,(1.02,2.40,.14),'red',sections=22,group='TerminationLink_LEVER_ANIMATE')
 m.group_pivots['TerminationLink_LEVER_ANIMATE']=pivot
 m.cyl(t+'_ClosedLamp_Rim',.094,.04,(-1.01,1.88,-.66),'chrome',axis='z',sections=23,group='TerminationClosedLamp_VISUAL')
 m.cyl(t+'_ClosedLamp_Bulb',.061,.045,(-1.01,1.88,-.691),'green',axis='z',sections=23,group='TerminationClosedLamp_VISUAL')
 m.text(t+'_OPEN_CLOSED_Label','OPEN / CLOSED',.117,0,.92,-1.068,'fog',maxwidth=1.85)


def sensor_source():
 m=Model('11_Sensor_Source'); t='L42_SENSOR'
 # New design: plated graphite enclosure, clear raised sensor prism and physical
 # three-position rotary selector. No fake static voltage on the blank display.
 dac.chassis(m,t,'SENSOR SOURCE','A  /  B  /  3.200 V TEST',w=3.85,h=1.45,d=2.20,accent='electric')
 dac.socket(m,t,'SENSOR_OUT','OUT','mint',local_x=0,d=2.20)
 face=-2.20/2-.081
 m.bevel(t+'_ScreenBrushedFrame',(2.34,.47,.085),(0,1.86,face-.024),'titanium',.058)
 m.bevel(t+'_BlankLCD_For_TextMeshPro',(2.16,.34,.087),(0,1.86,face-.076),'screen',.043,group='SensorLiveDisplay_BLANK')
 m.box(t+'_ScreenTopGlint',(1.87,.017,.016),(0,1.997,face-.138),'cyan_soft',group='SensorLiveDisplay_BLANK')
 # The screen stays blank for real-time TextMeshPro; no caption crowds the chassis title.
 m.bevel(t+'_SelectorSeat',(1.17,.12,.99),(-.80,1.895,.13),'chrome',.07)
 m.cyl(t+'_Knob_Base',.31,.18,(-.80,2.028,.13),'mid_steel',sections=38)
 m.cyl(t+'_Rotary_Dial',.245,.13,(-.80,2.147,.13),'chrome',sections=42,group='SensorSelector_ROTATE_ANIMATE')
 m.box(t+'_KnobPointer',(.07,.022,.33),(-.80,2.221,-.035),'amber',group='SensorSelector_ROTATE_ANIMATE')
 m.group_pivots['SensorSelector_ROTATE_ANIMATE']=(-.80,2.147,.13)
 for i,(name,color,x) in enumerate([('A','cyan',.33),('B','violet',.83),('TEST','amber',1.35)]):
  m.cyl(t+f'_{name}_Light_Rim',.137,.062,(x,1.998,-.15),'chrome',sections=26,group=f'Sensor_{name}_Lamp_VISUAL')
  m.cyl(t+f'_{name}_LightLens',.091,.068,(x,2.036,-.15),color,sections=26,group=f'Sensor_{name}_Lamp_VISUAL')
  m.text(t+f'_{name}_SelectEngraving',name,.115,x,1.877,-.48,'white',maxwidth=.43)
 # Raised sapphire sensor package, with gold traces and transparent frame.
 m.bevel(t+'_SensorCore_Cradle',(1.64,.12,.87),(.16,1.965,.56),'mid_steel',.08)
 m.bevel(t+'_PrismSensor',(1.02,.28,.57),(.16,2.15,.56),'glass_edge',.08,group='Sensor_Prism_VISUAL')
 m.bevel(t+'_PrismActiveArea',(.76,.032,.34),(.16,2.31,.56),'electric',.03,group='Sensor_Prism_VISUAL')
 for i in range(5):
  m.box(t+f'_TracePin_{i}',(.055,.025,.19),(-.23+.19*i,1.998,1.08),'gold')
 return m


def comparator():
 m=Model('12_Comparator');t='L42_COMPARATOR'
 dac.chassis(m,t,'COMPARATOR','',w=4.10,h=1.47,d=2.20,accent='violet')
 dac.socket(m,t,'SENSOR_PLUS','SENSOR +','mint',local_x=1.08,d=2.20)
 dac.socket(m,t,'DAC_MINUS','DAC -','violet',local_x=-1.08,d=2.20)
 face=-2.20/2-.081
 m.bevel(t+'_ResultOLED_Bezel',(1.28,.42,.066),(0,1.62,face-.05),'chrome',.04)
 m.bevel(t+'_ResultOLED_Blank',(1.16,.31,.044),(0,1.62,face-.101),'screen',.036,group='ComparatorResultDisplay_BLANK')
 # Blank OLED reserves space for a real-time result without baked-in text.
 # Two independently controllable lamps. Default visual colors are references
 # only, not a claim that either condition is electrically active.
 for x,name,col in [(-1.26,'ABOVE','green'),(1.26,'BELOW','orange')]:
  group='Comparator_'+name+'_Lamp_VISUAL'
  m.cyl(t+'_'+name+'_Lamp_Bezel',.162,.050,(x,1.64,face-.09),'chrome',axis='z',sections=34,group=group)
  m.cyl(t+'_'+name+'_Lamp_Optic',.109,.065,(x,1.64,face-.131),col,axis='z',sections=32,group=group)
  m.text(t+'_'+name+'_StatusLabel',name,.117,x,1.89,face-.139,'white',maxwidth=.90)
 # Precision analog comparison IC visible beneath a minimalist open acrylic rail.
 m.bevel(t+'_IC_Socket',(1.57,.18,1.1),(0,1.95,.18),'titanium',.048)
 m.bevel(t+'_ActualComparatorIC',(1.25,.24,.83),(0,2.16,.18),'void',.057)
 m.text(t+'_IC_TopDesignation','CMP',.16,0,2.26,-.27,'cyan',maxwidth=.68)
 for side in (-1,1):
  for j in range(7):
   m.box(t+f'_IC_Pin_{side}_{j}',(.24,.045,.07),(side*.715,2.09,-.20+j*.137),'gold')
 for x in (-1.80,1.80):
  m.rod(t+f'_AcrylicCover_Corner_{x}',(x,1.86,-.82),(x,2.62,-.82),.025,'glass_edge',sections=12)
 for z in (-.82,.81):
  m.rod(t+f'_AcrylicCover_TopRail_{z}',(-1.80,2.62,z),(1.80,2.62,z),.025,'cyan_soft',sections=10)
 # Comparator result is routed internally; no extra user socket.
 return m


def monitor():
 m=Model('13_ADC_Monitor');t='L42_SAR_ADC_MONITOR'
 dac.chassis(m,t,'SAR ADC  /  MONITOR','',w=5.48,h=1.59,d=2.82,accent='mint')
 face=-2.82/2-.081
 # Top-mounted ANGLED screen, tilted toward the player camera, front = -Z.
 screen_parts_before=len(m.parts)
 m.bevel(t+'_Angled_MonitorChromeHousing',(4.76,1.12,.14),(0,1.965,-1.07),'chrome',.095,group='ADC_Screen_Static')
 m.bevel(t+'_Angled_MonitorBlackFace',(4.55,.94,.068),(0,1.965,-1.173),'screen',.079,group='ADC_Screen_Static')
 m.box(t+'_Blank_Display_SoftHighlight',(4.27,.027,.019),(0,2.349,-1.220),'cyan_soft',group='ADC_Screen_Static')
 # Reserve three blank live fields; titles do not obstruct the editable value area.
 for x,title in [(1.51,'TRIAL CODE'),(0,'DAC VOLTAGE'),(-1.51,'COMPARISON')]:
  m.bevel(t+f'_BlankField_{title.replace(" ","_")}',(1.32,.53,.025),(x,1.99,-1.227),'void',.038,group='ADC_Screen_Static')
  m.text(t+f'_FieldHeading_{title}',title,.122,x,2.231,-1.253,'cyan',maxwidth=1.25,group='ADC_Screen_Static')
  m.box(t+f'_FieldUnderscore_{title}',(1.08,.019,.020),(x,1.755,-1.272),'cyan_soft',group='ADC_Screen_Static')
 # Rotate every angled-screen mesh identically, preserving their named groups.
 P=(0,1.96,-1.17)
 T=trimesh.transformations.rotation_matrix(math.radians(19),[1,0,0],point=P)
 for p in m.parts[screen_parts_before:]:p.mesh.apply_transform(T)
 # Eight physically separate sweep bars, unlit until controlled by gameplay.
 m.bevel(t+'_EightCodeBarHousing',(4.56,.32,.35),(0,2.45,.82),'mid_steel',.06)
 for i in range(8):
  x=1.85-.528*i
  group=f'SweepCode_{i:03b}_BAR_VISUAL'
  m.bevel(t+f'_CodeIndicator_{i:03b}',(.35,.045,.20),(x,2.638,.78),'mint',.027,group=group)
  m.text(t+f'_CodeNumber_{i:03b}',format(i,'03b'),.092,x,2.687,.53,'white',maxwidth=.31,group=group)
 # Lower rim LED lamps and tactile trial control, visual-only.
 for x,name,color in [(1.9,'TRIAL','cyan'),(0,'SUBMIT','green'),(-1.9,'SWEEP','amber')]:
  group='ADC_'+name+'_StatusLamp_VISUAL'
  m.cyl(t+f'_{name}_Bezel',.13,.05,(x,.76,face-.06),'chrome',axis='z',sections=30,group=group)
  m.cyl(t+f'_{name}_Optic',.08,.048,(x,.76,face-.089),color,axis='z',sections=28,group=group)
  m.text(t+f'_{name}_Legend',name,.118,x,.52,face-.111,'white',maxwidth=1.03)
 # No fixed values or extra footer text compete with live UI fields.
 assert not m.anchors,'ADC monitor must be visual only'
 return m


def art_showcase():
 m=Model('00_Art_Showcase_Base');t='L42_BOARD'
 m.bevel(t+'_DampeningFeet',(26.0,.14,19.6),(0,.10,0),'rubber',.16)
 m.bevel(t+'_AlloyFrame',(25.77,.21,19.37),(0,.23,0),'steel',.13)
 m.bevel(t+'_GraphiteSurface',(25.48,.08,19.10),(0,.39,0),'graphite',.12)
 for x in (-12.42,12.42):m.box(t+f'_LongEdge_{x:+.1f}',(.057,.045,18.65),(x,.46,0),'cyan')
 for z in (-9.25,9.25):m.box(t+f'_ShortEdge_{z:+.1f}',(24.87,.043,.057),(0,.46,z),'cyan')
 for x in np.linspace(-12,12,35):
  for z in np.linspace(-8.8,8.8,25):
   m.cyl(t+f'_Peg_{x:.1f}_{z:.1f}',.014,.006,(x,.437,z),'mid_steel',sections=6)
 for z,c in ((5.78,'warm'),(1.74,'mint'),(-2.33,'violet'),(-6.45,'cyan')):
  m.box(t+f'_BoardRowGuide_{z}',(23.95,.024,.044),(0,.455,z),c,group='DecorativeLayoutTraces_VISUAL')
 return m

POSITIONS = {}
for col,key in enumerate(['01_Reference_5V','02_BitDriver_B2','03_BitDriver_B1','04_BitDriver_B0']):
 POSITIONS[key]=((9.0,3.0,-3.0,-9.0)[col],0,5.72)
for col,key in enumerate(['05_Branch_B2_20k','06_Branch_B1_20k','07_Branch_B0_20k','08_Link21_10k']):
 POSITIONS[key]=((9.0,3.0,-3.0,-9.0)[col],0,1.71)
for col,key in enumerate(['09_Link10_10k','10_Termination_20k','11_Sensor_Source','12_Comparator']):
 POSITIONS[key]=((9.0,3.0,-3.0,-9.0)[col],0,-2.31)
POSITIONS['13_ADC_Monitor']=(0,0,-6.38)
POSITIONS['00_Art_Showcase_Base']=(0,0,0)


def build():
 models=base_dac_models()+[sensor_source(), comparator(), monitor()]
 assert len(models)==13, '13 individual components expected'
 ids=[sid for m in models for sid in m.anchors]
 assert len(ids)==19 and len(set(ids))==19,(len(ids),ids)
 assert len(models[-1].anchors)==0
 assert len([m for m in models if m.anchors])==12
 assert {'RET','SENSOR_OUT','SENSOR_PLUS','DAC_MINUS'}.issubset(ids)
 manifest={}
 for m in models:
  fbx=MODELS/(m.key+'.fbx'); glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]); export_glb(glb,[m])
  scene=trimesh.load_scene(str(glb)); assert scene.geometry and all(len(x.faces)>0 for x in scene.geometry.values())
  assert fbx.stat().st_size>1000 and fbx.read_bytes()[:21]==b'Kaydara FBX Binary  \x00'
  manifest[m.key]={'model':m.key,'fbx':fbx.name,'glb':glb.name,
      'meshes':len(m.parts),'triangles':sum(len(p.mesh.faces) for p in m.parts),
      'terminal_anchors':m.anchors,'animation_groups':list(dict.fromkeys(p.group for p in m.parts if p.group!='Static')),
      'animation_pivots':m.group_pivots}
  print(f'EXPORTED {m.key:29} {len(m.parts):>3} meshes {manifest[m.key]["triangles"]:>6} triangles',flush=True)
 assembled=[art_showcase()]+models
 name='Level42_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(name+'.fbx'),assembled,positions=POSITIONS)
 export_glb(MODELS/(name+'.glb'),assembled,positions=POSITIONS)
 assert len(trimesh.load_scene(str(MODELS/(name+'.glb'))).geometry)>0
 data={'level':42,'title':'Read the Analog Signal','circuit':'3-bit successive approximation ADC using 3-bit R-2R ladder',
      'individual_model_count':13,'electrical_module_count':12,'visual_only_module_count':1,
      'player_socket_count':19,'official_level42_wiring':'Not provided; no official player wiring map is claimed or generated.',
      'coordinate_system':'Y up, front towards negative Z; art units not necessarily meters',
      'sensor_states':['Sensor A 3.200 V','Sensor B 1.100 V','Known test 3.200 V'],
      'dac_codes':EXPECTED_CODES,'sensor_A_expected':'101','sensor_B_expected':'001',
      'levels_of_sar_order':['B2','B1','B0'],
      'notes':['Power feed for bit drivers internal, not extra sockets.',
               'All module art meshes are visuals only; they do not create functional SparkTerminals.',
               'Monitor and sensor screen areas are deliberately blank for live TMPro or UI.',
               'The comparator is a visual housing; preserve your actual electrical component and solver.',
               'The ADC monitor is the sole visual-only standalone module, with no player sockets.',
               'A module with a single socket does not automatically require an additional power socket.',
               'FBX animation groups have defined centered pivots for driver rockers, sensor selector, and termination link.',
               'The exact Level 42 wiring map was not supplied; do not assume Level 41 connections are complete.' ],
      'positions':POSITIONS,
      'models':manifest,'assembled_showcase':{'fbx':name+'.fbx','glb':name+'.glb',
      'triangles':sum(len(p.mesh.faces) for m in assembled for p in m.parts),
      'mesh_parts':sum(len(m.parts) for m in assembled)}}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  out=csv.writer(f);out.writerow(['FBX File','Socket ID','Local X','Local Y','Local Z','Visible Role','Notes'])
  for m in models:
   for sid,coord in m.anchors.items():
    out.writerow([m.key+'.fbx',sid,*coord,sid.replace('_',' '),'Visual socket; create/link actual SparkTerminal component separately'])
 with (ROOT/'DAC_Ladder_Reference_Routing.csv').open('w',newline='',encoding='utf-8') as f:
  out=csv.writer(f);out.writerow(['Reference only','From','To','Notes'])
  for idx,(wid,a,b) in enumerate([
    ('L41-W01','B2','B2_IN'),('L41-W02','B1','B1_IN'),('L41-W03','B0','B0_IN'),
    ('L41-W04','B2_OUT','LINK21_IN'),('L41-W05','LINK21_OUT','B1_OUT'),
    ('L41-W06','B1_OUT','LINK10_IN'),('L41-W07','LINK10_OUT','B0_OUT'),
    ('L41-W08','B0_OUT','TERM_IN'),('L41-W09','TERM_OUT','RET') ]):
   out.writerow([wid,a,b,'Level 41 R-2R reference only; not confirmed as official Level42 wire IDs'])
  out.writerow(['SUGGESTED','SENSOR_OUT','SENSOR_PLUS','Logical comparator input; verify with actual Level42 definition'])
  out.writerow(['SUGGESTED','B2_OUT','DAC_MINUS','Logical DAC comparator input; verify with actual Level42 definition'])
 print('LEVEL 42 DONE: 13 FBX + 13 GLB, 1 assembly, EXACTLY 19 sockets',flush=True)
 return models

if __name__=='__main__':build()
