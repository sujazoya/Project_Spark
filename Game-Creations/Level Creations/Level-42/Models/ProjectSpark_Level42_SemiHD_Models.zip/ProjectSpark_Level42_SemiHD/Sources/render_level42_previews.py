"""Offscreen render actual Level 42 FBX-matched triangle geometry with VTK."""
from build_level42_models import *
from pathlib import Path
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from PIL import Image, ImageDraw, ImageFont
import numpy as np
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
P=ROOT/'Previews';P.mkdir(exist_ok=True)

def actor_for(part,offset=(0,0,0)):
 mesh=part.mesh;poly=vtk.vtkPolyData()
 xyz=np.ascontiguousarray(np.asarray(mesh.vertices)+np.asarray(offset),dtype=np.float32)
 pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(xyz,deep=1));poly.SetPoints(pts)
 faces=np.ascontiguousarray(mesh.faces,dtype=np.int64)
 cells=np.column_stack((np.full(len(faces),3,dtype=np.int64),faces)).reshape(-1)
 cc=vtk.vtkCellArray();cc.SetCells(len(faces),numpy_to_vtkIdTypeArray(cells,deep=1));poly.SetPolys(cc)
 norm=vtk.vtkPolyDataNormals();norm.SetInputData(poly);norm.SplittingOff();norm.ConsistencyOn()
 mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norm.GetOutputPort())
 actor=vtk.vtkActor();actor.SetMapper(mapper)
 rgb=np.array(PALETTE[part.mat][:3])/255.0;pr=actor.GetProperty()
 pr.SetColor(*rgb);pr.SetAmbient(.40);pr.SetDiffuse(.64)
 metallic=part.mat in ('chrome','titanium','steel','gold','copper','orange','mid_steel','brass')
 pr.SetSpecular(.7 if metallic else .24);pr.SetSpecularPower(72 if metallic else 26)
 if part.mat in ('cyan','cyan_hi','green','blue','red','amber','mint','electric','screen_green','violet','warm','yellow'):
  pr.SetAmbient(.8);pr.SetDiffuse(.3)
 if any(v in part.name for v in ('_Text','_Engraving','_Legend','_Label','_Mark','_3D','_Title','_Note','_Subtitle','_STATIC','_Static','_Demo')):
  pr.SetAmbient(.98);pr.SetDiffuse(.035);pr.SetSpecular(.005)
 if part.mat in ('glass','glass_body','water'):
  pr.SetOpacity(.25)
 pr.SetBackfaceCulling(False)
 return actor

def render(models,path,positions=None,eye=(0,22,-27),look=(0,1.2,0),scale=7.9,size=(2400,1450)):
 positions=positions or {};ren=vtk.vtkRenderer()
 ren.SetBackground(.026,.044,.078);ren.SetBackground2(.006,.013,.030);ren.GradientBackgroundOn()
 window=vtk.vtkRenderWindow();window.SetOffScreenRendering(1);window.SetSize(*size);window.SetMultiSamples(2);window.AddRenderer(ren)
 for m in models:
  for part in m.parts:ren.AddActor(actor_for(part,positions.get(m.key,(0,0,0))))
 for pos,c,intensity in [((-14,19,-16),(1,.96,.89),1.0),((14,13,5),(.48,.79,1),1.14),((0,10,-6),(.66,.96,1),.66)]:
  light=vtk.vtkLight();light.SetLightTypeToSceneLight();light.SetPosition(*pos);light.SetFocalPoint(0,0,0)
  light.SetColor(*c);light.SetIntensity(intensity);ren.AddLight(light)
 cam=ren.GetActiveCamera();cam.SetPosition(*eye);cam.SetFocalPoint(*look);cam.SetViewUp(0,1,0)
 cam.ParallelProjectionOn();cam.SetParallelScale(scale)
 window.Render()
 filt=vtk.vtkWindowToImageFilter();filt.SetInput(window);filt.SetInputBufferTypeToRGB();filt.ReadFrontBufferOff();filt.Update()
 writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(filt.GetOutputPort());writer.Write()
 window.Finalize();print('RENDERED',path.name,path.stat().st_size,flush=True)

def overlay(path,title,subtitle,badge=None,level=42):
 im=Image.open(path).convert('RGBA');w,h=im.size;draw=ImageDraw.Draw(im,'RGBA')
 bw=min(w-50,int(w*.85));draw.rounded_rectangle((23,18,bw,139),radius=14,fill=(4,17,30,240),outline=(37,219,250,255),width=2)
 font1=ImageFont.truetype(BOLD,42 if w>=2000 else 27 if w<1200 else 36)
 font2=ImageFont.truetype(FONT,20 if w<1200 else 23)
 draw.text((49,35),title,font=font1,fill=(233,249,255))
 draw.text((49,102),subtitle,font=font2,fill=(117,225,237))
 if badge and w>=1600:
  draw.rounded_rectangle((w-465,20,w-30,90),radius=9,fill=(8,28,43,235),outline=(255,177,65,255),width=2)
  draw.text((w-449,43),badge,font=ImageFont.truetype(BOLD,19),fill=(255,218,148))
 draw.text((w-22,h-24),f'PROJECT SPARK  /  LEVEL {level}  /  REAL FBX MODEL PREVIEW',
           font=ImageFont.truetype(BOLD,13),anchor='ra',fill=(131,218,238))
 im.convert('RGB').save(path)

if __name__=='__main__':
 models=base_dac_models()+[sensor_source(),comparator(),monitor()]
 hero=P/'Level42_Complete_13Piece_Kit_Preview.png'
 render([art_showcase()]+models,hero,POSITIONS,eye=(0,32,-32),look=(0,1.35,0),scale=8.9,size=(2600,1600))
 overlay(hero,'LEVEL 42  /  READ THE ANALOG SIGNAL',
         '13 POLISHED SEMI-HD MODELS   |   SAR ADC + R-2R DAC   |   19 PLAYER SOCKETS',
         badge='SENSOR  /  COMPARATOR  /  8-CODE SWEEP')
 for i,m in enumerate(models):
  ymax=max(p.mesh.bounds[1,1] for p in m.parts)
  sc=2.45 if ymax<2.8 else 2.8
  if i==0:sc=2.55
  if i==12:sc=3.45
  if i==11:sc=2.88
  out=P/(m.key+'_Preview.png')
  render([m],out,eye=(3.8,4.1,-8.4),look=(0,1.25,0),scale=sc,size=(1000,760))
  overlay(out,m.key[3:].replace('_',' ').upper(), 'LEVEL 42 / INDIVIDUAL FBX + GLB MODEL')
 cols=4;rows=4;tw=520;th=390
 sheet=Image.new('RGB',(cols*tw,rows*th),(5,18,30));dr=ImageDraw.Draw(sheet)
 for i,m in enumerate(models):
  x=(i%cols)*tw+6;y=(i//cols)*th+4
  img=Image.open(P/(m.key+'_Preview.png')).convert('RGB')
  img.thumbnail((tw-12,th-68),Image.Resampling.LANCZOS)
  sheet.paste(img,(x,y))
  dr.rounded_rectangle((x,y+th-65,x+tw-12,y+th-14),radius=8,fill=(8,30,48),outline=(37,218,251),width=2)
  name=m.key[3:].replace('_',' ').upper()
  if len(name)>35:name=name[:33]+'..'
  dr.text((x+12,y+th-54),name,font=ImageFont.truetype(BOLD,18),fill=(235,246,252))
 sheet.save(P/'Level42_All_13_Models_ContactSheet.png',quality=96)
 print('LEVEL 42 HERO+13 PREVIEWS+SHEET COMPLETE',flush=True)
