"""Project Spark / Level 38 ONE PRESS, ONE COUNT: polished semi-HD mesh generator.
Generates 6 real electronic props (12 visible terminal sockets), 2 visual analysis props,
individual binary FBX 7.4 and GLB files, art-kit showcase, CSV manifest and wiring list.
No SparkElectricalComponent or gameplay C# scripts are modified.
"""
from __future__ import annotations
import math, csv, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import *

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models'; PREV=ROOT/'Previews'
for p in (MODELS,PREV):p.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'ceramic':(227,197,145,255),'bronze':(148,92,48,255),'aluminium':(202,214,222,255),
 'rose':(246,69,94,255), 'electric':(23,205,255,255), 'mint':(56,238,183,255),
 'violet':(179,100,245,255), 'magenta':(252,94,219,255),'yellow':(255,217,68,255),
 'glass_soft':(112,194,236,75), 'glass_hard':(92,182,232,100),
 'pcb':(21,75,77,255), 'darkglass':(35,113,138,105),
 'screen_green':(60,247,145,255),'dullred':(112,43,53,255),
 'silkscreen':(240,245,233,255),'brass':(216,173,73,255),
})
PORTS={
 '01_5V_Regulated_Supply': [('Battery_positive','+','red'),('Battery_negative','-','blue')],
 '02_Debounce_Pushbutton': [('SW_IN','SW IN','red'),('SW_OUT','SW OUT','red')],
 '03_Feed_Resistor_1kOhm': [('FEED_IN','FEED IN','red'),('FEED_OUT','FEED OUT','amber')],
 '04_Pull_Down_Resistor_10kOhm': [('PULLDOWN_IN','PULL IN','amber'),('PULLDOWN_OUT','PULL OUT','blue')],
 '05_Filter_Resistor_10kOhm': [('FILTER_IN','FILTER IN','amber'),('FILTER_OUT','FILTER OUT','mint')],
 '06_Filter_Capacitor_47uF': [('CAP_Positive','CAP +','mint'),('CAP_Negative','CAP -','blue')],
}
WIRES=[
 ('W01','Battery_positive','SW_IN'),
 ('W02','SW_OUT','FEED_IN'),
 ('W03','FEED_OUT','PULLDOWN_IN'),
 ('W04','FEED_OUT','FILTER_IN'),
 ('W05','PULLDOWN_OUT','Battery_negative'),
 ('W06','FILTER_OUT','CAP_Positive'),
 ('W07','CAP_Negative','Battery_negative'),
]

def chassis(m,t,label,subtitle='',w=3.18,d=1.94,h=1.28):
 m.base(t,w=w,d=d,bodyh=h,fronttext=label,status='')
 z=-d/2-.079
 if subtitle:m.text(t+'_Subtitle',subtitle,.129,0,.91,z-.005,'cyan',maxwidth=w-.28)
 # high-contrast front nameplate strip, industrial corner clips, light piping
 m.box(t+'_FrontAmberAccent',(.54,.026,.029),(-w*.31,.332,z),'orange',group='Illumination_VISUAL')
 m.box(t+'_FrontCyanAccent',(.54,.026,.029),(w*.31,.332,z),'cyan',group='Illumination_VISUAL')
 for x in (-w/2+.16,w/2-.16):
  for zz in (-d/2+.15,d/2-.15):
   m.cyl(t+f'_TopBolt_{x:+.2f}_{zz:+.2f}',.078,.047,(x,.32+h+.114,zz),'chrome',sections=20)
   m.box(t+f'_BoltSlot_{x:+.2f}_{zz:+.2f}',(.082,.006,.017),(x,.32+h+.141,zz),'void')
 for s,x in enumerate((-w/2+.06,w/2-.06)):
  m.box(t+f'_SideFiber_{s}',(.027,.36,.027),(x,.87,-d/2+.08),'amber',group='Illumination_VISUAL')
 return z

def add_ports(m,t,ids=None,w=3.18,d=1.94,at_y=.46):
 ids = PORTS[m.key] if ids is None else ids
 zz=-d/2-.100
 for idx,(id,label,c) in enumerate(ids):
  x=.87 if idx==0 else -.87
  m.cyl(t+'_'+id+'_TitaniumCollar',.196,.070,(x,at_y,zz),'titanium',axis='z',sections=40)
  m.cyl(t+'_'+id+'_ColorRing',.155,.084,(x,at_y,zz-.032),c,axis='z',sections=36)
  m.cyl(t+'_'+id+'_DarkSocket',.104,.090,(x,at_y,zz-.073),'void',axis='z',sections=34)
  m.cyl(t+'_'+id+'_BrassContact',.037,.025,(x,at_y,zz-.101),'gold',axis='z',sections=24)
  m.torus(t+'_'+id+'_NeonLip',.165,.011,(x,at_y,zz-.055),c,axis='z',segments=34,tube_segs=7)
  m.text(t+'_'+id+'_Silkscreen',label,.141,x,at_y+.284,zz-.121,'white',maxwidth=1.00)
  m.anchors[id]=[round(x,4),round(at_y,4),round(zz-.110,4)]

def acrylic_resistor_case(m,t):
 # open-rim clear protective rail above exposed wirewound component
 for x in (-1.30,1.30):
  for z in (-.61,.69):
   m.rod(t+f'_ClearCornerPost_{x:+.2f}_{z:+.2f}',(x,1.78,z),(x,2.47,z),.029,'chrome',sections=10)
 for y in (1.80,2.47):
  for z in (-.61,.69):
   m.rod(t+f'_CaseTopRail_{y:.2f}_{z:+.2f}',(-1.30,y,z),(1.30,y,z),.025,'cyan',sections=9,group='GlassCase_VISUAL')
 for x in (-1.3,1.3):
  m.box(t+f'_AcrylicSide_{x:+.2f}',(.025,.70,1.29),(x,2.12,.04),'glass_soft',group='GlassCase_VISUAL')

def resistor_core(m,t,ohms=1000):
 m.bevel(t+'_HardenedResistorTray',(2.51,.135,1.26),(0,1.67,.02),'steel',.044)
 m.box(t+'_BrushedBusRail',(2.24,.064,.26),(0,1.758,.04),'void')
 m.cyl(t+'_CeramicAxialBody',.235,1.42,(0,2.04,.07),'ceramic',axis='x',sections=40)
 bands=(('bronze','void','red','gold') if ohms==1000 else ('bronze','void','orange','gold'))
 for i,(x,col) in enumerate(zip((-.40,-.19,.125,.46),bands)):
  m.torus(t+f'_CalibrationBand_{i}_{col}',.240,.038,(x,2.04,.07),col,axis='x',segments=44,tube_segs=9)
 for sign in (-1,1):
  m.cyl(t+f'_EndCap_{sign}',.248,.065,(sign*.725,2.04,.07),'brass',axis='x',sections=30)
  m.rod(t+f'_NickelAxialLead_{sign}',(sign*.76,2.04,.07),(sign*1.23,2.04,.07),.039,'chrome',sections=12)
  m.cyl(t+f'_GoldScrewPost_{sign}',.13,.18,(sign*1.20,1.835,.07),'gold',sections=24)
 acrylic_resistor_case(m,t)

def supply():
 m=Model('01_5V_Regulated_Supply'); t='L38_Power'
 chassis(m,t,'5 V SUPPLY','REGULATED  5.00 V',h=1.53)
 add_ports(m,t)
 m.bevel(t+'_LCD_Bezel',(1.28,.38,.057),(0,1.58,-1.046),'titanium',.06)
 m.bevel(t+'_LCD_Screen',(1.19,.295,.058),(0,1.58,-1.087),'screen',.028)
 m.text(t+'_LCD_STATIC_5_00V','5.00 V',.25,0,1.57,-1.124,'screen_green',maxwidth=1.05)
 for i in range(14):m.box(t+f'_TopVent_{i:02d}',(.057,.025,.38),(-1.23+i*.19,2.05,.18),'void')
 m.box(t+'_PowerReadyBar_Animate',(.93,.052,.056),(0,2.00,-.55),'green',group='PowerReady_VISUAL')
 return m

def pushbutton():
 m=Model('02_Debounce_Pushbutton');t='L38_SW'
 chassis(m,t,'PUSHBUTTON','CONTACT BOUNCE / SPST')
 add_ports(m,t)
 m.bevel(t+'_ActuatorMount',(1.23,.20,1.11),(0,1.72,.04),'titanium',.085)
 m.cyl(t+'_ActuatorNeck',.47,.16,(0,1.87,.04),'chrome',sections=46)
 m.torus(t+'_SwitchChromeHalo',.49,.050,(0,1.98,.04),'cyan',axis='y',segments=54,tube_segs=11,group='Glow_RING_VISUAL')
 m.cyl(t+'_SwitchStem_ANIMATE',.31,.33,(0,2.10,.04),'steel',sections=40,group='ButtonCap_UPDOWN_ANIMATE')
 m.cyl(t+'_RedPushbuttonCap_ANIMATE',.45,.22,(0,2.32,.04),'red',sections=56,group='ButtonCap_UPDOWN_ANIMATE')
 m.cyl(t+'_RedCapInnerHighlight_ANIMATE',.33,.019,(0,2.435,.04),'rose',sections=50,group='ButtonCap_UPDOWN_ANIMATE')
 m.torus(t+'_PushbuttonLuminousLip_ANIMATE',.405,.018,(0,2.437,.04),'orange',axis='y',segments=54,tube_segs=10,group='ButtonCap_UPDOWN_ANIMATE')
 for k,x in enumerate((-.54,.54)):
  m.cyl(t+f'_BrassContactStand_{k}',.101,.24,(x,1.79,.48),'gold',sections=18,group='SwitchContacts_VISUAL')
  m.rod(t+f'_LeafSpring_{k}',(x,1.90,.48),(x*.42,2.02,.34),.038,'chrome',sections=10,group='SwitchContacts_VISUAL')
 m.box(t+'_PressTip',(.22,.041,.12),(0,1.715,-1.035),'cyan',group='InteractionHighlight_VISUAL')
 return m

def resistor(key,name,ohms,subtitle):
 m=Model(key);t='L38_'+name.replace(' ','_')
 chassis(m,t,name,subtitle)
 add_ports(m,t)
 resistor_core(m,t,ohms)
 return m

def capacitor():
 m=Model('06_Filter_Capacitor_47uF');t='L38_CAP'
 chassis(m,t,'47 uF CAPACITOR','LOW PASS / 16 V')
 add_ports(m,t)
 m.bevel(t+'_PositiveCapSocket',(1.65,.16,1.24),(0,1.70,.08),'steel',.075)
 m.cyl(t+'_InsulationSkirt',.50,.10,(0,1.84,.08),'rubber',sections=44)
 m.cyl(t+'_MetalCan',.49,1.26,(0,2.53,.08),'void',sections=58)
 m.cyl(t+'_CanColorStrip',.50,.11,(0,2.38,.08),'blue',sections=56)
 m.cyl(t+'_CanSilverRim',.50,.092,(0,3.20,.08),'titanium',sections=56)
 m.cyl(t+'_CanTop',.46,.019,(0,3.25,.08),'chrome',sections=56)
 m.torus(t+'_CapTopCrossEtching',.33,.015,(0,3.268,.08),'steel',axis='y',segments=52,tube_segs=8)
 m.text(t+'_CanBodyText_47uF','47 uF',.22,0,2.69,-.444,'white',maxwidth=.75)
 m.text(t+'_CanBodyText_16V','16 V',.19,0,2.47,-.448,'fog',maxwidth=.64)
 m.box(t+'_BlueIndicatorStrip_VISUAL',(.037,.8,.020),(.25,2.62,-.418),'cyan',group='CapacitorStripe_VISUAL')
 for s in (-1,1):
  m.cyl(t+f'_GoldTerminal_{s}',.075,.21,(s*.49,1.75,.48),'gold',sections=18)
 return m

def trace_line(m,t,p,q,color,thickness=.022,group='Static'):
 m.rod(t,p,q,thickness,color,sections=9,group=group)

def pulse_analyzer():
 m=Model('07_Visual_RawFiltered_Analyzer');t='L38_PULSE_SCOPE'
 chassis(m,t,'PULSE ANALYZER','RAW / FILTERED  |  VISUAL ONLY',w=3.70,d=2.18,h=1.65)
 # Scope front display faces player; two horizontal rows on a single screen
 m.bevel(t+'_WideAluminumDisplayFrame',(3.13,1.25,.10),(0,1.35,-1.155),'chrome',.075)
 m.bevel(t+'_OLED_Screen',(3.00,1.14,.071),(0,1.35,-1.209),'screen',.05)
 for i in range(12):
  x=-1.26+i*.23;m.box(t+f'_ScopeGridV_{i}',(.008,.91,.004),(x,1.35,-1.252),'mid_steel')
 for i in range(6):
  y=.92+i*.18;m.box(t+f'_ScopeGridH_{i}',(2.70,.008,.004),(0,y,-1.252),'mid_steel')
 m.text(t+'_LegendRAW','RAW',.12,-1.21,1.74,-1.266,'red',maxwidth=.40)
 m.text(t+'_LegendFiltered','FILTER',.12,-1.14,1.12,-1.266,'mint',maxwidth=.65)
 # three bouncing edges in raw waveform; one clean filtered event
 coords=[(-.69,1.46),(-.49,1.46),(-.49,1.81),(-.29,1.81),(-.29,1.46),(-.14,1.46),(-.14,1.81),(.05,1.81),(.05,1.46),(.21,1.46),(.21,1.81),(.39,1.81),(.39,1.46),(.90,1.46)]
 for i in range(len(coords)-1):
  (x,y),(xx,yy)=coords[i],coords[i+1]
  trace_line(m,t+f'_RawBouncePulse_{i}',(x,y,-1.277),(xx,yy,-1.277),'red',.026,group='RAW_BOUNCE_SIGNAL_VISUAL')
 coords2=[(-.69,.97),(-.17,.97),(-.17,1.27),(.51,1.27),(.51,.97),(.90,.97)]
 for i in range(len(coords2)-1):
  (x,y),(xx,yy)=coords2[i],coords2[i+1]
  trace_line(m,t+f'_FilteredCleanPulse_{i}',(x,y,-1.280),(xx,yy,-1.280),'mint',.030,group='FILTERED_SIGNAL_VISUAL')
 m.box(t+'_PowerLamp_VISUAL',(.30,.044,.025),(0,.327,-1.16),'cyan',group='ScopeStatus_VISUAL')
 for k,x in enumerate((-.75,0,.75)):
  m.cyl(t+f'_FrontKnob_{k}',.12,.072,(x,.46,-1.21),'steel',axis='z',sections=30,group='ScopeControls_VISUAL')
 return m

def counter():
 m=Model('08_Visual_Press_Counter');t='L38_COUNTER'
 chassis(m,t,'ONE COUNT','01 PER VALID PRESS',w=3.46,d=2.08,h=1.56)
 m.bevel(t+'_CounterOLEDBezel',(2.52,.91,.06),(0,1.32,-1.098),'titanium',.065)
 m.bevel(t+'_CounterOLEDGlass',(2.42,.82,.055),(0,1.32,-1.139),'screen',.06)
 m.text(t+'_Display_Static_01','01',.69,0,1.32,-1.184,'screen_green',maxwidth=1.55,group='CounterDigits_REPLACE_VISUAL')
 m.text(t+'_MeterLabel','COUNTED PRESSES',.16,0,1.92,-1.184,'white',maxwidth=2.2)
 for s,x in enumerate((-.9,0,.9)):
  m.cyl(t+f'_SoftKey_{s}',.12,.065,(x,1.92,.05),'steel' if s else 'gold',sections=32,group='CounterButton_VISUAL')
 m.torus(t+'_IndicatorRing_VISUAL',.30,.026,(0,1.975,.65),'mint',axis='y',segments=50,tube_segs=9,group='CounterStatus_VISUAL')
 return m

def board():
 m=Model('00_Showcase_Base');t='L38_BOARD'
 m.bevel(t+'_GroundRubber',(21.8,.13,9.95),(0,.10,0),'rubber',.18)
 m.bevel(t+'_BrushedTitaniumBase',(21.7,.18,9.82),(0,.21,0),'steel',.14)
 m.bevel(t+'_BlackPerforatedWorksurface',(21.46,.065,9.58),(0,.34,0),'graphite',.085)
 for x in (-10.60,10.60):m.box(t+f'_NeonX_{x}',(.050,.040,9.2),(x,.39,0),'cyan',group='ShowcaseEdge_VISUAL')
 for z in (-4.69,4.69):m.box(t+f'_NeonZ_{z}',(21.12,.040,.055),(0,.39,z),'cyan',group='ShowcaseEdge_VISUAL')
 for x in np.linspace(-10.3,10.3,45):
  for z in np.linspace(-4.48,4.48,20):
   m.cyl(t+f'_ToolingHole_{x:+.2f}_{z:+.2f}',.013,.004,(x,.381,z),'mid_steel',sections=6)
 # two large, purely decorative routing channels: no connection to the electrical solver
 m.box(t+'_ChannelCyan',(.06,.015,8.50),(0,.40,0),'cyan',group='ShowcaseEdge_VISUAL')
 return m

BUILDERS=[supply,pushbutton,
 lambda:resistor('03_Feed_Resistor_1kOhm','1 kOhm FEED',1000,'BROWN BLACK RED GOLD'),
 lambda:resistor('04_Pull_Down_Resistor_10kOhm','10 kOhm PULL-DOWN',10000,'RAW SIGNAL / GROUND'),
 lambda:resistor('05_Filter_Resistor_10kOhm','10 kOhm FILTER',10000,'LOW PASS / 10 kOhm'),
 capacitor,pulse_analyzer,counter]
STAGING={
 '01_5V_Regulated_Supply':(8.0,0,2.10),
 '02_Debounce_Pushbutton':(3.58,0,2.10),
 '03_Feed_Resistor_1kOhm':(-.82,0,2.10),
 '04_Pull_Down_Resistor_10kOhm':(-5.27,0,2.10),
 '05_Filter_Resistor_10kOhm':(8.0,0,-2.20),
 '06_Filter_Capacitor_47uF':(3.58,0,-2.20),
 '07_Visual_RawFiltered_Analyzer':(-.82,0,-2.20),
 '08_Visual_Press_Counter':(-5.32,0,-2.20),
 '00_Showcase_Base':(0,0,0),
}

def build():
 mods=[fn() for fn in BUILDERS]
 pins=[pin for m in mods[:6] for pin in m.anchors]
 assert len(pins)==12 and len(set(pins))==12
 assert len(WIRES)==7 and all(a in pins and b in pins for _,a,b in WIRES)
 data={}
 for m in mods:
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m]);
  data[m.key]={'fbx':fbx.name,'glb':glb.name,'mesh_objects':len(m.parts),
               'triangles':sum(len(p.mesh.faces) for p in m.parts),
               'terminal_anchors':m.anchors,
               'animation_groups':list(dict.fromkeys(p.group for p in m.parts if p.group!='Static'))}
  print('EXPORTED',m.key,data[m.key]['triangles'],'triangles',len(m.parts),'mesh objects',flush=True)
 allmods=[board()]+mods
 full=MODELS/'Level38_Complete_ArtKit_Showcase.fbx';fullglb=MODELS/'Level38_Complete_ArtKit_Showcase.glb'
 export_fbx(full,allmods,positions=STAGING);export_glb(fullglb,allmods,positions=STAGING)
 data['Level38_Complete_ArtKit_Showcase']={'fbx':full.name,'glb':fullglb.name,
 'triangles':sum(len(p.mesh.faces) for mod in allmods for p in mod.parts),
 'mesh_objects':sum(len(mod.parts) for mod in allmods)}
 manifest={'level':38,'title':'One Press, One Count','individual_models':8,
           'real_electrical_models':6,'decorative_visual_models':2,
           'electrical_terminal_anchors':12,'wire_count':7,
           'coordinate_system':'Y-up, front faces -Z, arbitrary art units',
           'showcase_positions':STAGING,
           'wires':[{'wire':i,'from':a,'to':b} for i,a,b in WIRES],
           'models':data,
           'notes':'Art assets only, no SparkTerminal or electrical simulator components. Scope/counter screens are static visuals by default.'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
  writer=csv.writer(f);writer.writerow(['Wire','From','To']);writer.writerows(WIRES)
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  writer=csv.writer(f);writer.writerow(['FBX','Runtime ID suggestion','Local X','Local Y','Local Z','Suggested GameObject'])
  for m in mods[:6]:
   for pin,coord in m.anchors.items():writer.writerow([m.key+'.fbx',pin,*coord,pin])
 print('SUCCESS Level 38 8FBX+8GLB + assembled, 12 anchors, 7 wires',flush=True)

if __name__=='__main__':build()
