PROJECT SPARK — LEVEL 38 / ONE PRESS, ONE COUNT
POLISHED SEMI-HD UNITY FBX MODEL PACK
============================================

WHAT IS INCLUDED
----------------
Eight individual 3D art models (FBX and GLB), one assembled showcase FBX/GLB,
model preview PNGs, a terminal-anchor CSV, the exact W01-W07 connection CSV,
a JSON manifest, and editable procedural creation/render source scripts.

SIX ELECTRICAL ART MODELS — 12 PHYSICAL SOCKET POSITIONS
-------------------------------------------------------
01_5V_Regulated_Supply.fbx           Battery_positive / Battery_negative
02_Debounce_Pushbutton.fbx           SW_IN / SW_OUT
03_Feed_Resistor_1kOhm.fbx           FEED_IN / FEED_OUT
04_Pull_Down_Resistor_10kOhm.fbx     PULLDOWN_IN / PULLDOWN_OUT
05_Filter_Resistor_10kOhm.fbx        FILTER_IN / FILTER_OUT
06_Filter_Capacitor_47uF.fbx        CAP_Positive / CAP_Negative

VISUAL-ONLY ADD-ONS — NO ELECTRICAL SOCKETS
-------------------------------------------
07_Visual_RawFiltered_Analyzer.fbx   Red RAW contact bounce + mint filtered pulse
08_Visual_Press_Counter.fbx         Green '01' pulse counter

EXACT LEVEL 38 CONNECTIONS
--------------------------
W01 Battery_positive -> SW_IN
W02 SW_OUT -> FEED_IN
W03 FEED_OUT -> PULLDOWN_IN
W04 FEED_OUT -> FILTER_IN
W05 PULLDOWN_OUT -> Battery_negative
W06 FILTER_OUT -> CAP_Positive
W07 CAP_Negative -> Battery_negative

REFERENCE COMPONENT VALUES
--------------------------
Supply: 5 V
Pushbutton: momentary contact
Feed resistor: 1 kOhm, brown-black-red-gold
Pull-down resistor: 10 kOhm, brown-black-orange-gold
Filter resistor: 10 kOhm, brown-black-orange-gold
Capacitor: 47 microfarads, 16 V, polarized
RC filter nominal time constant: 10,000 Ohm * 0.000047 F = 0.47 s
The raw contact bounce is visualized as multiple short transitions while the
filtered pulse remains ONE stable count per press.

UNITY SETUP
-----------
1. Drag the Models directory into Assets/My_Assets/_Project_Spark/Models/Level38/.
2. Import the individual FBX models, not the assembled showcase, for gameplay.
3. Front of each module faces local -Z; model coordinate system is Y-UP.
4. Adjust scale uniformly to match your existing Project Spark workbench shelf.
5. Under a game object for each prop, create actual SparkTerminal child objects
   at the suggested Local XYZ positions from Terminal_Anchors.csv.
   IMPORTANT: FBX socket meshes are art. They are NOT SparkTerminal components.
6. Keep existing Project Spark scene bindings, resistor/Capacitor/Switch electrical
   controllers, circuit solver, interaction systems, and Level 38 evaluator.
   Do not attach a second SparkSwitch/Resistor/Capacitor if one is already present.
7. Connect your existing Switch / MomentaryButton gameplay interaction to the
   Group 'ButtonCap_UPDOWN_ANIMATE'. Animate local Y depression gently (e.g. 0.09).
8. The analyzer waveform and counter digits are static visual preview meshes.
   To show live values, hide/replace their named display groups and bind your
   existing UI/TMP/dynamic material to your live Level 38 controller.
9. The entire assembled art-kit FBX is a DESIGN SHOWCASE, not a prewired scene.

MATERIAL / MODEL DETAILS
------------------------
- Metallic, machined, chamfered industrial shells and steel bases
- Actual 3D front labels, realistic resistor body/color bands
- Cyan LED accents, rings around gold-contact terminal sockets
- Sculpted red pushbutton cap with a separate animation group
- Full 47uF cylindrical capacitor with cathode stripe, rated 16 V
- A raw vs filtered waveform screen and a 2-digit press counter
- FBX 7.4 BINARY and GLB alternatives, procedural Python build source
- The UV-free solid colors are attached as geometry/material definitions;
  adjust shader metallic/smoothness/emission in your Unity renderer to taste.

QUALITY / LIMITATIONS
---------------------
The exports are structurally checked and GLB meshes can be parsed. The models
have NOT been imported into your particular Unity project; refine material
mapping, normals, import axis, and animation pivots there as needed.
No working game physics, electrical devices, components, scripts, or prefab
references are embedded in these files. They are intentionally VISUAL assets.

PROJECT SPARK / LEVEL 38 / ONE PRESS ONE COUNT
