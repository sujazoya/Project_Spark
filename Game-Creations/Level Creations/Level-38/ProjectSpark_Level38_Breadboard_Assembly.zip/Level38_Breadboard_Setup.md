# Level 38 | One Press, One Count

Wire a pushbutton and an RC filter. The analyzer shows RAW in amber and FILTERED in mint. The pushbutton cap follows the contact while the on-screen controls run repeatable bounce patterns.

## Wire the breadboard

| Wire | From | To |
| --- | --- | --- |
| W01 | Supply + | Pushbutton IN |
| W02 | Pushbutton OUT | 1 kΩ Feed IN |
| W03 | 1 kΩ Feed RAW | 10 kΩ Pull-Down IN |
| W04 | 1 kΩ Feed RAW | 10 kΩ Filter IN |
| W05 | 10 kΩ Pull-Down OUT | Supply − |
| W06 | 10 kΩ Filter OUT | 47 µF Capacitor + |
| W07 | 47 µF Capacitor − | Supply − |

Feed RAW accepts W03 and W04. The capacitor positive socket is the FILTERED node.

## Play to 6/6

| Progress | Action | Expected result |
| --- | --- | --- |
| 1/6 | Finish all seven wires. | RAW and FILTERED settle near 0 V. |
| 2/6 | Press **RAW TEST**. | One bounced press gives three raw edges and a count of **03**. |
| 3/6 | Press **FILTERED MODE**, then **100 ms GLITCH**. | The filtered voltage stays below 3.0 V. The count stays **00**. |
| 4/6 | Press **BOUNCED PRESS**. | FILTERED crosses the threshold once. The count becomes **01** and the display shows **HELD**. |
| 5/6 | Press **BOUNCED RELEASE**. | The count stays **01**. The display switches to **ARMED** when FILTERED falls below 2.0 V. |
| 6/6 | Press **SECOND CYCLE**. | The count ends at **02**, the input rearms, and the campaign marks the level complete. |

## Install in another Project Spark checkout

Merge the included `Assets` folder into the existing project and keep the Unity `.meta` files. Use the existing Level 38 campaign entry, layout catalog, and teaching drawing. The existing solver needs transient simulation enabled with a step of 50 ms or less. If the MainMenu breadboard geometry changes, open MainMenu in Edit Mode and run **Tools → Project Spark → Level 38 → Fit Breadboard Assembly**.
