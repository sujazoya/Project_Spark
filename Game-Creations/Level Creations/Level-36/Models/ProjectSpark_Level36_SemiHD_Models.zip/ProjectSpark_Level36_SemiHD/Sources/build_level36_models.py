"""Project Spark Level 36 THERMAL INTERLOCK: original semi-HD mesh set.
Unity axes: +Y up, -Z module front; one gameplay terminal socket = one local anchor.
Pure geometry only: visual 3D meshes, never simulated electrical elements.
"""
from __future__ import annotations
import math, json, csv
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import *

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models'; PREV=ROOT/'Previews'
MODELS.mkdir(parents=True,exist_ok=True); PREV.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'warm_white':(250,239,204,255),'ceramic':(223,214,188,255),
 'resistor':(221,180,126,255),'bronze':(145,81,48,255),'warm_metal':(177,143,101,255),
 'acrylic':(70,206,246,47),'glass_gold':(230,172,90,59),'glass_clear':(135,235,252,33),
 'red_hot':(255,79,37,255),'dark_red':(135,37,37,255),'copper_bright':(255,143,47,255),
 'blue_fan':(38,170,253,255),'light_cyan':(136,249,251,255),
 'sensor_steel':(145,175,199,255),'dark_ceramic':(29,39,51,255),
 'screen_green':(102,251,161,255),'safety_yellow':(255,192,53,255),
 'crimson':(255,48,77,255),'amber_led':(255,140,57,255),
})

# 5 ports x +/- for all ten modules; physical sockets correspond EXACTLY to Level36 image.
PORTSETS={
 '01_5V_Regulated_Supply':('Battery_positive','Battery_negative'),
 '02_10kOhm_Pullup':('PULLUP_IN','PULLUP_OUT'),
 '03_NTC_Temperature_Sensor':('SENSOR_IN','SENSOR_RETURN'),
 '04_Cooling_Fan_Contact':('FAN_SW_IN','FAN_SW_OUT'),
 '05_Cooling_Fan_47Ohm':('FAN_A','FAN_B'),
 '06_Heater_Safety_Contact':('HEAT_SW_IN','HEAT_SW_OUT'),
 '07_Tubular_Heater_100Ohm':('HEATER_IN','HEATER_OUT'),
 '08_Fault_Trip_Contact':('FAULT_SW_IN','FAULT_SW_OUT'),
 '09_LED_Resistor_330Ohm':('LED_R_IN','LED_R_OUT'),
 '10_Fault_LED_Indicator':('LED_A','LED_K')
}
WIRES=[
 ('W01','Battery_positive','PULLUP_IN'),
 ('W02','PULLUP_OUT','SENSOR_IN'),
 ('W03','SENSOR_RETURN','Battery_negative'),
 ('W04','Battery_positive','FAN_SW_IN'),
 ('W05','FAN_SW_OUT','FAN_A'),
 ('W06','FAN_B','Battery_negative'),
 ('W07','Battery_positive','HEAT_SW_IN'),
 ('W08','HEAT_SW_OUT','HEATER_IN'),
 ('W09','HEATER_OUT','Battery_negative'),
 ('W10','Battery_positive','FAULT_SW_IN'),
 ('W11','FAULT_SW_OUT','LED_R_IN'),
 ('W12','LED_R_OUT','LED_A'),
 ('W13','LED_K','Battery_negative'),
]

def ports(m,t,ids,labels=('IN','OUT'),colors=('red','blue'), w=2.85,d=1.88):
 z=-d/2-.088
 for x,pid,label,col in zip((.78,-.78),ids,labels,colors):
  m.cyl(t+pid+'_ChromeSocket',.158,.061,(x,.45,z),'chrome',axis='z',sections=36)
  m.cyl(t+pid+'_SocketPolarityRing',.128,.064,(x,.45,z-.037),col,axis='z',sections=36)
  m.cyl(t+pid+'_Recess',.084,.074,(x,.45,z-.076),'void',axis='z',sections=30)
  m.cyl(t+pid+'_MetalPin',.033,.025,(x,.45,z-.103),'gold',axis='z',sections=20)
  m.torus(t+pid+'_SocketHalo',.126,.011,(x,.45,z-.074),col,axis='z',segments=40,tube_segs=8)
  m.text(t+pid+'_SocketLabel',label,.126,x,.72,z-.11,'white',maxwidth=.83)
  m.anchors[pid]=[round(x,4),.45,round(z-.114,4)]

def shell(m,t,label,sub='', w=2.94,d=1.88,h=1.12):
 m.base(t,w=w,d=d,bodyh=h,fronttext=label,status=sub)
 for side in (-1,1):
  xx=side*(w/2-.13)
  for zz in (-d/2+.16,d/2-.16):
   m.cyl(t+f'_TopArmorFastener_{side:+}_{zz:+.2f}',.061,.05,(xx,.32+h+.1,zz),'chrome',sections=20)
 m.box(t+'_FrontStatusBar',(.78,.027,.034),(0,.302,-d/2-.07),'cyan',group='StatusLED_VISUAL')

def resistor_body(m,t,kind='10k'):
 x,y,z=0,2.01,.08
 m.cyl(t+'_CeramicAxialBody',.215,1.27,(x,y,z),'resistor',axis='x',sections=46)
 for k in (-1,1):
  m.cyl(t+f'_AxialCap_{k}',.225,.075,(k*.65,y,z),'gold',axis='x',sections=36)
  m.rod(t+f'_NickelLead_{k}',(k*.69,y,z),(k*1.12,y,z),.039,'chrome',sections=14)
  m.cyl(t+f'_BrassMount_{k}',.118,.076,(k*1.12,1.64,z),'copper',sections=20)
 band={'10k':['bronze','void','orange','gold'], '330':['orange','orange','bronze','gold']}[kind]
 for i,(xx,c) in enumerate(zip((-.39,-.17,.08,.38),band)):
  m.torus(t+f'_ColorCodeBand_{i+1}',.217,.031,(xx,y,z),c,axis='x',segments=40,tube_segs=8)
 m.bevel(t+'_InsulatingCeramicSeat',(2.34,.105,1.02),(0,1.65,.06),'ceramic',.065)

def guard(m,t,wide=2.45,depth=1.29,level=1.63,height=.84):
 # Thin translucent acrylic side sheets, OPEN TOP to reveal internal mechanics in Unity.
 for xx in (-wide/2,wide/2):
  m.box(t+f'_AcrylicSidePanel_{xx}',(.025,height,depth),(xx,level+height/2,.06),'acrylic')
  for zz in (-depth/2+.06,depth/2+.06):
   m.rod(t+f'_GuardCornerPost_{xx}_{zz}',(xx,level,zz),(xx,level+height,zz),.030,'light_cyan',sections=10)
  m.rod(t+f'_TopGuardRail_{xx}',(xx,level+height,-depth/2+.06),(xx,level+height,depth/2+.06),.033,'chrome',sections=12)
 for zz in (-depth/2+.06,depth/2+.06):
  m.rod(t+f'_GuardCrossRail_{zz}',(-wide/2,level+height,zz),(wide/2,level+height,zz),.033,'chrome',sections=12)

def supply():
 m=Model('01_5V_Regulated_Supply'); t='L36_SUPPLY'
 shell(m,t,'5 V SUPPLY','REGULATED / 5.00 V',w=3.18,d=1.88,h=1.51)
 ports(m,t,PORTSETS[m.key],('+','-'),('red','blue'),w=3.18)
 m.bevel(t+'_LED_DisplayChrome',(1.49,.34,.060),(0,1.48,-.992),'chrome',.045)
 m.bevel(t+'_DigitalVoltageDisplay',(1.40,.26,.037),(0,1.48,-1.032),'screen',.032)
 m.text(t+'_Display_5_00V','5.00 V',.24,0,1.48,-1.063,'screen_green',maxwidth=1.27)
 for x in np.linspace(-1.14,1.14,13):m.box(t+f'_SlottedCoolingVent_{x:.2f}',(.066,.013,.44),(float(x),1.94,.12),'void')
 m.box(t+'_ReadyGreen_VISUAL',(.83,.036,.04),(0,2.01,-.42),'green',group='PowerStatus_VISUAL')
 return m

def pullup():
 m=Model('02_10kOhm_Pullup');t='L36_PULLUP'
 shell(m,t,'10 kOhm PULL-UP','NTC DIVIDER / R = 10 kOhm')
 ports(m,t,PORTSETS[m.key],('IN','OUT'),('red','green'))
 resistor_body(m,t,'10k');guard(m,t)
 return m

def sensor():
 m=Model('03_NTC_Temperature_Sensor');t='L36_NTC_SENSOR'
 shell(m,t,'NTC SENSOR','TEMPERATURE / IN + RETURN')
 ports(m,t,PORTSETS[m.key],('IN','RETURN'),('green','blue'))
 m.bevel(t+'_Thermistor_Mount',(1.95,.15,1.11),(0,1.70,.03),'steel',.042)
 # machined steel cylindrical probe suspended above the mount
 m.cyl(t+'_NTC_MetalProbe',.28,1.45,(0,2.15,.12),'sensor_steel',axis='x',sections=40)
 m.cyl(t+'_NTC_ProbeTip',.27,.12,(-.78,2.15,.12),'chrome',axis='x',sections=36)
 m.cyl(t+'_NTC_BackNut',.33,.27,(.77,2.15,.12),'gold',axis='x',sections=36)
 m.torus(t+'_ProbeHeatIndicatorRing',.285,.024,(-.25,2.15,.12),'amber',axis='x',segments=42,tube_segs=7,group='HeatIndicator_VISUAL')
 for i in range(9):
  x=.47+i*.065
  m.torus(t+f'_CableGrip_Corrugation_{i}',.225,.031,(x,2.15,.12),'rubber',axis='x',segments=27,tube_segs=7)
 m.rod(t+'_ProbeCable',(.90,2.13,.13),(1.2,1.8,.42),.075,'rubber',sections=15)
 m.cyl(t+'_TempLED',.086,.061,(0,1.7,-.45),'amber',axis='z',sections=26,group='HeatIndicator_VISUAL')
 return m

def relay(key,t,label,kind):
 m=Model(key)
 subtitle={'fan':'COOL ON','heat':'OVERHEAT LOCKOUT','fault':'ALARM CONTACT'}[kind]
 shell(m,t,label,subtitle)
 colors=('red','green') if kind!='fault' else ('red','orange')
 ports(m,t,PORTSETS[key],('IN','OUT'),colors)
 # relay coil / armature exposed behind a clear protective cage
 m.bevel(t+'_ContactAssemblyBase',(2.41,.12,1.25),(0,1.61,.08),'steel',.07)
 coil_x=-.59
 m.cyl(t+'_FerrousCore',.20,.92,(coil_x,2.04,.14),'mid_steel',axis='x',sections=34)
 for i in range(17):
  xx=coil_x-.42+i*.052
  m.torus(t+f'_SolenoidCopperTurn_{i:02d}',.211,.038,(xx,2.04,.14),'copper_bright',axis='x',segments=33,tube_segs=7)
 m.cyl(t+'_BrassCommonStud',.16,.13,(.45,1.81,.17),'gold',sections=25)
 m.cyl(t+'_BrassNormallyOpenStud',.16,.13,(1.00,1.81,.17),'gold',sections=25)
 m.rod(t+'_Armature_Hinged_ANIMATE',(.17,2.17,.13),(.92,2.36,.13),.09,'gold',sections=12,group='ContactArmature_ANIMATE')
 m.cyl(t+'_ActuatorPivot_ANIMATE',.15,.13,(.17,2.16,.13),'steel',axis='z',sections=20,group='ContactArmature_ANIMATE')
 m.cyl(t+'_ContactSilverTip_ANIMATE',.11,.13,(.92,2.36,.13),'chrome',axis='z',sections=18,group='ContactArmature_ANIMATE')
 m.box(t+'_ContactStatusLight',(.35,.052,.045),(1.00,1.54,-.15),'red' if kind=='fault' else ('green' if kind=='fan' else 'amber'),group='ContactStatus_VISUAL')
 guard(m,t,wide=2.51,depth=1.39,level=1.69,height=.87)
 return m

def fan():
 m=Model('05_Cooling_Fan_47Ohm');t='L36_COOLING_FAN'
 shell(m,t,'COOLING FAN','47 Ohm / MOTOR LOAD')
 ports(m,t,PORTSETS[m.key],('A','B'),('green','blue'))
 # rotor faces UP to remain visible from top-down scene camera
 m.bevel(t+'_FanFrame',(2.15,.20,1.40),(0,1.67,.05),'steel',.062)
 m.cyl(t+'_OuterFanCowling',.69,.22,(0,1.82,.04),'void',sections=50)
 m.cyl(t+'_SpinningRotorHub_ANIMATE',.24,.19,(0,1.99,.04),'steel',sections=32,group='FanRotor_ANIMATE')
 for j in range(7):
  angle=math.tau*j/7
  # individually modeled swept blades, pivot in the FanRotor_ANIMATE group
  verts=[];faces=[]
  for k,(rad,ang,yy) in enumerate(((.22,angle-.10,1.91),(.64,angle+.17,1.92),(.59,angle+.57,1.95),(.24,angle+.45,1.94))):
   verts.append((rad*math.cos(ang),yy,.04+rad*math.sin(ang)))
  faces.extend([(0,1,2),(0,2,3),(2,1,0),(3,2,0)])
  m.add(t+f'_FanBlade_{j:02d}_ANIMATE',trimesh.Trimesh(vertices=verts,faces=faces,process=False),'blue_fan',group='FanRotor_ANIMATE')
 m.cyl(t+'_CenterHubLogo_ANIMATE',.15,.043,(0,2.1,.04),'cyan',sections=30,group='FanRotor_ANIMATE')
 for a in range(12):
  th=math.tau*a/12
  p1=(.74*math.cos(th),1.84,.04+.74*math.sin(th));p2=(.82*math.cos(th),1.84,.04+.82*math.sin(th))
  m.rod(t+f'_SafetyRingSpoke_{a}',p1,p2,.02,'steel',sections=8)
 m.torus(t+'_FanSafetyRim',.77,.055,(0,1.87,.04),'chrome',axis='y',segments=60,tube_segs=9)
 for dx in (-.81,.81):
  for dz in (-.55,.55):m.cyl(t+f'_GuardScrew_{dx}_{dz}',.063,.035,(dx,1.805,dz),'gold',sections=16)
 return m

def heater():
 m=Model('07_Tubular_Heater_100Ohm');t='L36_HEATER'
 shell(m,t,'HEATER 100 Ohm','THERMAL LOAD / HOT')
 ports(m,t,PORTSETS[m.key],('IN','OUT'),('amber','blue'))
 m.bevel(t+'_HeatSinkMount',(2.28,.12,1.08),(0,1.63,.06),'steel',.05)
 # Heat coil winding along X, seated in transparent open guard
 m.cyl(t+'_CoreCeramic',.18,1.6,(0,2.00,.08),'dark_ceramic',axis='x',sections=38)
 m.tube(t+'_TranslucentHeaterTube',.305,.282,1.62,(0,2.00,.08),'glass_gold',axis='x',segments=40,group='HeaterGlass_VISUAL')
 for i in range(20):
  x=-.71+i*.075
  m.torus(t+f'_IncandescentCoil_{i:02d}_VISUAL',.20,.041,(x,2,.08),'red_hot' if i%3==0 else 'copper_bright',axis='x',segments=38,tube_segs=8,group='HeaterGlow_VISUAL')
 for sx in (-.83,.83):
  m.cyl(t+f'_HeaterSocketCeramic_{sx}',.31,.18,(sx,2,.08),'ceramic',axis='x',sections=28)
  m.cyl(t+f'_ThermalContactStud_{sx}',.12,.15,(sx*1.02,2,.08),'gold',axis='x',sections=24)
 guard(m,t,wide=2.46,depth=1.30,level=1.64,height=.85)
 m.box(t+'_HeatWarningFront',(.38,.044,.035),(0,1.56,-.970),'red_hot',group='HeaterGlow_VISUAL')
 return m

def ledresistor():
 m=Model('09_LED_Resistor_330Ohm');t='L36_FAULT_R'
 shell(m,t,'330 Ohm','FAULT LED CURRENT LIMITER')
 ports(m,t,PORTSETS[m.key],('IN','OUT'),('orange','orange'))
 resistor_body(m,t,'330');guard(m,t)
 return m

def faultled():
 m=Model('10_Fault_LED_Indicator');t='L36_FAULT_LED'
 shell(m,t,'FAULT LED','TRIP WARNING / RED')
 ports(m,t,PORTSETS[m.key],('A','K'),('orange','blue'))
 m.cyl(t+'_IndicatorMountBase',.52,.13,(0,1.67,.08),'chrome',sections=40)
 m.cyl(t+'_IndicatorBlackCollar',.39,.21,(0,1.83,.08),'rubber',sections=36)
 m.cyl(t+'_RedLampBody_LIT',.31,.65,(0,2.15,.08),'crimson',sections=42,group='FaultLamp_Lit_VISUAL')
 m.cyl(t+'_RedLampLensHalo_LIT',.33,.057,(0,2.47,.08),'red_hot',sections=32,group='FaultLamp_Lit_VISUAL')
 for j in range(5):
  ang=math.tau*j/5
  m.rod(t+f'_LensFilament_{j}',(0,1.98,.08),(.21*math.cos(ang),2.34,.08+.21*math.sin(ang)),.012,'amber_led',sections=7,group='FaultLamp_Lit_VISUAL')
 m.torus(t+'_LEDBaseGasket',.42,.053,(0,1.75,.08),'gold',axis='y',segments=52,tube_segs=9)
 m.bevel(t+'_SafetyTrim',(2.18,.043,.11),(0,1.37,-.74),'dark_red',.03)
 return m

def monitor():
 # Not an electrical component - optional visual instrument, zero additional sockets.
 m=Model('11_OPTIONAL_Thermal_Logic_Monitor');t='L36_THERMAL_HUD'
 shell(m,t,'THERMAL INTERLOCK','INSTRUMENT / VISUAL ONLY',w=3.5,d=1.98,h=1.36)
 m.bevel(t+'_MonitorBezel',(2.85,.85,.071),(0,1.28,-1.036),'chrome',.05)
 m.bevel(t+'_OLED',(2.73,.73,.038),(0,1.28,-1.085),'screen',.04)
 m.text(t+'_TEMP_DIGITS','TEMP  62 C',.25,0,1.48,-1.113,'amber',maxwidth=2.35)
 m.text(t+'_Fan_ON','FAN  ON',.15,-.73,1.08,-1.114,'cyan',maxwidth=1.18)
 m.text(t+'_Heater_OFF','HEAT OFF',.15,.73,1.08,-1.114,'red',maxwidth=1.25)
 m.box(t+'_Warning_BAR_VISUAL',(1.32,.034,.033),(0,.92,-1.125),'red_hot',group='MonitorWarning_VISUAL')
 for i in range(5):
  m.box(t+f'_CoolingVents_{i}',(.08,.018,.37),(-1.04+i*.50,1.75,.35),'void')
 return m

BUILDERS=[supply,pullup,sensor,
 lambda:relay('04_Cooling_Fan_Contact','L36_FAN_CONTACT','FAN CONTACT','fan'),
 fan,
 lambda:relay('06_Heater_Safety_Contact','L36_HEATER_CONTACT','HEATER CONTACT','heat'),
 heater,
 lambda:relay('08_Fault_Trip_Contact','L36_FAULT_CONTACT','FAULT CONTACT','fault'),
 ledresistor, faultled, monitor]

STAGING={
 '01_5V_Regulated_Supply':(10.45,0,2.1),
 '02_10kOhm_Pullup':(5.20,0,2.1),
 '04_Cooling_Fan_Contact':(0,0,2.1),
 '06_Heater_Safety_Contact':(-5.20,0,2.1),
 '08_Fault_Trip_Contact':(-10.45,0,2.1),
 '03_NTC_Temperature_Sensor':(10.45,0,-2.55),
 '05_Cooling_Fan_47Ohm':(5.20,0,-2.55),
 '07_Tubular_Heater_100Ohm':(0,0,-2.55),
 '09_LED_Resistor_330Ohm':(-5.20,0,-2.55),
 '10_Fault_LED_Indicator':(-10.45,0,-2.55),
 '00_Optional_Showcase_Board':(0,0,0)
}

def board():
 m=Model('00_Optional_Showcase_Board');t='L36_HARDSHELL_BENCH'
 m.bevel(t+'_BaseRubber',(25.45,.13,10.50),(0,.073,0),'rubber',.16)
 m.bevel(t+'_SatinNickelSurround',(25.32,.145,10.42),(0,.19,0),'steel',.13)
 m.bevel(t+'_MattePegboard',(25.17,.074,10.26),(0,.303,0),'graphite',.1)
 for x in (-12.40,12.40):m.box(t+f'_BlueEdgeNeon_{x}',(.048,.041,10.0),(x,.367,0),'cyan')
 for z in (-5.02,5.02):m.box(t+f'_BlueEdgeStrip_{z}',(24.9,.042,.048),(0,.370,z),'cyan')
 # One merged geometry for small pegs, to avoid thousands of FBX nodes.
 dots=[]
 for x in np.linspace(-12.12,12.12,61):
  for z in np.linspace(-4.73,4.73,24):
   a=trimesh.creation.cylinder(radius=.0105,height=.004,sections=6)
   a.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
   a.apply_translation((float(x),.366,float(z)));dots.append(a)
 m.add(t+'_ToolingHoles',trimesh.util.concatenate(dots),'mid_steel')
 return m

def build():
 models=[fn() for fn in BUILDERS]
 electrical=models[:10];instrument=models[10:]
 ids=[pid for m in electrical for pid in m.anchors]
 assert len(ids)==20 and len(set(ids))==20,(len(ids),ids)
 assert len(WIRES)==13
 for name,a,b in WIRES:
  assert a in ids and b in ids,(name,a,b)
 info={}
 for mod in models:
  fbx=MODELS/(mod.key+'.fbx');glb=MODELS/(mod.key+'.glb')
  export_fbx(fbx,[mod]);export_glb(glb,[mod])
  ntri=sum(len(p.mesh.faces) for p in mod.parts)
  info[mod.key]={'fbx':fbx.name,'glb':glb.name,'triangles':ntri,'mesh_objects':len(mod.parts),
   'terminals':mod.anchors,
   'named_groups':list(dict.fromkeys(p.group for p in mod.parts if p.group!='Static'))}
  print('EXPORT',mod.key,ntri,'triangles',len(mod.parts),'meshes',flush=True)
 group=[board()]+electrical
 out=MODELS/'Level36_Complete_ArtKit_Showcase.fbx';g=MODELS/'Level36_Complete_ArtKit_Showcase.glb'
 export_fbx(out,group,positions=STAGING);export_glb(g,group,positions=STAGING)
 info['Level36_Complete_ArtKit_Showcase']={'fbx':out.name,'glb':g.name,
  'triangles':sum(len(p.mesh.faces) for m in group for p in m.parts),
  'mesh_objects':sum(len(m.parts) for m in group)}
 manifest={'level':36,'title':'Thermal Interlock','model_count':11,'electrical_model_count':10,
  'visual_only_models':1,'wire_count':13,'socket_count':20,
  'rendering':'Y-up Unity, front -Z; visual models only',
  'scene_positions':STAGING,
  'exact_wires':[{'wire':n,'from':a,'to':b} for n,a,b in WIRES],
  'models':info}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf8') as f:
  c=csv.writer(f);c.writerow(['Wire','From','To']);c.writerows(WIRES)
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf8') as f:
  c=csv.writer(f);c.writerow(['Visual FBX','Runtime Terminal ID','Local X','Local Y','Local Z','Suggested Terminal GameObject'])
  for m in electrical:
   for pid,p in m.anchors.items(): c.writerow([m.key+'.fbx',pid,*p,pid])
 print('LEVEL 36 DONE 11 ART MODELS / 20 SOCKETS / 13 WIRES',flush=True)

if __name__=='__main__':build()
