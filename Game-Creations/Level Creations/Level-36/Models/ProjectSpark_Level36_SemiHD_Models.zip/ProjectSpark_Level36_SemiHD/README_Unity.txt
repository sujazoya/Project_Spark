PROJECT SPARK — LEVEL 36: THERMAL INTERLOCK
Polished Semi-HD FBX + GLB art model collection
================================================

THIS PACKAGE CONTAINS 3D ART ONLY.
It does not install electrical solver definitions, thermal simulation, objectives,
SparkTerminal components, SparkSwitch controls or automatic material/VFX animation.
Keep all working Project Spark scripts, binding IDs, solver settings and gameplay logic.

PACKAGE CONTENTS
----------------
Models/  11 individual FBX files + 11 corresponding GLB backups
         1 assembled ArtKit showcase FBX + GLB
Previews/  11 actual-mesh renders, 1 assembled preview, 1 contact sheet
Sources/  Python generator and VTK preview script
Terminal_Anchors.csv  20 physical electrical socket coordinates in local FBX space
Exact_Wiring.csv  Exact W01-W13 connections from your Level 36 wiring diagram
Model_Manifest.json  Technical model/mesh/animation-group metadata

THE TEN CORE ELECTRICAL MODELS
------------------------------
01_5V_Regulated_Supply.fbx        5 V power source, red+ / blue- sockets
02_10kOhm_Pullup.fbx             10 kOhm thermistor-divider pull-up resistor
03_NTC_Temperature_Sensor.fbx    Stainless probe, connector / heat ring
04_Cooling_Fan_Contact.fbx       Copper-coil relay/contact visual
05_Cooling_Fan_47Ohm.fbx         Cooling fan, separately grouped spinning rotor
06_Heater_Safety_Contact.fbx     Heater interlock relay/contact visual
07_Tubular_Heater_100Ohm.fbx     Ceramic heater, visible heating coil and guard
08_Fault_Trip_Contact.fbx        Fault/trip contact with articulated armature
09_LED_Resistor_330Ohm.fbx       330 Ohm fault indicator current limiting resistor
10_Fault_LED_Indicator.fbx       Red fault warning lamp

OPTIONAL VISUAL-ONLY MODEL
--------------------------
11_OPTIONAL_Thermal_Logic_Monitor.fbx
This temperature monitor has ZERO additional electrical sockets.
Its sample 'TEMP 62 C / FAN ON / HEAT OFF' is a STATIC art mesh, not live telemetry.
Use a Unity TMP/RenderTexture display if a live numeric reading is desired.

WIRE & TERMINAL PLAN — NO TOPOLOGY CHANGE
-----------------------------------------
W01 Battery_positive  -> PULLUP_IN
W02 PULLUP_OUT        -> SENSOR_IN
W03 SENSOR_RETURN     -> Battery_negative
W04 Battery_positive  -> FAN_SW_IN
W05 FAN_SW_OUT        -> FAN_A
W06 FAN_B             -> Battery_negative
W07 Battery_positive  -> HEAT_SW_IN
W08 HEAT_SW_OUT       -> HEATER_IN
W09 HEATER_OUT        -> Battery_negative
W10 Battery_positive  -> FAULT_SW_IN
W11 FAULT_SW_OUT      -> LED_R_IN
W12 LED_R_OUT         -> LED_A
W13 LED_K             -> Battery_negative

Game circuit: 13 wires, 20 physical socket anchors, 10 electrical 2-pin devices.
Crossing drawn wires do not create connections except at game terminals.
Do not assign electrical terminals to the optional monitor or the showcase tray.

UNITY IMPORT & BINDING
----------------------
1. Unzip and copy individual FBX files to
   Assets/My_Assets/_Project_Spark/Models/Level36/ (or your preferred art folder).
2. In Model Import Settings inspect the model at Scale Factor 1, preserving hierarchy.
   FBX uses Y-up, with connector faces oriented toward LOCAL -Z.
3. Check orientation in Unity Prefab mode before applying any rotation or scale.
   These model units are stylized relative units, not guaranteed 1:1 with your shelf slots.
4. Assign the individual FBX as VISUAL children of the existing Level 36 objects.
   Don't replace or remove SparkElectricalComponent, SparkTerminal, SparkShelfItem,
   scene bindings, or wiring system objects.
5. Using Terminal_Anchors.csv, place 20 existing or new SparkTerminal transforms at
   the visual sockets. Coordinates are LOCAL to the specific individual FBX root.
   A visually painted socket has no electrical behavior on its own.
6. Configure each matching SparkElectricalComponent to refer to the corresponding
   real SparkTerminals. Reuse your declared runtime IDs exactly.
7. Let the Project Spark circuit tool create the actual 13 wires. The art kit
   does not force or change circuit connections.
8. For URP/HDRP, check imported materials: the FBX ships diffuse material colors.
   Create URP Lit/HDRP Lit materials for optional metallic/roughness/emissive polish.

VISUAL ANIMATION GROUPS / SUGGESTED PIVOTS
----------------------------------------
* Cooling fan: FanRotor_ANIMATE, visual center approx (0, 1.99, 0.04).
  Create a pivot there and rotate around its local UP axis. Do not spin the housing.
* Contact relays: ContactArmature_ANIMATE, visual hinge approx (0.17,2.16,0.13).
  Put this group under a dedicated pivot so the armature swings at the hinge.
* Heater: HeaterGlow_VISUAL controls the orange/red heater-coil mesh; use an
  emissive shader and toggle/animate its intensity from the existing heater state.
* Fault lamp: FaultLamp_Lit_VISUAL should be driven by the existing fault LED's
  state; for bloom use an emissive material and optional small point light.
* NTC probe: HeatIndicator_VISUAL may be tinted according to a valid temperature
  reported by gameplay; it is not a sensor by itself.
* StatusLED_VISUAL is cosmetic. The optional monitor remains static until you
  replace its front static text with UI/RenderTexture live values.

IMPORTANT
---------
The 3D relay contacts and heater are illustrative physical art; the real switch
and temperature state remain the responsibility of your existing Level 36 systems.
They should not create new SparkSwitch or SparkElectricalComponent instances.

EXPECTED LEVEL 36 PLAY LESSON
-----------------------------
Wire NTC divider, fan circuit, heater circuit and fault LED circuit. Test cold,
warming, thermal trip and reset behavior using the Level 36 logic currently
implemented in your project. Only your controller can define exact transitions.
Do not use the visual art or static status LEDs as completion evidence.

DIAGNOSTIC / QUALITY NOTES
--------------------------
FBX 7.4 binary + GLB backups built with original procedural mesh geometry.
All generated files have been checked for existence and nonzero file size.
The GLB files have been reloaded by trimesh to verify accessible 3D geometry.
No automated test of Unity FBX import, pivots, shader matching or animation has
been performed. Inspect in your Unity version before using as final shipped art.
