# Level 36 | Thermal Interlock

Wire the sensor and three output branches. The same **WARM** reading should produce two different results depending on whether the chamber was previously hot or cool. Then verify that both sensor faults latch and require a manual reset.

## Wire the workbench

Use the Wire tool and the socket labels on the breadboard. IN and A are on the left side of each module. OUT, RET, B and K are on the right. Both supply sockets accept four connections.

| Wire | From | To |
| --- | --- | --- |
| W01 | Supply + | 10 kΩ Pull-Up IN |
| W02 | 10 kΩ Pull-Up OUT | NTC Sensor SENSE |
| W03 | NTC Sensor RET | Supply − |
| W04 | Supply + | Fan Contact IN |
| W05 | Fan Contact OUT | Cooling Fan A |
| W06 | Cooling Fan B | Supply − |
| W07 | Supply + | Heater Contact IN |
| W08 | Heater Contact OUT | 100 Ω Heater IN |
| W09 | 100 Ω Heater OUT | Supply − |
| W10 | Supply + | Fault Contact IN |
| W11 | Fault Contact OUT | 330 Ω Resistor IN |
| W12 | 330 Ω Resistor OUT | Fault LED A |
| W13 | Fault LED K | Supply − |

## Play to 6/6

1. Finish the 13 wires. At **3.00 V**, the heater glows and the fan is stopped.
2. Press **HOT**. At **1.60 V**, the fan spins and the heater switches off.
3. Press **WARM**. At **2.25 V**, the fan keeps spinning.
4. Press **COOL**, wait for the heater to return, then press **WARM** again. At the same **2.25 V**, the fan stays off.
5. Press **COOL**, then **OPEN SENSOR**. At **5.00 V**, the fault lamp comes on, the fan runs, and the heater switches off.
6. Press **RESTORE SENSOR**. The fault stays latched at **3.00 V**. Press **RESET FAULT**, then **SHORT SENSOR**. At **0.00 V**, the same fault response occurs. Press **RESTORE SENSOR** and **RESET FAULT** again. The heater returns, the warning goes out, and the level completes.

## Install in another Project Spark checkout

Merge the included `Assets` folder into the existing project and keep the Unity `.meta` files. Use the existing Level 36 definition, layout catalog entry, campaign entry, teaching drawing, and registered SparkMotor solver. The included prefab is fitted to the MainMenu breadboard. If the board geometry changes, open MainMenu in Edit Mode and run **Tools → Project Spark → Level 36 → Fit Breadboard Assembly**.
