# Level 65 — The Factory Thinks

Open MainMenu and choose Level 65. To install the package in another checkout, merge its Assets directory into Project Spark, open MainMenu and run **Tools → Project Spark → Levels → Create Level 65**. Save the scene. The original art kit and companion files are included under Reference.

1. Wire W01–W66 from the illustrated guide. Connect W66 last so **Undo Last Wire** can remove it for the encoder test.
2. Commission the PLC, calibrate the sensors and vision, then feed a test part.
3. Home the robot and enable vacuum and pneumatic air. Run the A/B/C sorting test and then the defect test.
4. Select fast belt and fast robot cycle, then run the mixed batch. Throughput is calculated from simulated elapsed production time.
5. Select **W66 Test** and undo **ENC PULSE → PLC ENCODER**. Reconnect it, recalibrate the encoder, reset the fault, home the robot and re-enable vacuum and air.
6. Select **Run Final 20**. Certification requires all 20 dispositions correct, no defective escapes, and at least 12 parts per simulated minute.

The simulation uses the shared 5 V controls, wire graph and objective evaluator. The factory runs a 20 ms PLC scan, a level-specific belt and servo model, simulated material-color inspection, and one tracked product at a time. The six-axis arm uses joint-limited inverse kinematics and the four variants move to their matching conveyor or reject bin. The workbench fits the equipment uniformly and uses 0.20 local TextMesh scale.
