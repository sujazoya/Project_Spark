"""Project Spark Level 55 procedural HD 3D model generator.
Creates 20 independent, colored and named triangle-mesh assets plus FBX 7.4 binary and GLB backups.
Visual assets only: no electrical measurements or objectives fabricated.
"""
from __future__ import annotations
import os, math, csv, json, zlib, struct, zipfile, pathlib, textwrap
from collections import defaultdict
from dataclasses import dataclass
import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level56_HD_AAA')
for d in ['Models','GLB','Previews','Unity_Optional','Source']: (ROOT/d).mkdir(parents=True,exist_ok=True)
R = math.pi/180
C = {
 'titanium':(0.27,0.38,0.46,1),'blue_steel':(.17,.29,.38,1),'navy':(.045,.093,.155,1),
 'carbon':(.035,.065,.095,1),'dark':(.065,.10,.145,1),'chrome':(.74,.85,.90,1),
 'silver':(.49,.65,.75,1),'silver_dark':(.32,.44,.54,1),'copper':(.77,.34,.12,1),
 'bronze':(.84,.49,.18,1),'gold':(.96,.68,.25,1),'amber':(1,.66,.21,1),
 'cyan':(.18,.89,1,1),'electric':(.05,.56,.98,1),'mint':(.2,1,.72,1),
 'green':(.1,.93,.43,1),'red':(1,.18,.27,1),'white':(.82,.95,1,1),
 'acrylic':(.33,.71,.86,.15),'acrylic_rim':(.43,.69,.83,1),'rubber':(.035,.05,.075,1),
 'display':(.017,.066,.106,1),'grid':(.08,.22,.29,1),'warning':(.95,.65,.08,1),
 'violet':(.55,.35,.93,1)
}
@dataclass
class Part:
 name:str
 mesh:trimesh.Trimesh
 mat:str
 group:str|None=None
@dataclass
class Asset:
 name:str
 parts:list
 groups:dict
 def __init__(self,name):self.name=name;self.parts=[];self.groups={}
 def add(self,name,mesh,mat,group=None):
  if mesh is None or len(mesh.faces)==0: return
  mesh=mesh.copy(); mesh.remove_unreferenced_vertices()
  assert mat in C,mat
  self.parts.append(Part(name,mesh,mat,group))
 def pivot(self,name,loc): self.groups[name]=np.array(loc,dtype=float)

assets=[]; current=None
MODELS=['L56_IndustrialBase', 'L56_RegenerativeMotor', 'L56_FlywheelRotor', 'L56_LeftBearing', 'L56_RightBearing', 'L56_EncoderABZ', 'L56_BidirectionalConverter', 'L56_SupercapacitorBank', 'L56_CapacitorProtectionUnit', 'L56_BrakingResistor', 'L56_BrakeChopperDriver', 'L56_CurrentSensor', 'L56_VoltageSensor', 'L56_EnergyMeter', 'L56_RegenerationController', 'L56_EnergyFlowMonitor', 'L56_SafetyGuard', 'L56_ThermalCoolingModule', 'L56_ProgrammableLoad', 'L56_Regulated5VSupply']
def start(i):
 global current
 current=Asset(MODELS[i]);assets.append(current)
 return current

def add(n,m,mat,group=None):current.add(n,m,mat,group)
def T(mesh,pos):
 m=mesh.copy();m.apply_translation(pos);return m

def box(n,pos,size,mat,group=None):
 m=trimesh.creation.box(extents=size)
 add(n,T(m,pos),mat,group)
def cyl(n,pos,r,l,axis='y',mat='silver',sections=32,group=None):
 mesh=trimesh.creation.cylinder(radius=r,height=l,sections=sections)
 if axis=='x':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':mesh.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 add(n,T(mesh,pos),mat,group)
def tor(n,pos,rad,tube,axis='x',mat='silver',seg=64,minor=10,group=None):
 mesh=trimesh.creation.torus(major_radius=rad,minor_radius=tube,major_sections=seg,minor_sections=minor)
 if axis=='x':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':mesh.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 add(n,T(mesh,pos),mat,group)
def ann(n,pos,outer,inner,depth,axis='x',mat='silver',seg=56,group=None):
 # explicit annular extrusion, open bore
 angles=np.linspace(0,2*math.pi,seg,endpoint=False)
 pts=[]
 for x in [-depth/2,depth/2]:
  for rad in [outer,inner]:
   for a in angles:
    if axis=='x':p=[x,rad*math.cos(a),rad*math.sin(a)]
    elif axis=='y':p=[rad*math.cos(a),x,rad*math.sin(a)]
    else:p=[rad*math.cos(a),rad*math.sin(a),x]
    pts.append(p)
 faces=[]
 for k in range(seg):
  j=(k+1)%seg
  for a,b,c,d in [(k,j,seg+j,seg+k), (2*seg+k,3*seg+k,3*seg+j,2*seg+j),
                  (k,2*seg+k,2*seg+j,j),(seg+k,seg+j,3*seg+j,3*seg+k)]:
   faces.extend([[a,b,c],[a,c,d]])
 m=trimesh.Trimesh(vertices=np.array(pts),faces=np.array(faces),process=False)
 add(n,T(m,pos),mat,group)
def bolt(n,pos,axis='y',size=.038):
 cyl(n+'_Head',pos,size,size*.5,axis,'chrome',12)
 cyl(n+'_Mark',np.array(pos)+([0,size*.23,0] if axis=='y' else [size*.23,0,0]),size*.38,size*.09,axis,'dark',6)
def beam(n,a,b,r,mat='silver',seg=10,group=None):
 a=np.array(a,float);b=np.array(b,float)
 d=b-a; length=np.linalg.norm(d)
 if length<1e-5:return
 m=trimesh.creation.cylinder(radius=r,height=length,sections=seg)
 m.apply_transform(trimesh.geometry.align_vectors([0,0,1],d/length))
 add(n,T(m,(a+b)/2),mat,group)
def cable(n,points,r=.018,mat='rubber',seg=9):
 for j,(a,b) in enumerate(zip(points[:-1],points[1:])): beam(n+f'_{j:02d}',a,b,r,mat,seg)
def led(n,pos,mat='cyan',r=.045,axis='z'):
 cyl(n+'_Bezel',pos,r*1.35,.017,axis,'chrome',18)
 d={'x':[.010,0,0],'y':[0,.010,0],'z':[0,0,.010]}[axis]
 cyl(n+'_Lens',np.array(pos)+d,r,.015,axis,mat,20)
def feet(n,x,z):
 cyl(n+'_Rubber',(x,-.35,z),.14,.12,'y','rubber',16)
 cyl(n+'_Top',(x,-.28,z),.12,.035,'y','silver',20)
def panel(n,pos,w=1.25,header='DRIVE',color='cyan',socket_names=None):
 # Front-facing electronic module at z=2.13, sockets are front face (+Z)
 x,y,z=pos; width=w
 box(n+'_Body',(x,y,z),[width,.56,.48],'navy')
 box(n+'_Face',(x,y,z+.245),[width-.06,.48,.018],'dark')
 box(n+'_AnodizedTop',(x,y+.291,z),[width,.025,.48],'blue_steel')
 box(n+'_TopLight',(x,y+.308,z),[width-.07,.010,.033],color)
 for sign in [-1,1]:
  for signy in [-1,1]: bolt(n+f'_Screw_{sign}_{signy}',(x+sign*(width/2-.09),y+signy*.18,z+.263),'z',.023)
 text_geo(n+'_Label',header,(x-width*.42,y+.13,z+.264),max_width=width*.84,size=.055,mat='white')
 led(n+'_PowerStatus',(x-width*.40,y-.01,z+.264),'green',.029,'z')
 if socket_names:
  m=len(socket_names); spacing=min(.25,(width-.20)/max(1,m));first=x-(m-1)*spacing/2
  for i,s in enumerate(socket_names):
   xx=first+i*spacing; zz=z+.277
   cyl(n+f'_JackOuter_{s}',(xx,y-.145,zz),.072,.024,'z','chrome',18)
   cyl(n+f'_JackInner_{s}',(xx,y-.145,zz+.014),.048,.024,'z',('red' if s in ['+5V','M+','PWR+'] else 'electric' if s in ['GND','0V','M-','PWR-'] else color),18)
   cyl(n+f'_JackHole_{s}',(xx,y-.145,zz+.028),.018,.011,'z','dark',12)

def text_geo(n,st,pos,max_width=1.2,size=.08,mat='white',group=None):
 try:
  import vtk
  v=vtk.vtkVectorText();v.SetText(st);v.Update();p=v.GetOutput();N=p.GetNumberOfPoints();F=p.GetNumberOfCells()
  if not N or not F:return
  arr=np.array([p.GetPoint(i) for i in range(N)])
  fs=[]
  for i in range(F):
   c=p.GetCell(i)
   if c.GetNumberOfPoints()==3: fs.append([c.GetPointId(j) for j in range(3)])
  if not fs:return
  arw=arr[:,0].max()-arr[:,0].min()
  scl=min(size,max_width/max(arw,.01))
  arr[:,:2]*=scl;arr[:,0]-=arr[:,0].min();arr[:,1]-=arr[:,1].min();
  arr+=np.array(pos)
  add(n,trimesh.Trimesh(vertices=arr,faces=np.array(fs),process=False),mat,group)
 except Exception as ex: print('text geo skipped',st,str(ex)[:100])

# ===================================================================
# Project Spark Level 56: HARVEST THE SPIN — polished procedural art pack
# Unity Y-up, shaft +X, front-facing panel +Z, shared bench coordinate.
# ===================================================================
Y=1.42

def decorbolt(prefix,x,y,z):
 bolt(prefix,(x,y,z),'y',.034)
def heatfins(prefix,x,y,z,n=9,dx=.095):
 for i in range(n):box(f'{prefix}_FIN_{i:02d}',(x+(i-(n-1)/2)*dx,y,z),(.055,.32,.39),'silver')
def frontpanel(n,x,y,z,w=1.0,h=.48,d=.56,title='MODULE',accent='cyan',count=4):
 box(n+'_Chassis',(x,y,z),(w,h,d),'navy')
 box(n+'_Face',(x,y,z+d/2+.015),(w-.045,h-.055,.035),'dark')
 box(n+'_TopBezel',(x,y+h/2+.015,z),(w-.04,.025,d-.05),'blue_steel')
 box(n+'_Stripe',(x,y+h/2+.034,z),(w-.10,.013,.032),accent)
 text_geo(n+'_LaserEtchedName',title,(x-w*.44,y+h*.16,z+d/2+.045),max_width=w*.88,size=.069,mat='white')
 for j in range(count):
  cx=x+(j-(count-1)/2)*min(.22,(w-.20)/max(1,count))
  circ=(['red','electric','cyan','mint','amber','violet','white'][j%7])
  cyl(f'{n}_PortShell_{j}',(cx,y-h*.19,z+d/2+.064),.065,.028,'z','chrome',18)
  cyl(f'{n}_Port_{j}',(cx,y-h*.19,z+d/2+.085),.042,.025,'z',circ,18)
  cyl(f'{n}_SocketHole_{j}',(cx,y-h*.19,z+d/2+.103),.017,.009,'z','carbon',12)
 led(n+'_Power',(x-w*.42,y,z+d/2+.058),'green',.022,'z')
 for sx in (-1,1):
  for sy in (-1,1):bolt(f'{n}_Fastener_{sx}_{sy}',(x+sx*(w/2-.065),y+sy*(h/2-.06),z+d/2+.05),'z',.02)

def stand(prefix,x,upper=.98):
 box(prefix+'_Pedestal',(x,.49,0),(.59,.80,.54),'blue_steel')
 box(prefix+'_BaseFoot',(x,.14,0),(.85,.14,.83),'carbon')
 box(prefix+'_Crown',(x,upper,0),(.57,.16,.55),'titanium')
 for b in [-.25,.25]:bolt(prefix+f'_Bolt{b}',(x+b,.16,.25),'y',.025)

def vented(prefix,x,y,z,w,n=11):
 for j in range(n):box(f'{prefix}_Vent{j:02d}',(x+(j-(n-1)/2)*w/(n+1),y,z),(.029,.026,.30),'carbon')

# 00 Precision base
start(0)
box('Chassis_MachinedTitanium',(0,-.13,0),(8.5,.33,4.70),'titanium')
box('CarbonDeck',(0,.052,0),(8.29,.05,4.5),'carbon')
for z in [-1.18,1.23]:
 box(f'MountRail_{z}',(0,.13,z),(7.9,.16,.16),'blue_steel')
 box(f'RailSilverInlay_{z}',(0,.23,z),(7.75,.03,.04),'chrome')
for x in [-3.82,3.82]:
 for z in [-2.04,2.04]:
  cyl(f'IsolationFoot_{x}_{z}',(x,-.40,z),.18,.20,'y','rubber',20)
  bolt(f'DeckBolt_{x}_{z}',(x,.10,z),'y',.045)
for z in [-2.3,2.30]:box(f'CyanDeskStripe_{z}',(0,.084,z),(8.25,.022,.035),'cyan')
for i in range(18):
 x=-3.74+i*.44;box(f'FrontCableTrack_{i}',(x,.1,1.74),(.12,.05,.032),'silver_dark')
for i in range(15):
 x=-3.45+i*.50; box(f'WarningStripe_{i}',(x,.091,-2.13),(.18,.012,.035),'amber')
text_geo('Base_ProjectSpark','PROJECT SPARK / ENERGY RECOVERY',( -3.75,.09,1.99),max_width=3.3,size=.12,mat='white')

# 01 Motor at shaft left
start(1); current.pivot('ANIM_MOTOR_SHAFT',(-2.70,Y,0))
stand('DriveStation',-2.70)
cyl('MainMotorHousing',(-2.70,Y,0),.42,1.10,'x','blue_steel',64)
cyl('MotorFaceLeft',(-3.27,Y,0),.35,.08,'x','chrome',64)
cyl('MotorFaceRight',(-2.15,Y,0),.33,.11,'x','silver',64)
for i in range(22):
 xx=-3.17+i*.043
 ann(f'CoolingRib_{i:02d}',(xx,Y,0),.432,.392,.025,'x','silver_dark',40)
cyl('ShaftDriven',(-1.91,Y,0),.11,.66,'x','chrome',56,'ANIM_MOTOR_SHAFT')
ann('MotorCoupler',(-1.82,Y,0),.22,.115,.19,'x','chrome',56,'ANIM_MOTOR_SHAFT')
for i in range(10):
 angle=2*math.pi*i/10
 cyl(f'StatorBolt_{i}',(-2.11,Y+.29*math.cos(angle),.29*math.sin(angle)),.029,.05,'x','chrome',12)
box('MotorJunctionBox',(-2.75,1.95,0),(.36,.24,.35),'carbon')
led('DriveValid',(-2.60,2.09,.09),'green',.037,'y')

# 02 Large vertical flywheel on shaft
start(2);current.pivot('ANIM_FLYWHEEL_SPIN',(0,Y,0))
cyl('SpinningPrecisionShaft',(0,Y,0),.13,4.60,'x','chrome',72,'ANIM_FLYWHEEL_SPIN')
ann('FlywheelForgedOuterRim',(0,Y,0),.94,.65,.29,'x','silver',104,'ANIM_FLYWHEEL_SPIN')
ann('FlywheelCarbonCore',(0,Y,0),.66,.19,.25,'x','silver_dark',100,'ANIM_FLYWHEEL_SPIN')
ann('FlywheelOrangeBalanceBand',(.16,Y,0),.88,.83,.012,'x','amber',100,'ANIM_FLYWHEEL_SPIN')
ann('FlywheelCyanEnergyBand',(-.16,Y,0),.88,.846,.015,'x','cyan',100,'ANIM_FLYWHEEL_SPIN')
ann('HubFront',(.19,Y,0),.25,.12,.09,'x','chrome',72,'ANIM_FLYWHEEL_SPIN')
ann('HubRear',(-.19,Y,0),.25,.12,.09,'x','chrome',72,'ANIM_FLYWHEEL_SPIN')
for i in range(12):
 a=math.tau*i/12
 # forge radial decorative spoke bolting
 cyl(f'FlywheelPrecisionFastener_{i:02d}',(.199,Y+.52*math.sin(a),.52*math.cos(a)),.036,.027,'x','gold',16,'ANIM_FLYWHEEL_SPIN')
for j in range(6):
 x=-.11+j*.043
 ann(f'Rim_MachinedDetail_{j}',(x,Y,0),.93,.916,.014,'x','chrome',100,'ANIM_FLYWHEEL_SPIN')

# 03/04 Rotor bearings
for index,x in [(3,-1.27),(4,1.29)]:
 start(index)
 stand('BearingStation',x)
 ann('BearingOuterRace',(x,Y,0),.37,.255,.19,'x','blue_steel',64)
 ann('BearingInnerRace',(x,Y,0),.25,.18,.21,'x','silver',64)
 ann('BearingSealFront',(x+.13,Y,0),.305,.274,.035,'x','chrome',64)
 ann('BearingSealRear',(x-.13,Y,0),.305,.274,.035,'x','carbon',64)
 for i in range(14):
  a=math.tau*i/14
  cyl(f'Roller_{i:02d}',(x,Y+.291*math.sin(a),.291*math.cos(a)),.035,.08,'x','silver',16)
 for i in range(8):
  a=math.tau*i/8
  cyl(f'OuterFixing_{i:02d}',(x+.145,Y+.328*math.sin(a),.328*math.cos(a)),.020,.04,'x','chrome',12)
 led('BearingHealth',(x,.83,.30),'green',.030,'z')

# 05 Encoder
start(5);current.pivot('ANIM_ENCODER_DISC',(2.45,Y,0))
ann('EncoderGraduationDisc',(2.45,Y,0),.36,.135,.035,'x','carbon',88,'ANIM_ENCODER_DISC')
ann('EncoderOpticalTrack',(2.47,Y,0),.344,.32,.018,'x','cyan',88,'ANIM_ENCODER_DISC')
for k in range(80):
 a=math.tau*k/80
 box(f'EncoderGraduation_{k:02d}',(2.49,Y+.33*math.sin(a),.33*math.cos(a)),(.008,.012,.050),'silver','ANIM_ENCODER_DISC')
box('OpticalSensor',(2.48,Y+.40,0),(.24,.16,.23),'navy')
box('SensorLED',(2.48,Y+.51,0),(.12,.022,.11),'cyan')
stand('EncoderPedestal',2.45)

# 06 Bidirectional Converter
start(6)
frontpanel('BidirectionalConverter',-2.95,.52,1.78,1.32,.57,.75,'BIDIR CONVERTER','cyan',6)
heatfins('ConverterHeatsink',-2.95,1.04,1.79,12,.08)
box('ConverterCopperBusUpper',(-2.95,.96,1.40),(1.03,.07,.12),'copper')
for j in range(5):cyl(f'ConverterPowerScrew_{j}',(-3.38+j*.20,.86,1.32),.037,.03,'y','chrome',16)

# 07 Supercapacitor bank
start(7)
box('CapacitorCradle',(1.10,.47,1.75),(1.65,.22,.82),'carbon')
box('CapBankRearBusbar',(1.10,1.42,1.51),(1.42,.065,.08),'copper')
for i in range(5):
 x=.50+i*.30
 cyl(f'Ultracapacitor_Cell_{i}',(x,.97,1.75),.135,.91,'y','electric',36)
 cyl(f'Ultracapacitor_Top_{i}',(x,1.44,1.75),.14,.06,'y','chrome',36)
 cyl(f'Ultracapacitor_Positive_{i}',(x,1.49,1.75),.048,.04,'y','gold',20)
 for k in range(3):ann(f'CellAccent_{i}_{k}',(x,.75+k*.25,1.75),.14,.134,.024,'y','cyan',32)
box('BankProtectiveTop',(1.10,1.61,1.75),(1.70,.07,.97),'acrylic_rim')
for x in [.21,1.99]:
 for z in [1.32,2.17]:box(f'ProtectiveStandoff_{x}_{z}',(x,1.10,z),(.045,1.25,.045),'silver')
text_geo('CapBankLabel','SUPERCAPACITOR',( .33,.35,2.18),max_width=1.48,size=.11,mat='white')

# 08 Protection
start(8)
frontpanel('CapacitorProtection',2.85,.48,1.80,1.04,.51,.62,'CAP PROTECT','amber',4)
for j in range(4):box(f'BalanceResistor_{j}',(2.56+j*.19,.82,1.67),(.09,.055,.26),'copper')
led('ProtectTrip',(3.18,.54,2.15),'red',.025,'z')

# 09 Braking resistor
start(9)
box('BrakingResistor_CeramicBlock',(3.15,.68,-1.68),(1.14,.55,.68),'silver')
box('Resistor_ThermalCoating',(3.15,.96,-1.68),(1.11,.045,.62),'dark')
for i in range(10):
 x=2.65+i*.11
 box(f'CeramicCoolingVane_{i}',(x,1.04,-1.68),(.045,.22,.63),'silver')
for i in range(7):
 z=-1.94+i*.08
 box(f'BrakingHeatTrace_{i}',(3.16,.97,z),(.92,.018,.025),'amber')
for xx in [2.70,3.60]:cyl(f'CeramicTerminal_{xx}',(xx,.80,-1.34),.067,.11,'z','copper',20)
text_geo('BrakeWarning','HOT / BRAKE',(2.79,.56,-1.29),max_width=.77,size=.07,mat='amber')

# 10 Brake chopper
start(10)
frontpanel('BrakeChopper',1.78,.48,-1.78,.95,.52,.61,'BRAKE DRIVER','amber',4)
for j in range(7):box(f'ChopperCoolFin_{j}',(1.48+j*.10,.85,-1.78),(.04,.20,.38),'silver_dark')

# 11 Hall current sensor
start(11)
box('CurrentTransducerShell',(-1.15,.57,1.81),(.50,.40,.48),'navy')
ann('HallCurrentRing',(-1.15,.72,1.89),.19,.105,.13,'z','silver',44)
ann('HallCyanAccent',(-1.15,.72,1.98),.16,.142,.018,'z','cyan',44)
box('CurrentSensorID',(-1.15,.39,2.075),(.40,.09,.02),'silver_dark')

# 12 Voltage sensor
start(12)
frontpanel('VoltageSensor',-.22,.46,1.85,.80,.45,.54,'VOLT SENSE','mint',3)
for j in range(2):cyl(f'PrecisionVoltageProbe_{j}',(-.39+j*.29,.80,1.8),.045,.15,'y','chrome',16)

# 13 energy meter
start(13)
frontpanel('EnergyMeter',-1.50,.47,-1.85,1.04,.57,.57,'ENERGY METER','mint',4)
box('MeterDisplayGlass',(-1.53,.51,-1.54),(.54,.17,.025),'display')
text_geo('EnergyUnit','JOULES',(-1.78,.49,-1.523),max_width=.50,size=.065,mat='mint')

# 14 regeneration controller
start(14)
frontpanel('RegenerationController',0,.46,-1.88,1.73,.60,.62,'REGEN CONTROLLER','cyan',8)
for j,col in enumerate(['green','cyan','amber','red']):
 box(f'ControlButtonBase_{j}',(-.58+j*.34,.84,-1.87),(.22,.12,.19),'blue_steel')
 box(f'ControlButtonFace_{j}',(-.58+j*.34,.914,-1.87),(.15,.028,.13),col)
led('ControllerHeartbeat',(-.7,.48,-1.51),'green',.025,'z')

# 15 diagnostics monitor
start(15)
box('DisplayFrame',(2.62,2.15,-1.73),(2.10,1.45,.20),'blue_steel')
box('DisplayBlackGlass',(2.62,2.15,-1.60),(1.91,1.27,.025),'display')
box('DisplayCyanHeader',(2.62,2.67,-1.577),(1.82,.03,.022),'cyan')
text_geo('MonitorTitle','ENERGY FLOW + PERFORMANCE',(1.79,2.48,-1.56),max_width=1.72,size=.086,mat='white')
for j in range(6):
 box(f'MonitorGraphVertical_{j}',(1.90+j*.27,2.05,-1.56),(.008,.70,.007),'grid')
for j in range(5):
 box(f'MonitorGraphHorizontal_{j}',(2.58,1.80+j*.17,-1.55),(1.55,.008,.007),'grid')
for i in range(22):
 xx=1.94+i*.064
 yy=1.82+.44*(i/21)**1.8
 yy2=2.30-.44*(i/21)**1.8
 box(f'StoredEnergyLine_{i}',(xx,yy,-1.537),(.058,.014,.013),'cyan')
 box(f'MechanicalEnergyLine_{i}',(xx,yy2,-1.537),(.058,.014,.013),'amber')
box('MonitorMount',(2.62,1.10,-1.89),(.20,.82,.20),'silver_dark')
box('MonitorStand',(2.62,.67,-1.89),(.68,.13,.47),'carbon')
current.pivot('ANIM_MONITOR_TILT',(2.62,1.2,-1.85))

# 16 transparent guard with hinged front door
start(16)
for xx in [-3.25,3.25]:
 for zz in [-.90,.92]:
  box(f'GuardUpright_{xx}_{zz}',(xx,1.30,zz),(.065,2.45,.065),'silver')
for yy in [.24,2.53]:
 for zz in [-.90,.92]:box(f'GuardLongRail_{yy}_{zz}',(0,yy,zz),(6.57,.055,.055),'chrome')
 for xx in [-3.25,3.25]:box(f'GuardEndRail_{yy}_{xx}',(xx,yy,0),(.055,.055,1.86),'chrome')
for xx in [-3.27,3.27]:box(f'GuardEndPanel_{xx}',(xx,1.31,0),(.025,2.30,1.77),'acrylic')
box('GuardRearAcrylic',(0,1.31,-.91),(6.4,2.3,.02),'acrylic')
current.pivot('ANIM_SAFETY_DOOR',(0,2.53,.92))
box('GuardFrontAcrylic',(0,1.31,.92),(6.37,2.26,.022),'acrylic','ANIM_SAFETY_DOOR')
box('GuardDoorHandle',(2.82,1.22,1.01),(.37,.11,.11),'chrome','ANIM_SAFETY_DOOR')
for i in range(14):
 xx=-3.02+i*.45
 box(f'GuardYellowWarningMark_{i}',(xx,2.555,.92),(.18,.012,.035),'warning')

# 17 cooling module
start(17)
frontpanel('ThermalCooling',3.40,.48,1.82,1.03,.53,.58,'COOLING','electric',2)
for j in range(2):
 x=3.16+j*.43
 ann(f'FanShroud_{j}',(x,.91,1.80),.18,.137,.06,'y','silver',44)
 for k in range(5):
  a=math.tau*k/5
  beam(f'FanSpoke_{j}_{k}',(x,.96,1.8),(x+.12*math.cos(a),.96,1.8+.12*math.sin(a)),.035,'electric',10,'ANIM_FAN_'+str(j) if False else None)
 current.pivot(f'ANIM_COOLING_FAN_{j}',(x,.96,1.8))

# 18 programmable load
start(18)
frontpanel('ProgrammableLoad',-3.05,.50,-1.83,1.07,.56,.62,'LOAD / REUSE','mint',5)
for j in range(8):box(f'LoadHeatsinkFin_{j}',(-3.43+j*.10,.88,-1.83),(.045,.26,.39),'silver_dark')
box('LoadCautionDecal',(-3.05,.86,-1.48),(.70,.02,.035),'amber')

# 19 5V supply
start(19)
frontpanel('Regulated5VSupply',-.16,.42,1.83,1.04,.54,.62,'5.00 V DC','green',2)
box('SupplyDisplay',(-.16,.50,2.19),(.47,.18,.02),'display')
text_geo('SupplyValue','5.00 V',(-.37,.47,2.205),max_width=.41,size=.095,mat='green')
for j in range(8):box(f'SupplyCoolingSlot_{j}',(-.51+j*.10,.73,1.76),(.045,.02,.29),'silver_dark')

# Export writer reused from pre-existing Level 55 generator. Assets are new.
# ---- FBX 7400 binary writer ------------------------------------------------
class N:
 def __init__(self,name,*props,children=None):self.name=name;self.props=list(props);self.children=children or []
class Arr:
 def __init__(self,typ,arr):self.typ=typ;self.arr=arr
class I64:
 def __init__(self,n):self.n=int(n)
def prop_data(v):
 if isinstance(v,Arr):
  dtype={'d':np.dtype('<f8'),'f':np.dtype('<f4'),'i':np.dtype('<i4'),'l':np.dtype('<i8')}[v.typ]
  arr=np.asarray(v.arr,dtype=dtype);data=arr.tobytes();compressed=zlib.compress(data,5)
  return v.typ.encode()+struct.pack('<III',len(arr),1,len(compressed))+compressed
 if isinstance(v,I64):return b'L'+struct.pack('<q',v.n)
 if isinstance(v,bool):return b'C'+struct.pack('<?',v)
 if isinstance(v,int):return b'I'+struct.pack('<i',v)
 if isinstance(v,float):return b'D'+struct.pack('<d',v)
 if isinstance(v,str):
  b=v.encode('utf-8');return b'S'+struct.pack('<I',len(b))+b
 raise TypeError((type(v),v))
def write_node(n,offset):
 name=n.name.encode('utf8');props=b''.join(prop_data(p) for p in n.props)
 out=bytearray();children_offset=offset+13+len(name)+len(props)
 for child in n.children:
  childdata=write_node(child,children_offset+len(out));out.extend(childdata)
 if n.children:out.extend(b'\0'*13)
 end=offset+13+len(name)+len(props)+len(out)
 return struct.pack('<IIIB',end,len(n.props),len(props),len(name))+name+props+out

def P(name,typ,value,kind='Number'):
 # standard FBX Properties70 declaration
 if isinstance(value,(tuple,list,np.ndarray)):
  return N('P',name,typ,kind,'',*[float(x) for x in value])
 return N('P',name,typ,kind,'',value)
def model_node(i,name,mode,trans=(0,0,0)):
 return N('Model',I64(i),'Model::'+name,mode,children=[N('Version',232),N('Properties70',children=[P('Lcl Translation','Lcl Translation',trans,'A'),P('Lcl Rotation','Lcl Rotation',(0,0,0),'A'),P('Lcl Scaling','Lcl Scaling',(1,1,1),'A')]),N('Shading',True),N('Culling','CullingOff')])

def fbx_export(items,path,model_root):
 """Input: list Asset. Each mesh exported as independent geometry and Mesh model. Binary FBX7.4."""
 all_parts=[(a,p) for a in items for p in a.parts]
 material_names=sorted(set(p.mat for a,p in all_parts))
 matids={name:10000+i for i,name in enumerate(material_names)}
 obj=[];conn=[];gid=200000
 rootid=gid;gid+=1
 obj.append(model_node(rootid,'PROJECT_SPARK_LEVEL56_VISUAL_ROOT','Null'))
 conn.append(N('C','OO',I64(rootid),I64(0)))
 for name in material_names:
  rr,gg,bb,alpha=C[name];rr=float(rr);gg=float(gg);bb=float(bb)
  props=[P('DiffuseColor','Color',(rr,gg,bb)),P('AmbientColor','Color',(rr*.23,gg*.23,bb*.23)),
   P('SpecularColor','Color',(.43,.48,.52)),P('Shininess','double',38.0),P('Opacity','double',float(alpha))]
  obj.append(N('Material',I64(matids[name]),'Material::'+name,'',children=[N('Version',102),N('ShadingModel','phong'),N('MultiLayer',0),N('Properties70',children=props)]))
 for asset in items:
  aid=gid;gid+=1
  obj.append(model_node(aid,asset.name,'Null'))
  conn.append(N('C','OO',I64(aid),I64(rootid)))
  parents={None:aid}
  for group,loc in asset.groups.items():
   ig=gid;gid+=1;parents[group]=ig
   obj.append(model_node(ig,group,'Null',loc))
   conn.append(N('C','OO',I64(ig),I64(aid)))
  for part in asset.parts:
   m=part.mesh
   parent_loc=asset.groups.get(part.group,np.zeros(3))
   vertices=np.asarray(m.vertices,dtype=np.float64)-parent_loc
   faceindex=np.asarray(m.faces,dtype=np.int32).copy();faceindex[:,-1]=-faceindex[:,-1]-1
   # Explicit averaged normals: FBX ByVertice Direct
   normals=np.asarray(m.vertex_normals,dtype=np.float64)
   g_id=gid;mo_id=gid+1;gid+=2
   g_children=[N('GeometryVersion',124),N('Vertices',Arr('d',vertices.reshape(-1))),
    N('PolygonVertexIndex',Arr('i',faceindex.reshape(-1))),
    N('LayerElementNormal',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','ByVertice'),N('ReferenceInformationType','Direct'),N('Normals',Arr('d',normals.reshape(-1)))]),
    N('LayerElementMaterial',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','AllSame'),N('ReferenceInformationType','IndexToDirect'),N('Materials',Arr('i',[0]))]),
    N('Layer',0,children=[N('Version',100),N('LayerElement',children=[N('Type','LayerElementNormal'),N('TypedIndex',0)]),N('LayerElement',children=[N('Type','LayerElementMaterial'),N('TypedIndex',0)])])]
   obj.append(N('Geometry',I64(g_id),'Geometry::'+asset.name+'__'+part.name,'Mesh',children=g_children))
   obj.append(model_node(mo_id,asset.name+'__'+part.name,'Mesh'))
   conn.extend([N('C','OO',I64(g_id),I64(mo_id)),N('C','OO',I64(mo_id),I64(parents[part.group])),N('C','OO',I64(matids[part.mat]),I64(mo_id))])
 globs=N('GlobalSettings',children=[N('Version',1000),N('Properties70',children=[
 P('UpAxis','int',1,'Integer'),P('UpAxisSign','int',1,'Integer'),
 P('FrontAxis','int',2,'Integer'),P('FrontAxisSign','int',1,'Integer'),
 P('CoordAxis','int',0,'Integer'),P('CoordAxisSign','int',1,'Integer'),
 P('UnitScaleFactor','double',100.0)])])
 defs=N('Definitions',children=[N('Version',100),N('Count',len(obj)),
 N('ObjectType','Model',children=[N('Count',sum(o.name=='Model' for o in obj))]),
 N('ObjectType','Geometry',children=[N('Count',sum(o.name=='Geometry' for o in obj))]),
 N('ObjectType','Material',children=[N('Count',len(material_names))])])
 nodes=[N('FBXHeaderExtension',children=[N('FBXHeaderVersion',1003),N('FBXVersion',7400),N('Creator','Project Spark Level56 Procedural HD Asset Generator')]),globs,defs,N('Objects',children=obj),N('Connections',children=conn),N('Takes',children=[N('Current','')])]
 out=bytearray(b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400))
 for node in nodes:out.extend(write_node(node,len(out)))
 out.extend(b'\0'*13);out.extend(b'\0'*160)
 path.write_bytes(out)
 return len(out),len(obj)

def glb_export(asset,path):
 scene=trimesh.Scene()
 for grp,loc in asset.groups.items():
  # Empty node with meaningful pivot, retained in GLB graph.
  scene.graph.update(frame_to=grp,frame_from='world',matrix=trimesh.transformations.translation_matrix(loc))
 for p in asset.parts:
  m=p.mesh.copy()
  if p.group:
   m.apply_translation(-asset.groups[p.group]);parent=p.group
  else:parent='world'
  rgba=np.array(C[p.mat])*255
  m.visual.vertex_colors=np.tile(rgba.astype(np.uint8),(len(m.vertices),1))
  scene.add_geometry(m,geom_name=p.name,node_name=p.name,parent_node_name=parent)
 path.write_bytes(scene.export(file_type='glb'))

from collections import Counter
import hashlib
for idx, asset in enumerate(assets):
 name=f'{idx:02d}_{asset.name}'
 fbx_export([asset],ROOT/'Models'/(name+'.fbx'),asset.name)
 glb_export(asset,ROOT/'GLB'/(name+'.glb'))
 print(f'{name}: {len(asset.parts)} meshes, {sum(len(p.mesh.faces) for p in asset.parts)} triangles',flush=True)
fbx_export(assets,ROOT/'Models'/'Level56_Complete_ArtKit_Showcase.fbx','ALL')
scene=trimesh.Scene()
for a in assets:
 for p in a.parts:
  mesh=p.mesh.copy();mesh.visual.vertex_colors=np.tile((np.array(C[p.mat])*255).astype(np.uint8),(len(mesh.vertices),1))
  scene.add_geometry(mesh,geom_name=a.name+'__'+p.name,node_name=a.name+'__'+p.name)
(ROOT/'GLB'/'Level56_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
manifest={'levelId':'level_56','displayName':'Harvest the Spin','subtitle':'Advanced Regenerative Braking and Bidirectional Energy Recovery',
 'artUnits':'Meters, Y up, shaft along +X, panel fronts toward +Z',
 'visualReference':'User-approved Level 56 Harvest the Spin concept image',
 'models':[], 'limitations':'Art-only. Proposed 30 wires/48 terminals not instantiated or exact binding validated. Physics, gameplay, Unity import and animations not verified.'}
for idx,a in enumerate(assets):
 manifest['models'].append({'file':f'{idx:02d}_{a.name}.fbx','model':a.name,'triangle_count':sum(len(p.mesh.faces) for p in a.parts),'mesh_parts':len(a.parts),'animation_pivots':{k:list(map(float,v)) for k,v in a.groups.items()}})
manifest['triangle_count']=sum(m['triangle_count'] for m in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with open(ROOT/'Animation_Rigs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['Model','AnimationPivot','X','Y','Z','Notes'])
 for a in assets:
  for k,v in a.groups.items():w.writerow([a.name,k,*[round(float(z),5) for z in v],'Art-only; runtime simulation must drive transform'])
(ROOT/'README_Unity.txt').write_text('''PROJECT SPARK — LEVEL 56: HARVEST THE SPIN — HD PROCEDURAL ART PACK

20 individual FBX 7.4 binary models, 20 GLB backup models, one assembled FBX and one assembled GLB.
The art is authored in a common Y-up space, shaft +X, panel front +Z. Keep all 20 models at 0/0/0 under one common art root. FBX UnitScaleFactor=100 (source art units are meters). Verify import size and normals in Unity.

Models/  individual 3D objects. Do NOT instantiate both individual assets and assembled showcase simultaneously.
GLB/     geometry and vertex-color backups (use a glTF importer or Blender).
Model_Manifest.json / Animation_Rigs.csv  naming and pivot metadata.

Art only: no physical material textures, physically validated capacitor energy, electrical terminals, wire objects, authoritative objectives, Unity scene or prefab. FBX material colors and transparency may require Unity URP/HDRP remapping. This pack is procedurally modeled and AAA-inspired, not certified production AAA assets.

Important design references: proposed Level 56 uses 20 assets, 30 player wires, 48 socket IDs and six objectives. Those gameplay structures are NOT in this visual-only archive; their exact topology and locations must be finalized before implementation. Also verify the circuit's 5V supply and realistic flywheel/capacitor parameters.
''')
print('DONE', len(assets),'assets',manifest['triangle_count'],'tris')
