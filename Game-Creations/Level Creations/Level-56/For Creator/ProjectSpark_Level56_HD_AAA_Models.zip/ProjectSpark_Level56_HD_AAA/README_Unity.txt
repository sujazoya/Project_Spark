PROJECT SPARK — LEVEL 56: HARVEST THE SPIN — HD PROCEDURAL ART PACK

20 individual FBX 7.4 binary models, 20 GLB backup models, one assembled FBX and one assembled GLB.
The art is authored in a common Y-up space, shaft +X, panel front +Z. Keep all 20 models at 0/0/0 under one common art root. FBX UnitScaleFactor=100 (source art units are meters). Verify import size and normals in Unity.

Models/  individual 3D objects. Do NOT instantiate both individual assets and assembled showcase simultaneously.
GLB/     geometry and vertex-color backups (use a glTF importer or Blender).
Model_Manifest.json / Animation_Rigs.csv  naming and pivot metadata.

Art only: no physical material textures, physically validated capacitor energy, electrical terminals, wire objects, authoritative objectives, Unity scene or prefab. FBX material colors and transparency may require Unity URP/HDRP remapping. This pack is procedurally modeled and AAA-inspired, not certified production AAA assets.

Important design references: proposed Level 56 uses 20 assets, 30 player wires, 48 socket IDs and six objectives. Those gameplay structures are NOT in this visual-only archive; their exact topology and locations must be finalized before implementation. Also verify the circuit's 5V supply and realistic flywheel/capacitor parameters.
