Visual-only assembled DSX-33; keep Models_OBJ/ and Textures/ relative paths. GLB has material factors, OBJ/MTL uses texture library. No electrical certification.
