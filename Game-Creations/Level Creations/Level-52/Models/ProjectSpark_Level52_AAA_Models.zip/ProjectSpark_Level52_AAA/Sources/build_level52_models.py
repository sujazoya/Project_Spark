"""PROJECT SPARK Level 52 — Cancel the Shake: active rotor-balancing VISUAL MESHES.
Actual 3D Autodesk FBX 7.4 binary + GLB model set (Y-up, front -Z).
Does not implement electrical simulation, active balancing controller, or objective gates.
All dimensions are ART UNITS and require alignment to Unity breadboard sockets.
"""
from __future__ import annotations
import math, csv, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb
ROOT=Path(__file__).resolve().parents[1]
MOD=ROOT/'Models'
PALETTE.update({
 'nickel':(148,169,191,255),'aluminum':(179,195,211,255),'mirror':(225,235,243,255),
 'darksteel':(35,52,72,255),'carbon':(16,31,45,255),'coal':(9,19,30,255),
 'aqua':(42,223,251,255),'mint':(60,250,191,255),'electric':(43,127,240,255),
 'scarlet':(255,66,84,255),'safety':(250,182,52,255),'amberlit':(255,211,105,255),
 'brass':(208,163,73,255),'bronze':(173,106,52,255),'gunmetal':(70,93,116,255),
 'glassblue':(115,201,239,65),'screenback':(7,31,47,255),'smokeglass':(94,144,175,72),
 'pale':(226,241,248,255),'copperlight':(228,146,77,255),'teal':(40,147,160,255),
 'violet':(168,119,250,255),'orange_hi':(255,136,56,255)
})

def label(m,n,text,x,y,z,sz=.16,col='pale',width=None,g='Static'):
 m.text(n,text,sz,x,y,z,col,maxwidth=width,group=g)

def screw(m,n,x,y,z):
 m.cyl(n+'_head',.059,.032,(x,y,z),'chrome','y',18)
 m.box(n+'_slot',(.070,.008,.010),(x,y+.017,z),'darksteel')

def led(m,n,x,y,z,c='mint',g=None):
 gr=g or n+'_LENS';m.cyl(n+'_rim',.119,.043,(x,y,z),'chrome','z',24,gr)
 m.cyl(n+'_lens',.091,.045,(x,y,z-.04),c,'z',24,gr)
 m.torus(n+'_halo',.127,.018,(x,y,z-.071),c,'z',32,7,gr)
 m.group_pivots[gr]=(x,y,z)

def jack(m,n,code,caption,x,y,z,c='aqua'):
 g='SOCKET_'+code
 m.cyl(n+'_'+code+'_Rim',.150,.053,(x,y,z),'chrome','z',30,g)
 m.cyl(n+'_'+code+'_Color',.127,.064,(x,y,z-.037),c,'z',30,g)
 m.cyl(n+'_'+code+'_Recess',.082,.063,(x,y,z-.078),'coal','z',26,g)
 m.cyl(n+'_'+code+'_Contact',.027,.026,(x,y,z-.110),'brass','z',12,g)
 label(m,n+'_'+code+'_Print',caption,x,y+.213,z-.125,.104,'pale',.75)
 assert code not in m.anchors,'duplicate '+code
 m.anchors[code]=(round(x,4),round(y,4),round(z-.132,4))

def foot(m,n,w=5,d=4,accent='aqua'):
 m.bevel(n+'_RubberIsolation',(w+.16,.15,d+.15),(0,.14,0),'rubber',.07)
 m.bevel(n+'_AluminumCasting',(w,.32,d),(0,.39,0),'darksteel',.14)
 m.bevel(n+'_TopSurface',(w-.18,.075,d-.18),(0,.58,0),'nickel',.05)
 m.box(n+'_LightStrip',(w-.47,.035,.06),(0,.67,-d/2-.049),accent)
 for x in (-w/2+.32,w/2-.32):
  for z in (-d/2+.35,d/2-.35):screw(m,n+f'_BOLT_{x:.1f}_{z:.1f}',x,.64,z)

def cabinet(m,n,heading,w=5.4,d=2.8,h=1.93,sub='',accent='aqua'):
 m.base(n,w,d,h)
 f=-d/2-.095
 m.box(n+'_Header',(w-.36,.29,.035),(0,.32+h*.82,f-.045),'coal')
 label(m,n+'_Title',heading,0,.32+h*.82,f-.077,.184,'pale',w-.54)
 if sub:label(m,n+'_Sub',sub,0,.32+h*.65,f-.073,.114,accent,w-.55)
 m.box(n+'_TopNeon',(w-.55,.036,.036),(0,.32+h+.085,-d/2+.13),accent)
 return f

def make_base():
 m=Model('00_L52_IndustrialBase');n='L52_PRECISION_BENCH'
 m.bevel(n+'_RubberShockBase',(44.0,.26,23.8),(0,.16,0),'rubber',.20)
 m.bevel(n+'_TitaniumMachinedMainDeck',(43.5,.59,23.2),(0,.50,0),'graphite',.26)
 m.box(n+'_BrushedWorkSurface',(43.0,.065,22.7),(0,.83,0),'darksteel')
 for xx in (-21.4,21.4):
  m.box(n+f'_RimSupport_{xx}',(.25,.35,22.5),(xx,1.01,0),'nickel')
  m.box(n+f'_NeonSeam_{xx}',(.06,.043,21.8),(xx,1.21,0),'aqua')
 for zz in (-11.25,11.25):
  m.box(n+f'_EndRail_{zz}',(42.5,.35,.20),(0,1.03,zz),'gunmetal')
  m.box(n+f'_EndSeam_{zz}',(42.0,.04,.042),(0,1.21,zz),'mint' if zz>0 else 'safety')
 for x in np.linspace(-19.7,19.7,29):
  for z in (-10.65,-10.2):m.cyl(n+f'_FrontBB_Hole_{x:.2f}_{z:.2f}',.041,.013,(float(x),.863,z),'coal','y',8)
 for x in (-20.5,20.5):
  for z in (-10.6,10.6):m.bevel(n+f'_DampingFoot_{x}_{z}',(1.22,.33,1.18),(x,.14,z),'rubber',.10)
 # Polished shared axle makes independently imported modules read as one assembly.
 axle_group='GLOBAL_DRIVETRAIN_SHAFT_ROTATE_X'
 m.cyl(n+'_SharedHardenedSteelShaft',.185,24.8,(.35,2.95,1.20),'mirror','x',48,axle_group)
 for k,xx in enumerate((-10.8,-4.15,2.62,8.50)):
  m.cyl(n+f'_ConnectingCoupler_{k}',.275,.46,(xx,2.95,1.20),'brass','x',36,axle_group)
  m.torus(n+f'_CouplerBlueRim_{k}',.258,.026,(xx+.21,2.95,1.20),'aqua','x',38,7,axle_group)
 m.group_pivots[axle_group]=(.35,2.95,1.20)
 for j,x in enumerate(np.linspace(-19,19,13)):
  m.box(n+f'_SafetyStripe_{j}',(.57,.024,.61),(float(x),.871,-10.97),'safety' if j%2 else 'coal')
 label(m,n+'_ProjectName','PROJECT SPARK   /   LEVEL 52   /   CANCEL THE SHAKE',0,1.24,-11.43,.34,'pale',24)
 return m

def make_motor():
 m=Model('01_L52_DriveMotor');n='L52_BRUSHED_MOTOR';foot(m,n,5.9,4.4,'aqua')
 y=2.95
 for xx in (-1.62,1.62):
  m.box(n+f'_Saddle_{xx}',(.44,1.57,2.04),(xx,1.51,0),'gunmetal')
  m.bevel(n+f'_SaddleFoot_{xx}',(.86,.20,2.65),(xx,.78,0),'mirror',.08)
 m.cyl(n+'_MotorCan',1.12,3.99,(0,y,0),'nickel','x',72)
 m.cyl(n+'_FrontEndbell',1.20,.30,(2.04,y,0),'carbon','x',64)
 m.cyl(n+'_RearEndbell',1.16,.28,(-2.04,y,0),'gunmetal','x',64)
 for k in range(32):
  a=math.tau*k/32
  m.rod(n+f'_ExtrudedCoolingFin_{k:02d}',(-1.75,y+1.11*math.cos(a),1.11*math.sin(a)),(1.73,y+1.11*math.cos(a),1.11*math.sin(a)),.048,'aluminum',9)
 for x in (-2.2,2.2):m.torus(n+f'_AccentRim_{x}',1.13,.055,(x,y,0),'aqua' if x>0 else 'mirror','x',64,9)
 for k in range(8):
  a=math.tau*k/8;m.cyl(n+f'_EndcapScrew_{k}',.07,.04,(2.26,y+.92*math.cos(a),.92*math.sin(a)),'mirror','x',12)
 g='MOTOR_SHAFT_ROTATE_X';m.cyl(n+'_DriveShaft',.22,2.48,(2.49,y,0),'mirror','x',32,g)
 m.cyl(n+'_MachinedCoupling',.37,.56,(3.40,y,0),'brass','x',34,g)
 m.group_pivots[g]=(2.48,y,0)
 for x in (-.84,.84):m.cyl(n+f'_CableStud_{x}',.145,.2,(-1.78,y+.52,x*.6),'copperlight','y',20)
 m.bevel(n+'_SocketDock',(3.16,.75,.67),(0,.62,-2.53),'carbon',.06)
 jack(m,n,'MOTOR_POS','MOTOR +',-.74,.76,-2.92,'scarlet')
 jack(m,n,'MOTOR_NEG','MOTOR -',.74,.76,-2.92,'coal')
 label(m,n+'_Plate','5 V DC PRECISION MOTOR',0,1.08,-2.59,.153,'pale',2.90)
 return m

def make_rotor():
 m=Model('02_L52_TestRotor');n='L52_PRECISION_ROTOR';foot(m,n,5.45,5.00,'mint')
 y=2.95;g='TEST_ROTOR_ROTATE_X'
 m.cyl(n+'_Axle',.29,4.4,(0,y,0),'mirror','x',44,g)
 m.cyl(n+'_SteelDisc',2.16,.63,(0,y,0),'nickel','x',92,g)
 m.cyl(n+'_InsetCarbonFace',1.88,.65,(0,y,0),'gunmetal','x',92,g)
 for x in (-.365,.365):
  m.torus(n+f'_BrightOuterRim_{x}',2.05,.074,(x,y,0),'mirror','x',84,9,g)
  m.torus(n+f'_BlueConcentricRing_{x}',1.77,.025,(x,y,0),'aqua','x',80,8,g)
  m.torus(n+f'_InnerCircle_{x}',.47,.069,(x,y,0),'chrome','x',64,8,g)
 for k in range(36):
  a=math.tau*k/36
  m.cyl(n+f'_PerimeterBore_{k:02d}',.083,.025,(.36,y+1.56*math.cos(a),1.56*math.sin(a)),'coal','x',16,g)
  if k%3==0:m.cyl(n+f'_DegreeIndex_{k:02d}',.046,.029,(.39,y+1.93*math.cos(a),1.93*math.sin(a)),'mint','x',14,g)
 for k in range(12):
  a=math.tau*k/12
  m.cyl(n+f'_HubBolt_{k:02d}',.083,.038,(.36,y+.78*math.cos(a),.78*math.sin(a)),'mirror','x',16,g)
 m.group_pivots[g]=(0,y,0)
 for xx in (-1.70,1.70):
  m.box(n+f'_ShaftPedestal_{xx}',(.37,1.72,1.31),(xx,1.50,0),'gunmetal')
  m.tube(n+f'_Bearing_Ring_{xx}',.58,.27,.48,(xx,y,0),'chrome','x',42)
 label(m,n+'_Caption','PRECISION ROTOR / 360 DEG',0,.94,-2.62,.160,'pale',4.95)
 return m

def make_fault_weight():
 m=Model('03_L52_ImbalanceWeight');n='L52_FAULT_WEIGHT';foot(m,n,3.75,3.1,'scarlet')
 m.cyl(n+'_MountPlate',.78,.15,(0,1.20,.30),'gunmetal','y',42)
 g='IMBALANCE_TEST_WEIGHT_DETACH'
 m.cyl(n+'_EccentricWeight',.36,.34,(0,1.58,.30),'scarlet','y',36,g)
 m.cyl(n+'_SteelLoadCore',.21,.38,(0,1.64,.30),'brass','y',26,g)
 m.cyl(n+'_CentralFastener',.10,.10,(0,1.88,.30),'mirror','y',18,g)
 for k in range(12):
  a=math.tau*k/12;m.cyl(n+f'_GripNotch_{k}',.034,.035,(.33*math.sin(a),1.75,.30+.33*math.cos(a)),'coal','y',9,g)
 m.group_pivots[g]=(0,1.58,.30)
 m.bevel(n+'_ScrewTray',(1.45,.19,.84),(0,.85,-.95),'coal',.07)
 for k in range(4):m.cyl(n+f'_SpareLockNut_{k}',.10,.055,(-.52+k*.34,1.02,-.95),'brass','y',15)
 label(m,n+'_Name','RED IMBALANCE TEST WEIGHT',0,.83,-1.64,.146,'pale',3.35)
 return m

def make_balance_ring():
 m=Model('04_L52_ActiveBalanceRing');n='L52_DUAL_MASS_RING';foot(m,n,6.0,5.7,'amberlit')
 y=2.95
 g='RING_ROTOR_ROTATE_X'
 m.tube(n+'_RotatingTitaniumAnnulus',2.20,1.54,.49,(0,y,0),'nickel','x',96,g)
 m.torus(n+'_OuterMachinedRail',2.13,.086,(.26,y,0),'mirror','x',88,12,g)
 m.torus(n+'_InnerTrack',1.72,.06,(.28,y,0),'carbon','x',88,10,g)
 m.torus(n+'_CyanTrackingArc',1.90,.027,(.31,y,0),'aqua','x',80,8,g)
 for k in range(48):
  a=math.tau*k/48
  m.cyl(n+f'_RingGraduation_{k:02d}',.032 if k%4 else .054,.023,(.32,y+2.00*math.cos(a),2.00*math.sin(a)),'mint' if k%6==0 else 'pale','x',11,g)
 m.group_pivots[g]=(0,y,0)
 for code,az,col in [('A',45,'aqua'),('B',225,'safety')]:
  ang=math.radians(az);gr='CORRECTION_MASS_'+code+'_ORBIT_X'
  cx=.46;cy=y+1.85*math.cos(ang);cz=1.85*math.sin(ang)
  m.bevel(n+f'_Mass_{code}_SlidingSaddle',(.42,.53,.63),(cx,cy,cz),'gunmetal',.06,gr)
  m.cyl(n+f'_Mass_{code}_TungstenCan',.31,.38,(cx+.22,cy,cz),'brass','x',28,gr)
  m.cyl(n+f'_Mass_{code}_LuminousCap',.16,.06,(cx+.45,cy,cz),col,'x',22,gr)
  m.cyl(n+f'_Mass_{code}_Fastener',.066,.04,(cx+.50,cy,cz),'mirror','x',14,gr)
  m.group_pivots[gr]=(0,y,0)
 for xx in (-2,2):
  m.box(n+f'_Upright_{xx}',(.32,1.85,1.44),(xx,1.62,0),'gunmetal')
  m.tube(n+f'_RotorBearing_{xx}',.54,.30,.43,(xx,y,0),'mirror','x',44)
 m.box(n+'_BackRingDriverMount',(.82,.76,1.10),(-.85,1.85,1.83),'carbon')
 m.bevel(n+'_PowerConnectorDock',(3.42,.69,.74),(0,.66,-3.00),'carbon',.06)
 jack(m,n,'RING_POWER_POS','RING +',-.75,.78,-3.43,'scarlet')
 jack(m,n,'RING_POWER_NEG','RING -',.75,.78,-3.43,'coal')
 label(m,n+'_Caption','ACTIVE RING / MASS A + MASS B',0,.99,-3.08,.15,'pale',5.1)
 return m

def make_actuator():
 m=Model('05_L52_BalanceActuator');n='L52_BALANCE_ACTUATOR';foot(m,n,4.8,4.5,'safety')
 y=2.95
 m.bevel(n+'_StatorMount',(2.85,1.1,2.85),(0,1.30,0),'gunmetal',.12)
 m.tube(n+'_CopperStatorOuter',1.22,.75,.69,(0,y,0),'brass','x',64)
 m.torus(n+'_ActiveCoilNeon',.97,.065,(.38,y,0),'aqua','x',58,11)
 m.cyl(n+'_ShaftPassage',.55,.74,(0,y,0),'carbon','x',54)
 for k in range(16):
  a=math.tau*k/16
  m.rod(n+f'_CopperWinding_{k:02d}',(-.33,y+.98*math.cos(a),.98*math.sin(a)),(.33,y+.98*math.cos(a),.98*math.sin(a)),.061,'copperlight',12)
 for code,x in [('A',-1.22),('B',1.22)]:
  gr='ACTUATOR_INDICATOR_'+code
  m.cyl(n+f'_StatusLens_{code}',.20,.045,(x,3.28,-.42),'mint' if code=='A' else 'safety','z',24,gr)
  m.group_pivots[gr]=(x,3.28,-.42)
 m.bevel(n+'_ControlBox',(3.1,.73,1.38),(0,.80,-1.35),'carbon',.09)
 label(m,n+'_Label','DUAL MASS ACTUATOR',0,.91,-2.00,.156,'pale',4.0)
 return m

def make_encoder():
 m=Model('06_L52_EncoderABZ');n='L52_ABZ_ENCODER';foot(m,n,4.55,4.7,'mint')
 y=2.95;g='ENCODER_ABZ_DISC_ROTATE_X'
 m.cyl(n+'_Shaft',.20,2.57,(0,y,0),'mirror','x',32,g)
 m.cyl(n+'_PatternDisc',1.43,.115,(0,y,0),'coal','x',72,g)
 m.torus(n+'_OutsideBlueRing',1.33,.036,(.075,y,0),'aqua','x',72,8,g)
 for k in range(80):
  a=math.tau*k/80;m.cyl(n+f'_EncoderTick_{k:02d}',.020 if k%5 else .038,.028,(.087,y+1.20*math.cos(a),1.20*math.sin(a)),'pale' if k%2 else 'mint','x',9,g)
 m.cyl(n+'_UniqueZIndexMark',.094,.029,(.09,y+1.20,0),'safety','x',18,g)
 m.group_pivots[g]=(0,y,0)
 m.box(n+'_FixedOpticalBracket',(.43,1.10,.52),(-1.14,2.50,0),'gunmetal')
 m.bevel(n+'_ReadingHead',(1.25,.42,.74),(0,4.09,.0),'nickel',.08)
 for x,c in [(-.34,'aqua'),(0,'mint'),(.34,'safety')]:
  m.cyl(n+f'_SensorLens_{x}',.105,.16,(x,3.87,-.08),c,'y',21)
 m.bevel(n+'_ABZ_SocketDock',(3.74,.75,.65),(0,.61,-2.53),'carbon',.07)
 for x,code,c in [(-1.21,'ENCODER_A','aqua'),(0,'ENCODER_B','mint'),(1.21,'ENCODER_Z','safety')]:
  jack(m,n,code,code.split('_')[1],x,.72,-2.90,c)
 label(m,n+'_Caption','80 COUNTS / REV  +  Z INDEX',0,1.02,-2.58,.143,'pale',4.2)
 return m

def make_vibration():
 m=Model('07_L52_VibrationSensor');n='L52_VIB_SENSOR';f=cabinet(m,n,'PRECISION VIBRATION',5.1,2.8,1.77,'PHASE LOCKED SENSOR','mint')
 m.box(n+'_AluminumStrut',(.32,1.3,.39),(0,2.55,.28),'mirror')
 m.bevel(n+'_PiezoSensor',(.95,.57,.83),(0,3.25,.30),'gunmetal',.11)
 m.bevel(n+'_PiezoMount',(.78,.20,.81),(0,2.87,.28),'brass',.05)
 m.cyl(n+'_StatusCrystal',.12,.16,(0,3.61,-.04),'mint','y',24)
 for x,code,col,txt in [(-1.44,'VIB_PLUS','scarlet','+5V'),(0,'VIB_GND','coal','GND'),(1.44,'VIB_OUT','aqua','SIGNAL')]:
  jack(m,n,code,txt,x,.72,f,col)
 return m

def make_motor_driver():
 m=Model('08_L52_MotorDriver');n='L52_MOTOR_DRIVER';f=cabinet(m,n,'ROTOR MOTOR DRIVER',6.6,2.8,1.94,'5 V / PWM / CURRENT LIMIT','aqua')
 for i in range(12):m.box(n+f'_HeatSinkFin_{i}',(.105,.56,1.29),(-2.64+i*.48,2.47,.25),'aluminum')
 for x,code,c,txt in [(-2.4,'MDRV_PLUS','scarlet','+5V'),(-1.2,'MDRV_GND','coal','GND'),(0,'MDRV_PWM','safety','PWM'),(1.2,'MDRV_MPOS','scarlet','M+'),(2.4,'MDRV_MNEG','coal','M-')]:
  jack(m,n,code,txt,x,.76,f,c)
 led(m,n+'_DriveActive',2.7,1.51,f,'mint')
 return m

def make_balance_driver():
 m=Model('09_L52_BalanceDriver');n='L52_BAL_DRIVER';f=cabinet(m,n,'DUAL WEIGHT DRIVER',6.8,2.95,1.99,'SMART MASS A/B ACTUATION','safety')
 for i in range(10):m.box(n+f'_CopperCoolingFin_{i}',(.17,.42,1.20),(-2.5+i*.56,2.51,.17),'brass')
 for x,code,c,txt in [(-2.50,'BDRV_PLUS','scarlet','+5V'),(-1.24,'BDRV_GND','coal','GND'),(0,'BDRV_CMD','safety','CMD'),(1.25,'BDRV_OUTP','aqua','OUT+'),(2.50,'BDRV_OUTN','coal','OUT-')]:
  jack(m,n,code,txt,x,.75,f,c)
 for x,col in [(-1.50,'aqua'),(1.5,'safety')]:led(m,n+'_MassIndicator'+str(x),x,1.52,f,col)
 return m

def make_controller():
 m=Model('10_L52_BalanceController');n='L52_BALANCE_CTRL';f=cabinet(m,n,'ACTIVE BALANCE CONTROL',10.3,3.5,2.48,'MEASURE  >  ANALYZE  >  AUTO CORRECT','aqua')
 m.bevel(n+'_HMIFrame',(6.3,.84,.065),(0,1.93,f-.081),'gunmetal',.075)
 m.box(n+'_HMIBlankDisplay',(5.91,.64,.029),(0,1.93,f-.132),'screenback',group='CONTROLLER_BLANK_HMI_FACE')
 m.group_pivots['CONTROLLER_BLANK_HMI_FACE']=(0,1.93,f-.132)
 for i,(text,colour) in enumerate([('MANUAL','aqua'),('AUTO','mint'),('ANALYZE','safety'),('STOP','scarlet')]):
  x=-3.57+i*2.38;g='CTRL_BUTTON_'+text
  m.bevel(n+'_'+text+'_Button',(1.66,.27,.145),(x,1.21,f-.11),'carbon',.07,g)
  m.box(n+'_'+text+'_Accent',(1.42,.025,.015),(x,1.31,f-.196),colour,g)
  label(m,n+'_'+text+'_Label',text,x,1.22,f-.202,.105,'pale',1.5,g)
  m.group_pivots[g]=(x,1.21,f-.11)
 positions=[(-4.22,'CTRL_PLUS','+5V','scarlet'),(-3.18,'CTRL_GND','GND','coal'),(-2.12,'CTRL_PWM','PWM','safety'),(-1.06,'CTRL_VIB','VIB','aqua'),(0,'CTRL_EA','ENC A','mint'),(1.06,'CTRL_EB','ENC B','mint'),(2.12,'CTRL_EZ','ENC Z','safety'),(3.18,'CTRL_BAL','BAL CMD','aqua'),(4.22,'CTRL_SAFE','SAFE','amberlit')]
 for x,code,txt,c in positions:jack(m,n,code,txt,x,.69,f,c)
 return m

def make_monitor():
 m=Model('11_L52_SpectrumMonitor');n='L52_WAVEFORM_MONITOR';f=cabinet(m,n,'VIBRATION + POLAR BALANCE',10.0,2.8,2.58,'ROTATION-SYNCHRONOUS ANALYSIS','mint')
 m.bevel(n+'_GlassDisplayBezel',(9.17,1.33,.065),(0,1.83,f-.081),'gunmetal',.065)
 m.box(n+'_HMI_EmptyDynamicDisplay',(8.95,1.11,.035),(0,1.81,f-.136),'screenback',group='SPECTRUM_BLANK_SCREEN_FACE')
 m.group_pivots['SPECTRUM_BLANK_SCREEN_FACE']=(0,1.81,f-.136)
 for yy in (1.45,1.67,1.89,2.11):m.box(n+f'_Gridline_{yy}',(8.50,.012,.012),(0,yy,f-.165),'gunmetal')
 for k in range(24):
  x=-4.1+k*.35;m.box(n+f'_VerticalGrid_{k}',(.009,1.02,.010),(x,1.79,f-.165),'darksteel')
 for lane,col,amp in [(0,'safety',.18),(1,'mint',.048)]:
  yy=2.02-lane*.44;xs=np.linspace(-4.03,4.03,72)
  for k in range(len(xs)-1):
   a=yy+amp*math.sin(k*.64);b=yy+amp*math.sin((k+1)*.64)
   m.rod(n+f'_STATIC_ILLUSTRATIVE_WAVE_{lane}_{k}',(float(xs[k]),a,f-.174),(float(xs[k+1]),b,f-.174),.006,col,6)
 label(m,n+'_Below','MEASURED RMS   /   PHASE DEGREES   /   RESIDUAL VECTOR',0,.93,f-.085,.134,'aqua',8.2)
 return m

def make_guard():
 m=Model('12_L52_SafetyGuard');n='L52_ACTIVE_GUARD';w=27.8;d=8.1
 for x in (-w/2,w/2):
  for z in (-d/2,d/2):m.box(n+f'_Post_{x}_{z}',(.17,5.12,.17),(x,3.32,z),'mirror')
 for yy in (.90,5.90):
  for z in (-d/2,d/2):m.box(n+f'_CrossBar_{yy}_{z}',(w+.22,.18,.20),(0,yy,z),'nickel')
  for x in (-w/2,w/2):m.box(n+f'_SideBar_{yy}_{x}',(.20,.18,d+.23),(x,yy,0),'nickel')
 for x in (-w/2,w/2):m.box(n+f'_ClearSideWall_{x}',(.050,4.62,d-.32),(x,3.34,0),'glassblue')
 for i,x in enumerate(np.linspace(-w/2+1,w/2-1,11)):
  m.box(n+f'_OverheadGuardSlat_{i}',(.058,.07,d),(float(x),5.99,0),'mirror')
 g='FRONT_SAFETY_DOOR_HINGE_Y'
 m.box(n+'_TransparentFrontSwingDoor',(w-.65,4.44,.055),(0,3.37,-d/2),'glassblue',g)
 m.box(n+'_SafetyDoorChromeHandle',(.27,.78,.27),(w/2-1.06,2.8,-d/2-.20),'mirror',g)
 m.group_pivots[g]=(-w/2+.35,3.38,-d/2)
 m.bevel(n+'_InterlockHousing',(1.84,.70,.86),(w/2-.88,.68,-d/2-.40),'carbon',.08)
 jack(m,n,'GUARD_NC','SAFE NC',w/2-.88,.79,-d/2-.89,'safety')
 led(m,n+'_InterlockReady',w/2-2.12,1.49,-d/2-.12,'mint')
 label(m,n+'_Warning','CLEAR ROTOR SAFETY ENCLOSURE',0,6.15,-d/2-.12,.258,'safety',12)
 return m

def make_service_tray():
 m=Model('13_L52_ServiceTray');n='L52_BALANCE_SERVICE';foot(m,n,5.6,4.4,'safety')
 m.bevel(n+'_PartsStoragePocket',(5.05,.34,3.56),(0,.95,0),'carbon',.10)
 for idx in range(8):
  i=idx%4;j=idx//4;x=-1.92+i*1.27;z=-.67+j*1.24
  m.cyl(n+f'_Socket_{idx}',.40,.031,(x,1.18,z),'coal','y',32)
  g=f'TEST_WEIGHT_{idx:02d}_DETACH'
  m.cyl(n+f'_Weight_{idx}',.24+(idx%3)*.018,.16,(x,1.33,z),'brass' if idx<4 else 'nickel','y',28,g)
  m.cyl(n+f'_Bore_{idx}',.075,.18,(x,1.35,z),'coal','y',14,g)
  m.group_pivots[g]=(x,1.33,z)
 for k in range(3):
  m.rod(n+f'_Wrench_{k}',(-2.10+k*1.55,.93,1.72),(-1.62+k*1.55,.99,1.32),.055,'mirror',10)
 label(m,n+'_Name','TEST MASSES + SERVICE TOOLS',0,.87,-2.29,.145,'pale',4.9)
 return m

def make_supply():
 m=Model('14_L52_5VSupply');n='L52_POWER';f=cabinet(m,n,'REGULATED 5 V POWER',4.9,2.95,1.91,'BALANCING LAB SUPPLY','aqua')
 m.box(n+'_DisplayBlank',(2.68,.47,.026),(0,1.56,f-.087),'screenback')
 label(m,n+'_NominalVoltage','5.00 V',0,1.56,f-.131,.257,'mint',2.32)
 led(m,n+'_PowerOn',1.89,1.59,f,'mint')
 for k in range(11):m.box(n+f'_CoolingVent_{k}',(.063,.02,1.21),(-1.77+k*.354,2.61,.23),'coal')
 jack(m,n,'SUPPLY_PLUS','+5V',-1.02,.77,f,'scarlet')
 jack(m,n,'SUPPLY_RETURN','RETURN',1.02,.77,f,'coal')
 return m

BUILDERS=[make_base,make_motor,make_rotor,make_fault_weight,make_balance_ring,make_actuator,make_encoder,make_vibration,make_motor_driver,make_balance_driver,make_controller,make_monitor,make_guard,make_service_tray,make_supply]
POS={
 '00_L52_IndustrialBase':(0,0,0),
 '01_L52_DriveMotor':(-14.50,0,1.20),
 '02_L52_TestRotor':(-7.45,0,1.20),
 '03_L52_ImbalanceWeight':(15.90,0,3.20),
 '04_L52_ActiveBalanceRing':(-.95,0,1.20),
 '05_L52_BalanceActuator':(6.28,0,1.20),
 '06_L52_EncoderABZ':(12.28,0,1.20),
 '07_L52_VibrationSensor':(15.88,0,7.37),
 '08_L52_MotorDriver':(-13.60,0,-7.58),
 '09_L52_BalanceDriver':(-5.16,0,-7.55),
 '10_L52_BalanceController':(4.20,0,-7.67),
 '11_L52_SpectrumMonitor':(-7.36,0,8.26),
 '12_L52_SafetyGuard':(-4.40,0,1.22),
 '13_L52_ServiceTray':(16.05,0,-3.02),
 '14_L52_5VSupply':(16.80,0,-7.56)
}
WIRES=[
 ('W01','SUPPLY_PLUS','CTRL_PLUS','Supply +5V → Balance Controller +5V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply RETURN → Controller GND'),
 ('W03','SUPPLY_PLUS','MDRV_PLUS','Supply +5V → Motor Driver +5V'),
 ('W04','SUPPLY_RETURN','MDRV_GND','Supply RETURN → Motor Driver GND'),
 ('W05','SUPPLY_PLUS','VIB_PLUS','Supply +5V → Vibration Sensor +5V'),
 ('W06','SUPPLY_RETURN','VIB_GND','Supply RETURN → Vibration Sensor GND'),
 ('W07','SUPPLY_PLUS','BDRV_PLUS','Supply +5V → Balance Driver +5V'),
 ('W08','SUPPLY_RETURN','BDRV_GND','Supply RETURN → Balance Driver GND'),
 ('W09','CTRL_PWM','MDRV_PWM','Controller ROTOR PWM → Motor Driver PWM'),
 ('W10','MDRV_MPOS','MOTOR_POS','Motor Driver M+ → DC Motor +'),
 ('W11','MDRV_MNEG','MOTOR_NEG','Motor Driver M− → DC Motor −'),
 ('W12','VIB_OUT','CTRL_VIB','Vibration Sensor OUT → Controller VIB'),
 ('W13','ENCODER_A','CTRL_EA','Encoder A → Controller ENC A'),
 ('W14','ENCODER_B','CTRL_EB','Encoder B → Controller ENC B'),
 ('W15','GUARD_NC','CTRL_SAFE','Guard NC OUT → Controller SAFE'),
 ('W16','CTRL_BAL','BDRV_CMD','Controller BAL CMD → Balance Driver COMMAND'),
 ('W17','BDRV_OUTP','RING_POWER_POS','Balance Driver OUT+ → Ring POWER+'),
 ('W18','BDRV_OUTN','RING_POWER_NEG','Balance Driver OUT− → Ring POWER−'),
 ('W19','ENCODER_Z','CTRL_EZ','Encoder Z → Controller ENC Z')
]

def build():
 models=[]
 for fn in BUILDERS:
  m=fn();models.append(m)
  fb=MOD/(m.key+'.fbx');gl=MOD/(m.key+'.glb')
  export_fbx(fb,[m]);export_glb(gl,[m])
  assert fb.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  assert len(trimesh.load_scene(gl).geometry)>0
  print('MODEL',m.key,'TRIS',sum(len(p.mesh.faces) for p in m.parts),'PARTS',len(m.parts),'SOCKETS',len(m.anchors),flush=True)
 sock=[s for m in models for s in m.anchors]
 assert len(models)==15 and len(sock)==32 and len(sock)==len(set(sock)),(len(models),len(sock),sock)
 wired={q for _,a,b,_ in WIRES for q in (a,b)}
 assert len(WIRES)==19 and wired==set(sock),(len(WIRES),wired^set(sock))
 assert set(POS)==set(m.key for m in models)
 assembled='Level52_Complete_ArtKit_Showcase'
 export_fbx(MOD/(assembled+'.fbx'),models,positions=POS)
 export_glb(MOD/(assembled+'.glb'),models,positions=POS)
 assert len(trimesh.load_scene(MOD/(assembled+'.glb')).geometry)>0
 partinfo={m.key:{'fbx':m.key+'.fbx','glb':m.key+'.glb','triangle_count':sum(len(p.mesh.faces) for p in m.parts),'part_count':len(m.parts),'local_socket_anchors':m.anchors,'animation_pivots':m.group_pivots} for m in models}
 tris=sum(v['triangle_count'] for v in partinfo.values())
 data={'level':52,'name':'Cancel the Shake','theme':'Active Rotor Balancing Laboratory','scope':'VISUAL 3D ASSETS ONLY. No Unity gameplay/circuit/solver/evaluator provided.',
       'individual_models':15,'player_wires':19,'art_socket_count':32,'triangle_count':tris,
       'assembled_fbx':assembled+'.fbx','parts':partinfo,'showcase_positions':POS,'wires':WIRES,
       'coordinate_system':'Y up, front -Z; art-relative units; scale to scene',
       'balance_note':'CORRECTION_MASS_A/B_ORBIT_X both pivot about full ring center; each can move independently. RING_ROTOR_ROTATE_X shows shaft spin only.',
       'electrical_note':'Wiring is design spec. PWM/encoder and balance command require Project Spark signal integration. Art jacks must be snapped to breadboard sockets.'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(data,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','SocketID','LocalX','LocalY','LocalZ','Note'])
  for m in models:
   for s,xyz in m.anchors.items():w.writerow([m.key+'.fbx',s,*xyz,'Art socket only; align real SparkTerminal manually'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','SocketID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for s,xyz in m.anchors.items():w.writerow([m.key+'.fbx',s,*[round(a+b,4) for a,b in zip(xyz,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','GroupName','PivotX','PivotY','PivotZ','DrivenBy'])
  for m in models:
   for g,xyz in m.group_pivots.items():w.writerow([m.key+'.fbx',g,*xyz,'External authoritative runtime state — visuals only'])
 with (ROOT/'Material_Palette.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Material','Red','Green','Blue','Alpha','SuggestedUnityShader'])
  for k,v in PALETTE.items():w.writerow([k,*v,'URP/Lit or HDRP/Lit; configure transmission/emission manually'])
 (ROOT/'VALIDATION.txt').write_text(f'LEVEL 52 / CANCEL THE SHAKE\n15 individual FBXs + 15 GLBs; one assembled FBX + GLB.\n{tris:,} triangles. 19 player design wires / 32 unique art socket anchors.\nFBX binary headers/pointers checked; GLB geometry parsed; all socket IDs validated.\nUnity import, materials, electrical and gameplay integration NOT TESTED.\n')
 print('SUCCESS',tris,'triangles','15 FBX','32 sockets','19 wires',flush=True)
 return models

if __name__=='__main__':build()
