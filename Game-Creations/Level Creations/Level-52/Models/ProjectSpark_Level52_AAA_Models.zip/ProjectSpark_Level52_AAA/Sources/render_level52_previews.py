"""Actual Level 52 triangle mesh previews rendered offscreen using VTK.
No AI mockups: display corresponds to procedural FBX/GLB geometry.
"""
from build_level52_models import *
from pathlib import Path
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from PIL import Image,ImageFont,ImageDraw
import numpy as np
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
P=ROOT/'Previews'

def actor_for(part, offset=(0,0,0)):
 mesh=part.mesh;poly=vtk.vtkPolyData()
 xyz=np.ascontiguousarray(np.asarray(mesh.vertices,dtype=np.float32)+np.asarray(offset,dtype=np.float32),dtype=np.float32)
 pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(xyz,deep=1));poly.SetPoints(pts)
 faces=np.ascontiguousarray(mesh.faces,dtype=np.int64)
 cc=vtk.vtkCellArray();arr=np.column_stack((np.full(len(faces),3,dtype=np.int64),faces)).reshape(-1)
 cc.SetCells(len(faces),numpy_to_vtkIdTypeArray(arr,deep=1));poly.SetPolys(cc)
 norms=vtk.vtkPolyDataNormals();norms.SetInputData(poly);norms.SplittingOff();norms.ConsistencyOn()
 mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norms.GetOutputPort())
 actor=vtk.vtkActor();actor.SetMapper(mapper)
 rgb=np.asarray(PALETTE[part.mat][:3],dtype=float)/255.;prop=actor.GetProperty()
 prop.SetColor(*rgb);prop.SetAmbient(.52);prop.SetDiffuse(.51)
 reflective=part.mat in ('chrome','titanium','steel','gold','copper','orange','orange_hi','mid_steel','brass','aluminum','polished')
 prop.SetSpecular(.70 if reflective else .25);prop.SetSpecularPower(83 if reflective else 32)
 if part.mat in ('cyan','mint','green','blue','red','amber','violet','electric','icy','screen_green','orange_hi','gold'):
  prop.SetAmbient(.81);prop.SetDiffuse(.29)
 if any(v in part.name for v in ('_Name','_Label','_Engraving','_Title','_Sub','_Mark','_Text','_Percent','_Front','_STATIC','_STATIC')):
  if 'Plate' not in part.name and 'Chrome' not in part.name:
   prop.SetAmbient(.96);prop.SetDiffuse(.045);prop.SetSpecular(.003)
 if part.mat in ('glass','darkglass','glass_body','water','glassblue','scan'):
  prop.SetOpacity(.20 if part.mat=='glassblue' else .38)
 prop.SetBackfaceCulling(False)
 return actor

def render(models,path,positions=None,eye=(0,22,-25),look=(0,1.2,0),scale=8.0,size=(2500,1520)):
 positions=positions or {};ren=vtk.vtkRenderer()
 ren.SetBackground(.035,.053,.081);ren.SetBackground2(.005,.012,.028);ren.GradientBackgroundOn()
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(2);win.AddRenderer(ren)
 for model in models:
  for part in model.parts:ren.AddActor(actor_for(part,positions.get(model.key,(0,0,0))))
 for pos,col,inten in [((-14,20,-10),(1.0,.95,.88),1.10),((12,15,7),(.48,.80,1),1.22),((2,13,-6),(.67,.95,1),.71)]:
  li=vtk.vtkLight();li.SetLightTypeToSceneLight();li.SetPosition(*pos);li.SetFocalPoint(0,0,0)
  li.SetColor(*col);li.SetIntensity(inten);ren.AddLight(li)
 camera=ren.GetActiveCamera();camera.SetPosition(*eye);camera.SetFocalPoint(*look);camera.SetViewUp(0,1,0)
 camera.ParallelProjectionOn();camera.SetParallelScale(scale)
 win.Render()
 img=vtk.vtkWindowToImageFilter();img.SetInput(win);img.SetInputBufferTypeToRGB();img.ReadFrontBufferOff();img.Update()
 writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(img.GetOutputPort());writer.Write()
 win.Finalize()
 print('RENDERED',path.name,path.stat().st_size,flush=True)

def overlay(path,title,sub,badge=None):
 im=Image.open(path).convert('RGBA');w,h=im.size;dr=ImageDraw.Draw(im,'RGBA')
 wide=min(w-32,int(w*.81))
 dr.rounded_rectangle((18,15,wide,134),radius=13,fill=(4,17,29,246),outline=(41,223,250,255),width=2)
 titlefont=ImageFont.truetype(BOLD,39 if w>1900 else 26)
 subfont=ImageFont.truetype(FONT,20 if w>1800 else 17)
 dr.text((43,35),title,font=titlefont,fill=(237,248,255))
 dr.text((43,100),sub,font=subfont,fill=(131,219,241))
 if badge and w>1500:
  dr.rounded_rectangle((w-530,24,w-24,82),radius=10,fill=(8,23,39,241),outline=(255,173,72,255),width=2)
  dr.text((w-517,43),badge,font=ImageFont.truetype(BOLD,18),fill=(255,213,144))
 dr.text((w-20,h-20),'PROJECT SPARK  /  LEVEL 52  /  ACTUAL EXPORTED GEOMETRY',font=ImageFont.truetype(BOLD,13),anchor='ra',fill=(138,218,235))
 im.convert('RGB').save(path)

def sheet(previews,models,cols=4):
 tw,th=575,432;rows=int(math.ceil(len(models)/cols));s=Image.new('RGB',(tw*cols,th*rows),(5,18,29))
 dr=ImageDraw.Draw(s)
 for i,(m,fn) in enumerate(zip(models,previews)):
  x=(i%cols)*tw+6;y=(i//cols)*th+5
  im=Image.open(fn).convert('RGB');im.thumbnail((tw-12,th-60),Image.Resampling.LANCZOS)
  s.paste(im,(x,y))
  dr.rounded_rectangle((x,y+th-61,x+tw-13,y+th-12),radius=8,fill=(9,32,50),outline=(43,219,250),width=2)
  name=m.key[3:].replace('_',' ').upper();dr.text((x+13,y+th-47),name,font=ImageFont.truetype(BOLD,19),fill=(241,247,252))
 dest=P/'Level52_All_15_Models_ContactSheet.png';s.save(dest);print('SHEET',dest,flush=True)


if __name__=='__main__':
 models=[fn() for fn in BUILDERS]
 hero=P/'Level52_Complete_15Piece_Kit_Preview.png'
 render(models,hero,POS,eye=(17,26,-41),look=(0,2.10,0),scale=17.2,size=(2780,1690))
 overlay(hero,'LEVEL 52  /  CANCEL THE SHAKE',
         'ACTIVE ROTOR BALANCING LABORATORY  |  15 AAA-STYLE 3D FBX MODELS',
         badge='19 PLAYER WIRES  /  32 SOCKETS')
 close=P/'Level52_Cinematic_Closeup_Preview.png'
 render(models,close,POS,eye=(10,22,-35),look=(-2,2.2,.5),scale=15.5,size=(2600,1550))
 overlay(close,'LEVEL 52  /  ACTIVE ROTOR BALANCING',
         'DUAL-MASS CORRECTION RING  |  A/B/Z ENCODER  |  PHASE MONITOR',
         badge='ACTUAL 3D GEOMETRY')
 close2=P/'Level52_TestRig_Detail_Preview.png'
 render(models,close2,POS,eye=(-8,14,-17),look=(-4,2.65,1.1),scale=8.8,size=(2170,1350))
 overlay(close2,'LEVEL 52  /  BALANCING MACHINE TEST CELL',
         'MOTOR  >  PRECISION ROTOR  >  ACTIVE RING  >  ENCODER')
 shots=[]
 for i,m in enumerate(models):
  dest=P/(m.key+'_Preview.png')
  # For large base and huge guard, frame more widely.
  if i==0:eye=(22,25,-35);look=(0,1,0);sc=16
  elif i==12:eye=(15,17,-28);look=(0,3.0,0);sc=10.0
  elif i==10:eye=(5,7,-14);look=(0,1.4,0);sc=4.8
  elif i==11:eye=(6,7,-13);look=(0,1.5,0);sc=4.6
  elif i in (1,2,3,4,5,6):eye=(5,7,-12);look=(0,1.9,0);sc=4.7
  else:eye=(4.5,7,-12);look=(0,1.6,0);sc=4.2
  render([m],dest,eye=eye,look=look,scale=sc,size=(950,740))
  overlay(dest,m.key.split('_',2)[-1].replace('_',' ').upper(),'LEVEL 52 / REAL EXPORTED MODEL MESH')
  shots.append(dest)
 sheet(shots,models,cols=4)
 print('ALL LEVEL 52 RENDERS COMPLETE',flush=True)
