PROJECT SPARK Level 120 RAX-28 THE AXIS FORGE

This contains the fully ASSEMBLED VISUAL motherboard in both OBJ+MTL and GLB.
The OBJ MTL uses relative ../Textures/ paths, so preserve the folder tree.
The GLB is portable and contains PBR material factors and model geometry; original source PBR textures are included separately for Unity URP remapping.
This is a visual model with 264 components and six heatsinks, NOT electrical or gameplay authority.
In Unity 6.3 import OBJ and create the complete motherboard prefab through the full kit Level 120 builder.
