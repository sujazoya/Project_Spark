import os, sys, json, csv, math, pathlib, shutil, zipfile, hashlib
import numpy as np, trimesh
sys.path.insert(0,'/mnt/data/ProjectSpark_Level57_HD_AAA/Source')
import l57_core as c
ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level59_HD_AAA')
for d in ['Models','GLB','Previews','Unity_Optional','Source']:(ROOT/d).mkdir(parents=True,exist_ok=True)
c.ROOT=ROOT;c.assets=[]
NAMES=['IndustrialBlackStartBase','BatteryStorageBank','BatteryManagementSystem','GridFormingInverter','DCPrechargeModule','DCPowerDistributionBus','ThreePhaseACBus','BackupGenerator','GeneratorStarter','GeneratorSynchronizationRelay','MainGridBreaker','GeneratorBreaker','EssentialLoadBreakerA','EssentialLoadBreakerB','EssentialLoadBreakerC','NonessentialLoadBreakerA','NonessentialLoadBreakerB','EmergencyLightingLoad','CriticalCoolingLoad','IndustrialMotorLoad','VoltageFrequencySensorHub','PowerEnergyMeter','RestorationSequencer','HolographicRestorationMonitor','TransparentSafetyEnclosure','Regulated5VControlSupply']
c.MODELS=['L59_'+s for s in NAMES]
from l57_core import box,cyl,ann,tor,beam,bolt,led,text_geo,cable

def b(n,x,y,z,w,h,d,mat='blue_steel',group=None):box(n,(x,y,z),(w,h,d),mat,group)
def txt(n,s,x,y,z,w=1,size=.075,mat='white'):text_geo(n,s,(x,y,z),w,size,mat)
def jack(n,x,y,z,color='cyan'):
 cyl(n+'Ring',(x,y,z),.075,.025,'z','chrome',20)
 cyl(n+'Insulator',(x,y,z+.018),.052,.024,'z',color,20)
 cyl(n+'Socket',(x,y,z+.033),.020,.012,'z','dark',16)
def enclosure(n,x,y,z,w,h,d,accent='cyan',title='MODULE',ports=4):
 b(n+'Body',x,y,z,w,h,d,'blue_steel');b(n+'Face',x,y,z+d/2+.011,w-.065,h-.07,.025,'navy');b(n+'Lid',x,y+h/2+.025,z,w+.025,.045,d+.02,'silver_dark')
 b(n+'Accent',x,y+h/2+.052,z+d*.28,w-.10,.016,.026,accent)
 for sx in [-1,1]:
  for sy in [-1,1]:bolt(n+'Bolt'+str(sx)+str(sy),(x+sx*(w/2-.07),y+sy*(h/2-.08),z+d/2+.04),'z',.019)
 txt(n+'Title',title,x-w*.44,y+h*.24,z+d/2+.036,w*.88,.07)
 led(n+'Healthy',(x-w*.38,y+.02,z+d/2+.038),'green',.029,'z')
 for k in range(ports):
  xx=x+(k-(ports-1)/2)*(w-.25)/max(1,ports-1)
  jack(n+'Port'+str(k),xx,y-h*.29,z+d/2+.04,['red','electric','cyan','green','amber'][k%5])
def display(n,x,y,z,w,h):
 b(n+'Frame',x,y,z,w+.06,h+.06,.035,'silver_dark');b(n+'Screen',x,y,z+.025,w,h,.015,'display')
 for j in range(9):
  xx=x-w*.43+j*w*.108
  beam(n+'Signal'+str(j),(xx,y-.08,z+.037),(xx,y-.08+.07*math.sin(j*1.3),z+.037),.006,'cyan',7)
def breaker(idx,x,z,name,accent='green'):
 c.start(idx);enclosure(name.replace(' ','')+'Cabinet',x,1.03,z,.72,.74,.63,accent,name,2)
 b(name+'RockerHousing',x,1.05,z+.355,.32,.30,.064,'silver_dark')
 b(name+'Rocker',x,1.075,z+.41,.115,.24,.13,'chrome','ANIM_BREAKER_HANDLE')
 b(name+'RockerGrip',x,1.18,z+.49,.18,.070,.11,'red','ANIM_BREAKER_HANDLE')
 c.current.pivot('ANIM_BREAKER_HANDLE',(x,1.055,z+.415))
 b(name+'Lamp',x,.91,z+.43,.26,.075,.022,accent)

def load(idx,x,z,nam,kind='panel'):
 c.start(idx)
 enclosure(nam.replace(' ','')+'Load',x,.87,z,.88,.60,.69,'green',nam,3)
 if kind=='light':
  for j in range(5):b('EmergencyLamp'+str(j),x-.30+j*.15,1.36,z-.07,.10,.11,.22,'amber')
 elif kind=='cool':
  for j in range(2):
   xx=x+(-.22 if j==0 else .22)
   tor('CoolingFanRing'+str(j),(xx,1.26,z-.06),.17,.03,'z','chrome',32,8)
   for k in range(6):beam('FanBlade'+str(j)+'_'+str(k),(xx,1.26,z-.03),(xx+.13*math.cos(k*math.tau/6),1.26+.13*math.sin(k*math.tau/6),z-.03),.026,'electric',8,'ANIM_FAN_SPIN')
  c.current.pivot('ANIM_FAN_SPIN',(x,1.26,z-.06))
 elif kind=='motor':
  cyl('LoadMotorBody',(x,1.42,z-.09),.21,.67,'x','blue_steel',32)
  for j in range(12):b('MotorFin'+str(j),x-.27+j*.05,1.63,z-.09,.030,.09,.39,'silver')
  cyl('LoadMotorShaft',(x+.44,1.42,z-.09),.063,.33,'x','chrome',20,'ANIM_MOTOR_SPIN')
  c.current.pivot('ANIM_MOTOR_SPIN',(x,1.42,z-.09))
 else:
  for j in range(6):b('LoadCoolingFin'+str(j),x-.30+j*.12,1.29,z-.10,.042,.27,.35,'silver')

# 00 precision base with power rails
c.start(0)
b('DiecastMainBed',0,.05,0,10.7,.35,6.1,'titanium')
b('InsetNonConductiveDeck',0,.268,0,10.46,.075,5.87,'carbon')
b('FrontControlConnectionBay',0,.60,2.53,10.45,.55,.57,'navy')
for z in [-2.88,2.87]:b('PerimeterEdgeLight',0,.32,z,10.42,.028,.036,'cyan')
for x in [-5.13,5.13]:b('MachinedSideRail',x,.31,0,.06,.065,5.93,'silver')
for x in [-4.85,4.85]:
 for z in [-2.68,2.68]:cyl('AntiVibrationMount',(x,-.22,z),.14,.23,'y','rubber',16)
for j in range(34):
 xx=-5.0+j*.303
 cyl('FrontJackRim'+str(j),(xx,.62,2.833),.066,.016,'z','silver',14)
 cyl('FrontJackInsulator'+str(j),(xx,.62,2.847),.042,.014,'z',['red','electric','cyan','green'][j%4],14)
for j in range(23):b('DeckVent'+str(j),-4.82+j*.44,.324,-2.64,.032,.012,.36,'silver_dark')
txt('Brand','PROJECT SPARK / BLACK START LAB',-2.5,.77,2.832,5.0,.115)
# 01 Battery bank
c.start(1)
b('BatteryCabinet',-4.32,1.42,-1.34,1.54,1.82,1.18,'blue_steel')
b('BatteryOpenFront',-4.32,1.43,-.732,1.39,1.59,.038,'dark')
for row in range(3):
 for k in range(4):
  xx=-4.85+k*.35;yy=.88+row*.46
  b(f'BatteryCell_{row}_{k}',xx,yy,-.67,.245,.36,.31,'electric')
  b(f'BatteryCellGlow_{row}_{k}',xx,yy+.14,-.495,.16,.035,.02,'cyan')
  for sh in [-1,1]:bolt('CellTerminal',(xx+sh*.09,yy+.20,-.64),'y',.028)
for j in range(4):beam('BatteryVerticalBus',(-4.85+j*.35,.83,-.47),(-4.85+j*.35,1.97,-.47),.022,'copper',8)
led('BatterySOC',(-4.8,2.21,-.72),'green',.065,'z')
txt('BatteryLabel','BATTERY STORAGE',-4.89,2.47,-.719,1.30,.084)
# 02 BMS
c.start(2);enclosure('BMS',-4.32,.75,.80,1.28,.60,.69,'green','BATTERY BMS',4)
display('SOCmonitor',-4.32,.80,1.162,.77,.20)
# 03 inverter
c.start(3);enclosure('FormingInverter',-2.65,1.42,-1.38,1.60,1.75,1.12,'cyan','GRID INVERTER',5)
display('ACWaveLCD',-2.64,1.58,-.794,.98,.34)
for j in range(12):b('InverterFin'+str(j),-3.29+j*.117,2.31,-1.44,.040,.27,.79,'silver')
for j,col in enumerate(['red','amber','electric']):jack('ACOutput'+str(j),-3.05+j*.40,1.13,-.75,col)
# 04 precharge module
c.start(4);enclosure('PrechargeUnit',-1.45,1.64,-1.46,.83,1.06,.72,'amber','PRECHARGE',3)
for j in range(4):b('PrechargeResistor'+str(j),-1.72+j*.17,2.19,-1.42,.065,.20,.40,'silver')
# 05 DC bus
c.start(5)
b('DCPowerBackplate',-2.33,.72,-.24,3.75,.46,.15,'navy')
for j,(col,yy) in enumerate([('red',.83),('electric',.62)]):
 beam('DCCopperRail'+str(j),(-4.16,yy,-.11),(-.49,yy,-.11),.051,col,16)
 for k in range(7):b('DCCeramicMount',-4.0+k*.58,.67,-.24,.11,.22,.13,'white')
# 06 AC bus
c.start(6)
b('ThreePhaseBusBackplate',1.33,1.57,-.82,4.72,1.07,.08,'acrylic')
for j,(yy,col) in enumerate([(1.88,'red'),(1.57,'amber'),(1.26,'electric')]):
 beam('ACConductor'+str(j),(-.94,yy,-.64),(3.57,yy,-.64),.065,col,18)
 for k in range(6):b('Insulator'+str(j)+'_'+str(k),-.85+k*.83,yy-.12,-.78,.12,.25,.15,'white')
for k in range(4):b('BusSupport'+str(k),-.96+k*1.50,1.57,-.76,.09,1.20,.18,'titanium')
# 07 generator hero
c.start(7)
b('GeneratorSkid',3.18,.55,-1.96,2.72,.33,1.25,'carbon')
for xx in [2.2,4.11]:
 for z in [-2.42,-1.52]:b('EngineMount',xx,.77,z,.21,.24,.22,'silver_dark')
cyl('AlternatorStator',(3.78,1.30,-1.95),.46,1.16,'x','electric',48)
for j in range(14):b('AlternatorCoolingFin',3.28+j*.078,1.76,-1.95,.043,.10,.78,'silver')
cyl('AlternatorRotor',(3.78,1.30,-1.95),.18,1.41,'x','chrome',32,'ANIM_GENERATOR_ROTOR')
cyl('GeneratorEngineBlock',(2.42,1.32,-1.95),.39,1.32,'x','blue_steel',40)
for j in range(4):cyl('EngineCylinderHead',(2.08+j*.23,1.76,-1.95),.11,.28,'y','silver_dark',16)
cyl('Coupling',(3.06,1.30,-1.95),.28,.28,'x','amber',28,'ANIM_GENERATOR_ROTOR')
for j in range(6):beam('GeneratorGrille'+str(j),(4.26,1.10+j*.073,-2.20),(4.26,1.10+j*.073,-1.70),.018,'silver_dark',8)
c.current.pivot('ANIM_GENERATOR_ROTOR',(3.78,1.30,-1.95))
# 08 starter
c.start(8);enclosure('StarterController',2.13,.89,-.76,.80,.65,.70,'amber','STARTER',3)
cyl('StarterGear',(2.16,1.36,-1.12),.14,.24,'x','chrome',22,'ANIM_STARTER_PINION')
c.current.pivot('ANIM_STARTER_PINION',(2.16,1.36,-1.12))
# 09 sync relay
c.start(9);enclosure('GenSyncRelay',4.30,1.50,-.72,1.13,.84,.58,'amber','SYNC RELAY',3)
display('PhaseComparator',4.30,1.56,-.402,.64,.25)
# 10 Main grid breaker
breaker(10,-.50,.72,'MAIN GRID CB','red')
# 11 Generator breaker
breaker(11,3.86,.72,'GEN CB','amber')
# 12-16 five load breakers in front rail
for i,xx,name,clr in [(12,-3.72,'ESSENTIAL A','green'),(13,-2.28,'ESSENTIAL B','green'),(14,-.84,'ESSENTIAL C','green'),(15,.60,'NONESSENTIAL A','red'),(16,2.04,'NONESSENTIAL B','red')]:breaker(i,xx,1.42,name,clr)
# 17 emergency lamp load
load(17,-3.68,2.11,'EMERGENCY LIGHTS','light')
# 18 critical cooling
load(18,-.82,2.11,'CRITICAL COOL','cool')
# 19 industrial motor
load(19,.62,2.10,'INDUSTRIAL MOTOR','motor')
# 20 sensor hub
c.start(20);enclosure('GridSensing',-1.25,.88,-1.42,.93,.72,.64,'cyan','GRID SENSOR',4)
display('FreqLCD',-1.25,.94,-1.076,.47,.23)
# 21 power meter
c.start(21);enclosure('EnergyMeter',1.04,1.73,-1.43,1.05,.66,.60,'cyan','POWER METER',4)
display('EnergyReading',1.04,1.81,-1.099,.63,.22)
# 22 restoration sequencer
c.start(22);enclosure('RestorationController',-4.44,.91,1.89,1.20,.76,.73,'cyan','SEQUENCER',5)
for j in range(6):led('ObjectiveIndicator'+str(j),(-4.88+j*.175,1.27,2.30),'green' if j==0 else 'amber',.025,'z')
# 23 large holographic monitor
c.start(23)
b('DisplayPedestal',4.22,1.15,.44,.21,1.33,.26,'silver_dark')
b('DisplayFoot',4.22,.45,.44,1.25,.12,.76,'titanium')
b('DisplayFrame',4.22,2.43,.36,2.53,1.73,.22,'blue_steel')
b('DisplayScreen',4.22,2.43,.50,2.32,1.53,.027,'display','ANIM_MONITOR_TILT')
for j in range(5):
 xx=3.36+j*.43
 b('RestoreLoadStatus'+str(j),xx,2.65,.523,.30,.21,.022,'green' if j<3 else 'red','ANIM_MONITOR_TILT')
for j in range(14):
 xx=3.16+j*.16
 beam('MonitorGraph'+str(j),(xx,2.03,.531),(xx,2.07+.14*math.sin(j*.7),.531),.008,'cyan',8,'ANIM_MONITOR_TILT')
txt('MonitorTitle','RESTORATION STATUS',3.09,3.02,.530,2.18,.082)
c.current.pivot('ANIM_MONITOR_TILT',(4.22,2.43,.36))
# 24 safety enclosure around generator
c.start(24)
for xx in [1.58,4.82]:
 for zz in [-2.68,-1.14]:beam('GeneratorGuardUpright',(xx,.45,zz),(xx,2.64,zz),.032,'acrylic_rim',10)
for yy in [.45,2.64]:
 for zz in [-2.68,-1.14]:beam('GeneratorGuardHorizontal',(1.58,yy,zz),(4.82,yy,zz),.032,'acrylic_rim',10)
 for xx in [1.58,4.82]:beam('GeneratorGuardDepth',(xx,yy,-2.68),(xx,yy,-1.14),.028,'acrylic_rim',10)
b('GeneratorGuardDoor',3.20,1.54,-1.12,3.20,2.16,.014,'acrylic','ANIM_SAFETY_DOOR')
c.current.pivot('ANIM_SAFETY_DOOR',(1.58,2.64,-1.12))
led('DoorInterlock',(1.64,2.50,-1.09),'green',.037,'z')
# 25 5v supply
c.start(25);enclosure('Supply5V',-4.38,.79,-.18,1.25,.80,.77,'cyan','5V CONTROL',2)
display('SupplyVoltage',-4.38,.84,.236,.62,.23)
txt('SupplyReading','5.00 V',-4.65,.86,.267,.59,.08,'mint')

manifest={'level_id':'level_59','display_name':'Bring Back the Power','asset_kind':'procedural 3D art only, no gameplay','individual_models':26,'planned_player_wires':42,'planned_unique_sockets':66,'real_terminals_included':False,'physics_included':False,'coordinate_system':'X bench width, Y up, Z front; 1 length unit = 1 Unity unit at scale 1','models':[]}
for i,asset in enumerate(c.assets):
 name=f'{i:02d}_{asset.name}';p=ROOT/'Models'/f'{name}.fbx';g=ROOT/'GLB'/f'{name}.glb'
 c.fbx_export([asset],p,asset.name);c.glb_export(asset,g)
 face_count=sum(len(x.mesh.faces) for x in asset.parts)
 manifest['models'].append({'file':p.name,'glb':g.name,'name':asset.name,'triangle_count':face_count,'mesh_parts':len(asset.parts),'animation_pivots':{k:v.tolist() for k,v in asset.groups.items()}})
 print('export',name,face_count,flush=True)
c.fbx_export(c.assets,ROOT/'Models'/'Level59_Complete_ArtKit_Showcase.fbx','showcase')
scene=trimesh.Scene()
for asset in c.assets:
 for part in asset.parts:
  m=part.mesh.copy();m.visual.vertex_colors=np.tile((np.array(c.C[part.mat])*255).astype('uint8'),(len(m.vertices),1));scene.add_geometry(m,geom_name=asset.name+'__'+part.name)
(ROOT/'GLB'/'Level59_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
manifest['triangle_count']=sum(m['triangle_count'] for m in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with open(ROOT/'Animation_Rigs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['model','pivot','x','y','z']);
 for a in c.assets:
  for k,v in a.groups.items():w.writerow([a.name,k,*v.tolist()])
print('EXPORTED ASSETS',len(c.assets),'TRIANGLES',manifest['triangle_count'],flush=True)
