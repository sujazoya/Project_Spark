PROJECT SPARK — LEVEL 59 / BRING BACK THE POWER
PROCEDURAL 3D ART COLLECTION — NOT A PLAYABLE LEVEL

CONTENTS
Models/: 26 individual FBX 7.4 binary files + 1 showcase FBX
GLB/: 26 individually colored GLB backup models + 1 showcase GLB
Previews/: assembled hero and 26-model contact sheet
Animation_Rigs.csv: pivot names and source coordinates
Model_Manifest.json: per-model names and triangle counts
Unity_Optional/SparkLevel59ArtPlacementEditor.cs: art-only editor placement
Source/: procedural generator and preview renderer

UNITY INSTALLATION
1. Unpack and copy all Models/*.fbx to Assets/ProjectSpark/Level59/Art.
2. Inspect importer scale and orientation; art uses X across bench, Y up, Z toward player, units in meters.
3. Copy Unity_Optional/SparkLevel59ArtPlacementEditor.cs into an Editor folder.
4. Select your existing Level 59 layout object in the Unity Hierarchy.
5. Use Tools > Project Spark > Levels > 59 > Place HD Art Under Selected Layout.
6. All 26 models use the same world-space art origin; do not individually reposition them or double-instantiate the showcase.
7. Animation pivots: generator rotor, starter pinion, main/grid and load breaker handles, critical cooling fan, industrial motor, display tilt, safety door. Verify pivot hierarchy after import.

SCOPE AND CAVEATS
This archive provides actual 3D geometry, modeled surface details, color material regions and named pivots.
It does NOT provide real SparkTerminals, 42 wire endpoint IDs, 66 gameplay terminal anchors, DC/AC solver behavior, black-start controller, sensor interfaces, load-restoration logic, six authoritative objectives, or a playable Unity scene.
Previews are offline renders of meshes. Shader materials may require manual URP/HDRP conversion.
The original concept art is a visual target, not a guarantee of identical art quality. No authored 2K/4K PBR texture set is supplied.
Unity import, compilation and Play Mode have NOT been run in the actual user's project.
