PROJECT SPARK — LEVEL 49: CUT ON THE MARK
AAA-STYLE ART PACK / UNITY IMPORT AND SCENE SETUP
=====================================================

WHAT THIS PACK CONTAINS
- 13 separately modeled Autodesk FBX 7.4 binary assets and 13 matching GLB backups.
- 1 assembled FBX/GLB showcase pair for reference placement.
- 13 individual model previews, complete kit preview, contact sheet.
- Optional SparkLevel49VisualRig.cs visual adapter.
- Terminal_Anchors.csv, World_Terminal_Anchors.csv, Exact_Wiring.csv.
- Animation_Rigs.csv, Model_Manifest.json and procedural generator sources.

THIS IS A VISUAL MODEL PACK, NOT A PLAYABLE LEVEL
The electronic sockets are mesh representations only. Add real SparkTerminal
components on your actual game board, supply real electrical/signal components,
and integrate the Level 49 safety, encoder and flying-shear objectives separately.
No changes are made to SparkElectricalSolver, LevelGamePlayManager or LevelEvaluator.

UNITY IMPORT
1. Extract ZIP, copy Models/*.fbx into Assets/My_Assets/_Project_Spark/Models/Level_49/.
2. Select imported FBX files. Keep their transform groups. Import Materials as desired;
   the FBX contains per-part material colors and GLBs serve as material references.
3. Place individual model FBXs under Level_49_Layout. The Showcase FBX is for
   preview only; do not duplicate it with the individual FBX instances.
4. Use Model_Manifest.json show-case placements as a starting guide. Model units
   are relative art units, Y up, front/socket face is negative Z. You may scale the
   whole Level_49_Layout parent to fit your actual Project Spark breadboard.
5. Set real SparkTerminal components at your actual available breadboard holes,
   aligned with art sockets as listed in Terminal_Anchors.csv. Art socket meshes
   themselves do not create electrical connections.
6. Wire up fixed electric systems, runtime IDs, and the actual signal interfaces
   using the existing Project Spark architecture. Never invent voltage stamps.
7. Install optional Unity_Optional/SparkLevel49VisualRig.cs. Assign named group
   transforms from Animation_Rigs.csv. The script only animates art from supplied
   runtime readings; it never supplies encoder counts, manipulates voltage,
   activates the motor, bypasses interlock logic or awards objectives.
8. Set blank controller and monitor faces to receive real TextMeshPro runtime UI.
   0.20 X/Y TMP label scale may be a starting point but must be fitted in scene.

PREVIEW ASSEMBLY VISUAL REGIONS
- Rear: quality monitor, registration optical eye.
- Midline: moving marked transport web, measuring encoder roller, dual linear
  shear rail, sliding carriage, cutter actuator, transparent safety enclosure.
- Right/rear: carriage motor and drive coupling.
- Front: 5 V supply, registration controller, carriage motor driver.

MECHANICAL ANIMATION GROUPS
- CARRIAGE_SLIDE_X: translate along rail X; pivot follows carriage model.
- CUTTER_VERTICAL_STROKE_Y: press down then return up, guarded training tool.
- CARR_MOTOR_SHAFT_ROTATE_X: shaft/pulley rotation.
- LEAD_SCREW_ROTATE_X: rotating threaded drive shaft.
- WEB_MEASURING_ROLLER_ROTATE_Z / ENCODER_DISC_ROTATE_Z: follow observed web travel.
- GUARD_DOOR_OPEN_PIVOT: rotate around the hinge Y axis.
- SCANNER_BEAM_ENABLE, visual indicator lights, runtime screen faces.

HIERARCHY SUGGESTION
Level_49_Layout
  L49_IndustrialFrame (FBX)
  L49_WebTransport (FBX)
  L49_EncoderRoller (FBX)
  L49_OpticalMarkSensor (FBX)
  L49_LinearRail (FBX)
  L49_FlyingCarriage (FBX, moving)
  L49_CarriageMotor (FBX)
  L49_CutterHead (FBX, must follow carriage motion in gameplay hierarchy)
  L49_MotorDriver (FBX)
  L49_RegistrationController (FBX)
  L49_SafetyGuard (FBX)
  L49_QualityMonitor (FBX)
  L49_5VSupply (FBX)
  SparkLevel49VisualRig (optional visual helper)
  [real SparkTerminal and existing scene bindings; not provided by this pack]

IMPORTANT HIERARCHY NOTE
The assembled showcase deliberately keeps each FBX instance independent.
For actual flying-shear animation, parent the cutter's visual to the same moving
carriage controller, or drive BOTH the cutter root and carriage group with the
same authoritative position. SparkLevel49VisualRig itself moves the carriage
model group, not the separate cutter FBX root. Do not leave the cutter stationary.

EXACT PLAYER WIRING (15 wires; 26 unique art socket IDs)
W01 SUPPLY_PLUS -> CTRL_PLUS
W02 SUPPLY_RETURN -> CTRL_GND
W03 SUPPLY_PLUS -> OPTICAL_PLUS
W04 SUPPLY_RETURN -> OPTICAL_GND
W05 ENCODER_A -> CTRL_ENC_A
W06 ENCODER_B -> CTRL_ENC_B
W07 OPTICAL_SIGNAL -> CTRL_MARK_IN
W08 CTRL_CARR_PWM -> DRIVER_PWM
W09 DRIVER_MOTOR_PLUS -> CARRIAGE_MOTOR_PLUS
W10 DRIVER_MOTOR_MINUS -> CARRIAGE_MOTOR_MINUS
W11 CTRL_CUT_TRIG -> CUTTER_TRIG
W12 SUPPLY_PLUS -> DRIVER_PLUS
W13 SUPPLY_RETURN -> DRIVER_GND
W14 GUARD_NC_OUT -> CTRL_GUARD_IN
W15 HOME_OUT -> CTRL_HOME_IN

SUPPLY_PLUS and SUPPLY_RETURN are each shared by three player wires.
The terminal named GUARD_NC_OUT is not a complete NC switch by itself: the
actual guard contact must have a real signal source and must fail safe on
cable cut, de-energization or missing feedback. Never rely on this art to
provide mechanical safety. HOME_OUT similarly requires a real sensor and a
valid signal source. The 5 V supply and controlled PWM wiring may need
additional preinstalled circuitry according to the existing Project Spark APIs.

VISUAL-ONLY LIMITATIONS
- No electrically functional components / SparkTerminal MonoBehaviours included.
- No cut or drive gameplay controller, no safe-stopping guarantee, no 6/6 scoring.
- No rigged cloth, live TMPro text, baked Unity shaders, imported prefab or
  collision/navmesh setup.
- FBX binary structure was checked and GLBs loaded as meshes. Unity Editor import
  and play mode are not executed in this export environment.

INSPECTION
See 13 previews in Previews/, the contact sheet and the full assembly PNG.
Source generation code lives under Sources/ for art iteration.
