"""Project Spark L49 CUT ON THE MARK — precision flying shear AAA-style procedural art.
13 FBX 7.4 binary Unity assets, 13 GLBs, and complete assembly. Y up, front -Z.
Visual-only models; electrical simulation and safety logic remain external to art.
"""
from __future__ import annotations
import math, csv, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model,PALETTE,export_fbx,export_glb
ROOT=Path(__file__).resolve().parents[1]; MODELS=ROOT/'Models'
PALETTE.update({
 'ice':(221,241,253,255), 'nickel':(135,166,183,255), 'pewter':(106,129,151,255),
 'aluminum':(161,185,199,255),'polished':(192,215,230,255),
 'coal':(10,20,33,255),'carbon':(19,32,46,255), 'darksteel':(33,53,69,255),
 'aqua':(48,232,239,255),'mint':(50,246,192,255),'neonblue':(39,165,252,255),
 'scarlet':(247,65,83,255),'safety':(255,183,65,255), 'amberlit':(255,193,78,255),
 'orangebody':(220,123,40,255),'webwhite':(224,232,231,250),'ink':(33,111,137,255),
 'scan':(59,245,237,95),'glassblue':(113,206,235,74),'glassedge':(104,218,245,255),
 'screenback':(13,46,61,255),'rubberblue':(29,50,61,255), 'actuator':(87,113,134,255),
 'yellow':(249,224,73,255),'pale':(168,213,228,255),'bronze':(173,111,55,255),
 'tealshade':(25,116,133,255)
})

def text(m,key,content,x,y,z,size=.16,mat='ice',width=None,group='Static'):
 m.text(key,content,size,x,y,z,mat,maxwidth=width,group=group)

def bolt(m,key,x,y,z,r=.068):
 m.cyl(key+'_ChromedHead',r,.024,(x,y,z),'chrome','y',14)
 m.box(key+'_DriverSlot',(.077,.008,.012),(x,y+.018,z),'carbon')

def led(m,key,x,y,z,col='mint',group=None):
 group=group or key+'_LED'
 m.cyl(key+'_Rim',.130,.051,(x,y,z),'polished','z',30,group=group)
 m.cyl(key+'_Lens',.092,.051,(x,y,z-.054),col,'z',26,group=group)
 m.torus(key+'_EmissiveRing',.128,.018,(x,y,z-.067),col,'z',32,6,group=group)
 m.group_pivots[group]=(x,y,z)

def jack(m,t,sid,label,x,y,z,col='aqua',size=.105):
 # All 26 are visual socket art only. SparkTerminal must be attached separately in Unity.
 group='SOCKET_'+sid
 m.cyl(t+'_'+sid+'_ChromeBezel',.165,.068,(x,y,z),'chrome','z',28,group=group)
 m.cyl(t+'_'+sid+'_ColoredInsulator',.134,.070,(x,y,z-.030),col,'z',28,group=group)
 m.cyl(t+'_'+sid+'_SocketRecess',.091,.072,(x,y,z-.085),'void','z',28,group=group)
 m.cyl(t+'_'+sid+'_GoldTip',.028,.035,(x,y,z-.141),'gold','z',12,group=group)
 m.torus(t+'_'+sid+'_LEDBezel',.158,.014,(x,y,z-.10),col,'z',30,6,group=group)
 text(m,t+'_'+sid+'_Caption',label,x,y+.228,z-.145,size,'ice',.9)
 assert sid not in m.anchors
 m.anchors[sid]=[round(float(x),5),round(float(y),5),round(float(z-.169),5)]

def labelplate(m,t,title,w=4.3,d=2.5,h=1.68,accent='aqua',sub=''):
 m.base(t,w,d,h)
 face=-d/2-.091
 m.box(t+'_HeaderBlack',(w-.31,.32,.043),(0,.32+h*.79,face-.026),'coal')
 text(m,t+'_HeaderText',title,0,.32+h*.79,face-.058,.224,'ice',w-.41)
 if sub:text(m,t+'_Subtitle',sub,0,.32+h*.61,face-.057,.109,accent,w-.35)
 m.box(t+'_StatusStrip',(w-.58,.035,.039),(0,.32+h+.095,-d/2+.20),accent)
 for x in (-w/2+.20,w/2-.20):
  for z in (-d/2+.22,d/2-.22):bolt(m,t+f'_TopBolt_{x:.2f}_{z:.2f}',x,.32+h+.098,z,.045)
 return face


def make_frame():
 m=Model('00_L49_IndustrialFrame');t='L49_FRAME'
 m.bevel(t+'_RubberChassisIsolator',(35.4,.19,24.4),(0,.10,0),'rubber',.20)
 m.bevel(t+'_CNC_MachinedFoundation',(35.0,.45,24.1),(0,.34,0),'graphite',.20)
 m.box(t+'_SteelBedInsert',(29.2,.09,12.9),(0,.585,.15),'darksteel')
 for x in (-16.85,16.85):
  m.box(t+f'_ExtrudedEdgeRail_{x}',(.24,.50,22.6),(x,.64,0),'nickel')
  m.box(t+f'_CyanEdgeTrace_{x}',(.055,.038,21.9),(x,.918,0),'aqua')
  for z in np.linspace(-10.7,10.7,12):bolt(m,t+f'_FrameRivet_{x:.1f}_{z:.2f}',x,.920,float(z),.045)
 for z in (-11.1,11.1):
  m.box(t+f'_Crossbeam_{z}',(33.7,.24,.23),(0,.69,z),'nickel')
  m.box(t+f'_EmissiveRail_{z}',(32.9,.024,.034),(0,.827,z),'safety' if z>0 else 'aqua')
 # Sightline on front edge: perforations for breadboard visual, not actual electronics
 for row,z in enumerate((-9.7,-9.25,-8.8)):
  for i,x in enumerate(np.linspace(-15.8,15.8,54)):
   m.cyl(t+f'_Hole_{row:01d}_{i:02d}',.027,.012,(float(x),.569,z),'void','y',8)
 for x in (-16.1,16.1):
  for z in (-10.8,10.8):m.bevel(t+f'_Foot_{x:+.1f}_{z:+.1f}',(1.4,.24,1.1),(x,.10,z),'rubber',.10)
 text(m,t+'_Etch','CUT ON THE MARK  /  LEVEL 49',0,.96,-11.39,.22,'ice',13)
 return m


def make_web():
 m=Model('01_L49_WebTransport');t='L49_WEB';g='WEB_ADVANCE_X'
 m.bevel(t+'_ConveyorChassis',(28.5,.67,4.65),(0,.94,0),'carbon',.23)
 m.box(t+'_ContactBed',(27.8,.076,3.82),(0,1.33,0),'nickel')
 m.box(t+'_ContinuousPrintedMaterial',(27.4,.050,2.9),(0,1.41,0),'webwhite',group=g)
 m.group_pivots[g]=(0,1.41,0)
 for i,x in enumerate(np.linspace(-13.0,13.0,17)):
  m.box(t+f'_RegistrationBar_{i:02d}',(.10,.014,1.3),(float(x),1.449,-.25),'ink',group=g)
  if i%2==0:
   m.box(t+f'_ProductStrip_{i:02d}',(.77,.016,.84),(float(x+.64),1.454,.46),'white',group=g)
   m.box(t+f'_QualityStripe_{i:02d}',(.72,.018,.07),(float(x+.64),1.469,.12),'aqua',group=g)
 for i,x in enumerate(np.linspace(-13.3,13.3,16)):
  m.cyl(t+f'_UnderwebIdler_{i:02d}',.175,3.65,(float(x),1.02,0),'steel','z',24,group='WEB_IDLERS_ROTATE_Z')
 for z in (-2.26,2.26):
  m.box(t+f'_SideGuardRail_{z}',(28.1,.22,.16),(0,1.45,z),'chrome')
  m.box(t+f'_RailUnderlight_{z}',(27.6,.04,.035),(0,1.31,z),'aqua')
  for x in (-13,0,13):m.box(t+f'_RailMount_{x}_{z}',(.26,.49,.30),(x,.88,z),'steel')
 m.box(t+'_MaterialEntryRamp',(.62,.11,4.3),(-14.1,1.36,0),'polished')
 m.box(t+'_MaterialExitRamp',(.62,.11,4.3),(14.1,1.36,0),'polished')
 return m


def make_encoder_roller():
 m=Model('02_L49_EncoderRoller');t='L49_ENC';g='WEB_MEASURING_ROLLER_ROTATE_Z'
 m.cyl(t+'_NitrileSurface',.70,3.90,(0,1.45,0),'rubberblue','z',64,group=g)
 for z in np.linspace(-1.8,1.8,14):
  m.torus(t+f'_DiamondGrip_{z:+.2f}',.691,.014,(0,1.45,float(z)),'nickel','z',48,6,group=g)
 m.cyl(t+'_ChromedCentralShaft',.15,5.3,(0,1.45,0),'chrome','z',30,group=g)
 for z in (-2.12,2.12):
  m.cyl(t+f'_EndBearing_{z:+.1f}',.86,.27,(0,1.45,z),'polished','z',40)
  m.box(t+f'_BearingPedestal_{z:+.1f}',(1.36,.59,.49),(0,.75,z),'darksteel')
 m.group_pivots[g]=(0,1.45,0)
 gd='ENCODER_DISC_ROTATE_Z'
 m.cyl(t+'_OpticalEncoderDisc',.95,.093,(0,1.45,-2.51),'darksteel','z',64,group=gd)
 m.torus(t+'_EncoderDiscChromeBezel',.88,.028,(0,1.45,-2.572),'chrome','z',64,6,group=gd)
 m.torus(t+'_SignalRing',.76,.020,(0,1.45,-2.574),'aqua','z',64,6,group=gd)
 for i in range(80):
  a=math.tau*i/80
  m.cyl(t+f'_EncoderMark_{i:02d}',.014,.02,(.804*math.cos(a),1.45+.804*math.sin(a),-2.583),'ice' if i%4==0 else 'aqua','z',8,group=gd)
 m.cyl(t+'_DiscHub',.17,.10,(0,1.45,-2.61),'chrome','z',24,group=gd)
 m.group_pivots[gd]=(0,1.45,-2.51)
 m.box(t+'_OptoReadHead',(1.67,.39,.31),(0,2.52,-2.68),'nickel')
 led(m,t+'_AChannelLamp',-.32,2.49,-2.89,'aqua')
 led(m,t+'_BChannelLamp',.32,2.49,-2.89,'mint')
 m.bevel(t+'_SocketDock',(2.95,.84,.68),(0,.66,-3.32),'carbon',.09)
 jack(m,t,'ENCODER_A','A',-.62,.70,-3.72,'aqua')
 jack(m,t,'ENCODER_B','B',.62,.70,-3.72,'mint')
 return m


def make_optical_eye():
 m=Model('03_L49_OpticalMarkSensor');t='L49_OPTICAL_EYE'
 z=labelplate(m,t,'OPTICAL MARK EYE',4.23,2.55,1.75,'aqua','REGISTER / CYAN SCAN')
 for x in (-1.42,1.42):
  m.bevel(t+f'_OpticalTower_{x:+.1f}',(.36,2.2,.43),(x,2.63,.24),'nickel',.06)
 m.bevel(t+'_LaserCrossbar',(3.2,.39,.58),(0,3.71,.24),'polished',.10)
 m.cyl(t+'_LensBarrel',.43,.26,(0,3.46,.24),'chrome','y',36)
 m.cyl(t+'_SensorLens',.26,.065,(0,3.27,.24),'aqua','y',32)
 m.torus(t+'_EmissionRing',.30,.024,(0,3.22,.24),'mint','y',40,7)
 m.cyl(t+'_RealBeamReference',.025,1.15,(0,2.64,.24),'scan','y',12,group='SCANNER_BEAM_ENABLE')
 m.group_pivots['SCANNER_BEAM_ENABLE']=(0,3.22,.24)
 m.box(t+'_SensorResultDisplay',(2.5,.36,.047),(0,1.50,z-.13),'screenback')
 text(m,t+'_SensorReady','MARK SENSOR',0,1.50,z-.18,.16,'mint',2.2)
 led(m,t+'_DetectIndicator',1.62,1.50,z-.05,'mint')
 for sid,label,x,color in [('OPTICAL_PLUS','+5V',-1.26,'red'),('OPTICAL_GND','GND',0,'void'),('OPTICAL_SIGNAL','SIG',1.26,'mint')]:
  jack(m,t,sid,label,x,.70,z,color)
 return m


def make_linear_rail():
 m=Model('04_L49_LinearRail');t='L49_RAIL'
 m.bevel(t+'_PrecisionGroundRailBed',(11.6,.47,5.1),(0,.39,0),'darksteel',.15)
 for z in (-1.65,1.65):
  m.box(t+f'_FullLengthRunner_{z:+.2f}',(10.8,.30,.34),(0,.84,z),'nickel')
  m.box(t+f'_ShiningRailTop_{z:+.2f}',(10.66,.072,.24),(0,1.03,z),'chrome')
  for x in np.linspace(-4.95,4.95,10):
   bolt(m,t+f'_RunnerFastener_{x:+.1f}_{z:+.1f}',float(x),1.07,z,.041)
 for x in (-5.40,5.40):
  m.bevel(t+f'_EndStopHousing_{x:+.2f}',(.43,1.3,4.3),(x,1.12,0),'graphite',.08)
  m.box(t+f'_EndStopShockPad_{x:+.2f}',(.075,.65,3.4),(x+(-.07 if x>0 else .07),1.20,0),'rubber')
 m.cyl(t+'_LeadScrew_Core',.125,10.9,(0,.87,0),'chrome','x',24,group='LEAD_SCREW_ROTATE_X')
 for i,x in enumerate(np.linspace(-5.2,5.2,55)):
  m.torus(t+f'_LeadScrewThread_{i:02d}',.134,.018,(float(x),.87,0),'steel','x',16,5,group='LEAD_SCREW_ROTATE_X')
 m.group_pivots['LEAD_SCREW_ROTATE_X']=(0,.87,0)
 # Segmented articulated black cable drag chain, fixed graphical reference.
 for k,x in enumerate(np.linspace(-4.8,4.8,31)):
  m.bevel(t+f'_DragChainLink_{k:02d}',(.25,.24,.36),(float(x),1.10,2.22),'coal',.035)
  if k%3==0:
   m.box(t+f'_DragChainOrangeCatch_{k:02d}',(.08,.027,.34),(float(x),1.24,2.22),'safety')
 # End-mounted normally-open home sensor: source of HOME OUT to controller.
 m.bevel(t+'_HOME_OpticalSensorBlock',(.84,.64,1.0),(-4.9,1.14,-1.15),'carbon',.08)
 led(m,t+'_HOME_SignalLens',-4.95,1.34,-1.73,'mint')
 m.bevel(t+'_HomePort',(1.7,.69,.64),(-3.1,.58,-2.55),'carbon',.07)
 jack(m,t,'HOME_OUT','HOME OUT',-3.10,.62,-2.94,'mint')
 text(m,t+'_Label','LINEAR HOME RAIL',0,1.11,-2.62,.16,'ice',3.1)
 return m


def make_carriage():
 m=Model('05_L49_FlyingCarriage');t='L49_CARRIAGE';g='CARRIAGE_SLIDE_X'
 m.bevel(t+'_MovingBillet',(3.0,.48,4.48),(0,1.48,0),'nickel',.15,group=g)
 m.bevel(t+'_CarbonTop',(2.69,.17,4.17),(0,1.84,0),'carbon',.07,group=g)
 for z in (-1.66,1.66):
  for x in (-.88,.88):
   m.box(t+f'_LinearBearing_{x:+.2f}_{z:+.2f}',(.53,.31,.62),(x,1.18,z),'polished',group=g)
 for z in (-1.45,1.45):
  m.box(t+f'_SideArmor_{z:+.1f}',(2.68,.30,.21),(0,1.84,z),'darksteel',group=g)
  m.box(t+f'_CyanGuideLine_{z:+.1f}',(2.40,.04,.043),(0,2.01,z),'aqua',group=g)
 for x in (-.83,.83):
  m.cyl(t+f'_BridgePillar_{x:+.1f}',.16,.48,(x,2.05,0),'chrome','y',24,group=g)
 m.bevel(t+'_ToolMount',(2.25,.35,1.55),(0,2.31,0),'graphite',.07,group=g)
 m.box(t+'_SafetyStripe',(2.08,.045,.09),(0,2.515,-.51),'safety',group=g)
 m.cyl(t+'_MovingCableCoupler',.26,.26,(1.42,2.35,0),'bronze','x',24,group=g)
 text(m,t+'_MovingName','SYNC CARRIAGE',0,1.75,-2.265,.15,'ice',2.15,group=g)
 m.group_pivots[g]=(0,1.5,0)
 return m


def make_carriage_motor():
 m=Model('06_L49_CarriageMotor');t='L49_CARR_MOTOR';g='CARR_MOTOR_SHAFT_ROTATE_X'
 m.bevel(t+'_VibrationBase',(3.48,.32,3.6),(0,.29,0),'graphite',.12)
 for x in (-1.42,1.42):
  for z in (-1.43,1.43):bolt(m,t+f'_BaseFastener_{x:+.1f}_{z:+.1f}',x,.49,z)
 m.cyl(t+'_ServoBody',.88,2.82,(0,1.45,.1),'nickel','x',64)
 m.cyl(t+'_RearMotorEndbell',.91,.35,(1.54,1.45,.1),'carbon','x',40)
 m.torus(t+'_RearBacklight',.78,.043,(1.76,1.45,.1),'aqua','x',40,8)
 m.cyl(t+'_FrontMachinedBell',.96,.24,(-1.55,1.45,.1),'chrome','x',48)
 for i in range(16):
  a=math.tau*i/16
  y=1.45+.86*math.cos(a);z=.10+.86*math.sin(a)
  m.rod(t+f'_CoolingFin_{i:02d}',(-1.25,y,z),(1.25,y,z),.034,'steel',12)
 m.cyl(t+'_DriveShaft',.19,1.68,(-2.20,1.45,.1),'polished','x',28,group=g)
 m.cyl(t+'_RotatingCoupling',.45,.32,(-2.7,1.45,.1),'bronze','x',32,group=g)
 for i in range(18):
  a=math.tau*i/18
  m.cyl(t+f'_CouplingTooth_{i:02d}',.045,.28,(-2.7,1.45+.41*math.cos(a),.1+.41*math.sin(a)),'chrome','x',10,group=g)
 m.group_pivots[g]=(-2.2,1.45,.1)
 m.bevel(t+'_MotorElectricalDock',(3.0,.70,.62),(0,.73,-2.09),'carbon',.08)
 jack(m,t,'CARRIAGE_MOTOR_PLUS','MOTOR +',-.70,.70,-2.46,'red')
 jack(m,t,'CARRIAGE_MOTOR_MINUS','MOTOR -',.70,.70,-2.46,'void')
 text(m,t+'_MotorTitle','CARRIAGE DRIVE',0,1.38,-.89,.17,'ice',2.6)
 return m


def make_cutter():
 m=Model('07_L49_CutterHead');t='L49_CUTTER';g='CUTTER_VERTICAL_STROKE_Y'
 m.bevel(t+'_Toolplate',(3.20,.34,3.07),(0,.40,.13),'graphite',.11)
 for x in (-1.26,1.26):
  m.cyl(t+f'_GuideRod_{x:+.1f}',.12,2.55,(x,2.05,.1),'chrome','y',26)
  m.cyl(t+f'_GuideBushing_{x:+.1f}',.20,.30,(x,3.26,.1),'polished','y',30)
 m.bevel(t+'_ServoCasing',(3.18,.74,2.43),(0,3.34,.12),'nickel',.13)
 m.box(t+'_AmberWarningLip',(2.95,.07,.14),(0,3.73,-.69),'safety')
 m.cyl(t+'_VerticalActuator',.21,1.59,(0,2.45,.12),'chrome','y',28,group=g)
 m.bevel(t+'_MovingCutSlide',(2.55,.28,1.42),(0,1.67,.12),'polished',.06,group=g)
 m.bevel(t+'_CutterBladeCartridge',(2.25,.34,.58),(0,1.32,.12),'orangebody',.035,group=g)
 m.box(t+'_NON_SHARP_TrainingEdge',(2.11,.055,.085),(0,1.115,-.12),'safety',group=g)
 m.box(t+'_SoftContactPad',(2.04,.066,.25),(0,1.068,.13),'rubber',group=g)
 m.group_pivots[g]=(0,2.2,.12)
 for x in (-1.47,1.47):
  m.box(t+f'_CautionAccent_{x:+.1f}',(.10,.06,1.02),(x,.82,-1.12),'amberlit')
 led(m,t+'_HeadReady',-.96,3.26,-1.21,'mint')
 led(m,t+'_HeadBusy',.96,3.26,-1.21,'safety')
 m.bevel(t+'_CutTriggerDock',(2.25,.68,.66),(0,.68,-1.91),'carbon',.06)
 jack(m,t,'CUTTER_TRIG','CUT TRIG',0,.70,-2.31,'amberlit')
 text(m,t+'_Title','TRAINING SHEAR',0,3.37,-1.15,.155,'ice',2.54)
 return m


def make_driver():
 m=Model('08_L49_MotorDriver');t='L49_DRIVER'
 z=labelplate(m,t,'FLYING SHEAR DRIVER',6.05,3.08,1.80,'safety','PWM / H BRIDGE')
 for x in np.linspace(-2.25,2.25,11):m.box(t+f'_AluminumHeatFin_{x:+.2f}',(.105,.83,1.10),(float(x),2.45,.48),'nickel')
 m.box(t+'_PowerElectronics',(2.14,.14,.75),(0,1.95,-.35),'coal')
 for x in (-.63,.63):
  m.cyl(t+f'_CopperPowerBus_{x:+.2f}',.076,.81,(x,2.04,.52),'copper','z',16)
 led(m,t+'_PowerOnLamp',-2.48,1.56,z-.06,'green')
 led(m,t+'_OvercurrentLamp',2.48,1.56,z-.06,'scarlet')
 ports=[('DRIVER_PLUS','+5V',-2.13,'red'),('DRIVER_GND','GND',-1.05,'void'),('DRIVER_PWM','PWM',0,'safety'),('DRIVER_MOTOR_PLUS','M+',1.05,'red'),('DRIVER_MOTOR_MINUS','M-',2.13,'void')]
 for sid,label,x,color in ports:jack(m,t,sid,label,x,.69,z,color)
 return m


def make_controller():
 m=Model('09_L49_RegistrationController');t='L49_CTRL'
 z=labelplate(m,t,'FLYING SHEAR CTRL',10.25,3.3,2.05,'aqua','SYNC / HOME / MARK / INTERLOCK')
 m.bevel(t+'_MonitorChromeFrame',(4.85,1.05,.07),(0,1.65,z-.069),'polished',.04)
 m.box(t+'_BlankRuntimeTMProSurface',(4.54,.75,.025),(0,1.65,z-.116),'screenback',group='RUNTIME_DISPLAY_FACE')
 m.group_pivots['RUNTIME_DISPLAY_FACE']=(0,1.65,z-.15)
 # UI frames outside the blank screen, not printed numeric readouts
 for line,y in enumerate((1.89,1.65,1.41)):
  m.box(t+f'_DisplayGuide_{line}',(3.98,.013,.014),(0,y,z-.138),'tealshade')
 controls=[('AUTO',-4.10,'mint'),('HOME',-3.30,'neonblue'),('STOP',-2.53,'scarlet'),('RESET',2.53,'safety'),('CAL',3.30,'aqua'),('SPEED',4.10,'mint')]
 for name,x,color in controls:
  g='BUTTON_'+name+'_PRESS_Z'
  m.cyl(t+'_'+name+'_Bezel',.21,.07,(x,1.72,z-.057),'chrome','z',24,group=g)
  m.cyl(t+'_'+name+'_Cap',.152,.07,(x,1.72,z-.12),color,'z',24,group=g)
  text(m,t+'_'+name+'_Label',name,x,2.13,z-.117,.105,'ice',.66)
  m.group_pivots[g]=(x,1.72,z-.13)
 ports=[('CTRL_PLUS','+5V','red'),('CTRL_GND','GND','void'),('CTRL_ENC_A','ENC A','aqua'),('CTRL_ENC_B','ENC B','mint'),('CTRL_MARK_IN','MARK','mint'),('CTRL_CARR_PWM','PWM','safety'),('CTRL_CUT_TRIG','CUT','amberlit'),('CTRL_GUARD_IN','GUARD','green'),('CTRL_HOME_IN','HOME','neonblue')]
 for (sid,label,col),x in zip(ports,np.linspace(-4.35,4.35,9)):
  jack(m,t,sid,label,float(x),.66,z,col,.095)
 led(m,t+'_GuardOkLamp',4.64,2.23,z-.07,'green')
 led(m,t+'_SyncLamp',-4.64,2.23,z-.07,'aqua')
 return m


def make_guard():
 m=Model('10_L49_SafetyGuard');t='L49_GUARD';g='GUARD_DOOR_OPEN_PIVOT'
 # Front acrylic window. Separate door meshes from permanent frame.
 for x in (-4.5,4.5):
  m.box(t+f'_FixedAluminumUpright_{x:+.1f}',(.24,3.38,.27),(x,1.98,0),'chrome')
 for z in (-2.65,2.65):
  m.box(t+f'_FixedSideBrace_{z:+.1f}',(9.10,.17,.14),(0,3.59,z),'nickel')
 m.box(t+'_FrontRoofGuardBeam',(9.18,.22,.22),(0,3.76,-2.51),'polished')
 m.box(t+'_RearRoofGuardBeam',(9.18,.22,.22),(0,3.76,2.51),'polished')
 m.box(t+'_ClearAcrylicRoof',(8.91,.062,4.88),(0,3.80,0),'glassblue')
 for x in (-4.05,4.05):m.box(t+f'_SideAcrylic_{x:+.1f}',(.072,2.74,4.86),(x,2.14,0),'glassblue')
 m.box(t+'_RearClearScreen',(8.62,2.65,.068),(0,2.14,2.47),'glassblue')
 m.box(t+'_HingedFrontClearDoor',(8.58,2.68,.075),(0,2.16,-2.47),'glassblue',group=g)
 for x in (-4.12,4.12):
  m.box(t+f'_DoorFrameVertical_{x:+.1f}',(.10,2.76,.12),(x,2.16,-2.51),'chrome',group=g)
 for y in (.82,3.48):
  m.box(t+f'_DoorFrameHorizontal_{y:+.1f}',(8.54,.105,.12),(0,y,-2.51),'nickel',group=g)
 m.box(t+'_AmberDoorHandle',(.24,.72,.29),(3.65,2.17,-2.70),'safety',group=g)
 m.group_pivots[g]=(-4.15,2.15,-2.5)
 # 2 hinges on common origin, rotation needs animating around their actual shared pivot.
 for y in (1.2,3.0):
  m.cyl(t+f'_Hinge_{y}',.145,.35,(-4.20,y,-2.46),'chrome','y',24)
 m.bevel(t+'_InterlockHousing',(2.2,.81,.77),(3.25,.77,-3.25),'carbon',.08)
 jack(m,t,'GUARD_NC_OUT','NC OUT',3.20,.74,-3.73,'green')
 led(m,t+'_InterlockGreen',4.02,1.05,-3.70,'green')
 # Caution stripes (not covering acrylic middle)
 for i,x in enumerate(np.linspace(-3.75,3.75,11)):
  m.box(t+f'_DoorCautionStripe_{i:02d}',(.37,.10,.029),(float(x),.80,-2.60),'safety' if i%2==0 else 'coal',group=g)
 text(m,t+'_SAFETY','GUARD INTERLOCK',0,3.57,-2.61,.17,'ice',4.9)
 return m


def make_monitor():
 m=Model('11_L49_QualityMonitor');t='L49_QUALITY'
 z=labelplate(m,t,'CUT QUALITY MONITOR',6.68,3.15,2.05,'mint','WEB / CARRIAGE / ERROR')
 m.bevel(t+'_AluminumVideoBezel',(6.14,1.28,.071),(0,1.63,z-.065),'polished',.053)
 m.box(t+'_BlankLiveReadoutSurface',(5.87,1.04,.026),(0,1.64,z-.107),'screenback',group='QUALITY_READOUT_FACE')
 m.group_pivots['QUALITY_READOUT_FACE']=(0,1.64,z-.14)
 # Small independent progress bars under viewport
 for j in range(10):
  g=f'REGISTRATION_QUALITY_BAR_{j:02d}'
  m.box(t+f'_QualityBar_{j:02d}',(.40,.11,.034),(-2.52+j*.56,.74,z-.135),'aqua' if j<8 else 'safety',group=g)
  m.group_pivots[g]=(-2.52+j*.56,.74,z-.14)
 led(m,t+'_PASS_Indicator',-2.86,2.11,z-.08,'mint')
 led(m,t+'_REJECT_Indicator',2.86,2.11,z-.08,'scarlet')
 return m


def make_supply():
 m=Model('12_L49_5VSupply');t='L49_SUPPLY'
 z=labelplate(m,t,'5 V REGULATED',4.37,2.80,1.81,'aqua','CONTROL REFERENCE')
 m.box(t+'_SupplyBlackScreen',(2.45,.49,.028),(0,1.39,z-.078),'screenback')
 text(m,t+'_SupplyNominal','5.00 V',0,1.39,z-.123,.215,'mint',2.0)
 led(m,t+'_PowerLamp',1.67,1.44,z-.058,'green')
 jack(m,t,'SUPPLY_PLUS','+5V',-.85,.73,z,'red')
 jack(m,t,'SUPPLY_RETURN','RETURN',.85,.73,z,'void')
 for i in range(9):m.box(t+f'_RoofHeatVent_{i:02d}',(.10,.017,1.03),(-1.46+i*.36,2.28,.35),'coal')
 return m

BUILDERS=[make_frame,make_web,make_encoder_roller,make_optical_eye,make_linear_rail,
          make_carriage,make_carriage_motor,make_cutter,make_driver,make_controller,
          make_guard,make_monitor,make_supply]

# The assembly deliberately keeps its interactive front row clear of guard parts.
POS={
 '00_L49_IndustrialFrame':(0,0,0),
 '01_L49_WebTransport':(0,0,0),
 '02_L49_EncoderRoller':(-5.3,0,0),
 '03_L49_OpticalMarkSensor':(-10.6,0,1.40),
 '04_L49_LinearRail':(5.6,0,1.25),
 '05_L49_FlyingCarriage':(5.6,0,1.25),
 '06_L49_CarriageMotor':(13.45,0,3.40),
 '07_L49_CutterHead':(5.6,0,1.25),
 '08_L49_MotorDriver':(-10.6,0,-8.60),
 '09_L49_RegistrationController':(.40,0,-8.60),
 '10_L49_SafetyGuard':(5.6,0,1.20),
 '11_L49_QualityMonitor':(-9.8,0,8.15),
 '12_L49_5VSupply':(11.5,0,-8.6),
}

WIRES=[
 ('W01','SUPPLY_PLUS','CTRL_PLUS','Supply +5 V -> Controller +5 V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply RETURN -> Controller GND'),
 ('W03','SUPPLY_PLUS','OPTICAL_PLUS','Supply +5 V -> Optical Sensor +5 V'),
 ('W04','SUPPLY_RETURN','OPTICAL_GND','Supply RETURN -> Optical Sensor GND'),
 ('W05','ENCODER_A','CTRL_ENC_A','Encoder A -> Controller ENC A'),
 ('W06','ENCODER_B','CTRL_ENC_B','Encoder B -> Controller ENC B'),
 ('W07','OPTICAL_SIGNAL','CTRL_MARK_IN','Optical Sensor SIGNAL -> Controller MARK IN'),
 ('W08','CTRL_CARR_PWM','DRIVER_PWM','Controller carriage PWM -> Driver PWM'),
 ('W09','DRIVER_MOTOR_PLUS','CARRIAGE_MOTOR_PLUS','Driver M+ -> Carriage motor +'),
 ('W10','DRIVER_MOTOR_MINUS','CARRIAGE_MOTOR_MINUS','Driver M- -> Carriage motor -'),
 ('W11','CTRL_CUT_TRIG','CUTTER_TRIG','Controller CUT TRIG -> Cutter actuator TRIG'),
 ('W12','SUPPLY_PLUS','DRIVER_PLUS','Supply +5 V -> Driver +5 V'),
 ('W13','SUPPLY_RETURN','DRIVER_GND','Supply RETURN -> Driver GND'),
 ('W14','GUARD_NC_OUT','CTRL_GUARD_IN','Guard NC OUT -> Controller GUARD IN'),
 ('W15','HOME_OUT','CTRL_HOME_IN','Home sensor OUT -> Controller HOME IN'),
]

def build():
 models=[]
 for maker in BUILDERS:
  m=maker();models.append(m)
  fname=MODELS/(m.key+'.fbx');gname=MODELS/(m.key+'.glb')
  export_fbx(fname,[m]);export_glb(gname,[m])
  assert fname.read_bytes().startswith(b'Kaydara FBX Binary  \x00'),fname
  assert len(trimesh.load_scene(gname).geometry)>0
  print('MODEL',m.key,'TRIS',sum(len(p.mesh.faces) for p in m.parts),'PARTS',len(m.parts),'JACKS',len(m.anchors),flush=True)
 assert len(models)==13
 socket_ids=[s for m in models for s in m.anchors]
 assert len(socket_ids)==len(set(socket_ids))==26,(len(socket_ids),socket_ids)
 endpoints={s for _,a,b,_ in WIRES for s in (a,b)}
 assert len(WIRES)==15 and endpoints==set(socket_ids),(len(endpoints),set(socket_ids)^endpoints)
 assert all(m.key in POS for m in models)
 hero='Level49_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(hero+'.fbx'),models,positions=POS)
 export_glb(MODELS/(hero+'.glb'),models,positions=POS)
 assert len(trimesh.load_scene(MODELS/(hero+'.glb')).geometry)>0
 manifest={}
 for m in models:
  manifest[m.key]={
   'fbx':m.key+'.fbx','glb':m.key+'.glb',
   'triangles':sum(len(p.mesh.faces) for p in m.parts),
   'part_count':len(m.parts),'art_sockets_local_xyz':m.anchors,
   'animation_groups':m.group_pivots,
  }
 triangles=sum(v['triangles'] for v in manifest.values())
 doc={
  'level':49,'display_name':'Cut on the Mark','subtitle':'Synchronized Flying Shear',
  'type':'VISUAL ASSETS ONLY — no circuit components, motor/safety logic, or objectives implemented',
  'models_count':13,'wires_count':15,'art_sockets_count':26,'triangles':triangles,
  'assembled_fbx':hero+'.fbx','model_entries':manifest,'showcase_placements_xyz':POS,'wiring':WIRES,
  'coordinate_convention':'Y up; models face -Z; socket XYZ are art positions only, align real SparkTerminal to workbench holes',
  'guard_note':'W14 is guard NC output to controller; implement real normally-closed interlock with validated signal source and safe-stop logic',
  'home_note':'W15 home sensor output to controller; implement actual switch state and referential homing',
  'mechanics_note':'Carriage slides on X along rail; cutter follows carriage as separately parented assembly; stamp is a safeguarded training model',
  'screens':'Controller and quality monitor intentionally blank for live TextMeshPro.'
 }
 (ROOT/'Model_Manifest.json').write_text(json.dumps(doc,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBX Model','ArtSocketID','LocalX','LocalY','LocalZ','Note'])
  for m in models:
   for name,(x,y,z) in m.anchors.items():w.writerow([m.key+'.fbx',name,x,y,z,'Art only; add SparkTerminal at the corresponding shelf hole'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBX Model','ArtSocketID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for name,xyz in m.anchors.items():w.writerow([m.key+'.fbx',name,*[round(a+b,5) for a,b in zip(xyz,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBX Model','AnimationGroup','LocalPivotX','LocalPivotY','LocalPivotZ','DriveFrom'])
  for m in models:
   for grp,(x,y,z) in m.group_pivots.items():w.writerow([m.key+'.fbx',grp,x,y,z,'Level 49 simulation output / visual only'])
 (ROOT/'VALIDATION.txt').write_text(
  f'PROJECT SPARK LEVEL 49 / CUT ON THE MARK\n'
  f'Individual FBX: 13; individual GLB: 13; assembled FBX: 1; assembled GLB: 1.\n'
  f'Unique art sockets: 26; player wires: 15; assembled triangle count: {triangles:,}.\n'
  'FBX 7.4 binary nested pointer check passed; GLB loads with trimesh; all W01-W15 endpoints map to socket IDs.\n'
  'UNITY RUNTIME, ELECTRICAL COMPONENTS, PHYSICS, MATERIAL SHADERS AND PLAY MODE ARE NOT TESTED.\n')
 print('SUCCESS LEVEL 49: 13 models,',triangles,'triangles,',len(socket_ids),'sockets',flush=True)
 return models

if __name__=='__main__':build()
