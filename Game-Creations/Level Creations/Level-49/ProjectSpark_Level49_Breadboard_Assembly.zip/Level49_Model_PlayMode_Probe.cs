#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AAAUI.VFX;
using ProjectSpark.Circuit;
using ProjectSpark.EditorTools;
using ProjectSpark.Gameplay;
using UnityEditor;
using UnityEngine;

using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;

[InitializeOnLoad]
internal static class Level49ModelPlayModeProbe
{
    private const string Request = "Logs/Level49ModelTest.request";
    private const string Report = "Logs/Level49ModelTest.txt";
    private const string Running = "Codex.Level49.ModelTest";
    private static LevelGamePlayManager manager;
    private static SparkLevel49Shear loop;

    static Level49ModelPlayModeProbe()
    {
        EditorApplication.update += CheckRequest;
        EditorApplication.playModeStateChanged += StateChanged;
    }

    private static void CheckRequest()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || !File.Exists(Request)) return;
        try { File.Delete(Request); }
        catch (IOException) { return; }
        File.WriteAllText(Report, "Level 49 — Breadboard assembly and Cut on the Mark test\n");
        try
        {
            Check(SceneManager.GetActiveScene().path == SparkLevel49ModelInstaller.ScenePath, "Open MainMenu in Edit Mode.");
            SparkLevel49ModelInstaller.Install();
            Record("Installed the fitted assembly in the Level 49 prefab and registered the campaign.");
            SessionState.SetBool(Running, true);
            EditorApplication.EnterPlaymode();
        }
        catch (Exception error) { Record("FAIL: " + error); }
    }

    private static void StateChanged(PlayModeStateChange state)
    {
        if (!SessionState.GetBool(Running, false)) return;
        if (state == PlayModeStateChange.EnteredPlayMode) Run();
        if (state == PlayModeStateChange.EnteredEditMode)
        {
            SessionState.EraseBool(Running);
            Record("Returned to Edit Mode.");
        }
    }

    private static async void Run()
    {
        bool logEnabled = Debug.unityLogger.logEnabled;
        bool runInBackground = Application.runInBackground;
        try
        {
            Debug.unityLogger.logEnabled = false;
            Application.runInBackground = true;
            Record("Entered Play Mode.");
            await Wait(() => Object.FindFirstObjectByType<LevelGamePlayManager>() != null, "MainMenu manager");
            manager = Object.FindFirstObjectByType<LevelGamePlayManager>();
            var loader = Object.FindFirstObjectByType<SparkLevelLayoutLoader>();
            var wireBuilder = Object.FindFirstObjectByType<SignalWireBuilder>();
            var wirePaths = Object.FindFirstObjectByType<SignalPath_Manager>();
            var definition = AssetDatabase.LoadAssetAtPath<SparkLevelDefinition>(SparkLevel49ModelInstaller.Folder + "Level_49.asset");
            Check(definition != null && wireBuilder != null && loader != null, "Level definition, wire builder, or layout loader missing.");
            if (manager.LevelProgression != null) manager.LevelProgression.enabled = false;
            Write(manager, "enforceProgressionAccess", false);
            Write(manager, "autoAdvanceOnCompletion", false);
            Write(manager, "autoEvaluate", true);
            int levelIndex = Array.IndexOf(Read<SparkLevelDefinition[]>(manager, "levels"), definition);
            Check(levelIndex >= 0 && manager.StartLevel(levelIndex), "Level 49 is missing from the campaign or could not start.");
            await Wait(() => loader.ActiveLayout != null && manager.ActiveLevel == definition, "Level 49 loaded");
            loop = loader.ActiveLayout.GetComponent<SparkLevel49Shear>();
            await Wait(() => loop != null && Read<int>(loop, "topology") >= 0,
                "the active loop controller to check the empty circuit");

            var bench = loop.transform.Find("Shear Workbench");
            var camera = Read<Camera>(wireBuilder, "targetCamera");
            var grid = SparkLevel49ModelInstaller.FindBoard(SceneManager.GetActiveScene());
            var ids = SparkLevel49ModelInstaller.TerminalIds.ToArray();
            var pins = new Dictionary<string, SparkTerminal>();
            var holes = new HashSet<Vector2Int>();
            float maximumGap = 0;
            float lowestFoot = float.PositiveInfinity, highestFoot = float.NegativeInfinity;
            Physics.SyncTransforms();
            foreach (string id in ids)
            {
                Check(manager.SceneBindings.TryGetTerminal(id, out var terminal), "Missing " + id);
                pins.Add(id, terminal);
                var socket = terminal.transform;
                Vector3 foot = socket.TransformPoint(Vector3.down);
                float height = Vector3.Dot(foot, bench.up);
                lowestFoot = Mathf.Min(lowestFoot, height);
                highestFoot = Mathf.Max(highestFoot, height);
                Vector3 surface = SparkLevel49ModelInstaller.SurfacePoint(grid, foot, bench.up);
                maximumGap = Mathf.Max(maximumGap, Mathf.Abs(Vector3.Dot(surface - foot, bench.up)));
                Check(maximumGap < .001f, "Terminal base does not touch the breadboard: " + id);
                Check(grid.TryGetNearestHole(socket.position, .15f, out var hole, out int column, out int row) &&
                    holes.Add(new Vector2Int(column, row)) &&
                    Vector3.ProjectOnPlane(foot - hole, bench.up).magnitude < .001f,
                    "Terminal does not sit over its own wire hole: " + id);
            }
            Check(holes.Count == 26, "Expected 26 breadboard sockets.");
            Check(highestFoot - lowestFoot < .010f, $"Breadboard seating varies by {highestFoot-lowestFoot:F5} Unity units.");
            Record($"26/26 terminal feet touch the breadboard on distinct wire holes. Maximum seating error: {maximumGap:F6} Unity units.");
            var labels = bench.GetComponentsInChildren<TextMesh>();
            Check(labels.Length == 32 && Array.TrueForAll(labels, label => label.transform.localScale == Vector3.one * .20f),
                "TextMesh labels must use a local scale of 0.20.");
            Record("All 32 TextMesh labels use 0.20 local scale.");
            Capture(bench, pins, "Unwired", true);
            foreach (var pair in pins)
            {
                Vector3 point = camera.WorldToScreenPoint(pair.Value.transform.position);
                Check(point.z > 0 && point.x >= 0 && point.y >= 0 && point.x < camera.pixelWidth && point.y < camera.pixelHeight,
                    $"Terminal outside the active camera: {pair.Key} at {point}; camera {camera.pixelWidth}x{camera.pixelHeight}");
                Check(ReferenceEquals(pick.Invoke(wireBuilder, new object[] { (Vector2)point }), pair.Value),
                    "Wire tool cannot select " + pair.Key + " from the active game camera.");
            }
            Record("26/26 sockets picked by the real Wire tool from the active game camera.");
            void Connect(int from, int to, WirePolarity polarity = WirePolarity.Neutral)
            {
                Check(wireBuilder.BeginWire(pins[ids[from]], polarity), "Wire tool could not start at " + ids[from]);
                Check(wireBuilder.TryEndWire(camera.WorldToScreenPoint(pins[ids[to]].transform.position)),
                    "Wire tool could not finish " + ids[from] + " to " + ids[to]);
            }


            var wires = new (int from,int to)[] {(0,1),(2,3),(0,4),(2,5),(6,7),(8,9),(10,11),
                (12,13),(14,15),(16,17),(18,19),(0,20),(2,21),(22,23),(24,25)};
            for (int i=0;i<wires.Length-1;i++)
            {
                var (from,to)=wires[i];
                Connect(from,to,from==0 ? WirePolarity.Positive : from==2 ? WirePolarity.Negative : WirePolarity.Neutral);
            }
            await Wait(()=>loop.statusText.text.Contains("W15"),"missing home feedback diagnostic");
            Check(!loop.startButton.interactable && !loop.homeButton.interactable && manager.SatisfiedTargetCount==0,
                "Motion was available with home feedback disconnected.");
            Connect(24,25);
            await At(1);
            Record("All 15 connections placed through SignalWireBuilder. Missing W15 blocked motion.");
            await Click(loop.homeButton);
            await Wait(()=>Read<bool>(loop,"homed"),"physical homing");
            Check(Read<bool>(loop,"homeValid"),"Homing finished without solved home input.");
            await Click(loop.calibrateButton);
            await At(2);
            Check(Read<int>(loop,"pitch")==160,"Calibration pitch differs from 160 counts.");
            await Click(loop.startButton);
            await At(3);
            Check(Read<int>(loop,"accepted")==3 && Read<int>(loop,"rejected")==0,"Expected three good 30 RPM cuts.");
            Record($"30 RPM last cut error {Read<float>(loop,"error"):+0.00;-0.00;0.00} mm.");
            await Click(loop.fastButton);
            await At(4);
            Check(Read<bool>(loop,"transitioned") && Read<int>(loop,"accepted")>=6,"Missing actual 30 to 60 RPM transition or cuts.");
            Record($"60 RPM last cut error {Read<float>(loop,"error"):+0.00;-0.00;0.00} mm.");
            await Wait(()=>Read<float>(loop,"stroke")>.5f,"synchronized cutting stroke");
            Capture(bench,pins,"Running",false);
            await Click(loop.loadButton);
            await At(5);
            Check(Read<bool>(loop,"loadSeen") && Read<float>(loop,"trajectoryChange")>.018f,"No measured disturbance/trajectory correction.");
            await Wait(()=>Read<float>(loop,"position")>.006f,"carriage moving under guard");
            await Click(loop.guardButton);
            Check(loop.printDrive.IsOpen && loop.transportDrive.IsOpen,"Opening guard did not immediately release both contacts.");
            await Wait(()=>loop.statusText.text.Contains("SAFE STOP") && Read<float>(loop,"velocity")<.0005f &&
                Mathf.Abs(Read<float>(loop,"carriageVelocity"))<.0005f,"safe stop");
            Check(manager.SatisfiedTargetCount==5 && !loop.resetButton.interactable && Read<float>(loop,"stroke")<=0,
                "Guard fault did not retain 5/6, inhibit reset or retract the cutter.");
            Capture(bench,pins,"GuardOpen",false);
            await Click(loop.guardButton);
            await Wait(()=>loop.resetButton.interactable,"solved closed guard");
            Check(!loop.startButton.interactable,"Closing the guard bypassed the latch.");
            await Click(loop.resetButton);
            await Click(loop.homeButton);
            await Wait(()=>Read<bool>(loop,"homed"),"repeat homing");
            await Click(loop.startButton);
            await At(6);
            await Wait(()=>manager.IsCompleted,"authoritative campaign completion");
            Record($"6/6 — Campaign manager reports Completed. Recovery cut {Read<float>(loop,"error"):+0.00;-0.00;0.00} mm.");
            Capture(bench,pins,"Verified",false);

        }
        catch (Exception error)
        {
            Record("FAIL: " + error);
            if (loop != null) Record("Control panel: " + loop.statusText.text + " | " + loop.meterText.text + " | " + loop.detailText.text);
            if (manager != null) Record($"Evaluation {manager.SatisfiedTargetCount}/{manager.ActiveTargetCount}: {manager.LastEvaluationMessage}");
        }
        finally
        {
            Debug.unityLogger.logEnabled = logEnabled;
            Application.runInBackground = runInBackground;
            if (EditorApplication.isPlaying) EditorApplication.ExitPlaymode();
        }
    }

    private static readonly MethodInfo pick = typeof(SignalWireBuilder).GetMethod("FindTerminalAtScreenPosition",
        BindingFlags.Instance | BindingFlags.NonPublic);

    private static async Task At(int stage)
    {
        await Wait(() => Read<int>(loop, "stage") == stage && manager.SatisfiedTargetCount == stage, $"{stage}/6");
        Record($"{stage}/6 — {loop.statusText.text} | {loop.meterText.text}");
    }

    private static async Task Click(Button button)
    {
        await Wait(() => button.isActiveAndEnabled && button.interactable, button.name + " available");
        Check(button.onClick.GetPersistentEventCount() == 1 && button.onClick.GetPersistentTarget(0) == loop,
            "Missing Level 49 action on " + button.name);
        button.onClick.Invoke();
    }

    private static void Capture(Transform bench, Dictionary<string, SparkTerminal> pins, string name, bool overhead)
    {
        var view = new GameObject("Level 49 test camera");
        var camera = view.AddComponent<Camera>();
        camera.enabled = false;
        view.transform.position = bench.TransformPoint(new Vector3(0, 2.20f, overhead ? -.58f : -1.92f));
        view.transform.rotation = Quaternion.LookRotation(bench.TransformPoint(new Vector3(0, .04f, 0)) -
            view.transform.position, bench.up);
        camera.orthographic = true;
        camera.orthographicSize = bench.TransformVector(new Vector3(0, .90f, 0)).magnitude;
        const int width = 1600, height = 1050;
        var target = new RenderTexture(width, height, 24);
        var snapshot = new Texture2D(width, height, TextureFormat.RGB24, false);
        var previous = RenderTexture.active;
        try
        {
            camera.targetTexture = target;
            camera.Render();
            RenderTexture.active = target;
            snapshot.ReadPixels(new Rect(0, 0, width, height), 0, 0);
            snapshot.Apply();
            File.WriteAllBytes("Logs/Level49_" + name + ".png", snapshot.EncodeToPNG());
            if (!overhead) return;
            var rows = new List<string> { "Terminal,X,Y" };
            foreach (var pair in pins)
            {
                var p = camera.WorldToViewportPoint(pair.Value.transform.position);
                rows.Add($"{pair.Key},{Mathf.RoundToInt(p.x * width)},{Mathf.RoundToInt((1f - p.y) * height)}");
            }
            File.WriteAllLines("Logs/Level49_Pins.csv", rows);
        }
        finally
        {
            RenderTexture.active = previous;
            camera.targetTexture = null;
            Object.Destroy(target);
            Object.Destroy(snapshot);
            Object.Destroy(view);
        }
    }

    private static Task Wait(Func<bool> condition, string step)
    {
        if (condition()) return Task.CompletedTask;
        var completion = new TaskCompletionSource<bool>();
        var timeout = DateTime.UtcNow.AddSeconds(50);
        void Poll()
        {
            try
            {
                Check(EditorApplication.isPlaying, "Play Mode stopped while waiting for " + step);
                if (!condition())
                {
                    Check(DateTime.UtcNow < timeout, "Timed out waiting for " + step);
                    return;
                }
                EditorApplication.update -= Poll;
                completion.SetResult(true);
            }
            catch (Exception error)
            {
                EditorApplication.update -= Poll;
                completion.SetException(error);
            }
        }
        EditorApplication.update += Poll;
        return completion.Task;
    }

    private static FieldInfo Field(object target, string name) =>
        target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic) ?? throw new MissingFieldException(name);
    private static T Read<T>(object target, string name) => (T)Field(target, name).GetValue(target);
    private static void Write(object target, string name, object value) => Field(target, name).SetValue(target, value);
    private static void Record(string message) => File.AppendAllText(Report, message + Environment.NewLine);
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
#endif







