PROJECT SPARK — LEVEL 41 / BUILD THE ANALOG OUTPUT
POLISHED SEMI-HD FBX/GLB MODEL PACK — THREE-BIT R–2R LADDER DAC
============================================================

CONTENTS
--------
11 individual FBX 7.4 binary model files and 11 GLB backup files.
1 fully assembled ART SHOWCASE FBX and 1 matching GLB.
12 rendered previews + 1 contact sheet, Exact_Wiring.csv,
Terminal_Anchors.csv, Model_Manifest.json, editable Python generator.
The individual meshes are colored with export materials and feature 3D lettering.

ELECTRICAL MODELS (10 OBJECTS; EXACTLY 16 PLAYER SOCKETS)
--------------------------------------------------------
01_5V_DAC_Reference.fbx           DAC_RETURN          (1 socket)
02_B2_Bit_Driver.fbx              BIT2                (1 socket)
03_B1_Bit_Driver.fbx              BIT1                (1 socket)
04_B0_Bit_Driver.fbx              BIT0                (1 socket)
05_B2_20kOhm_Resistor.fbx         B2_IN, B2_OUT       (2 sockets)
06_B1_20kOhm_Resistor.fbx         B1_IN, B1_OUT       (2 sockets)
07_B0_20kOhm_Resistor.fbx         B0_IN, B0_OUT       (2 sockets)
08_Link21_10kOhm.fbx              LINK21_IN, LINK21_OUT (2 sockets)
09_Link10_10kOhm.fbx              LINK10_IN, LINK10_OUT (2 sockets)
10_20kOhm_Termination.fbx         TERM_IN, TERM_OUT   (2 sockets)

VISUAL ONLY (NO NEW ELECTRICAL SOCKETS)
---------------------------------------
11_VISUAL_3bit_DAC_Output_Monitor.fbx — Seven-segment DAC meter.
The 4.375 V / 111 display is a STATIC VISUAL DEMONSTRATION. The game
must update the display using your existing level electronics/controller.

EXACT NINE-WIRE ROUTING (FROM LEVEL 41 REFERENCE IMAGE)
-------------------------------------------------------
W01 BIT2       -> B2_IN
W02 BIT1       -> B1_IN
W03 BIT0       -> B0_IN
W04 B2_OUT     -> LINK21_IN
W05 LINK21_OUT -> B1_OUT
W06 B1_OUT     -> LINK10_IN
W07 LINK10_OUT -> B0_OUT
W08 B0_OUT     -> TERM_IN
W09 TERM_OUT   -> DAC_RETURN

The B1_OUT terminal accepts both W05 and W06.
The B0_OUT terminal accepts both W07 and W08.
The analog DAC OUT measurement point is B2_OUT; do not add a 17th player
socket just to measure output. The 5 V bit drivers are powered by FIXED
internal connections; do not create additional user wires.

EXPECTED LEVEL 41 HEALTHY OUTPUTS (SOURCE: USER DIAGRAM)
--------------------------------------------------------
Binary bits B2 B1 B0     Output
000                      0.000 V
001                      0.625 V
010                      1.250 V
011                      1.875 V
100                      2.500 V
101                      3.125 V
110                      3.750 V
111                      4.375 V

At state 111, opening the 20 kOhm termination raises the voltage toward
5 V according to the level reference. Let the existing game simulator
measure the actual behavior; don't make these values gameplay constants.

UNITY IMPORT AND SETUP
----------------------
1. Import the FBX files in Models/ into your Level41 art folder.
2. Use individual FBXs as art children of your existing electrical objects.
   Level41_Complete_ArtKit_Showcase is only a layout preview, NOT a
   prefab with gameplay wiring already installed.
3. Models use Y up and the socket/front label side faces local -Z.
   Match the scale to your existing game board before replacing assets.
4. Create actual SparkTerminal components at locations from
   Terminal_Anchors.csv. Socket ring meshes are visual only.
5. Use your actual SparkLevelSceneBindings and workstation bridge IDs,
   translating any suggested CSV names if your project uses different IDs.
6. Retain your existing battery, switch, resistor, network topology,
   solver, evaluator, and R-2R driver code. Models do not stamp electrical
   circuits and do not generate real current or voltage readings.
7. Bit toggles: Animate group BitSelector_TOGGLE_ANIMATE on each driver
   using your existing game logic. A bit's voltage must come from its
   assigned electrical source/controller—not the colored switch mesh.
8. Meter: The visual-only group Reading_StaticReplaceWithRuntime holds a
   static example value. For a live reading, hide/replace those 7-segment
   bars with UI/TextMeshPro or a runtime segment display updated from
   the actual DAC voltage.
9. Keep W01-W09 as game connections registered with SparkCircuitSystem.
   Decorative traces in the assembled SHOWCASE are not real electrical
   connections and must never count as user wires.
10. The 10k and 20k resistor modules have physical band colors and
    visually different legends but share the same art size. The installed
    gameplay resistor instance controls the real resistance.

MESH / MATERIAL NOTES
---------------------
- Autodesk FBX 7.4 binary, distinct named mesh parts and materials.
- Matching GLB for inspection/conversion.
- Metallic graphite, cyan, warm amber and copper color palette.
- Resistors have actual cylindrical ceramics and ring-shaped color bands.
- Each bit driver has a separately named visual selector.
- The visual monitor has individually named seven-segment meshes.
- Text is 3D triangle geometry, not font assets or runtime textures.
- Highly thin 3D label faces may require a double-sided shader in Unity.
- Meshes and GLBs were generated and structurally checked, but Unity
  import, materials, scaling, editor prefab construction and the live
  electrical behavior were not tested in the user's project.

FILES
-----
Models/*.fbx, Models/*.glb
Previews/*.png
Terminal_Anchors.csv
Exact_Wiring.csv
Model_Manifest.json
Sources/build_level41_models.py
Sources/spark_model_core.py
Sources/render_level41_previews.py

No existing Unity scene or C# gameplay script is changed by this art pack.
