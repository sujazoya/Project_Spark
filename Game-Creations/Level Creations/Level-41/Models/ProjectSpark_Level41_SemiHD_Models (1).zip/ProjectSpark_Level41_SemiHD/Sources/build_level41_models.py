"""PROJECT SPARK — Level 41 Build The Analog Output (3-bit R-2R DAC)
Semi-HD material-colored FBX 7.4, GLB, exact 16 socket / 9 wire map.
Does NOT implement electronics; meshes only. Reuses proven Project Spark FBX mesh exporter.
"""
from __future__ import annotations
import json, csv, math
from pathlib import Path
import numpy as np
from spark_model_core import *
ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models';PREV=ROOT/'Previews'
MODELS.mkdir(parents=True,exist_ok=True);PREV.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'ceramic':(230,208,167,255),'brass':(236,179,71,255),
 'cyan_hi':(92,242,252,255),'mint':(49,235,195,255),
 'electric':(55,135,255,255),'violet':(176,104,249,255),
 'yellow':(247,212,92,255),'warm':(252,171,77,255),
 'glass_body':(68,171,212,78),'insulator':(41,51,65,255),
 'screen_green':(89,250,177,255),'pcb':(22,84,81,255),
 'teal':(30,209,192,255), 'brown':(122,67,41,255),
 'rose':(254,104,131,255), 'dark_copper':(109,66,40,255),
})
# 16 distinct socket IDs, 9 player-built wires exactly per uploaded Level41 diagram.
WIRES=[
 ('W01','BIT2','B2_IN'),('W02','BIT1','B1_IN'),('W03','BIT0','B0_IN'),
 ('W04','B2_OUT','LINK21_IN'),('W05','LINK21_OUT','B1_OUT'),
 ('W06','B1_OUT','LINK10_IN'),('W07','LINK10_OUT','B0_OUT'),
 ('W08','B0_OUT','TERM_IN'),('W09','TERM_OUT','DAC_RETURN')
]
PORTS={
 '01_5V_DAC_Reference':[('DAC_RETURN','DAC RETURN','blue')],
 '02_B2_Bit_Driver':[('BIT2','BIT2','warm')],
 '03_B1_Bit_Driver':[('BIT1','BIT1','warm')],
 '04_B0_Bit_Driver':[('BIT0','BIT0','warm')],
 '05_B2_20kOhm_Resistor':[('B2_IN','B2 IN','warm'),('B2_OUT','B2 OUT','mint')],
 '06_B1_20kOhm_Resistor':[('B1_IN','B1 IN','warm'),('B1_OUT','B1 OUT','mint')],
 '07_B0_20kOhm_Resistor':[('B0_IN','B0 IN','warm'),('B0_OUT','B0 OUT','mint')],
 '08_Link21_10kOhm':[('LINK21_IN','LINK21 IN','mint'),('LINK21_OUT','LINK21 OUT','mint')],
 '09_Link10_10kOhm':[('LINK10_IN','LINK10 IN','mint'),('LINK10_OUT','LINK10 OUT','mint')],
 '10_20kOhm_Termination':[('TERM_IN','TERM IN','mint'),('TERM_OUT','TERM OUT','blue')],
}

def chassis(m,t,title,sub='',w=3.16,h=1.23,d=1.96,accent='cyan'):
 m.base(t,w=w,d=d,bodyh=h,fronttext='',status='')
 face=-d/2-.081
 # inset LCD style faceplate with high contrast titles
 m.bevel(t+'_TitlePlate',(w-.29,.34,.037),(0,1.17,face-.018),'void',.035)
 m.text(t+'_Title_Text',title,.225,0,1.18,face-.061,'white',maxwidth=w-.39)
 if sub:m.text(t+'_Subtitle',sub,.131,0,.904,face-.064,accent,maxwidth=w-.40)
 m.box(t+'_PowerUnderGlow',(1.30,.040,.030),(0,.343,face-.012),accent,group='AccentLights_VISUAL')
 for x in (-w/2+.19,w/2-.19):
  for z in (-d/2+.17,d/2-.20):
   m.cyl(t+f'_LidScrew_{x:+.2f}_{z:+.2f}',.066,.025,(x,1.58,z),'chrome',sections=18)
 return face

def socket(m,t,slotid,designation,color,local_x,local_y=.47,d=1.96):
 zz=-d/2-.110
 m.cyl(t+'_'+slotid+'_MetalBoss',.197,.075,(local_x,local_y,zz),'chrome',axis='z',sections=34)
 m.cyl(t+'_'+slotid+'_Insulator',.160,.089,(local_x,local_y,zz-.035),color,axis='z',sections=34)
 m.cyl(t+'_'+slotid+'_BlackOpening',.109,.094,(local_x,local_y,zz-.086),'void',axis='z',sections=30)
 m.cyl(t+'_'+slotid+'_GoldContact',.036,.030,(local_x,local_y,zz-.124),'gold',axis='z',sections=18)
 m.torus(t+'_'+slotid+'_RingAccent',.173,.013,(local_x,local_y,zz-.055),color,axis='z',segments=34,tube_segs=7,group='SocketGlow_VISUAL')
 m.text(t+'_'+slotid+'_Engraving',designation,.139,local_x,local_y+.282,zz-.144,'white',maxwidth=1.30)
 m.anchors[slotid]=[round(local_x,4),round(local_y,4),round(zz-.144,4)]

def sockets(m,t,positions=None):
 data=PORTS[m.key]
 for i,(sid,txt,col) in enumerate(data):
  x=positions[i] if positions else (.87 if i==0 else -.87)
  socket(m,t,sid,txt,col,x)

def board_plate(m,name,center=(0,0,0),w=3.5,d=2.4):
 x,y,z=center
 m.bevel(name+'_AntiSlip',(w,.12,d),(x,.11,z),'rubber',.095)
 m.bevel(name+'_MachinedAluminum',(w-.075,.13,d-.075),(x,.205,z),'mid_steel',.08)
 for xx in (-w/2+.12,w/2-.12):
  m.box(name+f'_SideLight_{xx:+.2f}',(.041,.030,d-.32),(x+xx,.287,z),'cyan')

def small_panel(m,t,label,mat='mint',y=1.96, w=1.19):
 m.bevel(t+'_GlassPanelBody',(w,.115,.51),(0,y,.13),'screen',.050)
 m.box(t+'_PanelAccent',(w-.21,.014,.034),(0,y+.068,-.084),mat)
 m.text(t+'_PanelLegend_3D',label,.165,0,y+.008,-.145,mat,maxwidth=w-.18)

def source():
 m=Model('01_5V_DAC_Reference');t='L41_REF'
 chassis(m,t,'5 V REFERENCE','DAC DRIVER SUPPLY / FIXED +5 V',w=3.16,h=1.50,accent='blue')
 sockets(m,t,[0])
 m.bevel(t+'_DisplayFrame',(1.50,.42,.08),(0,1.62,-1.074),'chrome',.059)
 m.bevel(t+'_FrontOLED',(1.36,.33,.065),(0,1.62,-1.123),'screen',.044)
 m.text(t+'_Reference5V_STATIC','5.000 V',.244,0,1.625,-1.172,'screen_green',maxwidth=1.29,group='ReferenceDisplay_STATIC')
 for i in range(13):
  m.box(t+f'_TopHeatSinkVent_{i:02d}',(.07,.023,.60),(-1.19+i*.20,2.02,.12),'void')
 m.box(t+'_LEDReady',(1.08,.038,.04),(0,2.045,-.39),'green',group='PowerStatus_LED')
 m.text(t+'_FixedPowerWarning','DRIVERS POWERED INTERNALLY',.143,0,.78,-1.08,'fog',maxwidth=2.7)
 return m

def driver(bit,key):
 m=Model(key);t='L41_'+bit+'_DRV'
 chassis(m,t,bit+' DRIVER','LOGIC LEVEL  0 V / 5 V',accent='warm')
 sockets(m,t,[0])
 m.bevel(t+'_SwitchMount',(1.58,.17,1.04),(0,1.635,.09),'chrome',.09)
 m.bevel(t+'_Recess',(1.39,.13,.87),(0,1.755,.08),'void',.07)
 m.bevel(t+'_BitSelector_TOGGLE',(1.18,.23,.76),(0,1.875,.08),'deep_steel',.056,group='BitSelector_TOGGLE_ANIMATE')
 m.box(t+'_RedEndCap_TOGGLE',(.39,.238,.76),(-.38,1.89,.08),'red',group='BitSelector_TOGGLE_ANIMATE')
 m.box(t+'_GreenEndCap_TOGGLE',(.39,.238,.76),(.38,1.89,.08),'green',group='BitSelector_TOGGLE_ANIMATE')
 m.text(t+'_Bit_0_3D','0',.23,-.41,2.031,-.205,'white',maxwidth=.30,group='BitSelector_TOGGLE_ANIMATE')
 m.text(t+'_Bit_1_3D','1',.23,.40,2.031,-.205,'white',maxwidth=.30,group='BitSelector_TOGGLE_ANIMATE')
 m.box(t+'_Backlight',(1.05,.030,.041),(0,1.632,-.51),'warm',group='BitIndicator_VISUAL')
 for x in (-1.04,1.04):m.cyl(t+f'_SwitchScrew_{x:+.2f}',.085,.028,(x,1.72,.50),'chrome',sections=18)
 return m

def resistor(key,title,ohms,bit=None,small=False):
 m=Model(key);t='L41_'+key[3:].upper()
 col='mint' if ohms==10000 else 'warm'
 chassis(m,t,title,("R   10 kOhm" if small else "2R   20 kOhm"),accent=col)
 sockets(m,t)
 board_plate(m,t+'_ResistorSeat',(0,1.70,.07),w=2.65,d=1.24)
 m.box(t+'_Black_Lower_Insert',(2.39,.06,.34),(0,1.83,.07),'void')
 m.cyl(t+'_Ceramic_Resistor',.240,1.56,(0,2.15,.11),'ceramic',axis='x',sections=44)
 bands=('brown','void','orange','gold') if ohms==10000 else ('red','void','orange','gold')
 for i,(x,c) in enumerate(zip((-.48,-.20,.12,.44),bands)):
  m.torus(t+f'_BAND_{i+1}_{c.upper()}',.248,.039,(x,2.15,.11),c,axis='x',segments=48,tube_segs=9)
 for s in (-1,1):
  m.cyl(t+f'_ResistorEndcap_{s}',.254,.075,(s*.8,2.15,.11),'brass',axis='x',sections=26)
  m.rod(t+f'_AxialLead_{s}',(s*.825,2.15,.11),(s*1.24,2.15,.11),.032,'chrome',sections=12)
  m.cyl(t+f'_GoldMountPin_{s}',.123,.39,(s*1.25,1.99,.11),'gold',sections=23)
 # open transparent framed cover, not an opaque slab
 for x in (-1.32,1.32):
  for z in (-.63,.73):m.rod(t+f'_ClearCornerPost_{x}_{z}',(x,1.84,z),(x,2.68,z),.024,'glass_edge',sections=9)
 for z in (-.63,.73):
  m.rod(t+f'_TopAcrylicRim_{z}',(-1.32,2.68,z),(1.32,2.68,z),.022,'cyan',sections=9,group='AcrylicGuard_VISUAL')
 m.text(t+'_DeckOhmMark',str(ohms//1000)+' kOHM',.156,0,1.865,-.64,'fog',maxwidth=1.2)
 return m

def termination():
 m=resistor('10_20kOhm_Termination','20 kOhm TERM',20000)
 t='L41_TERMINATION_VISUAL'
 for x in (-1.3,1.3):
  m.box(t+f'_ChassisBlueReturnStripe_{x}',(.038,.35,.10),(x,.97,-.92),'blue')
 m.box(t+'_PrecisionStatusPlate',(1.18,.042,.027),(0,1.02,-1.056),'cyan')
 return m

def seven_segment_digit(m,prefix,number,x,y,z,material='screen_green',group='Reading_StaticReplaceWithRuntime'):
 # Mesh-based seven-segment numeric geometry; no font triangulation or texture dependency.
 patterns={
  '0':'abcdef','1':'bc','2':'abged','3':'abgcd','4':'fgbc',
  '5':'afgcd','6':'afgecd','7':'abc','8':'abcdefg','9':'abfgcd'
 }
 positions={
  'a':(0,.255,.285,.042),'g':(0,0,.285,.042),'d':(0,-.255,.285,.042),
  'f':(-.157,.127,.044,.244),'b':(.157,.127,.044,.244),
  'e':(-.157,-.127,.044,.244),'c':(.157,-.127,.044,.244)
 }
 for seg in patterns[number]:
  xx,yy,ww,hh=positions[seg]
  m.box(prefix+'_Seg_'+seg,(ww,hh,.014),(x-xx,y+yy,z),material,group=group)

def output_monitor():
 m=Model('11_VISUAL_3bit_DAC_Output_Monitor');t='L41_DAC_MONITOR'
 chassis(m,t,'DAC OUTPUT','3-BIT ANALOG VOLTAGE',w=4.22,h=1.77,d=2.15,accent='mint')
 m.bevel(t+'_MonitorScreen_Frame',(3.56,.69,.072),(0,1.71,-1.18),'chrome',.061)
 m.bevel(t+'_MonitorScreen_OLED',(3.40,.61,.058),(0,1.71,-1.222),'screen',.055)
 for i,(digit,x) in enumerate(zip('4375',(.91,.27,-.34,-.94))):
  seven_segment_digit(m,t+f'_Value_{i}',digit,x,1.70,-1.278)
 m.cyl(t+'_Decimal_Point',.028,.019,(.62,1.448,-1.282),'screen_green',axis='z',sections=18,group='Reading_StaticReplaceWithRuntime')
 m.text(t+'_VoltageUnit','V',.26,-1.47,1.70,-1.285,'screen_green',maxwidth=.27,group='Reading_StaticReplaceWithRuntime')
 for i in range(8):
  x=-1.54+i*.44
  m.box(t+f'_StepBar_{i}',(.21,.13+i*.06,.045),(x,2.29+i*.03,-.33),'mint' if i<7 else 'amber',group='Bargraph_VISUAL')
 for i in range(8):
  m.box(t+f'_BlueScreenCode_{i}',(.08,.025,.54),(-1.51+i*.40,2.72,.35),'blue',group='DACOutputVisual_ONLY')
 m.text(t+'_Note3Bit','B2 B1 B0  :  111',.144,0,.66,-1.21,'fog',maxwidth=2.9,group='Reading_StaticReplaceWithRuntime')
 return m

def showcase_board():
 m=Model('00_Showcase_Base');t='L41_BOARD'
 m.bevel(t+'_Rubber_Chassis',(25,.16,12.8),(0,.09,0),'rubber',.14)
 m.bevel(t+'_Aluminum_Trim',(24.8,.20,12.62),(0,.21,0),'mid_steel',.12)
 m.bevel(t+'_Panel_Black',(24.61,.067,12.37),(0,.35,0),'graphite',.10)
 for x in (-12.02,12.02):m.box(t+f'_SideAccent_{x}',(.046,.033,11.98),(x,.39,0),'cyan')
 for z in (-5.96,5.96):m.box(t+f'_FrontAccent_{z}',(24.05,.032,.043),(0,.39,z),'cyan')
 for x in np.linspace(-11.7,11.7,39):
  for z in np.linspace(-5.7,5.7,20):m.cyl(t+f'_PegDot_{x:.2f}_{z:.2f}',.012,.004,(x,.388,z),'mid_steel',sections=6)
 # underlights trace routes are art only, NOT actual wires
 for z,col in ((3.37,'amber'),(.03,'mint'),(-3.39,'cyan')):
  m.box(t+f'_Backboard_RowGuide_{z}',(22.05,.025,.047),(0,.398,z),col,group='DecorativeGuide_VISUAL')
 return m

BUILDERS=[
 source,
 lambda:driver('B2','02_B2_Bit_Driver'),
 lambda:driver('B1','03_B1_Bit_Driver'),
 lambda:driver('B0','04_B0_Bit_Driver'),
 lambda:resistor('05_B2_20kOhm_Resistor','B2  /  20 kOhm',20000),
 lambda:resistor('06_B1_20kOhm_Resistor','B1  /  20 kOhm',20000),
 lambda:resistor('07_B0_20kOhm_Resistor','B0  /  20 kOhm',20000),
 lambda:resistor('08_Link21_10kOhm','LINK 21  /  10 kOhm',10000,small=True),
 lambda:resistor('09_Link10_10kOhm','LINK 10  /  10 kOhm',10000,small=True),
 termination, output_monitor]
POSITIONS={
 '00_Showcase_Base':(0,0,0),
 '01_5V_DAC_Reference':(9.72,0,3.76),
 '02_B2_Bit_Driver':(5.37,0,3.76),
 '03_B1_Bit_Driver':(.60,0,3.76),
 '04_B0_Bit_Driver':(-4.18,0,3.76),
 '05_B2_20kOhm_Resistor':(9.55,0,.12),
 '06_B1_20kOhm_Resistor':(5.18,0,.12),
 '07_B0_20kOhm_Resistor':(.77,0,.12),
 '08_Link21_10kOhm':(-4.00,0,.12),
 '09_Link10_10kOhm':(-8.63,0,.12),
 '10_20kOhm_Termination':(8.75,0,-3.91),
 '11_VISUAL_3bit_DAC_Output_Monitor':(1.08,0,-3.91)
}

def build():
 models=[fn() for fn in BUILDERS]
 electrical=models[:10]
 pins=[s for m in electrical for s in m.anchors]
 assert len(models)==11 and len(electrical)==10
 assert len(pins)==16 and len(set(pins))==16, pins
 assert len(WIRES)==9 and all(a in pins and b in pins for _,a,b in WIRES)
 catalog={}
 for m in models:
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m])
  load=trimesh.load_scene(str(glb));assert len(load.geometry)>0,(m.key,'glb load failed')
  catalog[m.key]={
   'fbx':fbx.name,'glb':glb.name,'mesh_objects':len(m.parts),
   'triangles':sum(len(p.mesh.faces) for p in m.parts),
   'terminal_anchors':m.anchors,
   'animation_groups':list(dict.fromkeys(p.group for p in m.parts if p.group!='Static'))}
  print('EXPORTED',m.key,'triangles',catalog[m.key]['triangles'],'meshes',len(m.parts),flush=True)
 assembled=[showcase_board()]+models
 base='Level41_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(base+'.fbx'),assembled,positions=POSITIONS)
 export_glb(MODELS/(base+'.glb'),assembled,positions=POSITIONS)
 assert len(trimesh.load_scene(str(MODELS/(base+'.glb'))).geometry)>0
 catalog[base]={'fbx':base+'.fbx','glb':base+'.glb',
 'triangles':sum(len(p.mesh.faces) for m in assembled for p in m.parts),
 'mesh_objects':sum(len(m.parts) for m in assembled)}
 manifest={'level':41,'name':'Build the Analog Output','circuit':'3-bit R-2R ladder DAC',
  'theme':'Polished semi-HD sci-fi electromechanical training hardware',
  'individual_models':11,'electrical_models':10,'visual_only_models':1,
  'electrical_terminal_anchors':16,'player_wires':9,
  'coordinate_system':'Y-up, model fronts local -Z, art units; use anchor CSV',
  'notes':['Driver supply +5V connections are FIXED internally, not separate player wires.',
  'B1_OUT and B0_OUT each accept TWO user wires; do not invent extra sockets.',
  'The DAC output meter is a VISUAL ONLY reference and has zero electrical sockets.',
  'Static demo readings and bit switches require existing Unity gameplay binding/controllers.'],
  'expected_healthy_sweep':{'000':0,'001':.625,'010':1.25,'011':1.875,'100':2.5,'101':3.125,'110':3.75,'111':4.375},
  'wires':[{'id':w,'from':a,'to':b} for w,a,b in WIRES],
  'positions':POSITIONS,'models':catalog}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['Wire','From','To','Description'])
  for wid,a,b in WIRES:w.writerow([wid,a,b,'User wire; shared B1_OUT / B0_OUT sockets allow multiple cables'])
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['FBX file','Socket ID suggestion','Local X','Local Y','Local Z','Note'])
  for m in electrical:
   for pid,pos in m.anchors.items():w.writerow([m.key+'.fbx',pid,*pos,'Place actual SparkTerminal at this local point; mesh alone not electrical'])
 print('COMPLETE: 11 individual FBX+GLB models, 1 showcase, 16 sockets, W01-W09',flush=True)
 return models

if __name__=='__main__':build()
