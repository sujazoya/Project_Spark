import os, math, json, csv, struct, zlib, zipfile, io, time
from pathlib import Path
import numpy as np
import trimesh
from PIL import Image,ImageDraw,ImageFont

ROOT=Path('/mnt/data/ProjectSpark_Level66_HD_AAA'); (ROOT/'Models').mkdir(parents=True,exist_ok=True); (ROOT/'GLB').mkdir(exist_ok=True); (ROOT/'Previews').mkdir(exist_ok=True); (ROOT/'Unity_Optional').mkdir(exist_ok=True)
NAMES=['IndustrialPredictiveMaintenanceBase','IndustrialThreePhaseMotor','MotorStatorCutaway','MotorRotorShaft','IndustrialGearboxHousing','GearboxGearAssembly','DriveShaftCoupling','DriveEndBearingCartridge','NonDriveEndBearingCartridge','DamagedBearingCartridge','HealthyReplacementBearing','IndustrialConveyorAssembly','ConveyorDriveRoller','VariableFrequencyMotorDrive','MotorCurrentSensorBank','ThreeAxisVibrationSensor','SecondaryVibrationSensor','PrecisionShaftEncoder','BearingTemperatureProbe','MotorTemperatureProbe','InfraredThermalCamera','LubricationMonitoringModule','ShaftAlignmentSensor','GearWearSensorModule','VibrationFFTAnalyzer','ConditionMonitoringController','PredictiveMaintenanceAIUnit','IndustrialDigitalTwinDisplay','MotorProtectionRelay','MaintenancePLCRack','DigitalInputOutputModule','BearingRemovalTool','PrecisionAlignmentGauge','IndustrialTorqueTool','MaintenancePartsStorageRack','ActiveCoolingAssembly','EmergencyStopAndLockoutPanel','HolographicDiagnosticMonitor','TransparentMachineSafetyEnclosure','Regulated5VControlSupply']
C={
'dark':(26,42,58,255),'navy':(19,35,57,255),'steel':(77,101,118,255),'silver':(164,184,196,255),'chrome':(207,220,226,255),'blue':(21,103,184,255),'cyan':(25,204,239,255),'teal':(24,144,162,255),'gold':(220,156,47,255),'copper':(227,108,39,255),'orange':(251,144,35,255),'red':(218,53,53,255),'green':(39,214,128,255),'yellow':(255,206,52,255),'glass':(73,139,168,100),'rubber':(29,35,42,255),'white':(226,236,239,255),'rust':(124,67,35,255),'screen':(7,36,56,255), 'black':(12,20,28,255)}
MODULES={}
class Part:
 def __init__(self,mesh,color,name,pivot=None): self.mesh=mesh;self.color=color;self.name=name;self.pivot=pivot
parts=[]; current=''; pivots={}
def push(mesh,c='steel',name='',pivot=None):
 if mesh is None:return
 if not isinstance(mesh,trimesh.Trimesh):return
 if len(mesh.faces)==0:return
 mesh=mesh.copy(); mesh.remove_unreferenced_vertices();parts.append(Part(mesh,c,name or c,pivot))
def box(pos,size,c='steel',name='',pivot=None):
 m=trimesh.creation.box(extents=size);m.apply_translation(pos);push(m,c,name,pivot)
def cyl(pos,r,length,axis='y',c='steel',sections=20,name='',pivot=None):
 m=trimesh.creation.cylinder(radius=r,height=length,sections=sections)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='z':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
 m.apply_translation(pos);push(m,c,name,pivot)
def sphere(pos,r,c='steel',sub=1,name=''):
 m=trimesh.creation.icosphere(subdivisions=sub,radius=r);m.apply_translation(pos);push(m,c,name)
def pipe(a,b,r,c='steel',sections=10,name='',pivot=None):
 a=np.array(a);b=np.array(b);d=b-a;L=np.linalg.norm(d)
 if L<1e-6:return
 m=trimesh.creation.cylinder(radius=r,height=L,sections=sections);m.apply_transform(trimesh.geometry.align_vectors([0,0,1],d/L));m.apply_translation((a+b)/2);push(m,c,name,pivot)
def ring(pos,outer,inner,length,axis='x',c='silver',sections=24,name='',pivot=None):
 # mesh hollow by annulus extruded local Z, transform orientation
 verts=[];faces=[]
 for z in [-length/2,length/2]:
  for r in [outer,inner]:
   for k in range(sections):
    t=2*math.pi*k/sections;verts.append([r*math.cos(t),r*math.sin(t),z])
 for k in range(sections):
  j=(k+1)%sections
  for a,b,c_,d in [(k,j,2*sections+j,2*sections+k),(sections+j,sections+k,3*sections+k,3*sections+j),(2*sections+k,2*sections+j,3*sections+j,3*sections+k),(j,k,sections+k,sections+j)]:faces.extend([(a,b,c_),(a,c_,d)])
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
 m.apply_translation(pos);push(m,c,name,pivot)
def gear(pos,r,width,teeth=18,axis='x',c='gold',pivot=None):
 cyl(pos,r*.82,width,axis,c,32,'GearCore',pivot)
 for k in range(teeth):
  a=2*math.pi*k/teeth
  if axis=='x':p=(pos[0],pos[1]+r*math.cos(a),pos[2]+r*math.sin(a));size=(width*.93,r*.27,r*.23);rot='x'
  elif axis=='y':p=(pos[0]+r*math.cos(a),pos[1],pos[2]+r*math.sin(a));size=(r*.25,width*.93,r*.27);rot='y'
  else:p=(pos[0]+r*math.cos(a),pos[1]+r*math.sin(a),pos[2]);size=(r*.25,r*.27,width*.93);rot='z'
  m=trimesh.creation.box(extents=size)
  if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(a,[1,0,0]))
  elif axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
  else:m.apply_transform(trimesh.transformations.rotation_matrix(a,[0,0,1]))
  m.apply_translation(p);push(m,c,'GearTooth',pivot)
 cyl(pos,r*.22,width+.04,axis,'chrome',20,'GearHub',pivot)
def bolt_line(pos,half_x,half_z,y,size=.07):
 x,y0,z=pos
 for dx in [-half_x,half_x]:
  for dz in [-half_z,half_z]:cyl((x+dx,y0,z+dz),size,.055,'y','chrome',10)
def leds(x,y,z,n=5,step=.16,colors=None):
 for i in range(n): sphere((x+i*step,y,z),.052,(colors or ['green','cyan','yellow','red'])[i%4],1)
def panel(pos,size,name='',screen=True,led=True):
 x,y,z=pos; box(pos,size,'dark','Enclosure');box((x,y,z+size[2]/2+.018),(size[0]*.9,size[1]*.88,.035),'steel','Faceplate')
 if screen:box((x,y+.12,z+size[2]/2+.048),(size[0]*.71,size[1]*.38,.025),'screen','Display');box((x,y+.12,z+size[2]/2+.065),(size[0]*.57,.028,.008),'cyan','DisplayCurve')
 if led:leds(x-size[0]*.32,y-size[1]*.29,z+size[2]/2+.065,min(5,max(2,int(size[0]*5))),max(.115,size[0]*.13))
 for dx in [-size[0]*.41,size[0]*.41]:
  for dy in [-size[1]*.39,size[1]*.39]:cyl((x+dx,y+dy,z+size[2]/2+.052),.025,.04,'z','silver',10)
def support(x,z,y=1.20):box((x,y-.27,z),(.16,.55,.16),'steel');box((x,y-.55,z),(.45,.10,.36),'dark')
def bearing(pos,damaged=False,replacement=False):
 x,y,z=pos
 col='rust' if damaged else 'chrome'
 ring(pos,.49,.30,.24,'x',col,32,'OuterRace')
 ring(pos,.33,.19,.28,'x','rust' if damaged else 'silver',32,'InnerRace')
 for k in range(12):
  a=2*math.pi*k/12;p=(x,y+.39*math.cos(a),z+.39*math.sin(a));sphere(p,.07,'rust' if damaged and k%4==0 else 'chrome',1,'Ball')
 if damaged:
  for k in range(4):
   a=k*1.33;box((x+.15,y+.48*math.cos(a),z+.48*math.sin(a)),(.08,.09,.08),'red','DamageMark')
 if replacement:box((x,y-.58,z),(.95,.11,.74),'green','NewPartTray')
def conveyor(x1,x2,z=0.2,y=1.35):
 mid=(x1+x2)/2;length=x2-x1
 box((mid,y-.18,z),(length,.16,1.18),'dark','ConveyorFrame')
 box((mid,y,z),(length-.16,.07,.98),'rubber','BeltTop')
 for x in np.arange(x1+.3,x2-.2,.38):cyl((float(x),y-.04,z),.105,.99,'z','chrome',12,'Roller')
 for z1 in [z-.63,z+.63]:box((mid,y+.06,z1),(length,.13,.09),'silver','GuideRail')
 for x in [x1+.3,x2-.3]:
  for zz in [z-.46,z+.46]:support(x,zz,y-.26)
def sensor(pos,color='cyan'):
 x,y,z=pos;box(pos,(.31,.3,.25),'dark');box((x,y,z+.135),(.20,.18,.035),color);cyl((x,y,z+.16),.045,.028,'z','chrome',12)
def motor(cx=-3.8,cy=1.53,cz=-.05):
 global pivots
 pivots['ANIM_MOTOR_ROTOR']=(cx+1.02,cy,cz)
 cyl((cx,cy,cz),.72,1.42,'x','blue',40,'MotorBody')
 for k in range(24):
  a=k*2*math.pi/24; y=cy+.735*math.cos(a);z=cz+.735*math.sin(a)
  m=trimesh.creation.box(extents=(1.20,.14,.10));m.apply_transform(trimesh.transformations.rotation_matrix(a,[1,0,0]));m.apply_translation((cx,y,z));push(m,'steel','CoolingFin')
 cyl((cx-.74,cy,cz),.77,.13,'x','dark',32,'RearEndCap');cyl((cx+.74,cy,cz),.76,.12,'x','silver',32,'FrontEndCap')
 cyl((cx-.87,cy,cz),.51,.055,'x','navy',32,'FanGrille')
 for k in range(10):
  a=k*2*math.pi/10;pipe((cx-.91,cy+.1*math.cos(a),cz+.1*math.sin(a)),(cx-.91,cy+.48*math.cos(a),cz+.48*math.sin(a)),.024,'chrome')
 box((cx,cy-.78,cz),(.82,.16,.86),'steel','MotorFoot');box((cx,cy-.9,cz),(1.1,.16,1.22),'dark','Mount')
 box((cx,cy+.49,cz+.66),(.63,.40,.36),'blue','TerminalBox');box((cx,cy+.49,cz+.855),(.54,.30,.03),'yellow','WarningPanel')
 cyl((cx+1.02,cy,cz),.15,.53,'x','chrome',20,'MotorShaft', 'ANIM_MOTOR_ROTOR')
 for x in [cx-.58,cx+.58]:bolt_line((x,cy-.85,cz),.3,.32,cy-.85)

def make(i):
 global parts,pivots
 parts=[];pivots={};name=NAMES[i]
 # machine origin x motor -3.8, gearbox -1.0, conveyor 1.5:5
 if i==0:
  box((0,.37,0),(12.8,.42,5.35),'navy','BasePlate');box((0,.60,0),(12.55,.065,5.08),'steel','BenchDeck')
  for x in np.arange(-6,6.2,.38):box((float(x),.66,2.55),(.035,.035,.06),'cyan','FrontLED')
  for x in [-5.9,5.9]:
   for z in [-2.26,2.26]:box((x,.08,z),(.45,.22,.45),'dark','Foot')
  for x in [-5.65,-2.7,.45,3.6,5.6]:
   for z in [-2.1,2.1]:cyl((x,.70,z),.066,.03,'y','chrome',12)
  box((-1.25,.91,-.25),(8.55,.25,2.34),'steel','MachineSupport');box((-1.25,1.065,-.25),(8.0,.06,1.9),'dark','IsolationPad')
  box((4.4,.8,1.8),(2.7,.22,1.2),'steel','DiagnosticConsole');box((-4.7,.85,1.9),(2.4,.22,1.2),'steel','MaintenanceTray')
  box((0,.55,2.64),(11.9,.07,.045),'cyan','LightStrip')
 elif i==1:motor()
 elif i==2:
  cx,cy,cz=-3.8,1.53,-.05
  ring((cx,cy,cz),.68,.52,1.37,'x','blue',32,'StatorShell');ring((cx,cy,cz),.52,.40,1.35,'x','copper',32,'CopperWinding')
  for k in range(18):
   a=k*math.pi*2/18;cyl((cx-.60,cy+.45*math.cos(a),cz+.45*math.sin(a)),.042,1.3,'x','orange',10,'Coil')
  for xx in [cx-.68,cx+.68]:ring((xx,cy,cz),.78,.61,.08,'x','chrome',32)
 elif i==3:
  cx,cy,cz=-2.75,1.53,-.05;cyl((cx,cy,cz),.25,1.75,'x','chrome',32,'RotorShaft','ANIM_MOTOR_ROTOR')
  cyl((cx-.12,cy,cz),.52,1.24,'x','steel',28,'RotorLamination','ANIM_MOTOR_ROTOR')
  for xx in np.arange(cx-.65,cx+.5,.18):ring((float(xx),cy,cz),.54,.47,.042,'x','silver',22,'RotorPlate','ANIM_MOTOR_ROTOR')
  cyl((cx+.81,cy,cz),.22,.28,'x','gold',24,'ShaftEnd','ANIM_MOTOR_ROTOR')
  pivots['ANIM_MOTOR_ROTOR']=(cx,cy,cz)
 elif i==4:
  cx,cy,cz=-.9,1.52,-.05
  box((cx,cy-.52,cz),(2.5,.2,1.75),'steel','GearboxPedestal')
  for dy in [-.38,.38]:
   for dz in [-.69,.69]:box((cx,cy+dy,cz+dz),(2.44,.08,.07),'chrome','AcrylicFrame')
  for dx in [-1.16,1.16]:
   for dz in [-.69,.69]:box((cx+dx,cy,cz+dz),(.09,1.56,.085),'chrome','CornerColumn')
  for dx in [-1.18,1.18]:
   box((cx+dx,cy,cz),(.06,1.58,1.45),'glass','TransparentEnd')
  for dz in [-.75,.75]:box((cx,cy,cz+dz),(2.46,1.58,.055),'glass','TransparentWall')
  box((cx,cy+.79,cz),(2.49,.10,1.55),'silver','TopCover','ANIM_GEARBOX_COVER');pivots['ANIM_GEARBOX_COVER']=(cx-1.15,cy+.79,cz);bolt_line((cx,cy+.85,cz),1.04,.62,cy+.85)
  cyl((cx+1.22,cy,cz),.35,.12,'x','chrome',28,'ShaftPort')
 elif i==5:
  cx,cy,cz=-.9,1.53,-.05
  gear((cx-.66,cy,cz),.53,.31,20,'x','gold','ANIM_GEARBOX_GEARS')
  gear((cx+.13,cy+.40,cz),.35,.28,16,'x','copper','ANIM_GEARBOX_GEARS')
  gear((cx+.68,cy-.20,cz),.44,.25,18,'x','gold','ANIM_GEARBOX_GEARS')
  for x,y in [(-1.56,cy),(-.77,cy+.4),(-.22,cy-.2)]:cyl((x,y,cz),.12,.55,'x','steel',18,'GearAxle','ANIM_GEARBOX_GEARS')
  pivots['ANIM_GEARBOX_GEARS']=(-1.56,cy,cz)
 elif i==6:
  x,y,z=-2.35,1.53,-.05
  cyl((x,y,z),.25,.86,'x','silver',26,'CouplerBody','ANIM_SHAFT_COUPLING')
  for dx in [-.30,.30]:ring((x+dx,y,z),.43,.17,.13,'x','chrome',26,'CouplerFlange','ANIM_SHAFT_COUPLING')
  for a in np.arange(0,2*math.pi,math.pi/3):pipe((x-.32,y+.32*math.cos(a),z+.32*math.sin(a)),(x+.32,y+.32*math.cos(a),z+.32*math.sin(a)),.065,'red',12,'FlexibleElement')
  pivots['ANIM_SHAFT_COUPLING']=(x,y,z)
 elif i in [7,8,9,10]:
  p={7:(-2.8,1.48,-.11),8:(-3.95,1.48,-.11),9:(-4.4,.87,1.77),10:(-3.38,.87,1.77)}[i];bearing(p,damaged=i==9,replacement=i==10)
  if i in [7,8]:box((p[0],p[1]-.53,p[2]),(.65,.19,.82),'dark','BearingBlock')
 elif i==11:
  conveyor(1.10,5.47,z=.15,y=1.53)
  for x in [1.2,2.2,3.2,4.2]:box((x,1.65,.15),(.22,.015,.92),'steel','BeltTexture')
 elif i==12:
  x,y,z=1.3,1.42,.15;cyl((x,y,z),.33,1.20,'z','rubber',28,'DriveRoller','ANIM_CONVEYOR_ROLLER')
  for zz in np.arange(-.40,.51,.16):ring((x,y,float(z+zz)),.338,.30,.032,'z','steel',20,'RollerRib','ANIM_CONVEYOR_ROLLER')
  cyl((x,y,z),.105,1.52,'z','chrome',20,'RollerAxle','ANIM_CONVEYOR_ROLLER');pivots['ANIM_CONVEYOR_ROLLER']=(x,y,z)
 elif i==13:panel((-5.48,1.86,-1.60),(.87,1.40,.46),'VFD');box((-5.48,2.61,-1.60),(.92,.13,.52),'blue')
 elif i==14:
  panel((-4.32,1.83,-1.60),(1.00,1.11,.48),'CurrentSensors')
  for xx in [-4.59,-4.32,-4.05]:ring((xx,1.63,-1.21),.115,.074,.10,'z','blue',16)
 elif i in [15,16]:
  p={15:(-1.60,1.94,.80),16:(-.44,1.83,.80)}[i];sensor(p,'cyan' if i==15 else 'orange')
  for k in range(3 if i==15 else 1):pipe((p[0],p[1]-.12,p[2]),(p[0]+.12*k,p[1]-.44,p[2]+.16),.024,'yellow',8,'SensorCable')
 elif i==17:
  x,y,z=-2.62,1.53,.54;box((x,y,z),(.38,.37,.38),'blue');cyl((x,y,z+.24),.17,.13,'z','chrome');cyl((x,y,z+.32),.12,.045,'z','cyan',24,'EncoderDisc','ANIM_ENCODER_DISC');pivots['ANIM_ENCODER_DISC']=(x,y,z+.32)
 elif i in [18,19]:
  x,y,z=(-1.15,2.11,.52) if i==18 else (-3.33,2.28,.55)
  cyl((x,y,z),.070,.37,'y','chrome',12,'TempProbe');box((x,y+.22,z),(.19,.20,.16),'steel');pipe((x,y+.3,z),(x+.42,y+.5,z+.35),.025,'yellow',8)
 elif i==20:
  x,y,z=2.54,2.41,-1.04;box((x,y,z),(.47,.36,.40),'yellow');cyl((x,y,z+.28),.14,.18,'z','dark');cyl((x,y,z+.36),.082,.045,'z','purple' if 'purple' in C else 'cyan');box((x,1.9,z),(.13,.97,.13),'steel')
 elif i==21:
  x,y,z=-.05,.95,-1.72;box((x,y,z),(.72,.70,.65),'steel');cyl((x,1.32,z),.22,.22,'y','gold');cyl((x,1.48,z),.11,.18,'y','silver');pipe((x+.18,1.0,z),(.35,1.23,-1.52),.048,'orange')
 elif i==22:
  for x in [-2.1,-1.6]:sensor((x,1.21,-.94),'green')
  pipe((-2.1,1.21,-.94),(-1.6,1.21,-.94),.02,'cyan')
 elif i==23:panel((.65,1.05,-1.74),(.72,.65,.40),'GearWear')
 elif i in [24,25,26,28,29,30,37,39]:
  loc={24:(-4.9,.98,1.85),25:(-3.85,.97,1.85),26:(-2.8,.97,1.85),28:(-5.55,1.57,-1.9),29:(-4.0,1.95,-1.98),30:(-2.65,1.55,-1.9),37:(3.9,1.23,1.72),39:(5.30,.98,1.83)}[i]
  size={24:(.90,.74,.52),25:(.92,.74,.52),26:(.91,.74,.52),28:(.90,1.05,.56),29:(1.38,1.75,.62),30:(1.02,1.08,.56),37:(2.13,1.05,.42),39:(.94,.79,.53)}[i]
  panel(loc,size,NAMES[i]);
  if i in [24,25]:
   for j in range(7):box((loc[0]-.30+j*.1,loc[1]+.09+math.sin(j)*.12,loc[2]+size[2]/2+.091),(.03,.06+abs(math.sin(j))*.15,.015),'red' if i==24 else 'cyan','DataGraph')
  if i==29:
   for r in range(2):
    for k in range(5):box((loc[0]-.5+k*.245,loc[1]-.31+r*.38,loc[2]+size[2]/2+.084),(.18,.28,.055),'blue' if k%2 else 'steel','PLCCard')
  if i==37:
   box((loc[0],loc[1]+.07,loc[2]+size[2]/2+.064),(1.72,.52,.05),'screen');leds(loc[0]-.55,loc[1]+.10,loc[2]+size[2]/2+.12,6,.23)
 elif i==27:
  x,y,z=3.65,3.2,-1.52
  pivots['ANIM_TWIN_MONITOR']=(x, y, z);box((x,y,z),(3.1,1.75,.14),'steel','TwinMonitorFrame','ANIM_TWIN_MONITOR');box((x,y,z+.085),(2.94,1.59,.04),'screen','TwinScreen','ANIM_TWIN_MONITOR')
  cyl((x,2.15,z),.095,.62,'y','steel');box((x,1.85,z),(.90,.12,.5),'dark')
  for k in range(12):
   xx=x-1.21+k*.22;box((xx,y-.53+.12*math.sin(k),z+.119),(.06,.1+abs(math.sin(k))*.23,.025),'cyan','HealthGraph')
  for k in range(6):box((x+.50+k*.16,y+.46,z+.119),(.10,.12,.018),'green' if k<4 else 'red','TwinIndicators')
 elif i==31:
  x,y,z=-4.25,.94,1.92
  box((x,y,z),(1.15,.14,.95),'steel','ToolTray');cyl((x,y+.36,z),.12,.68,'y','chrome',18,'PullerScrew','ANIM_BEARING_EXTRACTOR')
  for dx in [-.33,.33]:
   pipe((x,y+.47,z),(x+dx,y+.16,z),.085,'silver',14,'PullerArm','ANIM_BEARING_EXTRACTOR');pipe((x+dx,y+.16,z),(x+dx*.80,y-.06,z),.052,'silver')
  pivots['ANIM_BEARING_EXTRACTOR']=(x,y+.36,z)
 elif i==32:
  x,y,z=-2.78,.91,1.89;box((x,y,z),(.66,.16,.55),'black');box((x,y+.12,z),(.44,.09,.39),'yellow');box((x,y+.18,z+.23),(.30,.085,.02),'screen')
  for k in range(4):box((x-.15+.1*k,y+.18,z+.245),(.05,.028,.02),'cyan')
 elif i==33:
  x,y,z=-1.72,.94,1.98
  pipe((x-.54,y,z),(x+.54,y,z),.085,'silver',14,'TorqueHandle');cyl((x+.5,y,z),.12,.25,'x','gold');box((x-.60,y,z),(.12,.23,.30),'dark')
 elif i==34:
  x,y,z=-.08,1.45,-1.8
  for xx in [-.9,.9]:box((x+xx,y,z),(.095,1.51,.65),'blue')
  for yy in [.79,1.47,2.12]:box((x,yy,z),(2.07,.09,.72),'steel')
  for xx in [-.64,0,.64]:
   for yy in [1.06,1.73]:box((x+xx,yy,z),(.46,.28,.45),'yellow' if yy>1.5 else 'steel','PartsBox')
 elif i==35:
  x,y,z=-5.37,1.72,.65
  box((x,y,z),(1.12,1.05,.53),'steel','Radiator')
  for xx in [-.32,.32]:
   ring((x+xx,y,z+.31),.26,.19,.08,'z','dark',24,'FanFrame')
   for k in range(6):
    a=k*math.pi/3;box((x+xx+.12*math.cos(a),y+.12*math.sin(a),z+.39),(.12,.06,.04),'silver','FanBlade','ANIM_COOLING_FANS')
  pivots['ANIM_COOLING_FANS']=(x-.32,y,z+.39)
 elif i==36:
  x,y,z=5.25,1.06,1.82
  box((x,y,z),(.89,.74,.45),'yellow');box((x,y,z+.255),(.67,.56,.045),'red');cyl((x,y+.18,z+.29),.17,.13,'z','red',24,'Estop','ANIM_EMERGENCY_STOP');pivots['ANIM_EMERGENCY_STOP']=(x,y+.18,z+.29)
  box((x-.20,y-.13,z+.30),(.12,.11,.05),'black')
 elif i==38:
  x,y,z=-.30,2.45,-.08
  for xx in [-2.63,2.0]:
   for zz in [-1.34,1.35]:box((x+xx,y-.35,zz),(.095,2.35,.095),'chrome','SafetyPost')
  for zz in [-1.34,1.35]:
   box((x-.3,3.29,zz),(4.78,.10,.10),'chrome','SafetyTopRail');box((x-.3,2.16,zz),(4.7,1.95,.045),'glass','PolycarbonateWall')
  box((x+1.98,2.20,.08),(.08,1.85,2.45),'glass','SafetyDoor','ANIM_SAFETY_DOOR')
  pivots['ANIM_SAFETY_DOOR']=(x+1.98,2.20,.08)
 return parts,pivots

# FBX binary 7400 writer
class Node:
 def __init__(self,name,*props,children=None):self.name=name;self.props=list(props);self.children=children or []
class Prop:
 def __init__(self,typ,data):self.typ=typ;self.data=data

def encodeprop(p):
 if isinstance(p,Prop):
  if p.typ=='d':
   arr=np.asarray(p.data,dtype='<f8').tobytes();return b'd'+struct.pack('<III',len(p.data),0,len(arr))+arr
  if p.typ=='i':
   arr=np.asarray(p.data,dtype='<i4').tobytes();return b'i'+struct.pack('<III',len(p.data),0,len(arr))+arr
  raise Exception('prop')
 if isinstance(p,str):b=p.encode('utf-8');return b'S'+struct.pack('<I',len(b))+b
 if isinstance(p,bool):return b'C'+struct.pack('<?',p)
 if isinstance(p,int):return b'L'+struct.pack('<q',p)
 if isinstance(p,float):return b'D'+struct.pack('<d',p)
 raise TypeError(type(p))

def emit(node,start):
 name=node.name.encode();props=b''.join(map(encodeprop,node.props));head=13+len(name)+len(props)
 childstart=start+head;childdata=b''
 for ch in node.children:
  out=emit(ch,childstart+len(childdata));childdata+=out
 if node.children:childdata+=b'\x00'*13
 end=start+head+len(childdata)
 return struct.pack('<IIIb',end,len(node.props),len(props),len(name))+name+props+childdata

def p3(key,a,b,c):return Node('P',key,'Vector3D','Vector','','',float(a),float(b),float(c))
def pnum(key,v):return Node('P',key,'double','Number','',float(v))
def mesh_node(gid,name,mesh):
 v=mesh.vertices.astype('float64').flatten().tolist();faces=mesh.faces
 poly=np.column_stack([faces[:,0],faces[:,1],-(faces[:,2]+1)]).astype('int32').flatten().tolist()
 return Node('Geometry',gid, 'Geometry::'+name,'Mesh',children=[Node('Vertices',Prop('d',v)),Node('PolygonVertexIndex',Prop('i',poly)),Node('LayerElementNormal',0,children=[Node('Version',101),Node('Name',''),Node('MappingInformationType','ByPolygonVertex'),Node('ReferenceInformationType','Direct'),Node('Normals',Prop('d',mesh.face_normals.repeat(3,axis=0).flatten().tolist()))]),Node('LayerElementMaterial',0,children=[Node('Version',101),Node('Name',''),Node('MappingInformationType','AllSame'),Node('ReferenceInformationType','IndexToDirect'),Node('Materials',Prop('i',[0]))]),Node('Layer',0,children=[Node('Version',100),Node('LayerElement',children=[Node('Type','LayerElementNormal'),Node('TypedIndex',0)]),Node('LayerElement',children=[Node('Type','LayerElementMaterial'),Node('TypedIndex',0)])])])
def model_node(mid,name,typ='Mesh',pos=(0,0,0)):
 return Node('Model',mid,'Model::'+name,typ,children=[Node('Version',232),Node('Properties70',children=[Node('P','Lcl Translation','Lcl Translation','','A',*map(float,pos)),Node('P','Lcl Rotation','Lcl Rotation','','A',0.,0.,0.),Node('P','Lcl Scaling','Lcl Scaling','','A',1.,1.,1.)]),Node('Shading',True),Node('Culling','CullingOff')])
def material_node(mid,c):
 rgb=[x/255 for x in C[c][:3]]
 return Node('Material',mid,'Material::'+c,'',children=[Node('Version',102),Node('ShadingModel','phong'),Node('MultiLayer',False),Node('Properties70',children=[Node('P','DiffuseColor','Color','','A',*rgb),Node('P','AmbientColor','Color','','A',*(x*.25 for x in rgb)),Node('P','SpecularColor','Color','','A',.48,.51,.54),Node('P','Shininess','double','Number','A',50.),Node('P','Opacity','double','Number','A',C[c][3]/255.)])])
def fbx_export(parts,pivots,path,modelname):
 # group all static parts by color, and animated parts by pivot/color
 groups={}
 for p in parts:groups.setdefault((p.pivot,p.color),[]).append(p.mesh)
 objects=[];connections=[];nid=100000;rootid=nid;nid+=1
 connections.append(Node('C','OO',rootid,0))
 objects.append(model_node(rootid,modelname,'Null'))
 matids={}
 for c in sorted(set(p.color for p in parts)):
  matids[c]=nid;objects.append(material_node(nid,c));nid+=1
 pids={}
 for name,xyz in pivots.items():
  pids[name]=nid;objects.append(model_node(nid,name,'Null',xyz));connections.append(Node('C','OO',nid,rootid));nid+=1
 for k,(pivot,col) in enumerate(sorted(groups,key=lambda v:(v[0] or '',v[1]))):
  mesh=trimesh.util.concatenate(groups[(pivot,col)])
  if pivot is not None and pivot in pivots:mesh.apply_translation(-np.array(pivots[pivot]))
  geomid=nid;nid+=1;modelid=nid;nid+=1
  partname='L66_'+str(k).zfill(3)+'_'+col+('_'+pivot if pivot else '')
  objects.append(mesh_node(geomid,partname,mesh));objects.append(model_node(modelid,partname))
  connections.extend([Node('C','OO',geomid,modelid),Node('C','OO',modelid,pids.get(pivot,rootid)),Node('C','OO',matids[col],modelid)])
 head=[Node('FBXHeaderExtension',children=[Node('FBXHeaderVersion',1003),Node('FBXVersion',7400),Node('Creator','Project Spark Procedural FBX Geometry Exporter')]),Node('GlobalSettings',children=[Node('Version',1000),Node('Properties70',children=[Node('P','UpAxis','int','Integer','',1),Node('P','UpAxisSign','int','Integer','',1),Node('P','FrontAxis','int','Integer','',2),Node('P','FrontAxisSign','int','Integer','',1),Node('P','CoordAxis','int','Integer','',0),Node('P','CoordAxisSign','int','Integer','',1),Node('P','UnitScaleFactor','double','Number','',100.)])]),Node('Documents',children=[Node('Count',1),Node('Document',12345,'Scene','Scene',children=[Node('Properties70',children=[Node('P','SourceObject','object','',''),Node('P','ActiveAnimStackName','KString','','','')]),Node('RootNode',0)])]),Node('Definitions',children=[Node('Version',100),Node('Count',len(objects)),Node('ObjectType','Model',children=[Node('Count',1+len(groups)+len(pids))]),Node('ObjectType','Geometry',children=[Node('Count',len(groups))]),Node('ObjectType','Material',children=[Node('Count',len(matids))])]),Node('Objects',children=objects),Node('Connections',children=connections),Node('Takes',children=[Node('Current','')])]
 h=b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400)
 blob=bytearray(h)
 for node in head:blob.extend(emit(node,len(blob)))
 blob.extend(b'\x00'*13)
 # FBX trailing file footer
 blob.extend(b'\0' * 16)
 blob.extend(struct.pack('<I',7400))
 blob.extend(b'\0'*120)
 blob.extend(b'\xf8\x5a\x8c\x6a\xde\xf5\xd9\x7e\xec\xe9\x0c\xe3\x75\x8f\x29\x0b')
 path.write_bytes(blob)
 return len(blob)

def glb_export(parts,pivots,path):
 sc=trimesh.Scene()
 for k,part in enumerate(parts):
  m=part.mesh.copy();m.visual.face_colors=np.tile(np.array(C[part.color],dtype=np.uint8),(len(m.faces),1));sc.add_geometry(m,geom_name='part_'+str(k)+'_'+part.name.replace(' ','_'),node_name='part_'+str(k))
 sc.export(str(path),file_type='glb')

def grouped_for_scene(parts):
 groups={}
 for p in parts:groups.setdefault(p.color,[]).append(p.mesh)
 output=[]
 for c,arr in groups.items():
  m=trimesh.util.concatenate(arr);m.visual.face_colors=np.tile(C[c],(len(m.faces),1));output.append((c,m))
 return output

if __name__=='__main__':
 allparts=[];records=[];rigs=[]
 for i,name in enumerate(NAMES):
  pp,pv=make(i);pp=list(pp);pv=dict(pv)
  allparts.extend(pp)
  file=f'{i:02d}_L66_{name}.fbx';glb=f'{i:02d}_L66_{name}.glb'
  fbsize=fbx_export(pp,pv,ROOT/'Models'/file,'L66_'+name)
  glb_export(pp,pv,ROOT/'GLB'/glb)
  triangles=sum(len(p.mesh.faces) for p in pp)
  records.append(dict(file=file,glb=glb,name='L66_'+name,triangle_count=triangles,mesh_parts=len(pp),animation_pivots={k:list(v) for k,v in pv.items()}))
  for pname,xyz in pv.items():rigs.append([name,pname,*xyz,'Follow authoritative state; art pivot not gameplay physics'])
  print(i+1,name,triangles,len(pp),fbsize,flush=True)
 manifest={'level_id':'level_66','display_name':'Save the Factory','asset_kind':'procedural 3D art only, no gameplay','individual_models':40,'planned_player_wires':70,'planned_unique_sockets':110,'real_terminals_included':False,'physics_included':False,'coordinate_system':'X bench width, Y up, Z front; 1 length unit = 1 Unity unit at scale 1','models':records,'triangle_count':sum(d['triangle_count'] for d in records)}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['model','pivot_name','world_x','world_y','world_z','usage']);w.writerows(rigs)
 fbx_export(allparts,{},ROOT/'Models'/'Level66_Complete_ArtKit_Showcase.fbx','L66_Complete_ArtKit_Showcase')
 glb_export(allparts,{},ROOT/'GLB'/'Level66_Complete_ArtKit_Showcase.glb')
 print('FINAL',sum(d['triangle_count'] for d in records),'pivots',len(rigs),flush=True)
