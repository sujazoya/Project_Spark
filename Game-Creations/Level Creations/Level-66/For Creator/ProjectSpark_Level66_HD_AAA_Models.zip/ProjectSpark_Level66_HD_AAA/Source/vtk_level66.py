import sys
import numpy as np
from pathlib import Path
import importlib.util
import vtk
from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray
spec=importlib.util.spec_from_file_location('l66','/mnt/data/build_level66.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ren=vtk.vtkRenderer();ren.SetBackground(.012,.028,.052)
for i in range(40):
 pp,_=b.make(i)
 for col,mesh in b.grouped_for_scene(pp):
  if col=='glass':continue
  points=vtk.vtkPoints();points.SetData(numpy_to_vtk(np.ascontiguousarray(mesh.vertices.astype('float32')),deep=True));tri=vtk.vtkCellArray();f=mesh.faces.astype('int64');idx=np.hstack((np.full((len(f),1),3,dtype='int64'),f)).ravel();tri.SetCells(len(f),numpy_to_vtkIdTypeArray(idx,deep=True));poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(tri);mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(poly);actor=vtk.vtkActor();actor.SetMapper(mapper)
  rgb=b.C[col];actor.GetProperty().SetColor(*[v/255 for v in rgb[:3]]);actor.GetProperty().SetInterpolationToPhong();actor.GetProperty().SetSpecular(.22);actor.GetProperty().SetSpecularPower(24);ren.AddActor(actor)
cam=ren.GetActiveCamera();cam.SetPosition(13,9.5,16);cam.SetFocalPoint(0,1.38,0);cam.SetViewUp(0,1,0);cam.ParallelProjectionOn();cam.SetParallelScale(5.3)
win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1600,900);win.AddRenderer(ren);win.SetMultiSamples(4);ren.ResetCameraClippingRange()
print('rendering',flush=True)
win.Render()
w=vtk.vtkWindowToImageFilter();w.SetInput(win);w.Update();out=vtk.vtkPNGWriter();out.SetFileName('/mnt/data/ProjectSpark_Level66_HD_AAA/Previews/Level66_VTK_Render.png');out.SetInputConnection(w.GetOutputPort());out.Write();print('DONE')
