from pathlib import Path
import numpy as np, math
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import importlib.util
spec=importlib.util.spec_from_file_location('l66','/mnt/data/build_level66.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ROOT=b.ROOT
fontroot='/usr/share/fonts/truetype/dejavu/'
def font(n,bold=False):return ImageFont.truetype(fontroot+('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'),n)
right=np.array([.875,0,-.484]);down=np.array([.25,-.87,.452]);depth=np.array([.44,.49,.75]);light=np.array([-.32,.76,.57]);light/=np.linalg.norm(light)
def polygons(parts):
 P=[]
 for p in parts:
  m=p.mesh;v=m.vertices;proj=np.stack([v@right,v@down],axis=1);z=v@depth;faces=m.faces;n=m.face_normals
  base=b.C[p.color]
  for j,f in enumerate(faces):
   pts=proj[f];zz=np.mean(z[f]);sh=.60+.36*max(0,float(n[j]@light))
   col=tuple(min(255,int(x*sh+7)) for x in base[:3])
   alpha=70 if p.color=='glass' else 255
   P.append((zz,pts,col,alpha))
 return sorted(P,key=lambda t:t[0])
def paint(W,H,P,xoff,yoff,scale,background=True):
 if background:
  ys=np.linspace(0,1,H)[:,None,None];base=np.array([7,20,35])[None,None,:]*(1-ys)+np.array([12,36,55])[None,None,:]*ys
  arr=np.repeat(np.clip(base,0,255).astype('uint8'),W,axis=1)
  im=Image.fromarray(arr,'RGB').convert('RGBA')
 else: im=Image.new('RGBA',(W,H),(8,23,39,255))
 draw=ImageDraw.Draw(im,'RGBA')
 for _,pts,col,alpha in P:
  xy=[(int(xoff+x*scale),int(yoff+y*scale)) for x,y in pts]
  if min(x for x,y in xy)>W or max(x for x,y in xy)<0 or min(y for x,y in xy)>H or max(y for x,y in xy)<0:continue
  draw.polygon(xy,fill=(*col,alpha))
 return im
print('collect all parts',flush=True)
allparts=[];per=[]
for i in range(40):
 pp,_=b.make(i);pp=list(pp);per.append(pp);allparts.extend(pp)
P=polygons(allparts)
print('draw hero',len(P),flush=True)
W,H=1800,1040
im=paint(W,H,P,900,670,97)
d=ImageDraw.Draw(im)
d.rectangle((0,0,W,104),fill=(5,17,30,255));d.line((0,105,W,105),fill=(22,210,237),width=3)
d.text((48,23),'⚡ PROJECT SPARK / LEVEL 66 — SAVE THE FACTORY',font=font(39,True),fill=(226,243,251))
d.text((50,75),'PREDICTIVE MAINTENANCE  /  DIGITAL TWIN  /  MACHINE DIAGNOSTICS  /  SAFE REPAIR',font=font(16),fill=(89,209,234))
d.rectangle((0,957,W,H),fill=(5,16,28));d.line((0,956,W,956),fill=(26,213,230),width=3)
d.text((52,975),'40 MODULAR FBX MODELS   /   40 GLB BACKUPS   /   12 ANIMATION PIVOTS',font=font(22,True),fill=(129,226,219))
d.text((1440,988),'ART-ONLY 3D KIT',font=font(16,True),fill=(250,184,79))
im.convert('RGB').save(ROOT/'Previews'/'Level66_Hero_3D_Preview.png',optimize=True)
print('draw contact',flush=True)
cols,rows=5,8;tw,th=350,286;CW,CH=cols*tw,rows*th+125
im=Image.new('RGB',(CW,CH),(5,15,28));d=ImageDraw.Draw(im)
d.rectangle((0,0,CW,105),fill=(7,30,46));d.text((26,15),'PROJECT SPARK  /  LEVEL 66 — ALL 40 MODULAR 3D MODELS',font=font(29,True),fill=(229,243,250));d.text((29,65),'Individual binary FBX 7.4 • GLB backups • common-origin geometry • Unity-ready art placement',font=font(15),fill=(100,222,228))
for i,name in enumerate(b.NAMES):
 r,c=divmod(i,cols);ox=c*tw;oy=105+r*th
 d.rounded_rectangle((ox+5,oy+5,ox+tw-5,oy+th-5),radius=11,fill=(11,33,49),outline=(14,162,187),width=2)
 pp=polygons(per[i]);coords=np.vstack([v[1] for v in pp]);lo=coords.min(axis=0);hi=coords.max(axis=0);cx,cy=(lo+hi)/2;extent=hi-lo
 scale=min(285/max(extent[0],.08),200/max(extent[1],.08))
 # render directly onto transparent image sized 340x220
 tile=Image.new('RGBA',(tw-16,217),(0,0,0,0));td=ImageDraw.Draw(tile,'RGBA')
 for _,pts,col,alpha in pp:
  poly=[(int((tw-16)/2+(x-cx)*scale),int(105+(y-cy)*scale)) for x,y in pts]
  td.polygon(poly,fill=(*col,alpha))
 im.paste(tile,(ox+8,oy+9),tile)
 s=name
 # break camel / short
 import re
 s=re.sub(r'(?<!^)(?=[A-Z])',' ',s)
 if len(s)>28:s=s[:27]+'…'
 d.text((ox+17,oy+230),f'{i:02d}  {s}',font=font(14,True),fill=(223,244,250))
 d.text((ox+18,oy+255),f'{sum(len(p.mesh.faces) for p in per[i]):,} triangles',font=font(11),fill=(100,199,216))
im.save(ROOT/'Previews'/'Level66_40_Models_ContactSheet.png',optimize=True)
print('PREVIEWS DONE',flush=True)
