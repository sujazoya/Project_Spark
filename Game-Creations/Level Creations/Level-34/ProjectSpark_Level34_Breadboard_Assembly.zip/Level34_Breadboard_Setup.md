# Level 34 — Priority Power

Open **Priority Power** in the level picker. Use the Wire tool on the labeled rings. The 10 Ω feeder creates the bus voltage drop, and the demand bank is a single **47 Ω total** load at its two terminals. The bus monitor displays the live bus voltage, the recorded sag, and the auxiliary state.

| Wire | Start | End |
|---|---|---|
| W01 | Supply + | Feeder IN |
| W02 | Feeder BUS | Pump A |
| W03 | Feeder BUS | AUX IN |
| W04 | Feeder BUS | Demand Switch IN |
| W05 | AUX OUT | Fan A |
| W06 | Demand Switch OUT | Demand Bank IN |
| W07 | Pump B | Supply − |
| W08 | Fan B | Supply − |
| W09 | Demand Bank OUT | Supply − |

1. Finish the wiring and verify the pump runs alone.
2. Select **CONNECT AUX**. The fan starts alongside the pump.
3. Select **APPLY DEMAND**. The bus sags below 3.25 V and the cutoff opens the fan circuit.
4. Leave demand on until the critical pump recovers.
5. Select **REMOVE DEMAND**. The bus recovers above 3.90 V, and the fan stays off.
6. Select **RESTORE AUX** to restart the fan and complete the level.

All 14 sockets sit directly on the MainMenu breadboard over distinct grid holes. The fitted prefab keeps the original Level 34 circuit, definition, and campaign references. Visible TextMesh labels use local scale `0.25` on X and Y.

The ZIP mirrors the Unity `Assets` folder. In Edit Mode, **Tools → Project Spark → Level 34 → Fit Breadboard Assembly** refits the model and sockets. This level uses the existing Project Spark motor solver registration.
