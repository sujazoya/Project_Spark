# Level 30 — Elevate the Lamp

Open **Elevate the Lamp** in the level picker. The supplied motor, lift, lamp, contacts, resistor, and 5 V supply are fitted to the workbench. Use the **Wire** tool on the colored circular jacks. The lift carries the animated lamp while both lamp wiring jacks stay on the breadboard. The TextMesh labels have a local scale of `0.3` on all three axes.

## Wire the board

| Wire | Start | End |
|---|---|---|
| W01 | Supply + | UP Feed IN |
| W02 | Supply + | DOWN Feed IN |
| W03 | Supply + | Top Contact IN |
| W04 | Supply − | UP Return OUT |
| W05 | Supply − | DOWN Return OUT |
| W06 | Supply − | Lamp K |
| W07 | UP Feed OUT | Upper Limit IN |
| W08 | DOWN Feed OUT | Lower Limit IN |
| W09 | Upper Limit OUT | Motor A |
| W10 | Motor A | DOWN Return IN |
| W11 | Lower Limit OUT | Motor B |
| W12 | Motor B | UP Return IN |
| W13 | Top Contact OUT | 330 Ω Resistor IN |
| W14 | 330 Ω Resistor OUT | Lamp A |

## Verify the lift

1. Select **DOWN** at the bottom. The lower limit keeps the motor stopped.
2. Select **UP**. The platform rises.
3. Keep **UP** selected. The upper limit stops the motor and the lamp lights.
4. Select **DOWN**. The motor reverses and the lamp goes out.
5. Keep **DOWN** selected until the lower limit stops the platform. The level completes at **5/5**.

## Unity assets

The fitted prefab, level definition, drawing, model, and materials are under `Assets/My_Assets/_Project_Spark/Prefabs/Levels/Chapter_03/Level_30_Layout/`. The fitted FBX is a separate export. The original `Models/level-30.fbx` is the source artwork.

The existing Level 30 campaign entry, electrical components, and motor solver are reused. The lift controller asks the campaign evaluator to refresh each time an objective is recorded. The archive mirrors the Unity `Assets` folder and includes metadata to preserve existing asset references. The Unity command **Tools → Project Spark → Level 30 → Fit Breadboard Assembly** rebuilds the visual fit against the MainMenu breadboard and checks for a separate grid hole under each jack.
