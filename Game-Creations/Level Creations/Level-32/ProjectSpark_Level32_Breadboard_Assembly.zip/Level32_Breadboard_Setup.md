# Level 32 — Optical Quality Sorter

Open **Optical Quality Sorter** in the level picker. Use the **Wire** tool on the ten labeled sockets along the top of the breadboard. The supplied FBX provides the motor, optical head, belt, diverter, and bins. The modeled sample follows the belt and the selected route.

| Wire | Start | End |
|---|---|---|
| W01 | Supply + | MAIN IN |
| W02 | MAIN OUT | LDR A |
| W03 | LDR SENSE | 10 kΩ Divider IN |
| W04 | 10 kΩ Divider OUT | Supply − |
| W05 | MAIN OUT | Motor A |
| W06 | Motor B | Supply − |

1. Turn **MAIN** on once all six wires are in place.
2. Select **DARK REFERENCE** and wait for DARK OK. Select **BRIGHT REFERENCE** and wait for calibration to finish.
3. Select **RUN TEST** for the dark sample. It should reach DARK.
4. Select **RUN TEST** again for the bright sample. It should reach BRIGHT.
5. Run the borderline and glare test. The borderline sample should reach REVIEW and the dark sample should still reach DARK.
6. Run the six-part mixed batch. Completion requires two samples in each bin.

All visible TextMesh labels use local scale `0.25` on X and Y. Each socket sits directly on the actual MainMenu breadboard over its own grid hole. The fitted export uses the workbench surface and preserves the existing Level 32 prefab and definition references.

The ZIP mirrors the Unity `Assets` folder. In Edit Mode, **Tools → Project Spark → Level 32 → Fit Breadboard Assembly** refits the visuals and sockets. The level uses the existing Project Spark LDR and motor solver registrations.
