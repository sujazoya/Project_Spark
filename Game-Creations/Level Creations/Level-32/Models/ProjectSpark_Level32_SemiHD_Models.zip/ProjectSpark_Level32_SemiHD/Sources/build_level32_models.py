"""Project Spark: Level 32 — Optical Quality Sorter.
Actual semi-HD 3D mesh authoring and binary FBX / GLB export.
Contains 11 individual art-only modules, 10 precise electrical visual socket
anchors and the reference 6-wire map. Unity Y-up, visible sockets face -Z.

For live gameplay, attach your EXISTING Unity scripts and SparkTerminal objects:
these models deliberately contain no fake electrical integration.
"""
from __future__ import annotations
from spark_model_core import *
from pathlib import Path
import numpy as np
import json, csv, math

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models';PREV=ROOT/'Previews'
MODELS.mkdir(parents=True,exist_ok=True);PREV.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'belt':(24,32,42,255), 'acrylic':(85,173,218,68),
 'acrylic_edge':(132,237,255,255), 'dark_tile':(35,39,48,255),
 'review_tile':(130,146,155,255), 'bright_tile':(231,238,229,255),
 'sensor_ceramic':(237,194,115,255), 'trace':(160,77,34,255),
 'safety_yellow':(251,184,43,255), 'laser_red':(255,75,74,200)
})

def port2(m,t,ids,labels=('IN','OUT'),colors=('red','cyan'),xs=(-.69,.69),y=.48,z=-.842):
    for id,txt,c,x in zip(ids,labels,colors,xs):
        m.cyl(t+'_'+id+'_ChromeSocketSleeve',.159,.063,(x,y,z),'chrome',axis='z',sections=40)
        m.cyl(t+'_'+id+'_PolarityRing',.132,.062,(x,y,z-.033),c,axis='z',sections=40)
        m.cyl(t+'_'+id+'_SocketRecess',.093,.073,(x,y,z-.070),'void',axis='z',sections=34)
        m.cyl(t+'_'+id+'_ContactPin',.031,.017,(x,y,z-.101),'gold',axis='z',sections=18)
        m.text(t+'_'+id+'_TerminalName',txt,.118,x,y+.258,z-.13,'white',maxwidth=.67)
        m.anchors[id]=[round(float(x),4),round(y,4),round(z-.11,4)]

def small_screws(m,t,locations,y,metal='chrome'):
    for i,(x,z) in enumerate(locations):
        m.cyl(t+f'_Screw_{i:02}',.051,.026,(x,y,z),metal,sections=18)
        m.box(t+f'_ScrewSlot_{i:02}',(.047,.005,.007),(x,y+.014,z),'mid_steel')

def status_bar(m,t,y,z,material='green',w=.92):
    m.bevel(t+'_StatusBlackHousing',(w+.12,.055,.058),(0,y,z+.004),'void',.02)
    m.box(t+'_EmissiveStatus_BAR',(w,.028,.066),(0,y+.024,z),'cyan')

def build_supply():
    m=Model('01_5V_Regulated_Supply'); t='L32PSU'
    m.base(t,w=2.57,d=1.65,bodyh=1.42,fronttext='5 V SUPPLY',status='REGULATED DC SOURCE')
    port2(m,t,('Battery_positive','Battery_negative'),labels=('+','-'),colors=('red','blue'),xs=(-.78,.78),y=.49,z=-.9)
    m.bevel(t+'_OLED_Backplate',(1.32,.30,.052),(0,1.27,-.871),'bezel',.04)
    m.text(t+'_Voltage_Display','5.00 V',.243,0,1.27,-.912,'green',maxwidth=1.23)
    m.box(t+'_Power_OK_Green',(1.10,.042,.034),(0,1.80,-.48),'green')
    for i,x in enumerate(np.linspace(-.96,.96,11)):
        m.box(t+f'_TopCoolingVent_{i:02}',(.085,.012,.44),(float(x),1.86,.19),'void')
    m.cyl(t+'_SafetyFuse',.13,.093,(1.01,1.82,.17),'red',sections=24)
    return m

def build_main():
    m=Model('02_Main_Rocker_Switch');t='L32MAIN'
    m.base(t,w=2.36,d=1.58,bodyh=1.13,fronttext='MAIN',status='POWER SWITCH')
    port2(m,t,('MAIN_IN','MAIN_OUT'),labels=('IN','OUT'),colors=('red','cyan'))
    m.bevel(t+'_RockerChromeBezel',(1.2,.13,.84),(0,1.58,.14),'chrome',.06)
    m.bevel(t+'_RockerRubberBorder',(1.00,.096,.70),(0,1.68,.14),'rubber',.05)
    m.bevel(t+'_RockerRedActuator__ANIMATE',(.83,.215,.54),(0,1.78,.13),'red',.075,group='RockerPivot_ANIMATE')
    m.text(t+'_PowerGlyph','I / O',.18,0,1.64,-.831,'white',maxwidth=.78)
    m.box(t+'_GreenStatusLED',(.53,.031,.032),(0,1.91,-.17),'green','RockerPivot_ANIMATE')
    return m

def build_ldr():
    m=Model('03_Optical_LDR_Sensor');t='L32LDR'
    m.base(t,w=2.52,d=1.61,bodyh=1.15,fronttext='OPTICAL LDR',status='LIGHT / RESISTANCE')
    port2(m,t,('LDR_A','LDR_B'),labels=('A','B'),colors=('red','cyan'))
    m.bevel(t+'_SensorPolishedStand',(1.08,.08,.95),(0,1.55,.18),'steel',.06)
    m.cyl(t+'_LDR_GoldCeramicDisc',.434,.115,(0,1.70,.17),'sensor_ceramic',axis='y',sections=68)
    m.cyl(t+'_LDR_DarkOuterRing',.460,.029,(0,1.746,.17),'rubber',axis='y',sections=72)
    m.cyl(t+'_LDR_LightWindow',.399,.031,(0,1.769,.17),'sensor_ceramic',axis='y',sections=72)
    # Serpentine, raised photo-sensitive winding, visible from overhead.
    pts=[]
    for i,x in enumerate(np.linspace(-.305,.305,13)):
        y_z=.17+(-.26 if i%2 else .26)
        pts.append((float(x),1.797,float(y_z)))
    for i in range(len(pts)-1):
        m.rod(t+f'_Photoconductive_Path_{i:02}',pts[i],pts[i+1],.023,'trace',sections=8)
    for i,x in enumerate((-.31,.31)):
        m.cyl(t+f'_LDR_AgoldContact_{i}',.071,.027,(x,1.806,.17),'gold',sections=24)
    for x in [-.77,.77]:
        m.cyl(t+f'_Sensor_KnobMount_{x:+.2f}',.066,.20,(x,1.60,.28),'chrome',sections=20)
    m.box(t+'_LDR_Active_CyanGlow',(.69,.042,.04),(0,.32,-.843),'cyan')
    return m

def build_resistor():
    m=Model('04_10kOhm_Divider_Resistor');t='L32DIV'
    m.base(t,w=2.52,d=1.59,bodyh=1.10,fronttext='10 kOhm',status='OPTICAL DIVIDER')
    port2(m,t,('R_DIV_IN','R_DIV_OUT'),labels=('IN','OUT'),colors=('amber','blue'))
    m.bevel(t+'_ResistorBed',(1.57,.13,.65),(0,1.56,.12),'rubber',.07)
    m.cyl(t+'_MainCeramicResistor',.205,1.27,(0,1.80,.13),'sensor_ceramic',axis='x',sections=54)
    for i,(x,material) in enumerate(zip((-.38,-.20,.04,.41),('trace','rubber','orange','gold'))):
        m.torus(t+f'_ColorBand_{i+1}',.203,.026,(x,1.80,.13),material,axis='x',segments=44,tube_segs=9)
    for i,sgn in enumerate((-1,1)):
        m.cyl(t+f'_ResistorCap_{i}',.227,.082,(sgn*.66,1.80,.13),'gold',axis='x',sections=45)
        m.rod(t+f'_NickelLead_{i}',(sgn*.67,1.80,.13),(sgn*.85,1.80,.13),.046,'chrome')
        m.rod(t+f'_LeadIntoHousing_{i}',(sgn*.85,1.8,.13),(sgn*.85,1.55,.13),.045,'chrome')
    return m

def build_motor():
    m=Model('05_DC_Motor_33Ohm');t='L32MOTOR'
    m.base(t,w=2.83,d=1.78,bodyh=.79,fronttext='DC MOTOR',status='33 Ohm / BELT DRIVE')
    port2(m,t,('Motor_A','Motor_B'),labels=('A','B'),colors=('cyan','blue'),xs=(-.85,.85),y=.38,z=-.934)
    m.cyl(t+'_CNCBrushedSteelCan',.507,1.77,(0,1.27,.12),'titanium',axis='x',sections=72)
    m.cyl(t+'_FrontFaceplate',.532,.18,(-.92,1.27,.12),'steel',axis='x',sections=62)
    m.cyl(t+'_BrassBearing',.205,.16,(-1.05,1.27,.12),'gold',axis='x',sections=44)
    m.cyl(t+'_SpinningDriveShaft__ANIMATE',.092,.76,(-1.38,1.27,.12),'chrome',axis='x',sections=34,group='RotorShaft_ANIMATE')
    m.cyl(t+'_ShaftCollar__ANIMATE',.137,.08,(-1.13,1.27,.12),'chrome',axis='x',sections=34,group='RotorShaft_ANIMATE')
    m.cyl(t+'_RearBlueCap',.555,.22,(.90,1.27,.12),'blue',axis='x',sections=58)
    m.cyl(t+'_BrushRedInsulation',.493,.24,(1.10,1.27,.12),'red',axis='x',sections=58)
    m.cyl(t+'_RearTerminalGold',.28,.075,(1.26,1.27,.12),'gold',axis='x',sections=42)
    for i,x in enumerate(np.linspace(-.58,.53,9)):
        m.box(t+f'_CoolingSlot_{i:02}',(.078,.053,.12),(float(x),1.775,.12),'void')
    for x in (-.63,.60):
        m.torus(t+f'_MachinedChromeBand_{x}',.508,.016,(x,1.27,.12),'chrome',axis='x',segments=52)
    m.bevel(t+'_RatingTag',(.94,.24,.044),(0,1.115,-.405),'bezel',.03)
    m.text(t+'_RatingEmbossed','33 Ohm',.145,0,1.116,-.435,'white',maxwidth=.83)
    return m

def build_optical_head():
    m=Model('06_Inspection_Optical_Head');t='L32OPTIC'
    m.bevel(t+'_Footpad',(2.68,.12,1.64),(0,.08,0),'rubber',.07)
    m.bevel(t+'_RobotModuleFoot',(2.63,.19,1.59),(0,.22,0),'steel',.09)
    for x in [-1.01,1.01]:
        m.cyl(t+f'_StandPost_{x:+.2f}',.105,1.33,(x,1.06,.06),'titanium',sections=34)
        m.torus(t+f'_PostStatusCyan_{x:+.2f}',.107,.022,(x,1.44,.06),'cyan',axis='y',segments=34)
    m.bevel(t+'_TopInspectionHull',(2.63,.60,1.50),(0,1.89,0),'graphite',.12)
    m.bevel(t+'_CyanScannerBezel',(1.03,.32,.052),(0,1.91,-.78),'bezel',.04)
    m.text(t+'_ScannerFrontTitle','OPTICAL HEAD',.135,0,1.92,-.82,'white',maxwidth=.96)
    m.cyl(t+'_DownwardOpticalCylinder',.286,.31,(0,1.48,0),'titanium',axis='y',sections=42)
    m.cyl(t+'_DownwardLens_Housing',.255,.12,(0,1.29,0),'chrome',axis='y',sections=42)
    m.cyl(t+'_GoldInspectionLamp_Emissive',.190,.055,(0,1.22,0),'amber',axis='y',sections=36,group='InspectionLamp_VISUAL')
    m.cyl(t+'_CentralLEDWhiteCore',.105,.018,(0,1.183,0),'white',axis='y',sections=32,group='InspectionLamp_VISUAL')
    for i,x in enumerate((-.95,.95)):
        m.box(t+f'_ScannerSideAmberLight_{i}',(.048,.42,.064),(x,1.84,-.76),'orange')
    m.box(t+'_EmissiveCyanTopStrip',(.96,.035,.045),(0,2.23,-.45),'cyan')
    m.text(t+'_SensorProcessTag','5 V OPTICAL',.125,0,.35,-.831,'cyan',maxwidth=1.45)
    return m

def build_conveyor():
    m=Model('07_Inspection_Conveyor');t='L32BELT'
    m.bevel(t+'_Base_Rubber',(6.30,.17,2.44),(0,.09,0),'rubber',.11)
    m.bevel(t+'_Base_Titanium',(6.24,.24,2.42),(0,.29,0),'mid_steel',.1)
    m.bevel(t+'_BeltSurround',(5.98,.26,2.08),(0,.51,0),'graphite',.08)
    m.bevel(t+'_Machine_DarkUnderdeck',(5.37,.095,1.66),(0,.76,0),'rubber',.045)
    for x in (-2.70,2.70):
        m.cyl(t+f'_DriveRoller_{x:+.2f}',.33,1.75,(x,.91,0),'titanium',axis='z',sections=56)
        m.torus(t+f'_FrontRollerHalo_{x:+.2f}',.322,.034,(x,.91,-.885),'cyan',axis='z',segments=48)
        m.cyl(t+f'_PolishedRollerShaft_{x:+.2f}',.07,2.01,(x,.91,0),'chrome',axis='z',sections=24)
    m.box(t+'_BlackMovingBelt_ANIMATE',(5.37,.066,1.66),(0,1.157,0),'belt',group='MovingBelt_ANIMATE')
    for i,x in enumerate(np.linspace(-2.58,2.58,49)):
        m.box(t+f'_ConveyorGrip_{i:02}_ANIMATE',(.031,.014,1.56),(float(x),1.199,0),'mid_steel',group='MovingBelt_ANIMATE')
    for s,z in enumerate((-.995,.995)):
        m.box(t+f'_EdgeGuide_{s}',(5.80,.21,.11),(0,1.10,z),'steel')
        m.box(t+f'_NeonSideRail_{s}',(5.80,.043,.034),(0,.87,z),'cyan')
    for i,x in enumerate(np.linspace(-2.79,2.74,21)):
        m.box(t+f'_Warning_Marking_{i}',(.095,.041,.034),(float(x),.49,-1.066),'orange' if i%2 else 'rubber')
    m.bevel(t+'_FrontTitlePlate',(2.22,.25,.049),(0,.45,-1.166),'bezel',.02)
    m.text(t+'_Conveyor3DLettering','INSPECTION CONVEYOR',.134,0,.46,-1.202,'white',maxwidth=2.07)
    for i,(x,mat) in enumerate(((-1.55,'dark_tile'),(-.22,'review_tile'),(1.21,'bright_tile'))):
        m.bevel(t+f'_TestTile_{i+1}_ANIMATE',(.47,.21,.43),(x,1.34,-.08),mat,.035,group='MovingTestParts_ANIMATE')
    return m

def build_gate():
    m=Model('08_Three_Way_Sort_Diverter');t='L32GATE'
    m.bevel(t+'_RubberFoot',(2.37,.15,1.96),(0,.09,0),'rubber',.09)
    m.bevel(t+'_MachinedFoundation',(2.30,.29,1.89),(0,.30,0),'steel',.08)
    m.bevel(t+'_MetalTurretBase',(1.86,.30,1.31),(0,.56,0),'graphite',.10)
    m.cyl(t+'_ServoLowerRing',.40,.20,(0,.82,0),'titanium',sections=44)
    m.cyl(t+'_RotaryHub__ANIMATE',.308,.13,(0,.98,0),'gold',sections=44,group='DiverterArm_ANIMATE')
    m.cyl(t+'_HingeChromePin__ANIMATE',.13,.20,(0,1.08,0),'chrome',sections=32,group='DiverterArm_ANIMATE')
    m.bevel(t+'_ActuatorArmAmber__ANIMATE',(1.42,.25,.30),(.68,1.03,0),'orange',.075,group='DiverterArm_ANIMATE')
    for j,x in enumerate((.35,.73,1.04)):
        m.box(t+f'_ActuatorHazardStripe_{j}_ANIMATE',(.062,.028,.30),(x,1.168,0),'rubber',group='DiverterArm_ANIMATE')
    m.cyl(t+'_TipWheel__ANIMATE',.195,.29,(1.41,1.07,0),'chrome',sections=40,group='DiverterArm_ANIMATE')
    for i,(x,col) in enumerate(((-.80,'blue'),(0,'amber'),(.80,'green'))):
        m.box(t+f'_RouteLED_{i}',(.42,.042,.06),(x,.52,-.96),col,group='GateStatus_VISUAL')
    m.bevel(t+'_Gate_Label',(1.77,.30,.052),(0,.61,-.968),'bezel',.03)
    m.text(t+'_Gate_Engraved','3-WAY SORT GATE',.128,0,.62,-.999,'white',maxwidth=1.61)
    return m

def build_bin(key,name,color,tilemat):
    m=Model(key);t='L32BIN_'+name.upper()
    m.bevel(t+'_RubberFloorFoot',(2.12,.13,1.95),(0,.07,0),'rubber',.07)
    m.bevel(t+'_SteelBinBottom',(2.02,.21,1.83),(0,.23,0),'steel',.06)
    for x in (-.92,.92):
        m.box(t+f'_BinWall_X{x:+.2f}',(.115,.84,1.83),(x,.73,0),'mid_steel')
        m.box(t+f'_VerticalLaserBlade_{x:+.2f}',(.043,.45,.042),(x,.78,-.93),color)
    for z in (-.86,.86):
        m.box(t+f'_BinWall_Z{z:+.2f}',(1.92,.84,.115),(0,.73,z),'mid_steel')
    m.bevel(t+'_BlackInnerFloor',(1.73,.064,1.55),(0,.40,0),'void',.04)
    m.box(t+'_NeonBinHeader',(1.45,.06,.056),(0,1.18,-.88),color)
    m.bevel(t+'_FrontLabelPlate',(1.53,.28,.060),(0,.80,-.955),'bezel',.03)
    m.text(t+'_EngravedLabel',name,.192,0,.80,-1.002,'white',maxwidth=1.42)
    for i,x in enumerate((-.38,.40)):
        m.bevel(t+f'_SampleTile_{i}_ANIMATE',(.37,.23,.40),(x,.57,.16),tilemat,.031,group='SortedSamples_VISUAL')
    m.cyl(t+'_StatusBeaconSocket',.128,.11,(0,1.26,.72),'chrome',sections=28)
    m.cyl(t+'_StatusBeaconGlow',.101,.09,(0,1.34,.72),color,sections=32,group='BinStatus_VISUAL')
    return m

BUILDERS=[build_supply,build_main,build_ldr,build_resistor,build_motor,build_optical_head,build_conveyor,build_gate,
          lambda:build_bin('09_DARK_Sorter_Bin','DARK','blue','dark_tile'),
          lambda:build_bin('10_REVIEW_Sorter_Bin','REVIEW','amber','review_tile'),
          lambda:build_bin('11_BRIGHT_Sorter_Bin','BRIGHT','green','bright_tile')]

STAGING={
'01_5V_Regulated_Supply':(-10.7,.55,3.17),
'02_Main_Rocker_Switch':(-7.65,.55,3.17),
'03_Optical_LDR_Sensor':(-4.63,.55,3.17),
'04_10kOhm_Divider_Resistor':(-1.60,.55,3.17),
'05_DC_Motor_33Ohm':(2.01,.55,3.17),
'06_Inspection_Optical_Head':(5.43,.55,3.17),
'07_Inspection_Conveyor':(-6.24,.55,-2.24),
'08_Three_Way_Sort_Diverter':(-1.26,.55,-2.24),
'09_DARK_Sorter_Bin':(2.22,.55,-2.24),
'10_REVIEW_Sorter_Bin':(5.02,.55,-2.24),
'11_BRIGHT_Sorter_Bin':(7.82,.55,-2.24),
'00_Optional_Showcase_Board':(0,0,0),
}

CONNECTIONS=[
 ('W01','Battery_positive','MAIN_IN'),
 ('W02','MAIN_OUT','LDR_A'),
 ('W03','LDR_B','R_DIV_IN'),
 ('W04','R_DIV_OUT','Battery_negative'),
 ('W05','MAIN_OUT','Motor_A'),
 ('W06','Motor_B','Battery_negative'),
]

def build_board():
    m=Model('00_Optional_Showcase_Board');t='L32SHOWCASE'
    m.bevel(t+'_RubberSubstrate',(25.0,.14,10.95),(0,.07,0),'rubber',.14)
    m.bevel(t+'_MachinedFrame',(24.94,.19,10.90),(0,.24,0),'steel',.16)
    m.bevel(t+'_GraphiteWorkSurface',(24.67,.086,10.62),(0,.421,0),'graphite',.10)
    for x in (-12.28,12.28):m.box(t+f'_SideLight_{x:+.2f}',(.047,.038,10.20),(x,.476,0),'cyan')
    for z in (-5.23,5.23):m.box(t+f'_FrontLight_{z:+.2f}',(24.30,.038,.048),(0,.476,z),'cyan')
    # One batched mesh instead of 1000 draw calls.
    dots=[]
    for x in np.linspace(-11.91,11.91,56):
        for z in np.linspace(-4.91,4.91,25):
            p=trimesh.creation.cylinder(radius=.013,height=.005,sections=6)
            p.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
            p.apply_translation((float(x),.485,float(z))); dots.append(p)
    m.add(t+'_BatchedDottedWorkSurface',trimesh.util.concatenate(dots),'mid_steel')
    return m

def main():
    mods=[f() for f in BUILDERS]
    assert len(mods)==11
    term_names=[key for m in mods for key in m.anchors]
    assert len(term_names)==10,term_names
    assert len(set(term_names))==10,term_names
    for w,a,b in CONNECTIONS: assert a in term_names and b in term_names,(w,a,b)
    manifest={}
    for mod in mods:
        fbx=MODELS/(mod.key+'.fbx'); glb=MODELS/(mod.key+'.glb')
        export_fbx(fbx,[mod]);export_glb(glb,[mod])
        manifest[mod.key]={
            'fbx':fbx.name,'glb':glb.name,'mesh_objects':len(mod.parts),
            'triangles':int(sum(len(p.mesh.faces) for p in mod.parts)),
            'terminals':mod.anchors,
            'animation_groups':list(dict.fromkeys(p.group for p in mod.parts if 'ANIMATE' in p.group or 'VISUAL' in p.group)),
            'moving_parts':[p.name for p in mod.parts if 'ANIMATE' in p.name]
        }
        print('BUILT',mod.key,'triangles',manifest[mod.key]['triangles'],'meshes',len(mod.parts),flush=True)
    board=build_board(); assembly=[board]+mods
    export_fbx(MODELS/'Level32_Complete_ArtKit_Showcase.fbx',assembly,positions=STAGING)
    export_glb(MODELS/'Level32_Complete_ArtKit_Showcase.glb',assembly,positions=STAGING)
    tri=sum(len(p.mesh.faces) for m in assembly for p in m.parts)
    manifest['Level32_Complete_ArtKit_Showcase']={'fbx':'Level32_Complete_ArtKit_Showcase.fbx','glb':'Level32_Complete_ArtKit_Showcase.glb','triangles':int(tri),'mesh_objects':sum(len(m.parts) for m in assembly)}
    (ROOT/'Model_Manifest.json').write_text(json.dumps({
        'level':32,'title':'Optical Quality Sorter','project':'Project Spark',
        'model_count':len(mods),'socket_count':len(term_names),'wire_count':len(CONNECTIONS),
        'coords':'Y-up. Jack socket face toward negative local Z. Scene showcase positions are for art preview only.',
        'wiring': [{'wire':w,'from':a,'to':b} for w,a,b in CONNECTIONS],
        'items':manifest, 'showcase_positions':STAGING
    },indent=2),encoding='utf-8')
    with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['Model FBX','Runtime Terminal ID','local_X','local_Y','local_Z','GameObject Suggested'])
        for m in mods:
            for id,(x,y,z) in m.anchors.items():writer.writerow([m.key+'.fbx',id,x,y,z,id])
    with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
        wr=csv.writer(f);wr.writerow(['Wire','From Terminal ID','To Terminal ID']);wr.writerows(CONNECTIONS)
    print('DONE: 11 FBX + 11 GLB + full assembly, 10 terminal anchors, 6 wire map; total tris=',tri,flush=True)

if __name__=='__main__':main()
