PROJECT SPARK — LEVEL 32 / OPTICAL QUALITY SORTER
==================================================
POLISHED SEMI-HD 3D VISUAL ART KIT (11 COMPONENT FBX MODELS)

DELIVERABLES
------------
Models/01_5V_Regulated_Supply.fbx
Models/02_Main_Rocker_Switch.fbx
Models/03_Optical_LDR_Sensor.fbx
Models/04_10kOhm_Divider_Resistor.fbx
Models/05_DC_Motor_33Ohm.fbx
Models/06_Inspection_Optical_Head.fbx
Models/07_Inspection_Conveyor.fbx
Models/08_Three_Way_Sort_Diverter.fbx
Models/09_DARK_Sorter_Bin.fbx
Models/10_REVIEW_Sorter_Bin.fbx
Models/11_BRIGHT_Sorter_Bin.fbx

Each FBX has a matching GLB. The optional Level32_Complete_ArtKit_Showcase.fbx
and .glb group all 11 models on a display platform as a showroom visualization;
they are NOT exact world-space gameplay placement or a ready-wired circuit.

Previews/ includes one actual 3D render per model, a contact sheet, and
an assembled kit showcase. No image-to-mesh substitution: these are
procedurally generated triangle meshes with named groups/materials.

ELECTRICAL TERMINALS — TEN TOTAL
--------------------------------
5 V SUPPLY: Battery_positive, Battery_negative
MAIN: MAIN_IN, MAIN_OUT
OPTICAL LDR: LDR_A, LDR_B
10 kOhm RESISTOR: R_DIV_IN, R_DIV_OUT
DC MOTOR: Motor_A, Motor_B

The remaining art pieces (optical inspection head, conveyor, sorting gate,
three sorting bins) have ZERO electrical jacks intentionally. They are
scene mechanisms, not circuit network components.

PLAYER WIRING — SIX CONNECTIONS
--------------------------------
W01 Battery_positive -> MAIN_IN
W02 MAIN_OUT         -> LDR_A
W03 LDR_B            -> R_DIV_IN
W04 R_DIV_OUT        -> Battery_negative
W05 MAIN_OUT         -> Motor_A
W06 Motor_B          -> Battery_negative

SENSE is the shared solver node LDR_B and R_DIV_IN. It is NOT another
physical wire or dedicated seventh terminal.

UNITY INSTALLATION
------------------
1. Unzip into Assets/My_Assets/_Project_Spark/Models/Level32/.
2. Prefer individual FBXs for your Level_32_Layout prefab. Place the supply,
   rocker, LDR, 10 kOhm resistor and motor where the existing Level32 circuit
   layout expects them. Keep your original SparkLevelSceneBindings and
   Level 32 gameplay scripts.
3. Set FBX import scale and material conversion for your project. All mesh
   assets use Y up, front connector faces point along local negative Z.
   Unit sizes are artistic, not a fixed physical millimeter scale.
4. For each electrical component add/retain its EXISTING Project Spark
   electrical MonoBehaviour. Attach SparkTerminal GameObjects at socket
   centers using Terminal_Anchors.csv. Runtime binding IDs must match exact
   names above. Do not add a second solver or fake electric bridge.
5. Use existing Level 32 controller logic for optical readings, sorting
   animations and scoreboard. The imported assets do not implement these.
6. The optical head is an art-only separate model. Parent its scene instance
   over the conveyor inspection point. The mesh's LED/glow is emissive-look
   geometry; add Unity lights/material emission if desired.
7. The belt ribs and sample parts are under MovingBelt_ANIMATE and
   MovingTestParts_ANIMATE group names; the servo arm under
   DiverterArm_ANIMATE, the motor shaft under RotorShaft_ANIMATE, and the
   switch rocker under RockerPivot_ANIMATE. Create explicit Unity pivots for
   precise rotations or translation, then put the appropriate meshes under
   them. Imported null groups may have origins at module root rather than
   at the physical hinge.
8. Three bins intentionally have different status colors: DARK = blue,
   REVIEW = amber, BRIGHT = green. Separate sample meshes allow animations.
9. Keep all 6 player wire connections separate, including both connections
   beginning at MAIN_OUT and both ending at Battery_negative.

EXAMPLE GAME OBJECT LAYOUT
--------------------------
Level_32_Layout
  PowerSupply_01       (01_5V_Regulated_Supply)
  Main                 (02_Main_Rocker_Switch)
  OpticalLDR           (03_Optical_LDR_Sensor)
  DividerResistor      (04_10kOhm_Divider_Resistor)
  Motor                (05_DC_Motor_33Ohm)
  OpticalInspection    (06_Inspection_Optical_Head)
  Conveyor             (07_Inspection_Conveyor)
  SorterGate           (08_Three_Way_Sort_Diverter)
  DarkBin              (09_DARK_Sorter_Bin)
  ReviewBin            (10_REVIEW_Sorter_Bin)
  BrightBin            (11_BRIGHT_Sorter_Bin)

GAMEPLAY / EXPECTED BEHAVIOR
----------------------------
MAIN on => motor and sensor receive power.
DARK LDR SENSE ~0.83 V => DARK bin.
BORDERLINE SENSE ~2.50 V => REVIEW bin.
BRIGHT SENSE ~4.32 V => BRIGHT bin.
Glare pulse should not falsely classify a dark tile as BRIGHT.
After trials, six-part batch target is DARK 2 / BRIGHT 2 / REVIEW 2.
These values and timings are from your supplied Level32 creation guide;
physical measurement/classification remain the game's existing scripts.

CHECKS / LIMITATIONS
--------------------
- FBX 7.4 binary files exported and structurally parsed (built-in writer).
- GLB files loaded as trimesh scenes for mesh validity and geometry counts.
- Renders are screenshots of the actual generated meshes via offscreen VTK.
- No Unity editor/runtime import or lighting/bloom tests were possible here.
- Mesh material colors are present; match Project Spark's shader/emission
  manually if FBX importer does not use the original color values.
- The showcase model has a large batched dotted display floor for previews.
  Avoid using it as a duplicate scene workbench in production.
- No scripts modify the shared electrical solver, level definition or graph.

FILES FOR TECHNICAL INTEGRATION
--------------------------------
Terminal_Anchors.csv: suggested local socket centers, Y up, facing -Z
Exact_Wiring.csv: verified Level 32 6-wire map
Model_Manifest.json: individual mesh/triangle counts and animation groups
Sources/build_level32_models.py: original procedural mesh source
Sources/spark_model_core.py: model primitives / FBX exporter
Sources/render_level32_previews.py: optional VTK offline render source
Reference/Level32_Exact_Workbench_Wiring.png: original user schematic
