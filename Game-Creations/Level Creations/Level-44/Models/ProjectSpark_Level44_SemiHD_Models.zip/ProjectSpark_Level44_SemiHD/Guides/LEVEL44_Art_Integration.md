# Project Spark — Level 44 / Find Home — Art Integration

This is a **visual Unity asset pack**, not a replacement for your electrical or level-completion systems.

## Mechanics

The source geometry uses **Y up**, with the fixed read head placed at the **+X** radius, matching the single `Z_INDEX` stripe on the separate encoder disc at the home rotation. The platter and disc rotate on their **centered local Y pivots**.

| State | Signed count | Rotation from home |
|---|---:|---:|
| HOME | 0 | 0° |
| Station A | +20 | +90° |
| Station B | +52 | +234° |
| Full turn | 80 | 360° |

The encoder ring has 20 visibly distributed A/B periods: **20 cycles × four quadrature edges = 80 counts/revolution**. The disc's **single Z stripe** is the unique home mark.

## Art sockets / mapping

The nine requested model files contain **10 visual socket anchors**: 2 supply anchors integrated into the fixed `L44_TableBase`, 3 signal outputs in `L44_EncoderReadHead`, and 5 inputs in `L44_DecoderPanel`. Their **exact coordinates and role aliases** are in `Terminal_Anchors.csv`; assign the real `SparkTerminal` objects inside Unity.

| Player wire | From art anchor | To art anchor |
|---|---|---|
| W01 | `SUPPLY_PLUS_5V` | `DECODER_PLUS_5V` |
| W02 | `SUPPLY_RETURN` | `DECODER_RETURN` |
| W03 | `ENCODER_Z` | `DECODER_Z` |
| W04 | `ENCODER_A` | `DECODER_A` |
| W05 | `ENCODER_B` | `DECODER_B` |

**Wire A and B last.** Undo Last twice removes those two exact player wires to enable the reversed-channel lesson.

## Objects

The fixed base, platter, encoder disc, read head, decoder, controls and three station markers all have **separate FBXs**. There is also an assembled showcase FBX with an **art-only** display tray. To keep the front wiring area usable in gameplay, do not add decorative wires on top of player sockets.

## Optional visual adapter

`Unity_Optional/SparkLevel44VisualRig.cs` uses your game's actual count as an input and rotates the platter and encoder disc visually. It has no dependency on your electrical solver, doesn't apply motor torque, and does not determine homing or fault correctness. On a decoder power cycle, the game must keep the physical table where it is and invalidate the reference; the optional adapter provides the visual-only `PowerCycleReferenceLost()` method.

## Final material pass

Use your existing Project Spark URP/HDRP material library. Metallic body shells, brushed titanium machined edges, black high-contrast decal faces, low-intensity cyan/mint emission on accents, gold contact cores, and isolated orange warning pixels are recommended. Add collider volumes in Unity as needed.
