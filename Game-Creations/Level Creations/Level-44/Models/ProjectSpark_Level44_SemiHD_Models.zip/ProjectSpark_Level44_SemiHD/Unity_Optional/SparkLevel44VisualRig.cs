using UnityEngine;

namespace ProjectSpark.Gameplay
{
    /// <summary>
    /// OPTIONAL, VISUAL-ONLY helper for Level 44 FBX models.
    /// It never reads or changes circuit topology, motor state, or solved values.
    /// Your Level 44 controller must call SetDecodedCount / SetHomed.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SparkLevel44VisualRig : MonoBehaviour
    {
        [Header("FBX named group roots (assign child Transforms)")]
        [SerializeField] private Transform rotatingPlatter;
        [SerializeField] private Transform encoderDisc;

        [Header("Encoder")]
        [SerializeField, Min(1)] private int decodedCountsPerRevolution = 80;
        [SerializeField] private int decodedCount;
        [SerializeField] private bool isHomed;
        [SerializeField] private bool updateEveryFrame;

        [Header("Motion orientation")]
        [SerializeField] private bool invertDirection;
        [SerializeField] private float mechanicalHomeYawOffsetDegrees;

        private Quaternion platterInitialRotation = Quaternion.identity;
        private Quaternion discInitialRotation = Quaternion.identity;
        private bool initialized;

        public int DecodedCount => decodedCount;
        public bool IsHomed => isHomed;
        public float IndexAngleDegrees => (invertDirection ? -1f : 1f) *
            (360f * decodedCount / Mathf.Max(1, decodedCountsPerRevolution));

        private void Awake() { Initialize(); RefreshVisuals(); }
        private void OnEnable() { Initialize(); RefreshVisuals(); }
        private void Update()
        {
            // Normally OFF; enable only for inspector preview/debugging.
            if (updateEveryFrame) RefreshVisuals();
        }
        private void OnValidate()
        {
            decodedCountsPerRevolution = Mathf.Max(1, decodedCountsPerRevolution);
        }
        private void Initialize()
        {
            if (initialized) return;
            platterInitialRotation = rotatingPlatter != null
                ? rotatingPlatter.localRotation : Quaternion.identity;
            discInitialRotation = encoderDisc != null
                ? encoderDisc.localRotation : Quaternion.identity;
            initialized = true;
        }

        /// <summary>Call when the controller publishes its authoritative signed count.</summary>
        public void SetDecodedCount(int count)
        {
            decodedCount = count;
            RefreshVisuals();
        }

        /// <summary>Set homing status only. Does not alter mechanical position.</summary>
        public void SetHomed(bool homed) { isHomed = homed; }

        /// <summary>
        /// After a decoder power cycle, do NOT move the platter.
        /// Lose the reference in game logic and call this visual helper.
        /// </summary>
        public void PowerCycleReferenceLost() { isHomed = false; }

        /// <summary>Call after the real controller has detected the Z pulse and zeroed count.</summary>
        public void SetHomeZeroConfirmed()
        {
            decodedCount = 0;
            isHomed = true;
            RefreshVisuals();
        }

        public void RefreshVisuals()
        {
            Initialize();
            float yaw = mechanicalHomeYawOffsetDegrees + IndexAngleDegrees;
            Quaternion spin = Quaternion.AngleAxis(yaw, Vector3.up);
            // Both pieces share one physical angle and a correctly centered FBX pivot.
            if (rotatingPlatter != null)
                rotatingPlatter.localRotation = platterInitialRotation * spin;
            if (encoderDisc != null)
                encoderDisc.localRotation = discInitialRotation * spin;
        }
    }
}
