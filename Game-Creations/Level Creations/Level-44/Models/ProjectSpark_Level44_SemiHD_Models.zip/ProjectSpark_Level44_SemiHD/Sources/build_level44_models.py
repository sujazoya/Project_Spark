"""Project Spark — Level 44 / FIND HOME.
Nine polished semi-HD Unity 3D assets. Y up; local front -Z; rotary table local Y axis.
Exactly five player wire pairs = 10 art socket anchors. FBX 7.4 binary + GLB.
These meshes do not contain electrical simulation, scripted gameplay, or authoritative Unity bindings.
"""
from __future__ import annotations
import math,csv,json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb
ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models';P=ROOT/'Previews'
for d in [MODELS,P,ROOT/'Guides']:d.mkdir(parents=True,exist_ok=True)
PALETTE.update({'ice':(183,240,250,255),'mint':(37,244,192,255),'cyanlit':(46,246,255,255),
 'bronze':(175,117,59,255),'polished':(209,221,233,255),'indigo':(99,93,225,255),
 'greyblue':(82,107,137,255),'holo':(74,161,212,115),'red_dim':(110,40,64,255),
 'teal_dim':(15,89,84,255),'goldbright':(255,223,126,255), 'darkgreen':(15,89,60,255),
 'glass_black':(16,61,79,128),'orangehot':(255,119,41,255), 'shadow':(9,17,28,255)})

COUNT_PER_REV=80
R_PLATTER=3.58
R_DISC=4.07
R_MARKERS=5.25
STATION_A_DEG=90.0
STATION_B_DEG=234.0


def at_angle(deg,r):
 a=math.radians(deg)
 return (r*math.cos(a),-r*math.sin(a))  # positive = clockwise viewed down from +Y

def lbl(m,tag,s,x,y,z,size=.17,col='white',width=None,group='Static'):
 m.text(tag,s,size,x,y,z,col,maxwidth=width,group=group)

def bolt(m,tag,x,y,z,r=.06):
 m.cyl(tag+'_ChromeFastener',r,.032,(x,y,z),'chrome',sections=16)
 m.box(tag+'_Slot',(.055,.006,.014),(x,y+.021,z),'mid_steel')

def corners(m,tag,w,d,y):
 for x in (-w/2+.18,w/2-.18):
  for z in (-d/2+.18,d/2-.18):bolt(m,f'{tag}_{x:.2f}_{z:.2f}',x,y,z,.065)

def socket(m,tag,sid,label,x,y=.47,z=-1.22,col='cyan',label_above=True):
 # Front-facing hollow socket, with brass inner pin, and physical surface center in local model space.
 m.cyl(tag+'_'+sid+'_ChromedThread',.194,.082,(x,y,z+.016),'chrome',axis='z',sections=38)
 m.cyl(tag+'_'+sid+'_InsulatingColor',.150,.100,(x,y,z-.039),col,axis='z',sections=34)
 m.cyl(tag+'_'+sid+'_DeepSocketHole',.100,.107,(x,y,z-.089),'void',axis='z',sections=32)
 m.cyl(tag+'_'+sid+'_GoldInnerContact',.031,.030,(x,y,z-.144),'gold',axis='z',sections=18)
 m.torus(tag+'_'+sid+'_EmissiveHalo',.158,.012,(x,y,z-.099),col,axis='z',segments=36,tube_segs=8,group='Sockets_VISUAL')
 lbl(m,tag+'_'+sid+'_Label',label,x,y+(.260 if label_above else -.249),z-.153,.117,'ice',.81)
 m.anchors[sid]=[round(x,4),round(y,4),round(z-.16,4)]

def top_lamp(m,tag,x,y,z,col='mint',group='Lamps_VISUAL'):
 m.cyl(tag+'_ChromeCollar',.174,.05,(x,y,z),'chrome',sections=27,group=group)
 m.cyl(tag+'_LampGlow',.117,.060,(x,y+.042,z),col,sections=32,group=group)
 m.torus(tag+'_LensOuter',.137,.015,(x,y+.080,z),'ice',axis='y',segments=32,group=group)

def housing(m,tag,title,w=3.5,d=2.12,h=1.47,accent='cyan',subtitle=None):
 m.base(tag,w=w,d=d,bodyh=h)
 f=-d/2-.083
 m.bevel(tag+'_FrontHeadingBezel',(w-.32,.43,.035),(0,1.39,f-.013),'void',.035)
 lbl(m,tag+'_FrontHeading',title,0,1.41,f-.067,.245,'white',w-.41)
 if subtitle:lbl(m,tag+'_FrontSubTitle',subtitle,0,1.115,f-.076,.117,accent,w-.54)
 m.box(tag+'_TopLightBlade',(w-.66,.032,.054),(0,1.38+h-.26,-d/2+.26),accent)
 m.box(tag+'_BottomLightBlade',(w-.62,.041,.035),(0,.337,f-.02),accent)
 for xx in (-w/2+.17,w/2-.17):
  m.bevel(tag+f'_MachinedSideProtection_{xx}',(.15,.55,d-.22),(xx,.91,0),'steel',.025)
  m.box(tag+f'_AmberSideEdge_{xx}',(.046,.51,.046),(xx,.91,f+.12),'orange')
 corners(m,tag,w,d,.35+h+.037)
 return f

def rotary_foot(m,tag,x,z):
 m.bevel(tag+'_Foot',(1.06,.20,1.07),(x,.12,z),'rubber',.09)
 m.bevel(tag+'_Shim',(.83,.07,.82),(x,.24,z),'steel',.038)
 for xx in (-.28,.28):bolt(m,tag+f'_MountBolt_{xx}',x+xx,.295,z,.067)

def build_table_base():
 m=Model('01_L44_TableBase');t='L44_TABLE'
 # heavy custom indexing station plinth / bearing chassis, no platter or encoder included
 m.bevel(t+'_ShockIsolatingLower',(10.25,.20,10.25),(0,.11,0),'rubber',.22)
 m.bevel(t+'_MilledAluminumCasting',(10.13,.26,10.13),(0,.31,0),'titanium',.19)
 m.bevel(t+'_MachinedGraphiteTop',(9.90,.22,9.90),(0,.56,0),'graphite',.15)
 m.cyl(t+'_CastBearingSeat',4.18,.28,(0,.745,0),'mid_steel',sections=112)
 m.cyl(t+'_BlackBearingVoid',3.85,.074,(0,.918,0),'void',sections=128)
 m.torus(t+'_RadialBearingOuterRing',3.84,.105,(0,.970,0),'chrome',axis='y',segments=128,tube_segs=11)
 m.torus(t+'_RadialBearingSealRing',3.61,.053,(0,.995,0),'rubber',axis='y',segments=112,tube_segs=9)
 # mechanical slew-bearing rollers: 28 equally spaced beads near rim
 for k in range(28):
  a=math.tau*k/28;x,z=3.75*math.cos(a),3.75*math.sin(a)
  m.cyl(t+f'_VisibleBearingRoller_{k:02d}',.112,.062,(x,.996,z),'chrome',sections=16)
 # 80 tiny indicator slots aligned to true decoded count divisions
 for k in range(COUNT_PER_REV):
  a=math.tau*k/COUNT_PER_REV;x,z=4.37*math.cos(a),4.37*math.sin(a)
  side= .22 if k%10==0 else .14 if k%5==0 else .085
  p=(x,.721,z);ang=-a
  mesh=trimesh.creation.box((side,.026,.032))
  mesh.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
  mesh.apply_translation(p)
  m.add(t+f'_FixedScaleMarker_{k:02d}',mesh,'cyan' if k%10==0 else 'fog')
 # bold fixed circular rim / direction arrows
 m.torus(t+'_CyanOuterRing',4.58,.040,(0,.746,0),'cyan',axis='y',segments=148,tube_segs=8)
 m.torus(t+'_GoldSecurityOuterRing',4.77,.028,(0,.706,0),'gold',axis='y',segments=148,tube_segs=7)
 for j in range(8):
  a=math.tau*j/8
  m.cyl(t+f'_TopPlateBolt_{j}',.081,.036,(4.88*math.cos(a),.688,4.88*math.sin(a)),'gold',sections=14)
 # lower spindle (stationary outer bearing), a hub center spring showing depth below platter
 m.cyl(t+'_CentralPillar',.72,.46,(0,1.15,0),'steel',sections=72)
 m.torus(t+'_SpindleSeal',.73,.047,(0,1.36,0),'cyan',axis='y',segments=72,tube_segs=8)
 for xx in (-4.40,4.40):
  for zz in (-4.43,4.43):rotary_foot(m,t+f'_Corner_{xx:.0f}_{zz:.0f}',xx,zz)
 # built-in 5V SOURCE DOCK for art-only placement of sockets and existing 5V supply prefab connection
 # It stays part of fixed base, so exactly NINE individual FBX files.
 m.bevel(t+'_FiveVoltSupplyDockRubber',(3.17,.16,1.08),(-5.95,.17,-4.41),'rubber',.08)
 m.bevel(t+'_FiveVoltSupplyDock',(3.08,.40,1.03),(-5.95,.44,-4.41),'deep_steel',.06)
 m.bevel(t+'_FiveVoltDockFrontTag',(2.91,.28,.028),(-5.95,.69,-4.955),'void',.025)
 lbl(m,t+'_SupplyDock_Label','5 V POWER',-5.95,.68,-4.990,.171,'ice',2.55)
 # local port positions both inside dock front; labels top are clear
 socket(m,t,'SUPPLY_PLUS_5V','+5 V',-6.70,.405,-4.970,'red')
 socket(m,t,'SUPPLY_RETURN','GND',-5.27,.405,-4.970,'blue')
 top_lamp(m,t+'_SupplyPowerLamp',-5.94,.67,-4.15,'green')
 # fixed HOME mechanical index at +X, aligns with read head and disc Z at 0deg
 m.box(t+'_HomeIndexArrow_Plate',(.46,.045,.64),(4.95,.784,0),'void')
 m.box(t+'_HomeIndexArrow_LuminousTip',(.28,.06,.36),(5.04,.823,0),'orange')
 for xx,zz in [(-4.70,0),(4.70,0),(0,-4.70),(0,4.70)]:
  m.box(t+f'_Perimeter_MachinedTab_{xx:.1f}_{zz:.1f}',(.48,.11,.19) if xx else (.19,.11,.48),(xx,.719,zz),'steel')
 m.group_pivots['Fixed_Rail']= (0,0,0)
 return m

def build_platter():
 m=Model('02_L44_RotatingPlatter');t='L44_PLATTER';g='Platter_ROTATE_Y_ANIMATE'
 # platter is visual independent of bearing base and encoder disc; same exact central pivot
 m.cyl(t+'_RadialAluminumCasting',R_PLATTER,.33,(0,1.37,0),'titanium',sections=128,group=g)
 m.cyl(t+'_CarbonAntiSlipDeck',3.36,.084,(0,1.578,0),'graphite',sections=128,group=g)
 m.torus(t+'_OuterBlueLightRing',3.49,.052,(0,1.583,0),'cyan',axis='y',segments=128,tube_segs=8,group=g)
 m.torus(t+'_InnerOrangeLightRing',2.94,.025,(0,1.631,0),'amber',axis='y',segments=120,tube_segs=7,group=g)
 m.torus(t+'_FineMachinedGroove',2.31,.026,(0,1.623,0),'steel',axis='y',segments=128,tube_segs=7,group=g)
 # radial brushed-metal concentric panels and 80 slots
 for k in range(80):
  a=k*math.tau/80
  rr=3.18;x,z=rr*math.cos(a),rr*math.sin(a)
  rad=.32 if k%10==0 else .17 if k%5==0 else .100
  mm=trimesh.creation.box((rad,.018,.027))
  mm.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
  mm.apply_translation((x,1.633,z))
  m.add(t+f'_80CountRadialTick_{k:02d}',mm,'gold' if k%10==0 else 'cyan_soft',g)
 # concentric machined slots, inspection pattern plate
 for k in range(8):
  a=math.tau*k/8;x,z=2.37*math.cos(a),2.37*math.sin(a)
  mm=trimesh.creation.box((.51,.028,.10))
  mm.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
  mm.apply_translation((x,1.627,z))
  m.add(t+f'_Eight_IndexPads_{k:02d}',mm,'mid_steel',g)
 m.cyl(t+'_HubBearingLower',.65,.11,(0,1.659,0),'steel',sections=48,group=g)
 m.cyl(t+'_CenterChuck',.46,.25,(0,1.823,0),'chrome',sections=60,group=g)
 m.torus(t+'_HubAurora',.48,.030,(0,1.953,0),'mint',axis='y',segments=60,group=g)
 m.cyl(t+'_PartSeat',1.38,.08,(0,1.718,0),'void',sections=64,group=g)
 # mechanical inspection fixture, radial grippers with brass bolts
 for k in range(4):
  a=k*math.tau/2 if k<2 else math.tau*(k-2)/2+math.pi/2
  x,z=1.74*math.cos(a),1.74*math.sin(a)
  mm=trimesh.creation.box((.72,.16,.40))
  mm.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]));mm.apply_translation((x,1.76,z))
  m.add(t+f'_RotaryFixtureJaw_{k}',mm,'steel',g)
  m.cyl(t+f'_JawGoldBolt_{k}',.07,.035,(x,1.856,z),'gold',sections=16,group=g)
 # contrasting circular arrow trail with inset rings at intervals
 for k in range(12):
  a=math.tau*k/12
  m.cyl(t+f'_PlatterDeckLed_{k:02d}',.075,.023,(2.68*math.cos(a),1.638,2.68*math.sin(a)),'mint',sections=13,group=g)
 m.group_pivots[g]=(0,1.28,0)
 return m

def build_disc():
 m=Model('03_L44_EncoderDisc');t='L44_ENCODER';g='EncoderDisc_ROTATE_Y_ANIMATE'
 # separated slotted optic encoder ring directly below the platter: 20 alternating periods, 80 quadrature decoded counts
 m.cyl(t+'_CircularEncoderHub',3.43,.11,(0,1.087,0),'steel',sections=136,group=g)
 m.torus(t+'_GraduatedCrown',3.95,.105,(0,1.112,0),'graphite',axis='y',segments=160,tube_segs=11,group=g)
 m.torus(t+'_PolishedOuterEdge',4.12,.034,(0,1.130,0),'chrome',axis='y',segments=160,tube_segs=7,group=g)
 m.torus(t+'_DeepBlackOpticalRing',3.78,.082,(0,1.164,0),'void',axis='y',segments=160,tube_segs=7,group=g)
 for k in range(20):
  a=k*math.tau/20
  x,z=3.87*math.cos(a),3.87*math.sin(a)
  # 20 equal spaced optical slots = 20 A/B quadrature cycles => 80 decoded edges/rev
  obj=trimesh.creation.box((.315,.025,.125))
  obj.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]));obj.apply_translation((x,1.192,z))
  m.add(t+f'_OPTICAL_A_B_SLOT_{k:02d}',obj,'ice' if k%2==0 else 'cyan',g)
 for k in range(80):
  a=k*math.tau/80
  x,z=4.02*math.cos(a),4.02*math.sin(a)
  obj=trimesh.creation.box((.095,.014,.025));obj.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
  obj.apply_translation((x,1.202,z));m.add(t+f'_COUNT_80_Graduation_{k:02d}',obj,'fog',g)
 # exactly one Z index mark, angular 0 (toward +X), aligned to fixed read head at 0/homing angle
 m.box(t+'_Z_INDEX_UNIQUE_MAGENTA_STRIPE',(.16,.09,.62),(3.99,1.218,0),'red',g)
 m.box(t+'_Z_INDEX_GOLD_DOT',(.185,.10,.18),(4.08,1.275,0),'gold',g)
 m.box(t+'_Z_INDEX_RadialPaint',(.35,.022,.09),(3.79,1.277,0),'amber',g)
 m.group_pivots[g]=(0,1.12,0)
 return m

def build_readhead():
 m=Model('04_L44_EncoderReadHead');t='L44_READHEAD'
 # fixed right-side optical pickup module; can move beside disc at X + 4.5
 f=housing(m,t,'QUADRATURE HEAD',w=3.28,d=2.14,h=1.19,accent='cyan',subtitle='A / B + UNIQUE Z MARK')
 for k,(sid,txt,col) in enumerate([('ENCODER_A','A','mint'),('ENCODER_B','B','cyan'),('ENCODER_Z','Z','amber')]):
  xx=[.94,0,-.94][k]
  socket(m,t,sid,txt,xx,.51,f-.030,col)
  top_lamp(m,t+'_'+sid+'_FrontLens',xx,1.61,-.24,col,'EncoderSignalLamp_'+txt+'_VISUAL')
 # fixed dual optical reading heads on left side, pointing inward toward table edge
 m.bevel(t+'_PhotointerrupterFork',(1.31,.48,.89),(-1.77,1.05,.13),'steel',.046)
 for zz in (-.28,.28):
  m.box(t+f'_PhotointerrupterFinger_{zz}',(.83,.35,.11),(-2.34,1.10,zz),'chrome')
  m.box(t+f'_ReadPhotodiode_{zz}',(.13,.14,.10),(-2.69,1.11,zz),'green' if zz<0 else 'blue')
 m.box(t+'_IndexReadingEmitter',(.16,.12,.29),(-2.56,1.10,.0),'amber')
 m.torus(t+'_ScannerForkNeoTrapeze',.40,.018,(-2.58,1.16,0),'cyan',axis='x',segments=44,tube_segs=6)
 return m

def build_decoder():
 m=Model('05_L44_DecoderPanel');t='L44_DECODER';f=housing(m,t,'QUADRATURE DECODER',w=6.11,d=2.43,h=1.80,accent='cyan',subtitle='80 COUNTS / REV   |   A B Z')
 # Five sockets: 5V, RTN, Z, A, B. Arrange 5 front sockets spaced 1.09
 for xx,sid,txt,col in [(2.31,'DECODER_PLUS_5V','5V','red'),(1.14,'DECODER_RETURN','GND','blue'),(0.,'DECODER_Z','Z','amber'),(-1.14,'DECODER_A','A','mint'),(-2.31,'DECODER_B','B','cyan')]:
  socket(m,t,sid,txt,xx,.475,f-.033,col)
 # screen blank surface, angled slightly toward camera on a raised top bezel
 m.bevel(t+'_TopOLEDMount',(3.78,.10,1.18),(0,2.215,.13),'titanium',.055)
 m.bevel(t+'_BlankLiveDisplay',(3.50,.035,.97),(0,2.289,.14),'screen',.035)
 for xx in (-1.64,1.64):
  m.box(t+f'_OLED_EdgeGlow_{xx}',(.05,.022,.91),(xx,2.310,.14),'cyan')
 # three distinct visual state indicators: actual text via TMP in Unity
 for i,(name,col) in enumerate([('UNREF','amber'),('HOMED','green'),('DIR FAULT','red')]):
  xx=(1.52-i*1.52)
  m.bevel(t+f'_{name}_LampBacking',(.86,.08,.38),(xx,2.32,-.71),'void',.035)
  top_lamp(m,t+'_'+name+'_Lens',xx,2.39,-.71,col,'DecoderStatus_'+name.replace(' ','_')+'_VISUAL')
 lbl(m,t+'_FrontAbzLabels','A  /  B  /  Z',0,1.08,f-.068,.146,'ice',3.8)
 return m

def control_button(m,t,key,txt,x,z,col,pressed=False):
 g='Button_'+key+'_PRESS_ANIMATE'
 m.bevel(t+'_ButtonBezel_'+key,(1.01,.14,.67),(x,2.23,z),'steel',.055)
 m.bevel(t+'_ButtonCap_'+key,(.87,.18,.55),(x,2.34,z),col,.048,group=g)
 m.box(t+'_ButtonShine_'+key,(.61,.012,.040),(x,2.443,z-.12),'white',group=g)
 # text modeled on front face? top is upwards, no text on cap. Place a front-facing menu label panel below keys.
 m.group_pivots[g]=(x,2.34,z)
 return g

def build_controls():
 m=Model('06_L44_ControlPanel');t='L44_CTRL';f=housing(m,t,'INDEX TABLE CONTROL',w=8.0,d=3.35,h=1.80,accent='mint',subtitle='MOTION   /   REFERENCE   /   DIAGNOSTICS')
 # Seven pressable user controls including power cycle; each cap has own animation group.
 row=[('HOME','HOME',-2.80,.56,'green'),('CW','JOG CW',-1.56,.56,'cyan'),('CCW','JOG CCW',-.27,.56,'blue'),('STA','STATION A',1.10,.56,'mint'),('STB','STATION B',2.57,.56,'amber'),('FAULT','TEST DIR',-.80,-.49,'orange'),('POWER','POWER',1.70,-.49,'red')]
 for key,name,x,z,col in row:
  x=-x  # camera-facing hardware reads HOME -> CW -> CCW -> A -> B from left to right
  control_button(m,t,key,name,x,z,col)
  # clear separate front-facing engraved labels just above socket-free face
  label_x=x; size=.138 if len(name)<=7 else .112
  lbl(m,t+'_ControlLegend_'+key,name,x,.88 if z>.5 else .58,f-.061,size,'ice',1.08)
 # light strip around top edge and two status lenses
 for i,(name,col) in enumerate([('RUN','mint'),('STOP','red')]):
  xx=(-3.35 if i==0 else 3.35)
  top_lamp(m,t+'_Status_'+name,xx,2.21,-1.10,col,'StatusLamp_'+name+'_VISUAL')
 m.bevel(t+'_SafetyPowerPanel',(.73,.08,.45),(3.13,2.24,-.48),'graphite',.04)
 return m

def build_station(name,deg,color):
 # markers fixed, with separate illuminated lens for triggered station
 key={'HOME':'07_L44_HomeMarker','A':'08_L44_StationA','B':'09_L44_StationB'}[name]
 m=Model(key);t='L44_STATION_'+name
 m.bevel(t+'_RubberFloorPad',(1.39,.13,1.46),(0,.105,0),'rubber',.09)
 m.bevel(t+'_AnodizedStand',(1.30,.19,1.39),(0,.24,0),'steel',.08)
 m.bevel(t+'_RaisedSignPost',(1.08,1.16,.25),(0,.98,0),'graphite',.055)
 m.bevel(t+'_FrontPlate',(1.04,.72,.08),(0,1.13,-.172),'deep_steel',.04)
 lbl(m,t+'_Title',{'HOME':'HOME','A':'STATION A','B':'STATION B'}[name],0,1.18,-.229,.165,'white',.95)
 indicatorcol={'HOME':'amber','A':'mint','B':'blue'}[name]
 m.cyl(t+'_ChromeCircularBeaconRim',.29,.095,(0,1.78,0),'chrome',sections=40)
 m.cyl(t+'_BeaconLens',.225,.145,(0,1.865,0),indicatorcol,sections=40,group='Marker_StatusLamp_VISUAL')
 m.torus(t+'_BeaconHalo',.27,.026,(0,1.942,0),'ice',axis='y',segments=44,group='Marker_StatusLamp_VISUAL')
 m.bevel(t+'_PointerSurface',(.18,.26,.67),(0,.45,-.66),color,.06)
 m.box(t+'_GuideLED',(.086,.11,.30),(0,.53,-1.00),color)
 for x in (-.47,.47):bolt(m,t+f'_StandFastener_{x}',x,.351,-.48,.063)
 # informational only, marker transform placed in showcase on correct angular ray from home
 m.group_pivots['FixedStation']=(0,0,0)
 return m

def build_assembly_base():
 # visual-only foundation, not counted as one of the nine requested models
 m=Model('00_L44_Art_Only_AssemblyTray');t='L44_TRAY'
 m.bevel(t+'_FloatingRubberPerimeter',(24.85,.18,17.65),(0,.09,0),'rubber',.17)
 m.bevel(t+'_MachinedTitaniumEdge',(24.70,.22,17.50),(0,.23,0),'steel',.15)
 m.bevel(t+'_PerforatedGraphiteWorktop',(24.47,.09,17.22),(0,.37,0),'graphite',.10)
 for xx in (-12.09,12.09):m.box(t+f'_LongCyanEdge_{xx}',(.05,.06,16.85),(xx,.429,0),'cyan')
 for zz in (-8.48,8.48):m.box(t+f'_ShortCyanEdge_{zz}',(23.8,.06,.05),(0,.429,zz),'cyan')
 # Breadboard holes only on the front wiring row, spaced to be nonintrusive.
 for ii,xx in enumerate(np.linspace(-11.58,11.58,46)):
  for jj,zz in enumerate(np.linspace(-8.0,-6.37,4)):
   m.cyl(t+f'_BreadboardHole_{ii:02d}_{jj}',.026,.009,(xx,.422,zz),'void',sections=8)
 for x in [-10.6,-8.5,8.5,10.6]:
  m.box(t+f'_FrontWireRowGuide_{x}',(.07,.019,.65),(x,.426,-6.80),'mid_steel')
 m.box(t+'_RearCyanGuide',(22.4,.017,.045),(0,.424,7.82),'cyan_soft')
 m.box(t+'_FrontGroundTrace_VISUAL',(21.8,.016,.042),(0,.427,-7.63),'blue')
 m.box(t+'_FrontPowerTrace_VISUAL',(21.8,.016,.042),(0,.429,-7.30),'red')
 return m

BUILDERS=[build_table_base,build_platter,build_disc,build_readhead,build_decoder,build_controls,
          lambda:build_station('HOME',0,'amber'),lambda:build_station('A',STATION_A_DEG,'mint'),lambda:build_station('B',STATION_B_DEG,'blue')]

# Arranged ONLY as an art reference. Wiring sockets must be moved to actual breadboard holes in Unity.
POSITIONS={'00_L44_Art_Only_AssemblyTray':(0,0,0),
 '01_L44_TableBase':(0,0,-.40),'02_L44_RotatingPlatter':(0,0,-.40),'03_L44_EncoderDisc':(0,0,-.40),
 '04_L44_EncoderReadHead':(6.78,0,-.40),
 '05_L44_DecoderPanel':(-6.00,0,5.9),'06_L44_ControlPanel':(4.22,0,5.95),
 '07_L44_HomeMarker':(10.40,0,-.40),
 '08_L44_StationA':(0,0,-6.06),
 '09_L44_StationB':(-3.32,0,4.61)}

WIRES=[('W01','SUPPLY_PLUS_5V','DECODER_PLUS_5V'),
('W02','SUPPLY_RETURN','DECODER_RETURN'),
('W03','ENCODER_Z','DECODER_Z'),
('W04','ENCODER_A','DECODER_A'),
('W05','ENCODER_B','DECODER_B')]

def build():
 models=[b() for b in BUILDERS]
 assert len(models)==9
 assert sum(len(m.anchors) for m in models)==10,[(m.key,len(m.anchors)) for m in models]
 allids=[s for m in models for s in m.anchors]
 assert len(allids)==len(set(allids))==10
 assert sorted([p for _,a,b in WIRES for p in (a,b)])==sorted(allids)
 assets={}
 for m in models:
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m]);scene=trimesh.load_scene(glb)
  assert scene.geometry and fbx.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  assets[m.key]={'fbx':fbx.name,'glb':glb.name,'mesh_parts':len(m.parts),
   'triangles':int(sum(len(p.mesh.faces) for p in m.parts)),
   'anchors':m.anchors,'animation_groups':m.group_pivots,
   'non_static_groups':list(dict.fromkeys(p.group for p in m.parts if p.group!='Static'))}
  print('MODEL',m.key,'parts',len(m.parts),'triangles',assets[m.key]['triangles'],'sockets',len(m.anchors),flush=True)
 showcase=[build_assembly_base()]+models
 name='Level44_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(name+'.fbx'),showcase,positions=POSITIONS)
 export_glb(MODELS/(name+'.glb'),showcase,positions=POSITIONS)
 assert trimesh.load_scene(MODELS/(name+'.glb')).geometry
 manifest={'level':44,'name':'Find Home','style':'AAA-inspired semi-HD futuristic industrial indexing table','individual_models':9,
  'units':'Y UP. Local units. +X at the disc read head and HOME marker. Front is -Z.',
  'counts_per_revolution':COUNT_PER_REV, 'quadrature_cycles':20,
  'home_degrees':0,'station_A':{'counts':20,'degrees':90},'station_B':{'counts':52,'degrees':234},
  'index_Z_mark':'Single mark on rotating encoder disc at angle 0, under stationary read head; same local Y rotation as platter.',
  'wire_order':'Wire W01 W02 W03 then A and B last as W04 and W05. Undo Last twice removes A and B.',
  'art_socket_count':len(allids),'electrical_wires':WIRES,
  'notes':['Nine models as requested. The existing 5 V supply is represented by an integrated mounting dock on TableBase with its two sockets. This is only visual, not a substitute for the actual power-source component.',
    'The read head has encoder A, B, Z output sockets. Decoder has 5V, RETURN, Z, A, B input sockets.',
    'All sockets are geometry-only. SparkTerminal objects must be added/snapped in the game scene; avoid duplicate electrical components.',
    'The physical encoder disc has 20 alternating slots for 20 A/B cycles and a single Z index marking (80 decoded transitions/revolution).',
    'The platter and encoder disc have independent centered Y rotation group pivots; animate with identical local Y angle.',
    'Automatic station selection and homing logic are intentionally NOT included in the model pack.',
    'For visualized power cycle, turn off decoder UI lamps; the platter remains at its current position.',
    'Station positions are visual placements on showcase board; customize to your layout without changing their target angles.',
    'There are no official Level44 SparkLevelSceneBindings identifiers in the brief. Anchor IDs are suggested role labels.',
    'The model pack does not include wires, allowing player to draw them in-game.'],
  'models':assets,
  'showcase':{'fbx':name+'.fbx','glb':name+'.glb','triangles':int(sum(len(p.mesh.faces) for m in showcase for p in m.parts))},
  'showcase_positions':POSITIONS}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  wr=csv.writer(f);wr.writerow(['Model','ArtSocketID','X','Y','Z','Role / Unity note'])
  for m in models:
   for sid,v in m.anchors.items():
    wr.writerow([m.key+'.fbx',sid,*v,'ART ONLY; create SparkTerminal and snap to real breadboard holes; not official Unity binding ID'])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
  wr=csv.writer(f);wr.writerow(['Wire','From art anchor','To art anchor','Design intent'])
  for w,a,b in WIRES:wr.writerow([w,a,b,'A/B last for Undo Last twice' if w in ('W04','W05') else 'Base power / Z wiring'])
 with (ROOT/'Animation_Rigs.csv').open('w',newline='',encoding='utf-8') as f:
  wr=csv.writer(f);wr.writerow(['Model','Named FBX group','Pivot x','Pivot y','Pivot z','Animation behaviour'])
  for m in models:
   for group in dict.fromkeys(p.group for p in m.parts if p.group!='Static'):
    pivot=m.group_pivots.get(group,(0,0,0))
    if 'ROTATE_Y' in group:how='Rotate local Y to the SAME index angle as the other rotary group; count/80 * 360 degrees'
    elif 'Button_' in group:how='Translate button cap downward 0.04 local Y when pressed'
    else:how='Optional visual light / lamp activation; material emission via Unity scripts'
    wr.writerow([m.key+'.fbx',group,*pivot,how])
 return models

if __name__=='__main__':build()
