PROJECT SPARK — LEVEL 44 / FIND HOME
POLISHED SEMI-HD / AAA-INSPIRED UNITY 3D ART PACK
=================================================

CONTENTS
- 9 separate FBX 7.4 binary files and 9 GLB backup versions.
- 1 assembled showcase FBX + GLB with all 9 models arranged on an ART-ONLY tray.
- Actual rendered PNGs: complete kit, 9 standalone previews, contact sheet.
- Model_Manifest.json — mesh counts, groups, sockets, display positions.
- Terminal_Anchors.csv — exactly TEN visual socket coordinates.
- Exact_Wiring.csv — exact FIVE connections supplied in the level brief.
- Animation_Rigs.csv — child group names and model-local pivot locations.
- Sources/ — editable procedural geometry and preview renderer.
- Unity_Optional/SparkLevel44VisualRig.cs — OPTIONAL visual animation; no solver modifications.

THE NINE FBX MODELS
01_L44_TableBase.fbx             fixed housing / bearing / 5V supply dock with 2 visual sockets
02_L44_RotatingPlatter.fbx       rotary inspection table with centered Y-axis pivot
03_L44_EncoderDisc.fbx          20-cycle opto encoder / 80 decoded counts / single Z index
04_L44_EncoderReadHead.fbx      fixed read head with A, B and Z outputs
05_L44_DecoderPanel.fbx         5V / GND / Z / A / B inputs + blank display
06_L44_ControlPanel.fbx         HOME / CW / CCW / STATION A / STATION B / TEST DIR / POWER
07_L44_HomeMarker.fbx           fixed zero-position beacon
08_L44_StationA.fbx             fixed +20 counts (90 degrees) beacon
09_L44_StationB.fbx             fixed +52 counts (234 degrees) beacon

IMPORTANT: The user's model list specified nine physical models, no extra power supply.
The first model contains a 5V SUPPLY ART DOCK with 2 visible power sockets;
place the real, already-present Project Spark 5V source component behind/beside that dock.
Do NOT mistake the artwork for a new SparkPowerSupply/electrical simulator.

EXACT WIRING — CONNECT A/B LAST
W01   Supply +5 V     -> Decoder +5 V
W02   Supply return  -> Decoder return
W03   Encoder Z      -> Decoder Z
W04   Encoder A      -> Decoder A
W05   Encoder B      -> Decoder B

Wire W04 and W05 LAST. Undo Last twice will then remove A/B for the direction fault lesson.
There are 10 terminals in the artwork, each represented once in Terminal_Anchors.csv.
Use your actual binding IDs if they differ from the descriptive art anchor IDs.

UNITY IMPORT / SETUP
1. Unzip and import Models/*.fbx into Assets/My_Assets/_Project_Spark/Models/Level44/.
2. Place the TableBase, RotatingPlatter and EncoderDisc at EXACTLY the same world origin.
   They are modeled in one common local coordinate system; do not independently re-center meshes.
3. Find child null groups Platter_ROTATE_Y_ANIMATE and EncoderDisc_ROTATE_Y_ANIMATE.
   Use them as the local Y rotation targets and keep the disc and platter synchronized.
4. Place the EncoderReadHead so its fork senses the encoder edge and Z stripe at home.
   The assembled showcase has an example placement, but your game board can differ.
5. Put Home, Station A, Station B at 0 / 90 / 234 degrees around the table.
   The HOME Z stripe is on the +X radius in the model's default orientation.
6. Add/assign your real SparkTerminal objects to the 10 visually indicated art anchors.
   The CSV coordinates are local to each separate FBX/model's original origin.
   Snap the terminals to REAL breadboard holes in your level layout (visual sockets alone
   do not create a live circuit node or wire connection).
7. Keep the entire front row open for the player's 5 drawn wires. Models contain no wires.
8. Put your real TextMeshPro labels on the front surface, including actual A/B/Z/count
   and status text. Use your requested X/Y TextMesh style/size as appropriate (e.g. 0.20).
9. The decoder screen face is intentionally blank; do not keep a fake displayed count.
10. Assign actual Unity interaction and the Level 44 observer/controller to the switches.
    The meshes and optional visual helper DO NOT implement the 6 objectives.

ANIMATION RECOMMENDATIONS
- Visual angle: signed decodedCount * (360/80) degrees around local +Y.
- HOME mark: default +X radius aligns with stationary Z read head when homed.
- Station A: +20/80 rev = +90 degrees.
- Station B: +52/80 rev = +234 degrees.
- When decoder power cycles, the physical table DOES NOT MOVE; only reference is lost.
- A/B swap should reverse counted direction in your gameplay code and trigger the
  controller's safety stop. Never physically rotate the motor just from this visual rig.
- Status LEDs: UNREFERENCED amber / HOMED green / DIRECTION FAULT red.

MATERIALS
Current FBX is a separate-color metal/acrylic/cyan-orange industrial art pack.
GLBs are provided as visual backups and import/conversion resources.
For final AAA polish in URP/HDRP, assign suitable Lit/ShaderGraph materials,
normal/roughness maps, emission, reflection probes, and post-process bloom.

MODEL COORDINATES
Y up, +X toward the read head at 0 degrees, front faces -Z.
Visual units are intentionally relative and might require uniform scale in Unity.
FBX includes child hierarchy and named moving pieces; no baked animations.

VERIFICATION / LIMITATIONS
FBX files are structurally checked; GLB files successfully load as 3D mesh scenes.
No hands-on Unity import, collider test, gameplay script test, or animation test has
been performed. Mesh socket geometry is NOT the same as a live SparkTerminal.
