PROJECT SPARK — LEVEL 57: SYNCHRONIZE THE GRID
Modular procedural 3D art pack; 22 separate FBX 7.4 binary files + 22 GLB files, plus assembled FBX/GLB.

IMPORT: Import Models/ into Unity. Select your Level 57 layout object, place the Editor script inside an Editor folder, run Tools > Project Spark > Levels > 57 > Place HD Art Under Selected Layout. Keep every model under a shared root, each at local position zero, rotation identity, scale one. Assets are modeled in Y-up meters; verify actual imported size. Do NOT instantiate combined assembly and individual models at the same time.

NAMED PIVOTS: See Animation_Rigs.csv for controllable mesh groups (motor spin, monitor, contactor, switch, emergency button, cooling fans, synchronoscope). Model_Manifest.json describes each asset.

NOT INCLUDED: No authentic SparkTerminal components or validated socket anchor coordinates, no actual 34-wire topology, three-phase solver, real PLL, load balancing, fault handling, gameplay objectives, prefabs or Play Mode test. Decorative sockets are art only. Material assignment is colored FBX phong and GLB vertex colors, not photorealistic textured PBR. Final visual polish depends on Unity material conversion and lighting. Do not claim this procedural geometry to be studio-certified AAA quality.
