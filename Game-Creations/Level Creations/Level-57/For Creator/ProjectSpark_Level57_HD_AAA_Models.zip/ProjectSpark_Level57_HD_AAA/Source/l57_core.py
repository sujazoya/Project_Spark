"""Project Spark Level 57 procedural HD 3D model generator.
Creates 20 independent, colored and named triangle-mesh assets plus FBX 7.4 binary and GLB backups.
Visual assets only: no electrical measurements or objectives fabricated.
"""
from __future__ import annotations
import os, math, csv, json, zlib, struct, zipfile, pathlib, textwrap
from collections import defaultdict
from dataclasses import dataclass
import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level57_HD_AAA')
for d in ['Models','GLB','Previews','Unity_Optional','Source']: (ROOT/d).mkdir(parents=True,exist_ok=True)
R = math.pi/180
C = {
 'titanium':(0.27,0.38,0.46,1),'blue_steel':(.17,.29,.38,1),'navy':(.045,.093,.155,1),
 'carbon':(.035,.065,.095,1),'dark':(.065,.10,.145,1),'chrome':(.74,.85,.90,1),
 'silver':(.49,.65,.75,1),'silver_dark':(.32,.44,.54,1),'copper':(.77,.34,.12,1),
 'bronze':(.84,.49,.18,1),'gold':(.96,.68,.25,1),'amber':(1,.66,.21,1),
 'cyan':(.18,.89,1,1),'electric':(.05,.56,.98,1),'mint':(.2,1,.72,1),
 'green':(.1,.93,.43,1),'red':(1,.18,.27,1),'white':(.82,.95,1,1),
 'acrylic':(.33,.71,.86,.15),'acrylic_rim':(.43,.69,.83,1),'rubber':(.035,.05,.075,1),
 'display':(.017,.066,.106,1),'grid':(.08,.22,.29,1),'warning':(.95,.65,.08,1),
 'violet':(.55,.35,.93,1)
}
@dataclass
class Part:
 name:str
 mesh:trimesh.Trimesh
 mat:str
 group:str|None=None
@dataclass
class Asset:
 name:str
 parts:list
 groups:dict
 def __init__(self,name):self.name=name;self.parts=[];self.groups={}
 def add(self,name,mesh,mat,group=None):
  if mesh is None or len(mesh.faces)==0: return
  mesh=mesh.copy(); mesh.remove_unreferenced_vertices()
  assert mat in C,mat
  self.parts.append(Part(name,mesh,mat,group))
 def pivot(self,name,loc): self.groups[name]=np.array(loc,dtype=float)

assets=[]; current=None
MODELS=['L57_IndustrialMicrogridBase','L57_PrimaryGridInverter','L57_SecondaryGridInverter','L57_DCSource5V','L57_EnergyStorageModule','L57_ThreePhaseBusbar','L57_SynchronizationRelay','L57_ThreePoleContactor','L57_GridVoltageSensor','L57_InverterVoltageSensor','L57_FrequencyPhaseDetector','L57_CurrentTransformerBank','L57_SmartLoadBank','L57_IndustrialMotorLoad','L57_PowerQualityAnalyzer','L57_MicrogridController','L57_HolographicGridMonitor','L57_ProtectionRelayUnit','L57_IslandModeTransferSwitch','L57_CoolingAssembly','L57_TransparentSafetyEnclosure','L57_EmergencyStopStation']
def start(i):
 global current
 current=Asset(MODELS[i]);assets.append(current)
 return current

def add(n,m,mat,group=None):current.add(n,m,mat,group)
def T(mesh,pos):
 m=mesh.copy();m.apply_translation(pos);return m

def box(n,pos,size,mat,group=None):
 m=trimesh.creation.box(extents=size)
 add(n,T(m,pos),mat,group)
def cyl(n,pos,r,l,axis='y',mat='silver',sections=32,group=None):
 mesh=trimesh.creation.cylinder(radius=r,height=l,sections=sections)
 if axis=='x':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':mesh.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 add(n,T(mesh,pos),mat,group)
def tor(n,pos,rad,tube,axis='x',mat='silver',seg=64,minor=10,group=None):
 mesh=trimesh.creation.torus(major_radius=rad,minor_radius=tube,major_sections=seg,minor_sections=minor)
 if axis=='x':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':mesh.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 add(n,T(mesh,pos),mat,group)
def ann(n,pos,outer,inner,depth,axis='x',mat='silver',seg=56,group=None):
 # explicit annular extrusion, open bore
 angles=np.linspace(0,2*math.pi,seg,endpoint=False)
 pts=[]
 for x in [-depth/2,depth/2]:
  for rad in [outer,inner]:
   for a in angles:
    if axis=='x':p=[x,rad*math.cos(a),rad*math.sin(a)]
    elif axis=='y':p=[rad*math.cos(a),x,rad*math.sin(a)]
    else:p=[rad*math.cos(a),rad*math.sin(a),x]
    pts.append(p)
 faces=[]
 for k in range(seg):
  j=(k+1)%seg
  for a,b,c,d in [(k,j,seg+j,seg+k), (2*seg+k,3*seg+k,3*seg+j,2*seg+j),
                  (k,2*seg+k,2*seg+j,j),(seg+k,seg+j,3*seg+j,3*seg+k)]:
   faces.extend([[a,b,c],[a,c,d]])
 m=trimesh.Trimesh(vertices=np.array(pts),faces=np.array(faces),process=False)
 add(n,T(m,pos),mat,group)
def bolt(n,pos,axis='y',size=.038):
 cyl(n+'_Head',pos,size,size*.5,axis,'chrome',12)
 cyl(n+'_Mark',np.array(pos)+([0,size*.23,0] if axis=='y' else [size*.23,0,0]),size*.38,size*.09,axis,'dark',6)
def beam(n,a,b,r,mat='silver',seg=10,group=None):
 a=np.array(a,float);b=np.array(b,float)
 d=b-a; length=np.linalg.norm(d)
 if length<1e-5:return
 m=trimesh.creation.cylinder(radius=r,height=length,sections=seg)
 m.apply_transform(trimesh.geometry.align_vectors([0,0,1],d/length))
 add(n,T(m,(a+b)/2),mat,group)
def cable(n,points,r=.018,mat='rubber',seg=9):
 for j,(a,b) in enumerate(zip(points[:-1],points[1:])): beam(n+f'_{j:02d}',a,b,r,mat,seg)
def led(n,pos,mat='cyan',r=.045,axis='z'):
 cyl(n+'_Bezel',pos,r*1.35,.017,axis,'chrome',18)
 d={'x':[.010,0,0],'y':[0,.010,0],'z':[0,0,.010]}[axis]
 cyl(n+'_Lens',np.array(pos)+d,r,.015,axis,mat,20)
def feet(n,x,z):
 cyl(n+'_Rubber',(x,-.35,z),.14,.12,'y','rubber',16)
 cyl(n+'_Top',(x,-.28,z),.12,.035,'y','silver',20)
def panel(n,pos,w=1.25,header='DRIVE',color='cyan',socket_names=None):
 # Front-facing electronic module at z=2.13, sockets are front face (+Z)
 x,y,z=pos; width=w
 box(n+'_Body',(x,y,z),[width,.56,.48],'navy')
 box(n+'_Face',(x,y,z+.245),[width-.06,.48,.018],'dark')
 box(n+'_AnodizedTop',(x,y+.291,z),[width,.025,.48],'blue_steel')
 box(n+'_TopLight',(x,y+.308,z),[width-.07,.010,.033],color)
 for sign in [-1,1]:
  for signy in [-1,1]: bolt(n+f'_Screw_{sign}_{signy}',(x+sign*(width/2-.09),y+signy*.18,z+.263),'z',.023)
 text_geo(n+'_Label',header,(x-width*.42,y+.13,z+.264),max_width=width*.84,size=.055,mat='white')
 led(n+'_PowerStatus',(x-width*.40,y-.01,z+.264),'green',.029,'z')
 if socket_names:
  m=len(socket_names); spacing=min(.25,(width-.20)/max(1,m));first=x-(m-1)*spacing/2
  for i,s in enumerate(socket_names):
   xx=first+i*spacing; zz=z+.277
   cyl(n+f'_JackOuter_{s}',(xx,y-.145,zz),.072,.024,'z','chrome',18)
   cyl(n+f'_JackInner_{s}',(xx,y-.145,zz+.014),.048,.024,'z',('red' if s in ['+5V','M+','PWR+'] else 'electric' if s in ['GND','0V','M-','PWR-'] else color),18)
   cyl(n+f'_JackHole_{s}',(xx,y-.145,zz+.028),.018,.011,'z','dark',12)

def text_geo(n,st,pos,max_width=1.2,size=.08,mat='white',group=None):
 try:
  import vtk
  v=vtk.vtkVectorText();v.SetText(st);v.Update();p=v.GetOutput();N=p.GetNumberOfPoints();F=p.GetNumberOfCells()
  if not N or not F:return
  arr=np.array([p.GetPoint(i) for i in range(N)])
  fs=[]
  for i in range(F):
   c=p.GetCell(i)
   if c.GetNumberOfPoints()==3: fs.append([c.GetPointId(j) for j in range(3)])
  if not fs:return
  arw=arr[:,0].max()-arr[:,0].min()
  scl=min(size,max_width/max(arw,.01))
  arr[:,:2]*=scl;arr[:,0]-=arr[:,0].min();arr[:,1]-=arr[:,1].min();
  arr+=np.array(pos)
  add(n,trimesh.Trimesh(vertices=arr,faces=np.array(fs),process=False),mat,group)
 except Exception as ex: print('text geo skipped',st,str(ex)[:100])


# ---- FBX 7400 binary writer ------------------------------------------------
class N:
 def __init__(self,name,*props,children=None):self.name=name;self.props=list(props);self.children=children or []
class Arr:
 def __init__(self,typ,arr):self.typ=typ;self.arr=arr
class I64:
 def __init__(self,n):self.n=int(n)
def prop_data(v):
 if isinstance(v,Arr):
  dtype={'d':np.dtype('<f8'),'f':np.dtype('<f4'),'i':np.dtype('<i4'),'l':np.dtype('<i8')}[v.typ]
  arr=np.asarray(v.arr,dtype=dtype);data=arr.tobytes();compressed=zlib.compress(data,5)
  return v.typ.encode()+struct.pack('<III',len(arr),1,len(compressed))+compressed
 if isinstance(v,I64):return b'L'+struct.pack('<q',v.n)
 if isinstance(v,bool):return b'C'+struct.pack('<?',v)
 if isinstance(v,int):return b'I'+struct.pack('<i',v)
 if isinstance(v,float):return b'D'+struct.pack('<d',v)
 if isinstance(v,str):
  b=v.encode('utf-8');return b'S'+struct.pack('<I',len(b))+b
 raise TypeError((type(v),v))
def write_node(n,offset):
 name=n.name.encode('utf8');props=b''.join(prop_data(p) for p in n.props)
 out=bytearray();children_offset=offset+13+len(name)+len(props)
 for child in n.children:
  childdata=write_node(child,children_offset+len(out));out.extend(childdata)
 if n.children:out.extend(b'\0'*13)
 end=offset+13+len(name)+len(props)+len(out)
 return struct.pack('<IIIB',end,len(n.props),len(props),len(name))+name+props+out

def P(name,typ,value,kind='Number'):
 # standard FBX Properties70 declaration
 if isinstance(value,(tuple,list,np.ndarray)):
  return N('P',name,typ,kind,'',*[float(x) for x in value])
 return N('P',name,typ,kind,'',value)
def model_node(i,name,mode,trans=(0,0,0)):
 return N('Model',I64(i),'Model::'+name,mode,children=[N('Version',232),N('Properties70',children=[P('Lcl Translation','Lcl Translation',trans,'A'),P('Lcl Rotation','Lcl Rotation',(0,0,0),'A'),P('Lcl Scaling','Lcl Scaling',(1,1,1),'A')]),N('Shading',True),N('Culling','CullingOff')])

def fbx_export(items,path,model_root):
 """Input: list Asset. Each mesh exported as independent geometry and Mesh model. Binary FBX7.4."""
 all_parts=[(a,p) for a in items for p in a.parts]
 material_names=sorted(set(p.mat for a,p in all_parts))
 matids={name:10000+i for i,name in enumerate(material_names)}
 obj=[];conn=[];gid=200000
 rootid=gid;gid+=1
 obj.append(model_node(rootid,'PROJECT_SPARK_LEVEL57_VISUAL_ROOT','Null'))
 conn.append(N('C','OO',I64(rootid),I64(0)))
 for name in material_names:
  rr,gg,bb,alpha=C[name];rr=float(rr);gg=float(gg);bb=float(bb)
  props=[P('DiffuseColor','Color',(rr,gg,bb)),P('AmbientColor','Color',(rr*.23,gg*.23,bb*.23)),
   P('SpecularColor','Color',(.43,.48,.52)),P('Shininess','double',38.0),P('Opacity','double',float(alpha))]
  obj.append(N('Material',I64(matids[name]),'Material::'+name,'',children=[N('Version',102),N('ShadingModel','phong'),N('MultiLayer',0),N('Properties70',children=props)]))
 for asset in items:
  aid=gid;gid+=1
  obj.append(model_node(aid,asset.name,'Null'))
  conn.append(N('C','OO',I64(aid),I64(rootid)))
  parents={None:aid}
  for group,loc in asset.groups.items():
   ig=gid;gid+=1;parents[group]=ig
   obj.append(model_node(ig,group,'Null',loc))
   conn.append(N('C','OO',I64(ig),I64(aid)))
  for part in asset.parts:
   m=part.mesh
   parent_loc=asset.groups.get(part.group,np.zeros(3))
   vertices=np.asarray(m.vertices,dtype=np.float64)-parent_loc
   faceindex=np.asarray(m.faces,dtype=np.int32).copy();faceindex[:,-1]=-faceindex[:,-1]-1
   # Explicit averaged normals: FBX ByVertice Direct
   normals=np.asarray(m.vertex_normals,dtype=np.float64)
   g_id=gid;mo_id=gid+1;gid+=2
   g_children=[N('GeometryVersion',124),N('Vertices',Arr('d',vertices.reshape(-1))),
    N('PolygonVertexIndex',Arr('i',faceindex.reshape(-1))),
    N('LayerElementNormal',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','ByVertice'),N('ReferenceInformationType','Direct'),N('Normals',Arr('d',normals.reshape(-1)))]),
    N('LayerElementMaterial',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','AllSame'),N('ReferenceInformationType','IndexToDirect'),N('Materials',Arr('i',[0]))]),
    N('Layer',0,children=[N('Version',100),N('LayerElement',children=[N('Type','LayerElementNormal'),N('TypedIndex',0)]),N('LayerElement',children=[N('Type','LayerElementMaterial'),N('TypedIndex',0)])])]
   obj.append(N('Geometry',I64(g_id),'Geometry::'+asset.name+'__'+part.name,'Mesh',children=g_children))
   obj.append(model_node(mo_id,asset.name+'__'+part.name,'Mesh'))
   conn.extend([N('C','OO',I64(g_id),I64(mo_id)),N('C','OO',I64(mo_id),I64(parents[part.group])),N('C','OO',I64(matids[part.mat]),I64(mo_id))])
 globs=N('GlobalSettings',children=[N('Version',1000),N('Properties70',children=[
 P('UpAxis','int',1,'Integer'),P('UpAxisSign','int',1,'Integer'),
 P('FrontAxis','int',2,'Integer'),P('FrontAxisSign','int',1,'Integer'),
 P('CoordAxis','int',0,'Integer'),P('CoordAxisSign','int',1,'Integer'),
 P('UnitScaleFactor','double',100.0)])])
 defs=N('Definitions',children=[N('Version',100),N('Count',len(obj)),
 N('ObjectType','Model',children=[N('Count',sum(o.name=='Model' for o in obj))]),
 N('ObjectType','Geometry',children=[N('Count',sum(o.name=='Geometry' for o in obj))]),
 N('ObjectType','Material',children=[N('Count',len(material_names))])])
 nodes=[N('FBXHeaderExtension',children=[N('FBXHeaderVersion',1003),N('FBXVersion',7400),N('Creator','Project Spark Level57 Procedural HD Asset Generator')]),globs,defs,N('Objects',children=obj),N('Connections',children=conn),N('Takes',children=[N('Current','')])]
 out=bytearray(b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400))
 for node in nodes:out.extend(write_node(node,len(out)))
 out.extend(b'\0'*13);out.extend(b'\0'*160)
 path.write_bytes(out)
 return len(out),len(obj)

def glb_export(asset,path):
 scene=trimesh.Scene()
 for grp,loc in asset.groups.items():
  # Empty node with meaningful pivot, retained in GLB graph.
  scene.graph.update(frame_to=grp,frame_from='world',matrix=trimesh.transformations.translation_matrix(loc))
 for p in asset.parts:
  m=p.mesh.copy()
  if p.group:
   m.apply_translation(-asset.groups[p.group]);parent=p.group
  else:parent='world'
  rgba=np.array(C[p.mat])*255
  m.visual.vertex_colors=np.tile(rgba.astype(np.uint8),(len(m.vertices),1))
  scene.add_geometry(m,geom_name=p.name,node_name=p.name,parent_node_name=parent)
 path.write_bytes(scene.export(file_type='glb'))

