import l57_core as core
from l57_core import *
import hashlib
# approximate layout: 9.6m wide / 5.6m deep; near front +Z

def boxb(name,x,y,z,w,h,d,mat='navy',group=None):box(name,(x,y,z),(w,h,d),mat,group)
def fins(prefix,x,y,z,w=.9,n=9):
 for j in range(n):
  xp=x-w/2+(j+.5)*w/n
  box(f'{prefix}_CoolingFin{j:02}',(xp,y,z),(.035,.34,.44),'silver')
def terminalrow(prefix,x,y,z,n=5,accent='cyan',span=.9):
 for i in range(n):
  xx=x+(i-(n-1)/2)*span/max(1,n-1)
  cyl(f'{prefix}_JackShell{i}',(xx,y,z),.068,.03,'z','silver',20)
  cyl(f'{prefix}_JackFace{i}',(xx,y,z+.018),.049,.018,'z', ['red','electric','amber','cyan','green'][i%5],16)
  cyl(f'{prefix}_JackCore{i}',(xx,y,z+.030),.017,.01,'z','dark',12)
def module(prefix,x,z,width=1.0,depth=.85,height=.85,accent='cyan',label='',sockets=5,top=1.3):
 y=top+height/2
 boxb(prefix+'_MainHousing',x,y,z,width,height,depth,'blue_steel')
 boxb(prefix+'_FrontFace',x,y,z+depth/2+.011,width-.07,height-.07,.024,'navy')
 boxb(prefix+'_TopCap',x,y+height/2+.019,z,width+.025,.045,depth+.025,'titanium')
 boxb(prefix+'_AccentLight',x,y+height/2+.049,z+depth/3,width-.12,.015,.029,accent)
 for xi in [-1,1]:
  for yi in [-1,1]:bolt(prefix+f'_Bolt_{xi}_{yi}',(x+xi*(width/2-.08),y+yi*(height/2-.10),z+depth/2+.035),'z',.022)
 if label:text_geo(prefix+'_EngravedLabel',label,(x-width*.42,y+height*.20,z+depth/2+.033),width*.84,.067,'white')
 terminalrow(prefix+'_Terminal',x,y-height*.22,z+depth/2+.045,sockets,accent,span=max(.4,width-.25))
 led(prefix+'_ReadyLED',(x-width*.37,y,z+depth/2+.05),'green',.036)
 return y

def screen(prefix,x,y,z,w=1.,h=.44):
 boxb(prefix+'_Glass',x,y,z,w,h,.026,'display')
 for i in range(9):
  xx=x-w*.43+i*w*.107
  beam(prefix+f'_Graph{i}',(xx,y-.1,z+.02),(xx,y-.1+.06+.07*math.sin(i*.8),z+.02),.008,'cyan',6)
 for i in range(3):
  boxb(prefix+f'_Meter{i}',x-w*.31+i*w*.31,y+.13,z+.025,.12,.016,.01,['cyan','amber','green'][i])

# 00 industrial base
start(0)
boxb('MainRigidTitaniumBed',0,.09,0,9.55,.38,5.6,'titanium')
boxb('RaisedDarkBed',0,.31,0,9.38,.1,5.42,'carbon')
boxb('RearPowerBay',0,.67,-1.56,9.12,.60,1.35,'blue_steel')
boxb('FrontPowerRack',0,.65,1.65,9.12,.65,.88,'navy')
for x in [-4.5,4.5]:
 for z in [-2.5,2.5]:
  cyl(f'AdjustableFoot_{x}_{z}',(x,-.2,z),.16,.30,'y','rubber',16)
for x in np.linspace(-4.35,4.35,13):
 boxb(f'FrontVent_{x:.2f}',x,.70,2.105,.045,.22,.018,'silver_dark')
for z in [-2.66,2.66]:boxb(f'EdgeLight_{z}',0,.36,z,9.3,.015,.03,'cyan')
for x in [-4.55,4.55]:boxb(f'SideRail_{x}',x,.36,0,.05,.055,5.4,'silver')
for x in [-4.25,4.25]:
 for z in [-2.45,2.45]:bolt('DeckCaptiveFastener',(x,.4,z),'y',.04)
text_geo('FrontWorkstationBrand','PROJECT SPARK - MICROGRID',( -2.2,.59,2.11),4.5,.12,'white')

# inverters: impressive tall cabinets left right at back
for idx,x,accent,title in [(1,-3.12,'cyan','INVERTER A'),(2,3.12,'amber','INVERTER B')]:
 start(idx)
 module(title.replace(' ','_'),x,-.90,1.62,1.04,1.83,accent,title,6,top=.46)
 screen('LCD',x,1.60,-.90+1.04/2+.05,1.08,.44)
 fins('InverterHeatsink',x,2.32,-1.05,1.25,11)
 for j in range(3):
  xx=x-.43+j*.43
  cyl(f'PhaseConnector_{j}',(xx,1.07,-.30),.093,.07,'z','chrome',24)
  cyl(f'PhaseColoredBushing_{j}',(xx,1.07,-.25),.065,.065,'z',['red','amber','electric'][j],20)
 for side in [-1,1]:boxb(f'FanGrilleSide{side}',x+side*.70,1.1,-.80,.025,.42,.42,'silver_dark')
 led('DCReadyLamp',(x-.59,1.73,-.31),'green')

# 03 supply
start(3);module('SUPPLY5V',-4.1,1.25,1.15,.62,.72,'cyan','5V DC',3)
screen('FiveVolt',-4.1,1.72,1.575,.64,.19)
#04 energy store
start(4);module('STORAGE',-2.55,1.25,1.35,.69,.72,'mint','DC BUFFER',4)
for i in range(5):cyl('CapCell'+str(i),(-3.05+i*.25,2.22,1.05),.085,.60,'y','electric',20)
boxb('CapTopRail',-2.55,2.56,1.05,1.3,.07,.33,'silver')
#05 busbar center behind contacts
start(5)
boxb('BusTransparentShield',0,1.62,-.98,2.65,1.1,.58,'acrylic')
for i,(color,y) in enumerate([('red',1.90),('amber',1.64),('electric',1.38)]):
 boxb(f'Phase{i}_SolidCopper',0,y,-.95,2.5,.078,.10,'copper')
 boxb(f'Phase{i}_InsulatedStrip',0,y,-.89,2.45,.044,.063,color)
 for x in [-1.07,0,1.07]:
  boxb(f'BusClamp_{i}_{x}',x,y,-.9,.08,.17,.15,'silver')
for x in [-1.32,1.32]:boxb('BusFrame',x,1.68,-.98,.07,1.23,.68,'silver')
text_geo('BusLabel','THREE-PHASE BUS A/B/C',(-1.08,2.29,-.63),2.2,.10,'white')
#06 synchronoscope
start(6);module('SYNCHRELAY',0,-1.95,1.40,.47,.65,'mint','SYNC RELAY',3,top=1.72)
cyl('SynchronoscopeRim',(0,2.17,-1.66),.235,.038,'z','chrome',40)
cyl('SynchronoscopeBlack',(0,2.17,-1.63),.202,.014,'z','display',40)
beam('SynchronoscopeNeedle',(0,2.17,-1.6),(.12,2.30,-1.60),.012,'green')
core.current.pivot('ANIM_SYNCHROSCOPE_NEEDLE',(0,2.17,-1.6))
for k in range(5):led('SynchLED'+str(k),(-.49+k*.25,1.92,-1.63),['cyan','green','amber','green','cyan'][k],.02)
#07 contactor central under bus
start(7)
boxb('ContactorChassis',0,1.11,-.9,2.6,.65,.62,'blue_steel')
for j,x in enumerate([-.76,0,.76]):
 boxb(f'ContactPole{j}',x,1.28,-.55,.45,.44,.23,'chrome')
 boxb(f'CopperContact{j}',x,1.42,-.41,.35,.07,.11,'copper','ANIM_CONTACTOR_ARMATURE')
 boxb(f'ArcChute{j}',x,1.6,-.51,.46,.17,.22,'silver_dark')
core.current.pivot('ANIM_CONTACTOR_ARMATURE',(0,1.42,-.50))
boxb('ContactorBar',0,1.44,-.39,2.18,.06,.09,'silver','ANIM_CONTACTOR_ARMATURE')
for j in range(3):led('ContactorPol'+str(j),(-.75+j*.75,.87,-.56),'green',.029)
#08/09 voltage sensors
for idx,x,title,color in [(8,-1.65,'GRID V','cyan'),(9,1.65,'INV V','amber')]:
 start(idx);module(title.replace(' ',''),x,.38,1.18,.55,.55,color,title,5,top=.57)
 screen('WaveformProbe',x,1.02,.70,.70,.22)
#10 phase detector
start(10);module('PHASE',0,.34,1.18,.58,.63,'green','PHASE DETECT',4,top=.55)
cyl('AngleDial',(0,1.09,.67),.13,.035,'z','chrome',32)
cyl('AngleFace',(0,1.09,.70),.10,.026,'z','display',32)
beam('AngleNeedle',(0,1.09,.72),(.06,1.15,.72),.011,'cyan')
core.current.pivot('ANIM_PHASE_INDICATOR',(0,1.09,.72))
#11 transformer bank
start(11)
boxb('CurrentTransformerBase',-2.9,.75,.07,1.5,.29,.6,'dark')
for j in range(3):
 x=-3.37+j*.48
 ann(f'CT_Core_{j}',(x,1.18,.07),.24,.115,.15,'z','silver_dark',48)
 tor(f'CT_CopperRing_{j}',(x,1.18,.085),.19,.031,'z','copper',40,9)
 cyl(f'CTWire_{j}',(x,1.18,.07),.065,.68,'z',['red','amber','electric'][j],16)
#12 smart load
start(12);module('SMARTLOAD',2.45,1.15,1.4,.8,.75,'amber','SMART LOAD',6)
fins('LoadCeramicFins',2.45,2.2,1.10,1.20,10)
for j in range(3):led('LoadStepLED'+str(j),(2.07+j*.37,1.75,1.57),'green',.028)
#13 industrial motor
start(13)
boxb('MotorMount',3.64,.66,-.10,1.75,.22,1.40,'dark')
cyl('MotorHousing',(3.66,1.22,-.12),.44,1.22,'x','electric',40)
for j in range(13):cyl(f'CoolingRib_{j}',(3.09+j*.093,1.22,-.12),.468,.027,'x','blue_steel',32)
cyl('MotorEndCap',(4.27,1.22,-.12),.32,.14,'x','chrome',32)
cyl('RotorShaft',(4.48,1.22,-.12),.086,.45,'x','silver',20,'ANIM_MOTOR_SPIN')
core.current.pivot('ANIM_MOTOR_SPIN',(4.32,1.22,-.12))
for i in range(4):boxb(f'MotorMountBolt{i}',3.15+(i%2)*1.0,.78,-.62+(i//2)*1.03,.11,.10,.11,'chrome')
#14 power quality analyzer
start(14);module('PQUALITY',-1.10,1.18,1.26,.59,.74,'cyan','PWR QUALITY',4)
screen('Waveform',-1.10,1.72,1.58,.75,.22)
#15 microgrid controller
start(15);module('MICROGRIDCTRL',.33,1.18,1.40,.72,.78,'mint','GRID CTRL',7)
for j in range(4):led('CtrlMode'+str(j),(-.09+j*.25,1.70,1.61),['green','cyan','amber','red'][j],.029)
#16 monitor: raised at far right back
start(16)
boxb('MonitorFoot',3.55,.56,-2.18,1.1,.14,.64,'dark')
boxb('MonitorStem',3.55,2.10,-2.20,.10,3.1,.13,'silver_dark')
boxb('MonitorFrame',3.25,2.54,-2.06,3.05,2.02,.12,'titanium')
boxb('MonitorBlackScreen',3.25,2.54,-1.98,2.88,1.84,.025,'display')
text_geo('MonitorHeading','MICROGRID STATUS',(1.98,3.31,-1.95),2.55,.13,'white')
for j in range(3):
 for k in range(25):
  x=2.04+k*.10;y=2.75+.16*math.sin(k*.41 + j*2*math.pi/3)
  if k:beam(f'PhaseWave{j}_{k}',(x-.10,2.75+.16*math.sin((k-1)*.41 +j*2*math.pi/3),-1.94),(x,y,-1.94),.009,['cyan','amber','electric'][j],6)
for j in range(6):boxb('DiagnosticGraphGrid'+str(j),3.23,2.17+j*.16,-1.95,2.66,.004,.002,'grid')
core.current.pivot('ANIM_MONITOR_TILT',(3.55,2.10,-2.20))
#17 protection relay
start(17);module('PROTECTION',1.85,1.17,1.0,.66,.72,'green','PROTECTION',4)
for j in range(3):led('TripIndicator'+str(j),(1.58+j*.28,1.69,1.56),['green','amber','red'][j],.029)
#18 transfer switch
start(18);module('TRANSFER',1.65,-1.79,1.03,.65,.74,'amber','GRID/ISLAND',4,top=.88)
cyl('TransferKnobOuter',(1.65,1.34,-1.43),.18,.08,'z','chrome',32)
cyl('TransferKnobCore',(1.65,1.34,-1.38),.12,.08,'z','dark',32)
boxb('SwitchHandle',1.65,1.39,-1.33,.05,.21,.10,'silver','ANIM_TRANSFER_HANDLE')
core.current.pivot('ANIM_TRANSFER_HANDLE',(1.65,1.34,-1.33))
#19 cooling
start(19)
boxb('CoolingHousing',-4.0,.80,-1.65,1.2,.68,.65,'blue_steel')
for j in range(2):
 x=-4.30+j*.6
 ann(f'FanRim{j}',(x,.93,-1.29),.21,.165,.045,'z','silver',32)
 for k in range(6):
  t=k*math.pi/3
  beam(f'Blade{j}_{k}',(x,.93,-1.26),(x+.16*math.cos(t),.93+.16*math.sin(t),-1.26),.035,'cyan',8,f'ANIM_COOLING_FAN_{j}')
 core.current.pivot(f'ANIM_COOLING_FAN_{j}',(x,.93,-1.26))
#20 glass safety enclosure around middle bus and contactor
start(20)
for x in [-1.50,1.50]:
 for z in [-1.32,-.21]:beam('SafetyFrameVertical',(x,.46,z),(x,2.45,z),.034,'silver',10)
for y in [.48,2.45]:
 for z in [-1.32,-.21]:beam('SafetyFrameLong',(-1.5,y,z),(1.5,y,z),.03,'chrome',10)
 for x in [-1.5,1.5]:beam('SafetyFrameShort',(x,y,-1.32),(x,y,-.21),.03,'chrome',10)
boxb('TopShield',0,2.46,-.76,3.0,.024,1.1,'acrylic')
boxb('RearShield',0,1.46,-1.32,3.0,1.94,.025,'acrylic')
boxb('DoorGlass',0,1.45,-.21,3.0,1.92,.024,'acrylic')
core.current.pivot('ANIM_SAFETY_DOOR',(-1.5,2.45,-.21))
#21 E stop
start(21)
boxb('EmergencyMount',4.21,.62,2.11,.55,.30,.42,'warning')
cyl('EmergencyButtonShroud',(4.21,.88,2.11),.18,.16,'y','amber',32)
cyl('MushroomEmergencyStop',(4.21,1.01,2.11),.23,.11,'y','red',36)
text_geo('EmergencyLabel','EMERGENCY',(3.96,.65,2.34),.5,.055,'dark')
core.current.pivot('ANIM_EMERGENCY_BUTTON',(4.21,1.01,2.11))

for i,a in enumerate(assets):
 filename=f'{i:02d}_{a.name}'
 fbx_export([a],ROOT/'Models'/(filename+'.fbx'),a.name)
 glb_export(a,ROOT/'GLB'/(filename+'.glb'))
 print(filename,sum(len(p.mesh.faces) for p in a.parts),len(a.parts),flush=True)
fbx_export(assets,ROOT/'Models'/'Level57_Complete_ArtKit_Showcase.fbx','ALL')
scene=trimesh.Scene()
for a in assets:
 for p in a.parts:
  m=p.mesh.copy();m.visual.vertex_colors=np.tile((np.array(C[p.mat])*255).astype(np.uint8),(len(m.vertices),1))
  scene.add_geometry(m,geom_name=a.name+'__'+p.name,node_name=a.name+'__'+p.name)
(ROOT/'GLB'/'Level57_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
manifest={'levelId':'level_57','displayName':'Synchronize the Grid','subtitle':'Advanced Smart Microgrid Three-Phase Synchronization and Load Sharing','sourceReference':'Approved concept visual and Level 57 design','models':[],'planned_player_wires':34,'planned_unique_sockets':54,'unit_scale':'Y-up, meters, front Z+','limitations':'Procedurally generated visual models only; exact 34-wire/54-terminal topology, terminal behaviors, materials, control, Unity import and authoritative objectives not implemented or tested.'}
for i,a in enumerate(assets):
 manifest['models'].append({'file':f'{i:02d}_{a.name}.fbx','model':a.name,'triangles':sum(len(p.mesh.faces) for p in a.parts),'mesh_parts':len(a.parts),'animation_pivots':{k:list(map(float,v)) for k,v in a.groups.items()}})
manifest['total_triangles']=sum(x['triangles'] for x in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with open(ROOT/'Animation_Rigs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['Model','Pivot','X','Y','Z','Note'])
 for a in assets:
  for name,pos in a.groups.items():w.writerow([a.name,name,*[round(float(z),4) for z in pos],'Art-only; apply simulated state to pivots'])
(ROOT/'README_Unity.txt').write_text('''PROJECT SPARK — LEVEL 57: SYNCHRONIZE THE GRID
Modular procedural 3D art pack; 22 separate FBX 7.4 binary files + 22 GLB files, plus assembled FBX/GLB.

IMPORT: Import Models/ into Unity. Select your Level 57 layout object, place the Editor script inside an Editor folder, run Tools > Project Spark > Levels > 57 > Place HD Art Under Selected Layout. Keep every model under a shared root, each at local position zero, rotation identity, scale one. Assets are modeled in Y-up meters; verify actual imported size. Do NOT instantiate combined assembly and individual models at the same time.

NAMED PIVOTS: See Animation_Rigs.csv for controllable mesh groups (motor spin, monitor, contactor, switch, emergency button, cooling fans, synchronoscope). Model_Manifest.json describes each asset.

NOT INCLUDED: No authentic SparkTerminal components or validated socket anchor coordinates, no actual 34-wire topology, three-phase solver, real PLL, load balancing, fault handling, gameplay objectives, prefabs or Play Mode test. Decorative sockets are art only. Material assignment is colored FBX phong and GLB vertex colors, not photorealistic textured PBR. Final visual polish depends on Unity material conversion and lighting. Do not claim this procedural geometry to be studio-certified AAA quality.
''')
print('FINISHED',len(assets),'models',manifest['total_triangles'],'triangles')
