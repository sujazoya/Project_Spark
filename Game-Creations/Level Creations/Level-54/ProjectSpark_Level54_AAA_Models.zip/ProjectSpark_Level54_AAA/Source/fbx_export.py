"""Small self-contained FBX 7.4 binary mesh exporter; standard FBX Objects/Connections.
Creates FBX Mesh, Material, hierarchy Nulls, named animation pivots and socket anchors.
"""
import struct,zlib
import numpy as np
class N:
    def __init__(self,name,*props,children=None): self.name=name;self.props=props;self.children=children or []
def e(v):
    if isinstance(v,bool):return b'C'+struct.pack('<?',v)
    if isinstance(v,np.integer):v=int(v)
    if isinstance(v,int): return b'L'+struct.pack('<q',v) if abs(v)>2147483647 else b'I'+struct.pack('<i',v)
    if isinstance(v,float):return b'D'+struct.pack('<d',v)
    if isinstance(v,str):
        b=v.encode('utf8');return b'S'+struct.pack('<I',len(b))+b
    if isinstance(v,tuple) and v[0]=='i':
        x=np.asarray(v[1],dtype='<i4').tobytes();code=b'i';count=len(v[1])
    elif isinstance(v,tuple) and v[0]=='d':
        x=np.asarray(v[1],dtype='<f8').tobytes();code=b'd';count=len(v[1])
    else:raise ValueError(type(v))
    zipped=zlib.compress(x,6)
    if len(zipped)+4<len(x):return code+struct.pack('<III',count,1,len(zipped))+zipped
    return code+struct.pack('<III',count,0,len(x))+x
def serialize(node,offset):
    name=node.name.encode('utf8'); pp=b''.join(map(e,node.props)); raw=b''; at=offset+13+len(name)+len(pp)
    for ch in node.children:
        c=serialize(ch,at);raw+=c;at+=len(c)
    if node.children:raw+=b'\0'*13
    end=offset+13+len(name)+len(pp)+len(raw)
    return struct.pack('<IIIb',end,len(node.props),len(pp),len(name))+name+pp+raw
def prop(name,ptype,area,flag,*nums):return N('P',name,ptype,area,flag,*nums)
def vecprop(n,values):return prop(n,n,'','A',*map(float,values))
def model_node(uid,name,kind='Null',pos=(0,0,0)):
    p=[N('Version',232), N('Properties70',children=[prop('Lcl Translation','Lcl Translation','','A',*map(float,pos)),prop('Lcl Rotation','Lcl Rotation','','A',0.,0.,0.),prop('Lcl Scaling','Lcl Scaling','','A',1.,1.,1.)])]
    if kind=='Mesh':p +=[N('Shading',True),N('Culling','CullingOff')]
    return N('Model',int(uid),'Model::'+name,kind,children=p)
def material_node(uid,name,color):
    r,g,b=color;return N('Material',int(uid),'Material::'+name,'',children=[N('Version',102),N('ShadingModel','phong'),N('MultiLayer',0),N('Properties70',children=[prop('DiffuseColor','Color','','A',float(r),float(g),float(b)),prop('SpecularColor','Color','','A',.65,.68,.71),prop('Shininess','double','Number','A',44.)])])
def geom_node(uid,name,verts,faces):
    vv=np.asarray(verts,dtype=np.float64).reshape(-1,3);ff=np.asarray(faces,dtype=np.int32).reshape(-1,3)
    tri=vv[ff]; norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]); length=np.linalg.norm(norm,axis=1);norm/=np.maximum(length[:,None],1e-12)
    normals=np.repeat(norm,3,axis=0).flatten()
    ids=ff.copy();ids[:,-1]=-ids[:,-1]-1
    return N('Geometry',int(uid),'Geometry::'+name,'Mesh',children=[N('GeometryVersion',124),N('Vertices',('d',vv.flatten())),N('PolygonVertexIndex',('i',ids.flatten())),N('LayerElementNormal',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','ByPolygonVertex'),N('ReferenceInformationType','Direct'),N('Normals',('d',normals))]),N('Layer',0,children=[N('Version',100),N('LayerElement',children=[N('Type','LayerElementNormal'),N('TypedIndex',0)])])])
def export(path,display_name,parts,anchors,pivots,palette,extra_meta=''):
    # parts = [(name,mesh,material,pivot_parent)] ; models are local to display_name object.
    mids={k:10001+i for i,k in enumerate(palette)};nxt=20000
    ob=[material_node(mids[k],k,c) for k,c in palette.items()];conn=[]
    root=nxt;nxt+=1; group=nxt;nxt+=1; stat=nxt;nxt+=1
    ob+=[model_node(root,'LEVEL54_VISUAL_ROOT'),model_node(group,display_name),model_node(stat,display_name+'_STATIC')]
    conn +=[N('C','OO',group,root),N('C','OO',stat,group),N('C','OO',root,0)]
    pid={}
    for name,pos in pivots.items():
        uid=nxt;nxt+=1;pid[name]=uid
        ob.append(model_node(uid,name,pos=pos));conn.append(N('C','OO',uid,group))
    for name,pos in anchors.items():
        uid=nxt;nxt+=1
        ob.append(model_node(uid,'SOCKET_'+name,pos=pos));conn.append(N('C','OO',uid,group))
    for name,mesh,mat,parent in parts:
        geoid=nxt;nxt+=1; modid=nxt;nxt+=1
        v=mesh.vertices.astype(np.float64)
        if parent in pivots:v=v-np.asarray(pivots[parent])[None,:]
        f=mesh.faces.astype(np.int32)
        ob.append(geom_node(geoid,display_name+'__'+name,v,f));ob.append(model_node(modid,display_name+'__'+name,'Mesh'))
        conn +=[N('C','OO',geoid,modid), N('C','OO',modid,pid.get(parent,stat)), N('C','OO',mids[mat],modid)]
    kinds={'Model':len(pivots)+len(anchors)+3+len(parts),'Material':len(palette),'Geometry':len(parts)}
    nodes=[
      N('FBXHeaderExtension',children=[N('FBXHeaderVersion',1003),N('FBXVersion',7400),N('Creator','Project Spark Level54 Polished Assets | Generated geometrically')]),
      N('GlobalSettings',children=[N('Version',1000),N('Properties70',children=[prop('UpAxis','int','Integer','',1),prop('UpAxisSign','int','Integer','',1),prop('FrontAxis','int','Integer','',2),prop('FrontAxisSign','int','Integer','',1),prop('CoordAxis','int','Integer','',0),prop('CoordAxisSign','int','Integer','',1),prop('UnitScaleFactor','double','Number','',1.0)])]),
      N('Definitions',children=[N('Version',100),N('Count',sum(kinds.values()))]+[N('ObjectType',kind,children=[N('Count',count)]) for kind,count in kinds.items()]),
      N('Objects',children=ob),N('Connections',children=conn)]
    header=b'Kaydara FBX Binary  \0\x1a\0'+struct.pack('<I',7400)
    data=header
    for nd in nodes:data+=serialize(nd,len(data))
    data+=b'\0'*13
    data+=b'\0'*160
    open(path,'wb').write(data)
    return len(data)
