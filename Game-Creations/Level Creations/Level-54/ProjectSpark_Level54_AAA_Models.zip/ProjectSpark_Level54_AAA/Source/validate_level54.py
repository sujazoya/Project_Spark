from pathlib import Path
import json, csv, struct, zipfile, hashlib
import trimesh
root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'Model_Manifest.json').read_text())
fbxs=list((root/'Models').glob('*.fbx'))
glbs=list((root/'GLB').glob('*.glb'))
assert len(fbxs)==18 and len(glbs)==18,(len(fbxs),len(glbs))
assert len(manifest['models'])==17
with (root/'Exact_Wiring.csv').open() as f:wires=list(csv.DictReader(f))
with (root/'Terminal_Anchors.csv').open() as f:anchors=list(csv.DictReader(f))
assert len(wires)==22 and len(anchors)==36
ids={x['SocketID'] for x in anchors}
assert len(ids)==36
assert {x['FromSocketID'] for x in wires}.union({x['ToSocketID'] for x in wires})==ids
fbx_checks=[]
# Validate recursive 7.4 binary node block offsets, proper termination and counts.
def nodeparse(data,start,stop):
    names=[];pos=start
    while pos+13<=stop:
        end,np,plen=struct.unpack_from('<III',data,pos);namelen=data[pos+12]
        if end==0:return names,pos+13
        assert pos < end <= len(data) and end<=stop,('bad FBX offset',pos,end,stop)
        name=data[pos+13:pos+13+namelen].decode('utf8')
        p0=pos+13+namelen
        p=p0
        for k in range(np):
            fmt=chr(data[p]);p+=1
            if fmt=='S' or fmt=='R':n=struct.unpack_from('<I',data,p)[0];p+=4+n
            elif fmt=='I' or fmt=='F':p+=4
            elif fmt=='L' or fmt=='D':p+=8
            elif fmt=='Y':p+=2
            elif fmt=='C':p+=1
            elif fmt in 'idfb':n,enc,nb=struct.unpack_from('<III',data,p);p+=12+nb
            else:raise RuntimeError((name,fmt,p))
        assert p==p0+plen,(name,p,p0+plen)
        names.append(name)
        if p < end-13 and data[p:p+13]!=b'\0'*13:
            _,q=nodeparse(data,p,end)
            assert q==end,(name,q,end)
        pos=end
    return names,pos
for file in fbxs:
    data=file.read_bytes()
    assert data[:23]==b'Kaydara FBX Binary  \x00\x1a\x00'
    assert struct.unpack_from('<I',data,23)[0]==7400
    names,at=nodeparse(data,27,len(data))
    assert 'Objects' in names and 'Connections' in names and at<len(data)
    fbx_checks.append({'filename':file.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
glb_checks=[]
for file in glbs:
    scene=trimesh.load(file,force='scene')
    assert len(scene.geometry)>0
    triangles=sum(len(m.faces) for m in scene.geometry.values())
    assert triangles>100
    glb_checks.append({'filename':file.name,'parts':len(scene.geometry),'triangles':triangles})
assert (root/'Previews/Level54_Hero_Polished_Preview.png').exists()
assert (root/'Previews/Level54_All_17_Models_ContactSheet.png').exists()
report={'level_id':'level_54','individual_models':17,'fbx_files':len(fbxs),'glb_files':len(glbs),'wires':len(wires),'unique_sockets':len(anchors),'total_individual_triangles':sum(m['triangles'] for m in manifest['models']),'fbx_checked':fbx_checks,'glb_checked':glb_checks,'unity_runtime_test':'NOT RUN','unity_import_test':'NOT RUN','scope':'visual FBX/GLB art, layout, anchors and visual-only helpers; gameplay objectives not implemented'}
(root/'Validation_Report.json').write_text(json.dumps(report,indent=2))
print('PASS',report['individual_models'],'models;',len(fbxs),'FBX;',len(glbs),'GLB;',len(wires),'wires;',len(ids),'sockets;',report['total_individual_triangles'],'triangles')
