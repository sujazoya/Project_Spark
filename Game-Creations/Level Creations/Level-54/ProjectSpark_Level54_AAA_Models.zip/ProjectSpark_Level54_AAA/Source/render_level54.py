from pathlib import Path
import os, math, time
import numpy as np
import trimesh, vtk
from PIL import Image,ImageDraw,ImageFont,ImageEnhance
ROOT=Path(__file__).resolve().parent.parent;PR=ROOT/'Previews';PR.mkdir(exist_ok=True)
modnames=['IndustrialBase','DriveMotor','FlexibleShaft','TestRotor','LeftFlexureBearing','RightFlexureBearing','DisplacementProbeX','DisplacementProbeY','EncoderABZ','ActiveDamper','DamperDriver','MotorDriver','CriticalSpeedController','OrbitSpectrumMonitor','SafetyGuard','SensorCalibrationStand','5VSupply']
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
fontbold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def vtkactor(mesh):
 v=np.asarray(mesh.vertices);f=np.asarray(mesh.faces)
 pts=vtk.vtkPoints();pts.SetDataTypeToFloat()
 for xyz in v:pts.InsertNextPoint(float(xyz[0]),float(xyz[1]),float(xyz[2]))
 polys=vtk.vtkCellArray()
 for face in f:
  ids=vtk.vtkIdList();ids.SetNumberOfIds(3)
  for i in range(3):ids.SetId(i,int(face[i]))
  polys.InsertNextCell(ids)
 pd=vtk.vtkPolyData();pd.SetPoints(pts);pd.SetPolys(polys)
 m=vtk.vtkPolyDataMapper();m.SetInputData(pd);m.ScalarVisibilityOff()
 actor=vtk.vtkActor();actor.SetMapper(m)
 col=np.array(mesh.visual.vertex_colors[0],dtype=float)/255 if len(mesh.visual.vertex_colors) else np.array([.7,.7,.75,1])
 actor.GetProperty().SetColor(*[float(c) for c in col[:3]]);
 actor.GetProperty().SetOpacity(float(col[3]));actor.GetProperty().SetSpecular(.35);actor.GetProperty().SetSpecularPower(25);actor.GetProperty().SetInterpolationToPhong()
 return actor

def capture(glb_path,output,width,height,cam='hero',transparent=True):
 start=time.time()
 sc=trimesh.load(str(glb_path),force='scene');meshes=list(sc.geometry.values())
 ren=vtk.vtkRenderer();ren.GradientBackgroundOn();ren.SetBackground(.03,.075,.13);ren.SetBackground2(.08,.16,.22)
 ren.SetAmbient(.29,.32,.37)
 for mesh in meshes:
  if len(mesh.faces)<1:continue
  ren.AddActor(vtkactor(mesh))
 if transparent:
  ren.SetUseDepthPeeling(1);ren.SetMaximumNumberOfPeels(12);ren.SetOcclusionRatio(.12)
 w=vtk.vtkRenderWindow();w.SetOffScreenRendering(1);w.AddRenderer(ren);w.SetSize(width,height);w.SetMultiSamples(8);w.SetAlphaBitPlanes(1)
 for pos,col,intensity in [((24,34,-44),(0.76,0.90,1.0),.75),((-30,19,-16),(.31,.76,1),.65),((0,17,30),(1,.74,.43),.5)]:
  li=vtk.vtkLight();li.SetPosition(*pos);li.SetFocalPoint(0,2,0);li.SetColor(*col);li.SetIntensity(intensity);li.PositionalOn();ren.AddLight(li)
 camera=ren.GetActiveCamera()
 if cam=='hero':
  camera.SetPosition(-57,35,-69);camera.SetFocalPoint(0,3.4,-.3);camera.SetViewUp(0,1,0);camera.SetParallelProjection(True);camera.SetParallelScale(16.9)
 elif cam=='detail':
  camera.SetPosition(-30,18,-34);camera.SetFocalPoint(0.6,3.5,.4);camera.SetViewUp(0,1,0);camera.SetParallelProjection(True);camera.SetParallelScale(13.2)
 elif cam=='top':
  camera.SetPosition(-7,72,-31);camera.SetFocalPoint(0,2,0);camera.SetViewUp(0,1,0);camera.SetParallelProjection(True);camera.SetParallelScale(17.5)
 else:
  b=sc.bounds;center=(b[0]+b[1])/2;dim=b[1]-b[0]
  camera.SetPosition(*(center+np.array([1.25,.9,-1.8])*max(dim.max(),2)))
  camera.SetFocalPoint(*center);camera.SetViewUp(0,1,0);camera.SetParallelProjection(True);camera.SetParallelScale(max(dim.max()*.78,2.4))
 w.Render()
 filt=vtk.vtkWindowToImageFilter();filt.SetInput(w);filt.SetInputBufferTypeToRGB();filt.ReadFrontBufferOff();filt.Update()
 writer=vtk.vtkPNGWriter();writer.SetFileName(str(output));writer.SetInputConnection(filt.GetOutputPort());writer.Write()
 print('rendered',output.name,'meshes',len(meshes),'in',round(time.time()-start,1),'s',flush=True)
 # Release actors & window contexts promptly
 w.Finalize()
 return Image.open(output).convert('RGB')

def overlay(img,title,subtitle,footer):
 im=img.convert('RGB');d=ImageDraw.Draw(im)
 f1=ImageFont.truetype(fontbold,35);f2=ImageFont.truetype(fontpath,17);f3=ImageFont.truetype(fontbold,16)
 d.rectangle((0,0,im.width,104),fill='#0a1828')
 d.text((42,16),title,font=f1,fill='#d9f1fb');d.text((44,65),subtitle,font=f2,fill='#87cbdc')
 d.rectangle((0,im.height-49,im.width,im.height),fill='#0b1a2a')
 d.text((40,im.height-37),footer,font=f3,fill='#b5ebdb')
 return im

def hero():
 p=PR/'Level54_Hero_Polished_Preview.png'
 raw=capture(ROOT/'GLB/Level54_Complete_ArtKit_Showcase.glb',p,1710,970,'hero')
 im=overlay(raw,'PROJECT SPARK / LEVEL 54 — CROSS THE CRITICAL','AAA-inspired machine asset set  •  Flexible shaft  •  Active damper  •  X/Y probes  •  5 V DC','17 INDIVIDUAL FBX ASSETS     |     22 PLAYER WIRES     |     36 UNIQUE SOCKET ANCHORS')
 im.save(p,optimize=True)
 p2=PR/'Level54_Rotor_Engineering_Detail.png'
 capture(ROOT/'GLB/Level54_Complete_ArtKit_Showcase.glb',p2,1540,910,'detail')
 raw=Image.open(p2);overlay(raw,'ROTOR RESONANCE — MECHANICAL DETAIL','Dual-axis sensing, flexible rotor, compliant bearing supports, magnetic damping collar','VISUAL-ASSET PREVIEW  •  ANIMATION-READY PIVOTS  •  GAMEPLAY CONTROLLER NOT INCLUDED').save(p2,optimize=True)
 p3=PR/'Level54_Complete_17Piece_Kit_TopView.png'
 raw=capture(ROOT/'GLB/Level54_Complete_ArtKit_Showcase.glb',p3,1560,940,'top')
 overlay(raw,'LEVEL 54 — ASSEMBLED WORKBENCH','Top-down assembly reference: electrical modules and terminal anchors remain separate','INDIVIDUAL FBX + GLB FILES INCLUDED IN THE COMPLETE DOWNLOAD').save(p3,optimize=True)

def contact():
 W,H=450,300;cols=4;rows=5
 board=Image.new('RGB',(W*cols,H*rows),(9,23,37));d=ImageDraw.Draw(board)
 f=ImageFont.truetype(fontbold,20)
 for i,mod in enumerate(modnames):
  stem=f'{i:02d}_L54_{mod}'
  r=capture(ROOT/'GLB'/f'{stem}.glb',PR/f'{stem}_Preview.png',W,H-48,'item')
  x=i%cols*W;y=i//cols*H
  board.paste(r,(x,y+30));d.rectangle((x,y,x+W,y+30),fill='#152e44')
  d.text((x+12,y+4),f'{i+1:02}. {mod}',font=f,fill='#daeff8')
  d.rectangle((x,y+H-20,x+W,y+H),fill='#132a3c')
  d.text((x+12,y+H-18),'SEPARATE ANIMATION GROUPS WHERE NEEDED',font=ImageFont.truetype(fontpath,10),fill='#84e9ce')
 board.save(PR/'Level54_All_17_Models_ContactSheet.png',optimize=True)

if __name__=='__main__':
 import sys
 if '--hero' in sys.argv:hero()
 elif '--contact' in sys.argv:contact()
 else:hero();contact()
