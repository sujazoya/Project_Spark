"""Project Spark L54 — Cross the Critical. Procedural 3D model art builder.
All coordinates are model-local, Unity-style Y-up. Actual electrical/physics integration NOT included.
Requires numpy, trimesh, vtk (used for bevel-style 3D text and renders), PIL.
"""
from __future__ import annotations
import math, csv, json, os, zipfile, copy, random
from pathlib import Path
from collections import defaultdict
import numpy as np
import trimesh
from trimesh import transformations as tx
from fbx_export import export as fbx_export
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
ROOT=Path(__file__).resolve().parent.parent
MODELS=ROOT/'Models';GLB=ROOT/'GLB';PREV=ROOT/'Previews';UNI=ROOT/'Unity_Optional'
for p in (MODELS,GLB,PREV,UNI):p.mkdir(parents=True,exist_ok=True)
P={
 'titanium':(0.14,0.27,0.36), 'navy':(0.055,0.13,0.20),'carbon':(.033,.065,.084),
 'gunmetal':(.19,.26,.30),'aluminum':(.42,.54,.60),'chrome':(.75,.85,.90),
 'nickel':(.58,.66,.71),'cyan':(.09,.81,.94),'electric':(.19,.55,.87),
 'teal':(.13,.83,.68),'mint':(.40,1.0,.71),'amber':(.99,.60,.18),
 'copper':(.78,.37,.13),'scarlet':(.96,.21,.17),'gold':(.94,.73,.35),
 'white':(.90,.97,.99),'rubber':(.06,.085,.095),'glass':(.36,.78,.91),
 'smoke':(.13,.29,.36),'yellow':(.98,.82,.18)
}
MODELNAMES=['IndustrialBase','DriveMotor','FlexibleShaft','TestRotor','LeftFlexureBearing','RightFlexureBearing','DisplacementProbeX','DisplacementProbeY','EncoderABZ','ActiveDamper','DamperDriver','MotorDriver','CriticalSpeedController','OrbitSpectrumMonitor','SafetyGuard','SensorCalibrationStand','5VSupply']
STEMS=[f'{i:02d}_L54_{n}' for i,n in enumerate(MODELNAMES)]
placements={
 'IndustrialBase':(0,0,0),
 'DriveMotor':(-18.2,0,.45),
 'FlexibleShaft':(0,0,.45),
 'TestRotor':(2.4,0,.45),
 'LeftFlexureBearing':(-10.5,0,.45),
 'RightFlexureBearing':(16.8,0,.45),
 'DisplacementProbeX':(-.8,0,.45),
 'DisplacementProbeY':(4.9,0,.45),
 'EncoderABZ':(-13.6,0,.45),
 'ActiveDamper':(10.1,0,.45),
 'DamperDriver':(-4.4,0,-9.7),
 'MotorDriver':(-14.8,0,-9.7),
 'CriticalSpeedController':(4.6,0,10.2),
 'OrbitSpectrumMonitor':(-13.5,0,10.2),
 'SafetyGuard':(0,0,.45),
 'SensorCalibrationStand':(16.5,0,-9.7),
 '5VSupply':(19.3,0,10.2)
}
MODEL_PARTS={k:[] for k in MODELNAMES}
ANCH={k:{} for k in MODELNAMES}
PIV={k:{} for k in MODELNAMES}
ANIM=[]
MESH_COUNT=0

def add(mod,name,mesh,mat='aluminum',parent=None):
 global MESH_COUNT
 if mesh is None:return
 mesh=mesh.copy()
 mesh.remove_unreferenced_vertices()
 if not mesh.is_empty:
  MODEL_PARTS[mod].append((name,mesh,mat,parent));MESH_COUNT+=1

def cv(m,offset):
 m=m.copy();m.apply_translation(offset);return m

def box(mod,name,center,ext,mat='titanium',parent=None,rounding=0):
 m=trimesh.creation.box(extents=ext)
 if rounding:
  # optional faceted-bevel-like smaller inset rim handled by separate part
  pass
 add(mod,name,cv(m,center),mat,parent)
 return m

def cyl(mod,name,center,r,h,mat='nickel',axis='y',sections=32,parent=None):
 m=trimesh.creation.cylinder(radius=r,height=h,sections=sections)
 if axis=='x':m.apply_transform(tx.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(tx.rotation_matrix(-math.pi/2,[1,0,0]))
 add(mod,name,cv(m,center),mat,parent)

def ring(mod,name,center,r0,r1,h,mat='chrome',axis='x',sections=64,parent=None):
 try:m=trimesh.creation.annulus(r_min=r0,r_max=r1,height=h,sections=sections)
 except Exception:
  # fallback ring built from torus
  return torus(mod,name,center,(r0+r1)/2,(r1-r0)/2,mat,axis,sections,parent)
 if axis=='x':m.apply_transform(tx.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(tx.rotation_matrix(-math.pi/2,[1,0,0]))
 add(mod,name,cv(m,center),mat,parent)

def sphere(mod,name,center,r,mat='chrome',subdiv=2,parent=None):
 add(mod,name,cv(trimesh.creation.icosphere(subdivisions=subdiv,radius=r),center),mat,parent)

def tube(mod,name,pts,r,mat='nickel',sections=9,parent=None):
 pts=np.asarray(pts,dtype=float)
 if len(pts)<2:return
 verts=[];faces=[]
 for i,p in enumerate(pts):
  tan=pts[min(i+1,len(pts)-1)]-pts[max(0,i-1)];tan/=max(np.linalg.norm(tan),1e-8)
  up=np.array([0.,1.,0.]) if abs(tan[1])<.8 else np.array([1.,0.,0.])
  side=np.cross(tan,up);side/=np.linalg.norm(side);binormal=np.cross(tan,side)
  for j in range(sections):
   theta=j*2*math.pi/sections
   verts.append(p+r*(math.cos(theta)*side+math.sin(theta)*binormal))
  if i:
   for j in range(sections):
    a=(i-1)*sections+j;b=(i-1)*sections+(j+1)%sections
    c=i*sections+(j+1)%sections;d=i*sections+j
    faces.extend([[a,b,c],[a,c,d]])
 for j in range(1,sections-1):faces.append([0,j+1,j]);faces.append([(len(pts)-1)*sections,(len(pts)-1)*sections+j,(len(pts)-1)*sections+j+1])
 mesh=trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces),process=False)
 add(mod,name,mesh,mat,parent)

def torus(mod,name,center,major,minor,mat='nickel',axis='x',segments=48,radial=9,parent=None):
 v=[];f=[]
 for i in range(segments):
  t=2*math.pi*i/segments
  for j in range(radial):
   a=2*math.pi*j/radial
   rr=major+minor*math.cos(a)
   if axis=='x':v.append([center[0]+minor*math.sin(a),center[1]+rr*math.cos(t),center[2]+rr*math.sin(t)])
   elif axis=='y':v.append([center[0]+rr*math.cos(t),center[1]+minor*math.sin(a),center[2]+rr*math.sin(t)])
   else:v.append([center[0]+rr*math.cos(t),center[1]+rr*math.sin(t),center[2]+minor*math.sin(a)])
   if i:
    a0=(i-1)*radial+j;b=(i-1)*radial+(j+1)%radial;c=i*radial+(j+1)%radial;d=i*radial+j
    f.extend([[a0,b,d],[b,c,d]])
 for j in range(radial):
  a0=(segments-1)*radial+j;b=(segments-1)*radial+(j+1)%radial;c=(j+1)%radial;d=j
  f.extend([[a0,b,d],[b,c,d]])
 add(mod,name,trimesh.Trimesh(vertices=v,faces=f,process=False),mat,parent)

def bolt(mod,name,xyz,mat='chrome',axis='y',r=.14):
 cyl(mod,name+'_Head',xyz,r,.14,mat,axis,10)
 # innermost smaller black screw recess
 if axis=='y':p=(xyz[0],xyz[1]+.09,xyz[2])
 elif axis=='x':p=(xyz[0]+.09,xyz[1],xyz[2])
 else:p=(xyz[0],xyz[1],xyz[2]-.09)
 cyl(mod,name+'_Hex',p,r*.37,.02,'carbon',axis,6)

def socket(mod,label,pt,color='cyan',front=True):
 pt=tuple(map(float,pt));ANCH[mod][label]=pt
 # faces toward front camera (-Z), cylinder z axis
 x,y,z=pt
 torus(mod,'SOCKET_'+label+'_RIM',pt,.30,.067,'chrome',axis='z',segments=20,radial=8)
 cyl(mod,'SOCKET_'+label+'_INSULATOR',(x,y,z+.023),.224,.055,'rubber',axis='z',sections=20)
 torus(mod,'SOCKET_'+label+'_COLOR',(x,y,z-.045),.161,.045,color,axis='z',segments=22,radial=7)
 cyl(mod,'SOCKET_'+label+'_CONTACT',(x,y,z-.047),.074,.016,'gold',axis='z',sections=16)

def pivot(mod,name,pos,meaning):
 PIV[mod][name]=tuple(map(float,pos));ANIM.append({'Model':mod,'Pivot':name,'Local_X':pos[0],'Local_Y':pos[1],'Local_Z':pos[2],'Gameplay_Input':meaning})

def panel(mod,title,width=8.0,height=3.0,depth=2.1,style='titanium'):
 box(mod,'PanelShell',(0,1.8,0),(width,height,depth),style)
 box(mod,'InsetFace',(0,1.75,-depth*.52),(width-.4,height-.35,.06),'carbon')
 box(mod,'UpperGlow',(0,1.8+height*.43,-depth*.53),(width-.3,.045,.08),'cyan')
 box(mod,'LowerChromeLip',(0,1.8-height*.45,-depth*.53),(width-.3,.09,.1),'chrome')
 for x in [-width/2+.28,width/2-.28]:
  for y in [1.8-height/2+.25,1.8+height/2-.25]:bolt(mod,'PanelFastener_%s_%s'%(x,y),(x,y,-depth*.57),axis='z',r=.10)
 if title:textfront(mod,'Label_'+title,title,(0,1.8+height*.29,-depth*.56-.03),.23,'white')

def textfront(mod,name,txt,xyz,scale=.3,mat='white'):
 # Actual 3D text polygons (no texture/font dependency)
 import vtk
 v=vtk.vtkVectorText();v.SetText(str(txt));v.Update();poly=v.GetOutput()
 arr=np.array([poly.GetPoint(i) for i in range(poly.GetNumberOfPoints())])
 if not len(arr):return
 arr[:,:2]-=(arr[:,:2].max(axis=0)+arr[:,:2].min(axis=0))/2
 arr[:,0]*=-1   # Front surfaces face -Z in the workbench; mirror text geometry to read from front
 arr*=scale;arr+=np.asarray(xyz)
 faces=[]
 for i in range(poly.GetNumberOfCells()):
  cell=poly.GetCell(i)
  ids=[cell.GetPointId(j) for j in range(cell.GetNumberOfPoints())]
  if len(ids)==3:faces.append([ids[0],ids[1],ids[2]])
 if faces:add(mod,name,trimesh.Trimesh(vertices=arr,faces=faces,process=False),mat)

def module_lamps(mod,positions,colors):
 for i,((x,y,z),c) in enumerate(zip(positions,colors)):
  cyl(mod,'StatusLamp_%02d_Bezel'%i,(x,y,z+.01),.20,.09,'chrome',axis='z',sections=20)
  cyl(mod,'StatusLamp_%02d_Lens'%i,(x,y,z-.055),.135,.04,c,axis='z',sections=20)

# 00: machine chassis
m='IndustrialBase'
box(m,'HeavyMainCasting',(0,.20,.4),(47,.55,16.5),'titanium')
box(m,'CarbonInset',(0,.53,.4),(44,.12,14.6),'carbon')
for z in (-5.9,6.9):
 box(m,'TSlotExtrusion_'+str(z),(0,.82,z),(45,.58,.55),'aluminum')
 for x in range(-21,22,3):box(m,'SlotCaps_%s_%s'%(z,x),(x,1.14,z),(.12,.018,.37),'carbon')
for x in (-22,22):
 for z in (-7,7):
  box(m,'IsolatorFoot_%s_%s'%(x,z),(x,-.33,z),(2.7,.65,2.8),'rubber')
  cyl(m,'FootBolt_%s_%s'%(x,z),(x,.52,z),.22,.10,'chrome',sections=10)
for x in range(-20,21,5):
 box(m,'MountingChannel_%s'%x,(x,.62,.7),(.38,.25,11),'gunmetal')
for side,z in [('front',-7.7),('rear',8.0)]:
 box(m,side+'_Illumination',(0,.55,z),(44.8,.10,.12),'cyan')
box(m,'FactoryEmblem',(0,.69,-6.9),(6,.05,.5),'nickel')
# 01: electric motor
m='DriveMotor'
box(m,'MotorAnchorBase',(0,1.05,0),(6.9,.35,4.6),'gunmetal')
for x in (-2.0,2.0):
 for z in (-1.65,1.65):
  box(m,f'MotorFoot_{x}_{z}',(x,1.25,z),(1.0,.75,1.1),'aluminum')
  bolt(m,f'MotorMount_{x}_{z}',(x,1.68,z),'chrome')
cyl(m,'RibbedMotorBody',(0,3.70,0),1.83,5.3,'titanium','x',48)
for x in np.linspace(-2.55,2.55,21):
 ring(m,'CoolingRib_%.1f'%x,(x,3.70,0),1.72,2.06,.115,'gunmetal','x',32)
for x in (-2.45,2.5):
 ring(m,'EndBell_%s'%x,(x,3.70,0),.36,1.76,.30,'chrome','x',44)
 ring(m,'EndBellGlow_%s'%x,(x+(.1 if x>0 else -.1),3.7,0),1.70,1.81,.08,'cyan','x',44)
pivot(m,'MOTOR_SHAFT_ROTATE_X',(0,3.70,0),'shaft_angle_radians')
cyl(m,'LongMotorSpindle',(3.25,3.7,0),.37,2.7,'chrome','x',28,parent='MOTOR_SHAFT_ROTATE_X')
ring(m,'DriveCoupling',(4.5,3.7,0),.38,.70,.7,'nickel','x',32,parent='MOTOR_SHAFT_ROTATE_X')
box(m,'MotorNameplate',(0,4.8,-1.8),(3.2,.6,.04),'carbon')
textfront(m,'DCMotorLettering','5V DC MOTOR',(0,4.8,-1.84),.28,'white')
# separate upright terminals on motor body
socket(m,'MOTOR_POS',(-.70,5.1,-1.86),'scarlet')
socket(m,'MOTOR_NEG',(.70,5.1,-1.86),'electric')
# 02: deformable shaft 7 segments
m='FlexibleShaft'
for i in range(7):
 a=-13.5+i*(30.0/7);b=-13.5+(i+1)*(30.0/7);center=(a+b)/2
 pivot(m,'SHAFT_FLEX_SEGMENT_%02d'%i,(center,3.70,0),'shaft_bend_deformation_segment_%02d'%i)
 cyl(m,'SHAFT_SEGMENT_%02d'%i,(center,3.7,0),.31,(b-a)*.985,'chrome','x',22,parent='SHAFT_FLEX_SEGMENT_%02d'%i)
 for offset in [-.32,.32]:ring(m,'ShaftKey_%02d_%.2f'%(i,offset),(center+offset,3.7,0),.31,.37,.12,'nickel','x',20,parent='SHAFT_FLEX_SEGMENT_%02d'%i)
# 03: machined rotor (shaft axle x, y 3.7, z 0)
m='TestRotor'
pivot(m,'TEST_ROTOR_ROTATE_X',(0,3.7,0),'shaft_angle_radians')
cyl(m,'HeavyRotorWeb',(0,3.7,0),3.25,1.24,'nickel','x',72,parent='TEST_ROTOR_ROTATE_X')
for x in (-.68,.68):
 ring(m,'MassiveRim_%.2f'%x,(x,3.7,0),2.88,3.37,.28,'chrome','x',64,parent='TEST_ROTOR_ROTATE_X')
 ring(m,'MachinedInnerChannel_%.2f'%x,(x+(.06 if x>0 else -.06),3.7,0),1.78,1.89,.08,'gunmetal','x',64,parent='TEST_ROTOR_ROTATE_X')
ring(m,'CentralHub',(0,3.7,0),.28,.78,2.0,'titanium','x',44,parent='TEST_ROTOR_ROTATE_X')
for a in range(0,360,15):
 rad=math.radians(a);y=3.7+2.45*math.cos(rad);z=2.45*math.sin(rad)
 cyl(m,'RotorGrad_%03d'%a,(-.76,y,z),.077,.025,'amber' if a%90==0 else 'chrome','x',10,parent='TEST_ROTOR_ROTATE_X')
for a in range(0,360,45):
 rad=math.radians(a);y=3.7+1.22*math.cos(rad);z=1.22*math.sin(rad)
 cyl(m,'RotorBolt_%03d'%a,(.72,y,z),.15,.14,'gunmetal','x',12,parent='TEST_ROTOR_ROTATE_X')
# 04/05 flexure supports with visible springs
for m,label,accent in [('LeftFlexureBearing','LEFT','cyan'),('RightFlexureBearing','RIGHT','amber')]:
 box(m,label+'_Mount',(0,.95,0),(4.5,.56,4.6),'gunmetal')
 box(m,label+'_SlidingPedestal',(0,2.3,0),(3.4,.65,3.7),'nickel')
 for z in (-1.4,1.4):
  for x in (-1.24,1.24):
   pts=[]
   for i in range(101):
    t=i/100;y=1.3+t*1.05;theta=t*math.pi*11
    pts.append((x+.27*math.cos(theta),y,z+.27*math.sin(theta)))
   tube(m,f'{label}_Spring_{x}_{z}',pts,.075,'chrome',7)
   cyl(m,f'{label}_SpringPost_{x}_{z}',(x,1.75,z),.095,1.0,'aluminum',sections=12)
 pivot(m,label+'_FLEXURE_BEARING_YZ',(0,3.70,0),'bearing_displacement_xyz')
 box(m,label+'_BearingHousing',(0,3.7,0),(2.4,2.3,2.5),'aluminum',parent=label+'_FLEXURE_BEARING_YZ')
 ring(m,label+'_BearingInner',(0,3.7,0),.34,1.0,2.5,'gunmetal','x',40,parent=label+'_FLEXURE_BEARING_YZ')
 ring(m,label+'_SensorRing',(1.24,3.7,0),.77,.95,.12,accent,'x',40,parent=label+'_FLEXURE_BEARING_YZ')
 for x in (-1.45,1.45):
  for z in (-1.35,1.35):bolt(m,f'{label}PedestalBolt_{x}_{z}',(x,1.35,z))
 # signal indicator
 cyl(m,label+'_ConditionLamp',(0,5.0,-.95),.17,.15,accent,'y',20)
# 06 & 07 non-contact X/Y probes
m='DisplacementProbeX'
box(m,'XProbeStand',(0,1.0,-3.0),(2.6,.32,2.0),'gunmetal')
box(m,'XProbePole',(0,3.8,-3.0),(.43,5.2,.43),'nickel')
box(m,'XProbeArm',(0,6.35,-1.55),(.48,.48,3.45),'chrome')
pivot(m,'X_PROBE_ADJUST',(0,6.15,-.1),'x_probe_gap_mm')
cyl(m,'XSensorBody',(0,6.15,-.25),.48,1.38,'titanium','z',28,parent='X_PROBE_ADJUST')
ring(m,'XSensorLensRim',(0,6.15,-.98),.25,.45,.12,'cyan','z',30,parent='X_PROBE_ADJUST')
cyl(m,'XSensorLens',(0,6.15,-1.06),.19,.025,'white','z',20,parent='X_PROBE_ADJUST')
box(m,'XAmplifier',(.7,3.3,-3.55),(2.6,1.5,1.3),'titanium')
textfront(m,'XSensorTitle','X PROBE',(.65,3.64,-4.29),.22,'white')
for name,x,col in [('XS_POS',-.15,'scarlet'),('XS_GND',.65,'electric'),('XS_OUT',1.46,'cyan')]:socket(m,name,(x,3.0,-4.31),col)
# Y top mounted probe reaches toward bearing shaft
m='DisplacementProbeY'
box(m,'YProbeStand',(0,1.0,3.1),(2.7,.35,2.0),'gunmetal')
box(m,'YProbePole',(0,3.85,3.1),(.45,5.3,.45),'nickel')
box(m,'YProbeArm',(0,6.35,1.55),(.49,.49,3.3),'chrome')
pivot(m,'Y_PROBE_ADJUST',(0,5.8,.15),'y_probe_gap_mm')
cyl(m,'YSensorBody',(0,5.8,.15),.42,1.5,'titanium','y',32,parent='Y_PROBE_ADJUST')
ring(m,'YSensorRim',(0,4.98,.15),.20,.41,.12,'amber','y',28,parent='Y_PROBE_ADJUST')
cyl(m,'YSensorTip',(0,4.87,.15),.14,.035,'white','y',24,parent='Y_PROBE_ADJUST')
box(m,'YAmplifier',(.7,3.3,2.58),(2.6,1.5,1.1),'titanium')
textfront(m,'YSensorTitle','Y PROBE',(.65,3.64,1.96),.23,'white')
for name,x,col in [('YS_POS',-.15,'scarlet'),('YS_GND',.65,'electric'),('YS_OUT',1.46,'amber')]:socket(m,name,(x,3.0,1.95),col)
# 08 encoder
m='EncoderABZ'
box(m,'EncoderStand',(0,1.02,0),(3.5,.5,3.1),'gunmetal')
box(m,'EncoderPedestal',(0,2.25,0),(1.65,2.2,1.8),'nickel')
pivot(m,'ENCODER_DISC_ROTATE_X',(0,3.7,0),'shaft_angle_radians')
cyl(m,'EncoderDisc',(0,3.7,0),1.80,.18,'carbon','x',68,parent='ENCODER_DISC_ROTATE_X')
ring(m,'EncoderDiscShiny',(0,3.7,0),1.6,1.86,.22,'chrome','x',68,parent='ENCODER_DISC_ROTATE_X')
for a in range(80):
 th=2*math.pi*a/80
 y=3.7+1.57*math.cos(th);z=1.57*math.sin(th)
 cyl(m,f'OpticalGraduation_{a:02}',(-.126,y,z),.052,.012,'cyan' if a%10==0 else 'aluminum','x',7,parent='ENCODER_DISC_ROTATE_X')
box(m,'EncoderZMark',(0,5.55,0),(.3,.3,.65),'scarlet',parent='ENCODER_DISC_ROTATE_X')
box(m,'EncoderReadHead',(-.15,5.65,.45),(1.45,.5,1.15),'titanium')
box(m,'EncoderSignalBox',(-.9,2.25,-1.5),(3.5,1.3,1.2),'titanium')
for i,(name,col) in enumerate([('ENC_A','cyan'),('ENC_B','electric'),('ENC_Z','mint')]):socket(m,name,(-2.05+i*1.0,2.0,-2.15),col)
textfront(m,'EncoderTitle','ENC ABZ',(-.75,2.55,-2.16),.23,'white')
# 09 actuator ring and coils
m='ActiveDamper'
box(m,'DamperBase',(0,1.00,0),(5,.55,5.0),'gunmetal')
for z in (-1.7,1.7):box(m,'DamperPost_'+str(z),(0,2.1,z),(1.2,2.0,.65),'aluminum')
ring(m,'ActiveDamperCollar',(0,3.7,0),.63,2.09,1.65,'gunmetal','x',64)
ring(m,'ActiveDamperCyanGlow',(-.8,3.7,0),1.88,2.11,.18,'cyan','x',64)
ring(m,'ActiveDamperAmberGlow',(.8,3.7,0),1.88,2.11,.18,'amber','x',64)
for j in range(12):
 a=2*math.pi*j/12;y=3.7+2.25*math.cos(a);z=2.25*math.sin(a)
 cyl(m,'StatorPole_%02d'%j,(0,y,z),.36,1.20,'nickel','x',12)
 for x in [-.48,-.32,-.16,0,.16,.32,.48]:
  torus(m,'CopperCoil_%d_%s'%(j,str(x)),(x,y,z),.42,.052,'copper','x',16,7)
pivot(m,'DAMPER_X_FORCE',(0,3.7,0),'command_damper_x_newtons')
pivot(m,'DAMPER_Y_FORCE',(0,3.7,0),'command_damper_y_newtons')
box(m,'DamperPowerBox',(1.5,2.15,-2.2),(2.2,1.5,1.3),'titanium')
for name,x,c in [('DAMP_POS',.96,'scarlet'),('DAMP_NEG',2.05,'electric')]:socket(m,name,(x,2.04,-2.90),c)
# 10 - damper driver
m='DamperDriver';panel(m,'ACTIVE DAMPER DRIVE',8.7,3.3)
for i,(nm,c) in enumerate([('DDRV_POS','scarlet'),('DDRV_GND','electric'),('DDRV_CMD','amber'),('DDRV_ACTPOS','scarlet'),('DDRV_ACTNEG','electric')]):socket(m,nm,(-3.1+i*1.52,1.35,-1.23),c)
for x in np.linspace(-3.25,3.25,14):box(m,'HeatsinkFinger_%.2f'%x,(x,3.66,.23),(.22,.58,1.55),'aluminum')
module_lamps(m,[(-3.1,2.45,-1.20),(-2.55,2.45,-1.20),(-2.0,2.45,-1.20)],['mint','cyan','amber'])
# 11 motor driver
m='MotorDriver';panel(m,'PWM MOTOR DRIVE',8,3.3)
for i,(nm,c) in enumerate([('MDRV_POS','scarlet'),('MDRV_GND','electric'),('MDRV_PWM','amber'),('MDRV_MPOS','scarlet'),('MDRV_MNEG','electric')]):socket(m,nm,(-2.9+i*1.45,1.35,-1.24),c)
for x in np.linspace(-3.15,3.15,13):box(m,'HeatsinkFin_%.2f'%x,(x,3.69,.32),(.16,.66,1.55),'nickel')
module_lamps(m,[(-2.9,2.4,-1.22),(-2.35,2.4,-1.22)],['mint','amber'])
# 12 controller (large module at rear, 10 sockets across in front)
m='CriticalSpeedController';panel(m,'CRITICAL SPEED CONTROL',14,3.5)
box(m,'BlankControllerScreen',(0,2.7,-1.15),(9,.9,.09),'navy')
for i,x in enumerate(np.linspace(-5.65,5.65,10)):
 nm=['CTRL_POS','CTRL_GND','CTRL_MOTOR_PWM','CTRL_X_IN','CTRL_Y_IN','CTRL_ENC_A','CTRL_ENC_B','CTRL_ENC_Z','CTRL_DAMP_CMD','CTRL_SAFE_IN'][i]
 col=['scarlet','electric','amber','cyan','amber','electric','electric','mint','amber','teal'][i]
 socket(m,nm,(float(x),1.35,-1.2),col)
for i,x in enumerate(np.linspace(-5.1,5.1,9)):
 box(m,'ButtonPlinth_%d'%i,(float(x),3.05,-1.20),(.65,.35,.25),'aluminum')
 box(m,'ButtonCap_%d'%i,(float(x),3.08,-1.37),(.44,.25,.17),['cyan','mint','amber'][i%3])
# 13 display monitor tall tilted facing player, blank screen
m='OrbitSpectrumMonitor'
box(m,'MonitorStand',(0,1.06,1.0),(13.6,.45,3.0),'gunmetal')
box(m,'MonitorPost',(0,2.6,1.0),(2.0,2.7,1.0),'nickel')
box(m,'MonitorHousing',(0,5.05,0),(14.6,4.9,1.1),'titanium')
box(m,'GlassLCD',(0,5.1,-.62),(13.8,4.12,.08),'navy')
box(m,'GlassLCDInner',(0,5.1,-.68),(13.4,3.75,.04),'carbon')
box(m,'ScreenLowerCyan',(0,2.86,-.69),(13.7,.08,.05),'cyan')
for x in (-7.0,7.0):
 for y in (3.03,7.18):bolt(m,'DisplayBolt_%s_%s'%(x,y),(x,y,-.71),axis='z')
# decorate screen with subtle grids as non-emissive geometry; leave MAIN blank for TMP runtime
for x in np.linspace(-6.1,6.1,11):box(m,'UIGridV_%s'%x,(x,5.18,-.705),(.018,3.2,.008),'smoke')
for y in np.linspace(3.66,6.65,5):box(m,'UIGridH_%s'%y,(0,y,-.705),(12.6,.018,.008),'smoke')
textfront(m,'DisplayHeader','SHAFT ORBIT / RESONANCE', (0,7.64,-.71),.42,'white')
# 14 enclosure skeletal transparent panels, clear sight lines
m='SafetyGuard'
for x in (-23.2,23.2):
 for z in (-6.45,6.45):
  box(m,f'GuardPost_{x}_{z}',(x,4.2,z),(.25,7.5,.25),'chrome')
for y in (1.06,7.90):
 for z in (-6.45,6.45):box(m,f'GuardLongBeam_{y}_{z}',(0,y,z),(47,.23,.25),'chrome')
 for x in (-23.2,23.2):box(m,f'GuardEndBeam_{y}_{x}',(x,y,0),(.27,.25,13.1),'chrome')
# upper glass window, front & back transparent panels, with frame outlining see-through coverage
for x in [-15,-7,0,7,15]:box(m,'FrontGlassMullion_%s'%x,(x,4.3,-6.45),(.095,6.6,.10),'nickel')
box(m,'GlassBack',(0,4.4,6.5),(46.0,5.8,.055),'glass')
box(m,'GlassFront',(0,4.4,-6.47),(46,5.8,.055),'glass')
box(m,'GlassTop',(0,8.02,0),(46,.07,12.65),'glass')
pivot(m,'SAFETY_DOOR_HINGE',(-22.0,4.2,-6.48),'guard_open_fraction')
box(m,'SafetyDoorFrame',(-17.65,4.25,-6.52),(8.0,5.6,.18),'chrome',parent='SAFETY_DOOR_HINGE')
box(m,'SafetyDoorGlass',(-17.65,4.25,-6.60),(7.6,5.2,.06),'glass',parent='SAFETY_DOOR_HINGE')
box(m,'SafetyDoorHandle',(-13.9,4.32,-6.85),(.24,1.2,.4),'amber',parent='SAFETY_DOOR_HINGE')
box(m,'SafetyNCModule',(-20.0,1.72,-7.25),(3.5,1.7,.88),'titanium')
socket(m,'GUARD_NC',(-20.0,1.5,-7.78),'teal')
# danger stripes
for x in np.linspace(-22,22,45):
 box(m,'GuardWarningStripe_%.1f'%x,(x,1.08,-6.55),(.46,.13,.14),'yellow' if int(x)%2 else 'carbon')
# 15 test sensor jig
m='SensorCalibrationStand'
box(m,'CalibrationStandBase',(0,1.1,0),(5.2,.45,4),'gunmetal')
box(m,'MicrometerStem',(0,3.1,.25),(.48,3.6,.56),'nickel')
cyl(m,'MicrometerDial',(0,5.05,.25),.72,.35,'chrome',axis='z',sections=44)
for i in range(24):
 a=math.pi*2*i/24
 cyl(m,'DialTick_%d'%i,(.52*math.cos(a),5.05+.52*math.sin(a),-.1),.055,.02,'carbon','z',8)
box(m,'MicrometerTip',(0,3.2,-1.1),(.24,.35,2),'chrome')
for x in (-1.2,1.2):
 box(m,'CalibrationGauge_%s'%x,(x,2.1,-1.3),(.75,.6,1.1),'nickel')
textfront(m,'CalLabel','PROBE CAL',(0,1.85,-2.1),.28,'cyan')
# 16 power
m='5VSupply';panel(m,'5 V REGULATED',7.4,3.3)
for name,x,c in [('SUPPLY_POS',-1.65,'scarlet'),('SUPPLY_NEG',1.65,'electric')]:socket(m,name,(x,1.45,-1.27),c)
box(m,'DigitalPowerFace',(0,2.55,-1.2),(3.1,.6,.04),'navy')
textfront(m,'FiveVoltText','5.00 V',(0,2.59,-1.27),.4,'mint')
module_lamps(m,[(-2.7,2.55,-1.23)],['mint'])
# Finish validation
MODEL_ANCHORS={k:len(v) for k,v in ANCH.items()}
assert sum(MODEL_ANCHORS.values())==36,MODEL_ANCHORS
print('GEOMETRY PARTS',MESH_COUNT,'TOTAL TRIANGLES',sum(len(p[1].faces) for ps in MODEL_PARTS.values() for p in ps),'ANCHORS',MODEL_ANCHORS,flush=True)

# wire plan, models and the exact terminal ids specified in design
W=[('SUPPLY_POS','CTRL_POS'),('SUPPLY_NEG','CTRL_GND'),('SUPPLY_POS','MDRV_POS'),('SUPPLY_NEG','MDRV_GND'),('SUPPLY_POS','XS_POS'),('SUPPLY_NEG','XS_GND'),('SUPPLY_POS','YS_POS'),('SUPPLY_NEG','YS_GND'),('SUPPLY_POS','DDRV_POS'),('SUPPLY_NEG','DDRV_GND'),('CTRL_MOTOR_PWM','MDRV_PWM'),('MDRV_MPOS','MOTOR_POS'),('MDRV_MNEG','MOTOR_NEG'),('XS_OUT','CTRL_X_IN'),('YS_OUT','CTRL_Y_IN'),('ENC_A','CTRL_ENC_A'),('ENC_B','CTRL_ENC_B'),('ENC_Z','CTRL_ENC_Z'),('CTRL_DAMP_CMD','DDRV_CMD'),('DDRV_ACTPOS','DAMP_POS'),('DDRV_ACTNEG','DAMP_NEG'),('GUARD_NC','CTRL_SAFE_IN')]
lookup={a:k for k,aa in ANCH.items() for a in aa}
assert len(W)==22 and len(lookup)==36 and {a for w in W for a in w}==set(lookup)
with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['SocketID','Model','LocalX','LocalY','LocalZ','AssemblyWorldX','AssemblyWorldY','AssemblyWorldZ','Notes'])
 for mod,aa in ANCH.items():
  for a,pos in aa.items():
   world=np.array(pos)+np.array(placements[mod]);wr.writerow([a,f'{STEMS[MODELNAMES.index(mod)]}.fbx',*map(lambda v:f'{v:.4f}',pos),*map(lambda v:f'{v:.4f}',world),'Art anchor only: create actual SparkTerminal in Unity'])
with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['WireID','FromSocketID','FromModel','ToSocketID','ToModel'])
 for i,(a,b) in enumerate(W,1):wr.writerow([f'W{i:02d}',a,lookup[a],b,lookup[b]])
with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(ANIM[0]));wr.writeheader();wr.writerows(ANIM)
manifest={'level_id':'level_54','title':'Cross the Critical','asset_type':'visual_art_only','unit':'Unity Y-up, 1 art unit','models':[],'wires':len(W),'distinct_socket_anchors':len(lookup),'model_positions':placements,'terminal_note':'FBX socket anchor transforms are art locators, not electrical SparkTerminal components.'}

# FBX + GLB export. Mesh-by-mesh preserves named visual elements; material-colour GLB backups.
for mod in MODELNAMES:
 stem=STEMS[MODELNAMES.index(mod)];parts=MODEL_PARTS[mod]
 fbx=MODELS/(stem+'.fbx');glb=GLB/(stem+'.glb')
 nbytes=fbx_export(fbx,stem,parts,ANCH[mod],PIV[mod],P)
 scene=trimesh.Scene()
 for name,mesh,mat,piv in parts:
  mm=mesh.copy();r,g,b=P[mat]
  alpha=60 if mat=='glass' else 255
  mm.visual.vertex_colors=np.tile(np.array([round(r*255),round(g*255),round(b*255),alpha],dtype=np.uint8),(len(mm.vertices),1))
  scene.add_geometry(mm,node_name=name,geom_name=name)
 glb.write_bytes(scene.export(file_type='glb'))
 manifest['models'].append({'name':mod,'fbx':fbx.name,'glb':glb.name,'position_xyz':placements[mod],'mesh_count':len(parts),'triangles':sum(len(p[1].faces) for p in parts),'pivots':list(PIV[mod]),'sockets':list(ANCH[mod]),'fbx_bytes':nbytes,'glb_bytes':glb.stat().st_size})
 print(stem,'parts',len(parts),'triangles',manifest['models'][-1]['triangles'],'FBX',round(nbytes/1024),flush=True)
with (ROOT/'Model_Manifest.json').open('w') as f:json.dump(manifest,f,indent=2)

# showcase FBX: copy each mesh at its world assembly placement, preserving rig pivots.
all_parts=[];all_anchors={};all_pivots={}
for mod in MODELNAMES:
 shift=np.array(placements[mod]);stem=STEMS[MODELNAMES.index(mod)]
 for name,mesh,mat,piv in MODEL_PARTS[mod]:
  part=mesh.copy();part.apply_translation(shift)
  all_parts.append((stem+'__'+name,part,mat,stem+'__'+piv if piv else None))
 for key,val in PIV[mod].items():all_pivots[stem+'__'+key]=tuple(np.array(val)+shift)
 for key,val in ANCH[mod].items():all_anchors[key]=tuple(np.array(val)+shift)
fbx_export(MODELS/'Level54_Complete_ArtKit_Showcase.fbx','Level54_Complete_ArtKit_Showcase',all_parts,all_anchors,all_pivots,P)
showcase=trimesh.Scene()
for name,mesh,mat,piv in all_parts:
 mm=mesh.copy();r,g,b=P[mat];alpha=50 if mat=='glass' else 255
 mm.visual.vertex_colors=np.tile(np.array([int(r*255),int(g*255),int(b*255),alpha],dtype=np.uint8),(len(mm.vertices),1))
 showcase.add_geometry(mm,node_name=name,geom_name=name)
(GLB/'Level54_Complete_ArtKit_Showcase.glb').write_bytes(showcase.export(file_type='glb'))
print('All FBX + GLB done.',flush=True)
