"""Project Spark • Level 48 HIT THE MARK • AAA-style procedural model pack.
12 separate Unity Y-up FBX 7.4 binary meshes + GLB back-ups + assembled art layout.
Pure visual assets; real electrical simulation, mark processing, and print timing
must be supplied by the existing Project Spark scripts in Unity.
"""
from __future__ import annotations
import csv,json,math
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model,PALETTE,export_fbx,export_glb

ROOT=Path(__file__).resolve().parents[1]; MOD=ROOT/'Models'; PREV=ROOT/'Previews'
MOD.mkdir(parents=True,exist_ok=True);PREV.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'ice':(222,243,250,255),'polished':(188,214,225,255), 'nickel':(149,170,187,255),
 'aluminum':(147,176,197,255), 'brass':(221,164,81,255), 'amberlit':(255,181,75,255),
 'mint':(52,246,197,255),'pale_mint':(138,255,228,255),'cyanlit':(65,234,255,255),
 'scarlet':(252,67,86,255),'steel_dark':(34,53,68,255),'black':(8,17,29,255),
 'graphite2':(25,37,49,255), 'porcelain':(240,234,213,255),'webwhite':(200,228,228,238),
 'webshadow':(96,144,154,255),'rubberblue':(31,52,64,255),
 'glasstint':(99,201,229,105), 'scan':(63,253,238,130), 'film':(209,224,223,220),
 'printink':(29,94,108,255), 'purple':(146,116,238,255), 'backlit':(12,64,74,255),
 'browngold':(171,105,49,255), 'blueprint':(36,94,151,255), 'lampgreen':(45,255,172,255),
})


def txt(m,n,s,x,y,z,size=.16,mat='ice',width=None,group='Static'):
 m.text(n,s,size,x,y,z,mat,maxwidth=width,group=group)

def bolt(m,n,x,y,z):
 m.cyl(n+'_Head',.061,.032,(x,y,z),'chrome','y',14)
 m.box(n+'_Slot',(.056,.011,.009),(x,y+.017,z),'graphite2')

def led(m,name,x,y,z,mat='mint',group=None):
 g=group or (name+'_LIGHT')
 m.cyl(name+'_Bezel',.12,.057,(x,y,z),'nickel','z',24,group=g)
 m.cyl(name+'_Lens',.092,.048,(x,y,z-.049),mat,'z',24,group=g)
 m.torus(name+'_Halo',.123,.016,(x,y,z-.06),mat,'z',24,6,group=g)
 m.group_pivots[g]=(x,y,z)

def jack(m,name,sid,label,x,y,z,mat='cyan',label_size=.108):
 # Socket is a mesh-only art reference: create an actual SparkTerminal separately in Unity.
 g='SOCKET_'+sid
 m.cyl(name+'_'+sid+'_SocketRim',.166,.069,(x,y,z),'chrome','z',28,group=g)
 m.cyl(name+'_'+sid+'_Collar',.133,.075,(x,y,z-.035),mat,'z',28,group=g)
 m.cyl(name+'_'+sid+'_Recess',.093,.087,(x,y,z-.091),'void','z',24,group=g)
 m.cyl(name+'_'+sid+'_MetalPin',.028,.026,(x,y,z-.15),'gold','z',12,group=g)
 m.torus(name+'_'+sid+'_LightRing',.159,.014,(x,y,z-.096),mat,'z',28,6,group=g)
 txt(m,name+'_'+sid+'_PortLabel',label,x,y+.23,z-.155,label_size,'ice',.88)
 assert sid not in m.anchors,sid
 m.anchors[sid]=[round(float(x),5),round(float(y),5),round(float(z-.171),5)]

def panel(m,t,title,w=4.4,d=2.6,h=1.68,accent='cyan',tag=''):
 m.base(t,w,d,h)
 z=-d/2-.093
 m.box(t+'_FrontNameplate',(w-.38,.35,.052),(0,.32+h*.79,z-.032),'void')
 txt(m,t+'_MainName',title,0,.32+h*.79,z-.062,.220,'ice',w-.48)
 if tag:txt(m,t+'_Subtitle',tag,0,.32+h*.59,z-.052,.112,accent,w-.45)
 m.box(t+'_NeonTopRail',(w-.45,.039,.047),(0,.32+h+.105,-d/2+.16),accent)
 for x in (-w/2+.22,w/2-.22):
  for zz in (-d/2+.21,d/2-.21):bolt(m,t+f'_Screw{x:+.2f}_{zz:+.2f}',x,.32+h+.10,zz)
 return z

def rod(m,n,a,b,r=.07,mat='chrome',group='Static'):
 m.rod(n,a,b,r,mat,sections=16,group=group)


def make_frame():
 m=Model('00_L48_IndustrialFrame');t='L48_RIG'
 m.bevel(t+'_MachinedPlatform',(34.2,.44,23.3),(0,.27,0),'graphite',.20)
 m.bevel(t+'_RubberUndertray',(34.5,.17,23.6),(0,.08,0),'rubber',.10)
 m.box(t+'_CNC_Well',(28.5,.08,11.6),(0,.535,.3),'steel_dark')
 for x in (-16.6,16.6):
  m.box(t+f'_SideFlange_{x}',(.18,.42,22.1),(x,.60,0),'polished')
  m.box(t+f'_SideLight_{x}',(.065,.045,21.45),(x,.83,0),'cyan')
  for z in np.linspace(-10,10,11):bolt(m,t+f'_Bolt_{x:+.1f}_{z:+.1f}',x,.838,float(z))
 for z in (-10.3,10.3):
  m.box(t+f'_CrossFrame_{z}',(32.6,.12,.20),(0,.63,z),'nickel')
  m.box(t+f'_Glow_{z}',(31.6,.024,.04),(0,.72,z),'amber' if z>0 else 'cyan')
 for z in (-8.45,-7.90,-7.35):
  for j,x in enumerate(np.linspace(-15.6,15.6,52)):
   m.cyl(t+f'_BreadboardHole_{z:.2f}_{j}',.027,.02,(float(x),.502,z),'void','y',8)
 for x in (-15.8,15.8):
  for z in (-10.5,10.5):m.bevel(t+f'_ShockFoot_{x:+.1f}_{z:+.1f}',(1.1,.17,1.1),(x,.095,z),'rubber',.12)
 # Separate simple rear safety rail for frame silhouette.
 for z in (5.4,-5.4):
  m.box(t+f'_LinearSupport_{z:+.1f}',(26.4,.23,.36),(0,.75,z),'aluminum')
  m.box(t+f'_RunningTrack_{z:+.1f}',(26.2,.055,.11),(0,.91,z),'cyan_soft')
 return m


def make_web():
 m=Model('01_L48_WebTransport');t='L48_WEB'
 m.bevel(t+'_ConveyorMain',(25.8,.72,4.25),(0,.91,0),'graphite2',.24)
 m.box(t+'_DeckTitanium',(25.2,.073,3.45),(0,1.30,0),'nickel')
 m.box(t+'_PrintWeb_ContinuousRibbon',(25.0,.045,2.55),(0,1.365,0),'film',group='WEB_TRANSLATE_X')
 m.group_pivots['WEB_TRANSLATE_X']=(0,1.365,0)
 for k,x in enumerate(np.linspace(-11.75,11.75,13)):
  # registration marks are grouped with the web for visual scrolling.
  m.box(t+f'_REGISTRATION_MARK_{k:02d}',(.092,.011,1.05),(float(x),1.397,-.20),'printink',group='WEB_TRANSLATE_X')
  if k%2==0:
   m.box(t+f'_BLANK_LABEL_{k:02d}',(1.12,.011,.72),(float(x+.67),1.398,.51),'webwhite',group='WEB_TRANSLATE_X')
   m.box(t+f'_PRINTER_APPROVAL_LINE_{k:02d}',(.86,.012,.065),(float(x+.67),1.413,.25),'cyan',group='WEB_TRANSLATE_X')
 for i,x in enumerate(np.linspace(-11.9,11.9,17)):
  m.cyl(t+f'_SupportRoller_{i:02d}',.21,3.6,(float(x),1.05,0),'aluminum','z',24,group='ROLLER_FEED_VISUAL')
 for side in (-1,1):
  z=side*2.05
  m.box(t+f'_ChromeEdgeRail_{side}',(25.2,.19,.14),(0,1.42,z),'chrome')
  for x in (-12.1,12.1):
   m.box(t+f'_Bracket_{side}_{x:+.1f}',(.37,.54,.31),(x,1.04,z),'steel')
 m.box(t+'_LeftEntryPlate',(.58,.09,4.0),(-12.84,1.34,0),'polished')
 m.box(t+'_RightExitPlate',(.58,.09,4.0),(12.84,1.34,0),'polished')
 return m


def make_roller():
 m=Model('02_L48_DriveRoller');t='L48_DRIVE_ROLLER';g='MEASURING_ROLLER_ROTATE_Z'
 m.cyl(t+'_RubberMeasuringCylinder',.75,3.6,(0,1.45,0),'rubberblue','z',64,group=g)
 for z in np.linspace(-1.55,1.55,10):
  m.torus(t+f'_GripBand_{z:+.2f}',.743,.024,(0,1.45,float(z)),'steel','z',48,6,group=g)
 for z in (-1.92,1.92):
  m.cyl(t+f'_BearingHousing_{z:+.1f}',.88,.34,(0,1.45,z),'nickel','z',40)
  m.torus(t+f'_BearingChrome_{z:+.1f}',.73,.052,(0,1.45,z*1.08),'chrome','z',44,8)
  m.box(t+f'_Pedestal_{z:+.1f}',(1.47,.60,.61),(0,.58,z),'graphite')
 m.cyl(t+'_EncoderShaft',.15,5.1,(0,1.45,0),'chrome','z',32,group=g)
 for a in range(12):
  ang=math.tau*a/12;xx=.74*math.cos(ang); yy=1.45+.74*math.sin(ang)
  m.cyl(t+f'_IndexKnurl_{a:02d}',.030,3.55,(xx,yy,0),'chrome','z',10,group=g)
 m.group_pivots[g]=(0,1.45,0)
 return m


def make_encoder():
 m=Model('03_L48_WebEncoder');t='L48_WEB_ENC';g='ENCODER_DISC_ROTATE_Z'
 m.bevel(t+'_GlassBase',(3.2,.34,1.95),(0,.25,.47),'graphite',.12)
 m.box(t+'_ReadHeadBridge',(2.6,.18,.28),(0,2.52,.30),'nickel')
 for x in (-1.17,1.17):rod(m,t+f'_SensorSupport_{x:+.2f}',(x,.4,.30),(x,2.52,.30),.064,'chrome')
 m.cyl(t+'_Shaft',.20,1.3,(0,1.57,.2),'chrome','z',24)
 m.cyl(t+'_OpticalDisc',1.12,.11,(0,1.57,-.22),'steel_dark','z',72,group=g)
 m.torus(t+'_ChromeOuterRing',1.06,.028,(0,1.57,-.29),'chrome','z',72,6,group=g)
 m.torus(t+'_IlluminatedRing',.92,.020,(0,1.57,-.291),'cyan','z',64,6,group=g)
 for i in range(80):
  ang=math.tau*i/80
  x=math.cos(ang)*.96;y=1.57+math.sin(ang)*.96
  m.cyl(t+f'_OpticalSegment_{i:02d}',.021,.018,(x,y,-.310),'ice' if i%2==0 else 'cyan','z',8,group=g)
 m.cyl(t+'_EncoderHub',.22,.16,(0,1.57,-.39),'chrome','z',32,group=g)
 m.group_pivots[g]=(0,1.57,-.22)
 m.box(t+'_FixedReader',(1.6,.44,.32),(0,2.67,-.47),'aluminum')
 led(m,t+'_A',-.36,2.55,-.68,'cyan')
 led(m,t+'_B',.36,2.55,-.68,'mint')
 # Port column on fixed separate lower terminal dock. Front-facing.
 m.bevel(t+'_ElectricalIO',(3.18,.93,.64),(0,.89,-1.47),'graphite2',.10)
 z=-1.82
 jack(m,t,'ENCODER_A','A',-.62,.71,z,'cyan')
 jack(m,t,'ENCODER_B','B',.62,.71,z,'mint')
 return m


def make_optical_eye():
 m=Model('04_L48_OpticalMarkSensor');t='L48_OPTICAL_EYE'
 z=panel(m,t,'OPTICAL MARK EYE',4.48,2.65,1.66,'cyan','REGISTER / REG MARK')
 # Vertical scanner tower. Beveled metal arch with integrated down-looking lens.
 for x in (-1.57,1.57):
  m.bevel(t+f'_CNC_Upright_{x:+.1f}',(.34,2.16,.51),(x,2.57,.31),'nickel',.08)
 m.bevel(t+'_CrossBeam',(3.46,.35,.61),(0,3.71,.31),'polished',.09)
 m.cyl(t+'_LaserTurret',.46,.30,(0,3.50,.36),'chrome','y',40)
 m.cyl(t+'_ScannerLens',.28,.064,(0,3.30,.36),'cyan','y',32)
 m.torus(t+'_EmitterHalo',.30,.025,(0,3.27,.36),'mint','y',44,8)
 m.cyl(t+'_ScanBeam',.022,1.21,(0,2.60,.36),'scan','y',10,group='SCAN_BEAM_ENABLE')
 m.group_pivots['SCAN_BEAM_ENABLE']=(0,3.2,.36)
 m.box(t+'_GlassViewingWindow',(2.7,.52,.04),(0,1.48,-1.37),'backlit')
 txt(m,t+'_DetectionText','REGISTRATION EYE',0,1.49,-1.416,.14,'mint',2.35)
 led(m,t+'_MarkIndicator',1.55,1.45,z-.03,'green',group='MARK_DETECTED_LAMP')
 # Three real player art anchors.
 for sid,label,x,col in [('SENSOR_PLUS','+5V',-1.32,'red'),('SENSOR_GND','GND',0,'black'),('SENSOR_SIGNAL','SIG',1.32,'mint')]:
  jack(m,t,sid,label,x,.69,z,col)
 return m


def make_motor():
 m=Model('05_L48_PrintMotor');t='L48_PRINT_MOTOR';g='PRINT_MOTOR_SHAFT_ROTATE_X'
 m.bevel(t+'_CastFoot',(3.30,.35,3.7),(0,.26,0),'graphite',.16)
 for x in (-1.31,1.31):
  for z in (-1.5,1.5):bolt(m,t+f'_Fastener_{x}_{z}',x,.45,z)
 m.cyl(t+'_MainMotorHousing',.89,2.88,(0,1.48,.05),'nickel','x',58)
 m.cyl(t+'_FrontCouplerFlange',.99,.22,(-1.50,1.48,.05),'polished','x',48)
 m.cyl(t+'_RearCap',.93,.35,(1.5,1.48,.05),'blue','x',48)
 for a in range(14):
  ang=math.tau*a/14
  y=1.48+.90*math.cos(ang);z=.05+.90*math.sin(ang)
  m.rod(t+f'_LongCoolingFin_{a:02d}',(-1.25,y,z),(1.25,y,z),.045,'steel',12)
 m.cyl(t+'_Shaft',.20,2.10,(-2.28,1.48,.05),'chrome','x',36,group=g)
 m.cyl(t+'_TimingPulley',.47,.27,(-2.65,1.48,.05),'polished','x',40,group=g)
 for a in range(20):
  ang=math.tau*a/20
  x=-2.65;y=1.48+.46*math.sin(ang);z=.05+.46*math.cos(ang)
  m.cyl(t+f'_TimingNotch_{a:02d}',.036,.27,(x,y,z),'steel','x',10,group=g)
 m.group_pivots[g]=(-2.28,1.48,.05)
 m.bevel(t+'_TerminalDock',(3.27,.71,.60),(0,.70,-2.15),'graphite2',.07)
 z=-2.49
 jack(m,t,'PRINT_MOTOR_PLUS','MOTOR +',-.73,.71,z,'red')
 jack(m,t,'PRINT_MOTOR_MINUS','MOTOR -',.73,.71,z,'black')
 txt(m,t+'_MotorLabel','INDEX MOTOR',0,1.26,-.96,.21,'ice',2.55)
 return m


def make_printhead():
 m=Model('06_L48_PrintHead');t='L48_PRINT_HEAD';g='PRINT_HEAD_STROKE_Y'
 m.bevel(t+'_FixedMount',(4.20,.42,3.55),(0,.40,.25),'graphite',.14)
 for x in (-1.57,1.57):
  m.cyl(t+f'_GuideColumn_{x:+.2f}',.115,2.58,(x,2.13,.25),'chrome','y',24)
  m.cyl(t+f'_TopBushing_{x:+.2f}',.20,.36,(x,3.42,.25),'polished','y',28)
 m.bevel(t+'_ActuatorCasing',(3.48,.72,2.75),(0,3.45,.25),'nickel',.19)
 m.box(t+'_OrangeEndCap',(3.25,.09,.13),(0,3.83,-.72),'amber')
 m.cyl(t+'_LinearPushrod',.21,1.66,(0,2.48,.25),'chrome','y',24,group=g)
 m.bevel(t+'_MovingPrintCarriage',(2.75,.36,1.46),(0,1.58,.25),'polished',.11,group=g)
 m.bevel(t+'_InkPadBase',(2.22,.23,1.06),(0,1.28,.25),'orange',.08,group=g)
 m.box(t+'_RubberStampFace',(1.94,.115,.80),(0,1.12,.25),'black',group=g)
 for x in np.linspace(-.76,.76,13):
  m.box(t+f'_StampPattern_{x:+.2f}',(.033,.011,.50),(float(x),1.052,.25),'browngold',group=g)
 m.group_pivots[g]=(0,2.12,.25)
 for x in (-1.78,1.78):
  m.box(t+f'_HazardBar_{x:+.2f}',(.11,.06,.93),(x,.74,-1.13),'amber')
 led(m,t+'_Ready',-1.11,3.22,-1.18,'mint',group='HEAD_READY_LENS')
 led(m,t+'_Fire',1.11,3.22,-1.18,'amber',group='HEAD_TRIGGER_LENS')
 # Control jack on the front of fixed base.
 m.bevel(t+'_TriggerConnectorDock',(2.30,.73,.63),(0,.68,-2.07),'graphite2',.07)
 jack(m,t,'PRINT_HEAD_TRIG','PRINT TRIG',0,.73,-2.45,'amber')
 txt(m,t+'_Title','PRECISION PRINT HEAD',0,3.52,-1.18,.16,'ice',2.9)
 return m


def make_driver():
 m=Model('07_L48_PrintDriver');t='L48_DRIVER'
 z=panel(m,t,'PRINT MOTOR DRIVER',5.85,3.0,1.78,'amber','PWM / H BRIDGE')
 for x in np.linspace(-2.20,2.20,10):
  m.box(t+f'_HeatsinkFin_{x:+.2f}',(.11,.68,1.12),(float(x),2.29,.58),'nickel')
 m.box(t+'_DriverChip',(1.65,.14,.72),(0,1.95,-.44),'black')
 led(m,t+'_PWR_LED',-2.12,1.52,z-.05,'green')
 led(m,t+'_PWM_LED',2.12,1.52,z-.05,'amber')
 sockets=[('DRIVER_PWM','PWM',-2.02,'amber'),('DRIVER_MOTOR_PLUS','M+',-1.01,'red'),('DRIVER_MOTOR_MINUS','M-',0,'black'),('DRIVER_PLUS','+5V',1.01,'red'),('DRIVER_GND','GND',2.02,'black')]
 for sid,label,x,col in sockets:jack(m,t,sid,label,x,.72,z,col)
 return m


def make_controller():
 m=Model('08_L48_RegistrationController');t='L48_REG_CTRL'
 z=panel(m,t,'REGISTRATION CTRL',7.75,3.10,1.91,'cyan','ENCODER / OPTICAL / TRIGGER')
 m.bevel(t+'_DisplayOuter',(3.80,.95,.049),(0,1.56,z-.059),'nickel',.06)
 m.box(t+'_BlankTextMeshProFace',(3.55,.70,.022),(0,1.56,z-.098),'screen')
 # No hard-coded live values on blank screen. Segment line hints only.
 for y in (1.78,1.55,1.32):
  m.box(t+f'_HUD_Line_{y}',(3.07,.013,.01),(0,y,z-.121),'backlit')
 for i,(name,label,x,col) in enumerate([('START','START',-3.10,'mint'),('STOP','STOP',-2.40,'scarlet'),('CAL','CAL',2.41,'cyan'),('RESET','RESET',3.10,'amber')]):
  g=name+'_PRESS'
  m.cyl(t+f'_{name}_ButtonCollar',.23,.085,(x,1.72,z-.07),'chrome','z',24,group=g)
  m.cyl(t+f'_{name}_ButtonCap',.18,.079,(x,1.72,z-.135),col,'z',22,group=g)
  m.group_pivots[g]=(x,1.72,z-.14)
  txt(m,t+f'_{name}_Caption',label,x,2.07,z-.12,.083,'ice',.76)
 # Seven sockets arranged in one distinct front row, + labels.
 sockets=[('CTRL_PLUS','+5V',-3.12,'red'),('CTRL_GND','GND',-2.08,'black'),('CTRL_ENC_A','ENC A',-1.04,'cyan'),('CTRL_ENC_B','ENC B',0,'mint'),('CTRL_MARK_IN','MARK',1.04,'mint'),('CTRL_INDEX_PWM','PWM',2.08,'amber'),('CTRL_PRINT_TRIG','TRIG',3.12,'orange')]
 for sid,label,x,col in sockets:jack(m,t,sid,label,x,.67,z,col,.100)
 return m


def make_monitor():
 m=Model('09_L48_QualityMonitor');t='L48_QUALITY'
 z=panel(m,t,'PRINT QUALITY',6.35,3.35,1.77,'mint','REGISTRATION ACCURACY')
 # Angled screen is blank for TextMeshPro. Separate signal bars and status lamps.
 m.bevel(t+'_ScreenBezel',(5.75,1.07,.065),(0,1.37,z-.08),'polished',.075)
 m.box(t+'_BlankTMProSurface',(5.47,.84,.027),(0,1.38,z-.119),'screen',group='LIVE_SCREEN_FACE')
 m.group_pivots['LIVE_SCREEN_FACE']=(0,1.38,z-.14)
 for xx in np.linspace(-2.34,2.34,11):
  m.box(t+f'_QualityScale_{xx:+.2f}',(.019,.60,.02),(float(xx),1.38,z-.15),'backlit')
 for i in range(8):
  g=f'QUALITY_BAR_{i:02d}'
  m.box(t+f'_QualityBar_{i:02d}',(.42,.082,.028),(-2.37+i*.68,.72,z-.158),'cyan' if i<5 else 'amber',group=g)
  m.group_pivots[g]=(-2.37+i*.68,.72,z-.158)
 led(m,t+'_PASS_LENS',-2.67,1.86,z-.10,'mint')
 led(m,t+'_REJECT_LENS',2.67,1.86,z-.10,'scarlet')
 return m


def make_camera():
 m=Model('10_L48_InspectionCamera');t='L48_CAMERA'
 m.bevel(t+'_ArmBase',(2.65,.35,2.65),(0,.32,0),'graphite',.13)
 m.cyl(t+'_PanJoint',.38,.27,(0,.63,0),'nickel','y',36,group='CAMERA_PAN_Y')
 rod(m,t+'_AluminumColumn',(0,.73,.36),(0,3.62,.36),.12,'polished')
 m.bevel(t+'_AdjustableCameraHousing',(2.32,1.16,1.54),(0,3.47,-.14),'steel_dark',.15,group='CAMERA_TILT_X')
 m.cyl(t+'_LensMount',.61,.31,(0,3.47,-1.00),'chrome','z',48,group='CAMERA_TILT_X')
 m.cyl(t+'_LargeOpticalLens',.47,.060,(0,3.47,-1.19),'cyan_soft','z',48,group='CAMERA_TILT_X')
 m.torus(t+'_LensRing',.53,.044,(0,3.47,-1.23),'cyan','z',48,8,group='CAMERA_TILT_X')
 m.cyl(t+'_GlassPupil',.20,.030,(0,3.47,-1.234),'void','z',36,group='CAMERA_TILT_X')
 m.group_pivots['CAMERA_PAN_Y']=(0,.63,0)
 m.group_pivots['CAMERA_TILT_X']=(0,3.47,-.14)
 led(m,t+'_InspectionPass',.72,3.75,-.96,'mint')
 led(m,t+'_InspectionFail',-.72,3.75,-.96,'red')
 txt(m,t+'_Name','QUALITY CAMERA',0,3.09,-.94,.14,'ice',1.96)
 return m


def make_supply():
 m=Model('11_L48_5VSupply');t='L48_SUPPLY';z=panel(m,t,'5 V REGULATED',4.35,2.85,1.76,'cyan','POWER REFERENCE')
 m.box(t+'_SupplyScreen',(2.42,.44,.026),(0,1.36,z-.083),'screen')
 txt(m,t+'_NominalVoltage','5.00 V',0,1.36,z-.120,.21,'mint',2.22)
 led(m,t+'_PowerLED',1.72,1.43,z-.050,'green')
 jack(m,t,'SUPPLY_PLUS','+5 V',-.87,.70,z,'red')
 jack(m,t,'SUPPLY_RETURN','RETURN',.87,.70,z,'black')
 for i in range(9):
  m.box(t+f'_Vent_{i:02d}',(.088,.024,1.12),(-1.43+i*.34,2.19,.42),'void')
 return m

BUILDERS=[make_frame,make_web,make_roller,make_encoder,make_optical_eye,make_motor,
          make_printhead,make_driver,make_controller,make_monitor,make_camera,make_supply]
# Showcased objects are kept as independent FBX hierarchy groups (not merged geometry).
POS={
 '00_L48_IndustrialFrame':(0,0,0),
 '01_L48_WebTransport':(0,0,0),
 '02_L48_DriveRoller':(-10.1,0,0),
 '03_L48_WebEncoder':(-8.7,0,-3.95),
 '04_L48_OpticalMarkSensor':(-7.3,0,3.9),
 '05_L48_PrintMotor':(11.5,0,3.6),
 '06_L48_PrintHead':(5.1,0,0.75),
 '07_L48_PrintDriver':(-9.4,0,-8.0),
 '08_L48_RegistrationController':(0,0,-8.0),
 '09_L48_QualityMonitor':(-9.2,0,8.5),
 '10_L48_InspectionCamera':(1.25,0,6.3),
 '11_L48_5VSupply':(11.1,0,-8.0),
}
WIRES=[
 ('W01','SUPPLY_PLUS','CTRL_PLUS','Supply +5V -> Controller +5V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply RETURN -> Controller GND'),
 ('W03','SUPPLY_PLUS','SENSOR_PLUS','Supply +5V -> Optical Sensor +5V'),
 ('W04','SUPPLY_RETURN','SENSOR_GND','Supply RETURN -> Optical Sensor GND'),
 ('W05','ENCODER_A','CTRL_ENC_A','Web Encoder A -> Controller ENC A'),
 ('W06','ENCODER_B','CTRL_ENC_B','Web Encoder B -> Controller ENC B'),
 ('W07','SENSOR_SIGNAL','CTRL_MARK_IN','Optical Sensor SIGNAL -> Controller MARK IN'),
 ('W08','CTRL_INDEX_PWM','DRIVER_PWM','Controller INDEX PWM -> Print Driver PWM'),
 ('W09','DRIVER_MOTOR_PLUS','PRINT_MOTOR_PLUS','Print Driver MOTOR+ -> Print Motor +'),
 ('W10','DRIVER_MOTOR_MINUS','PRINT_MOTOR_MINUS','Print Driver MOTOR- -> Print Motor -'),
 ('W11','CTRL_PRINT_TRIG','PRINT_HEAD_TRIG','Controller PRINT TRIG -> Print Head TRIG'),
 ('W12','SUPPLY_PLUS','DRIVER_PLUS','Supply +5V -> Print Driver +5V'),
 ('W13','SUPPLY_RETURN','DRIVER_GND','Supply RETURN -> Print Driver GND'),
]

def build():
 models=[]
 for maker in BUILDERS:
  m=maker();models.append(m)
  f=MOD/(m.key+'.fbx');g=MOD/(m.key+'.glb')
  export_fbx(f,[m]);export_glb(g,[m])
  assert f.read_bytes().startswith(b'Kaydara FBX Binary  \x00'),f
  assert len(trimesh.load_scene(g).geometry)>0,g
  print('MODEL',m.key,'triangles',sum(len(p.mesh.faces) for p in m.parts),'subparts',len(m.parts),'sockets',len(m.anchors),flush=True)
 assert len(models)==12
 ids=[sid for m in models for sid in m.anchors]
 assert len(ids)==22 and len(set(ids))==22,(len(ids),ids)
 used={a for _,a,_,_ in WIRES}|{b for _,_,b,_ in WIRES}
 assert len(WIRES)==13 and set(ids)==used,(len(used),set(ids)^used)
 assert all(m.key in POS for m in models)
 hero='Level48_Complete_ArtKit_Showcase'
 export_fbx(MOD/(hero+'.fbx'),models,positions=POS)
 export_glb(MOD/(hero+'.glb'),models,positions=POS)
 assert len(trimesh.load_scene(MOD/(hero+'.glb')).geometry)>0
 manifest={}
 for m in models:
  manifest[m.key]={
   'fbx':m.key+'.fbx','glb':m.key+'.glb','triangles':sum(len(p.mesh.faces) for p in m.parts),
   'mesh_subparts':len(m.parts),'art_sockets_local_xyz':m.anchors,
   'animation_pivots_local_xyz':m.group_pivots,'mesh_groups':list(dict.fromkeys(p.group for p in m.parts))}
 triangles=sum(sum(len(p.mesh.faces) for p in m.parts) for m in models)
 doc={'level':48,'title':'Hit the Mark','subtitle':'Precision Print Registration','scope':'Visual 3D assets only. No existing Unity circuit solver, printer trigger, scan detector, or level logic changed.',
 'source':'Project Spark Level 48 approved design','model_count':12,'player_wires':13,'art_sockets':22,
 'model_entries':manifest,'showcase_placements':POS,'wiring':WIRES,'assembled_fbx':hero+'.fbx','showcase_triangles':triangles,
 'coordinate_convention':'Y up, front = -Z, local xyz relative art units; bind SparkTerminal on your real scene holes.',
 'electrical_note':'Supply plus and return each accept THREE player wires. Encoder and printer supply support can be internally preinstalled, but must be implemented with real project wiring/logic.',
 'screen_note':'Registration controller and quality monitor screens intentionally have blank faces for Unity TextMeshPro runtime data.'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(doc,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model FBX','SocketID','LocalX','LocalY','LocalZ','UnityPlacementNote'])
  for m in models:
   for sid,(x,y,z) in m.anchors.items():w.writerow([m.key+'.fbx',sid,x,y,z,'Place real SparkTerminal at matching workbench hole; do not mistake mesh for component'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model FBX','SocketID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for sid,xyz in m.anchors.items():w.writerow([m.key+'.fbx',sid,*[round(a+b,5) for a,b in zip(xyz,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model FBX','MovingGroupName','PivotX','PivotY','PivotZ','Purpose'])
  for m in models:
   for g,(x,y,z) in m.group_pivots.items():w.writerow([m.key+'.fbx',g,x,y,z,'Visual-only transform, drive from real gameplay state'])
 (ROOT/'VALIDATION.txt').write_text(f'Level 48 / Hit the Mark\nIndividual FBX: {len(models)}; individual GLB: {len(models)}; assembled FBX/GLB: 1 pair.\nDistinct art socket IDs: {len(ids)}; unique W01-W13 wires: {len(WIRES)}; assembled triangles: {triangles:,}.\nFBX 7.4 binary header verified, GLB loaded as nonempty trimesh scenes, wiring endpoints validated. Unity import / physics / gameplay NOT tested.\n')
 print('SUCCESS',len(models),'models',triangles,'triangles',len(ids),'sockets',len(WIRES),'wires',flush=True)
 return models

if __name__=='__main__':build()
