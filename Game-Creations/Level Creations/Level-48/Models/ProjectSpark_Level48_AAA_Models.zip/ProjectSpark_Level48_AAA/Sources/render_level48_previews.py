"""Actual Level 47 triangle mesh previews rendered offscreen using VTK.
No AI mockups: display corresponds to procedural FBX/GLB geometry.
"""
from build_level48_models import *
from pathlib import Path
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from PIL import Image,ImageFont,ImageDraw
import numpy as np
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
P=ROOT/'Previews'

def actor_for(part, offset=(0,0,0)):
 mesh=part.mesh;poly=vtk.vtkPolyData()
 xyz=np.ascontiguousarray(np.asarray(mesh.vertices,dtype=np.float32)+np.asarray(offset,dtype=np.float32),dtype=np.float32)
 pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(xyz,deep=1));poly.SetPoints(pts)
 faces=np.ascontiguousarray(mesh.faces,dtype=np.int64)
 cc=vtk.vtkCellArray();arr=np.column_stack((np.full(len(faces),3,dtype=np.int64),faces)).reshape(-1)
 cc.SetCells(len(faces),numpy_to_vtkIdTypeArray(arr,deep=1));poly.SetPolys(cc)
 norms=vtk.vtkPolyDataNormals();norms.SetInputData(poly);norms.SplittingOff();norms.ConsistencyOn()
 mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norms.GetOutputPort())
 actor=vtk.vtkActor();actor.SetMapper(mapper)
 rgb=np.asarray(PALETTE[part.mat][:3],dtype=float)/255.;prop=actor.GetProperty()
 prop.SetColor(*rgb);prop.SetAmbient(.43);prop.SetDiffuse(.59)
 reflective=part.mat in ('chrome','titanium','steel','gold','copper','orange','orange_hi','mid_steel','brass','aluminum','polished')
 prop.SetSpecular(.70 if reflective else .25);prop.SetSpecularPower(83 if reflective else 32)
 if part.mat in ('cyan','mint','green','blue','red','amber','violet','electric','icy','screen_green','orange_hi','gold'):
  prop.SetAmbient(.81);prop.SetDiffuse(.29)
 if any(v in part.name for v in ('_Name','_Label','_Engraving','_Title','_Sub','_Mark','_Text','_Percent','_Front','_STATIC','_STATIC')):
  if 'Plate' not in part.name and 'Chrome' not in part.name:
   prop.SetAmbient(.96);prop.SetDiffuse(.045);prop.SetSpecular(.003)
 if part.mat in ('glass','darkglass','glass_body','water'):
  prop.SetOpacity(.31)
 prop.SetBackfaceCulling(False)
 return actor

def render(models,path,positions=None,eye=(0,22,-25),look=(0,1.2,0),scale=8.0,size=(2500,1520)):
 positions=positions or {};ren=vtk.vtkRenderer()
 ren.SetBackground(.035,.053,.081);ren.SetBackground2(.005,.012,.028);ren.GradientBackgroundOn()
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(2);win.AddRenderer(ren)
 for model in models:
  for part in model.parts:ren.AddActor(actor_for(part,positions.get(model.key,(0,0,0))))
 for pos,col,inten in [((-14,20,-10),(1.0,.95,.88),1.10),((12,15,7),(.48,.80,1),1.22),((2,13,-6),(.67,.95,1),.71)]:
  li=vtk.vtkLight();li.SetLightTypeToSceneLight();li.SetPosition(*pos);li.SetFocalPoint(0,0,0)
  li.SetColor(*col);li.SetIntensity(inten);ren.AddLight(li)
 camera=ren.GetActiveCamera();camera.SetPosition(*eye);camera.SetFocalPoint(*look);camera.SetViewUp(0,1,0)
 camera.ParallelProjectionOn();camera.SetParallelScale(scale)
 win.Render()
 img=vtk.vtkWindowToImageFilter();img.SetInput(win);img.SetInputBufferTypeToRGB();img.ReadFrontBufferOff();img.Update()
 writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(img.GetOutputPort());writer.Write()
 win.Finalize()
 print('RENDERED',path.name,path.stat().st_size,flush=True)

def overlay(path,title,sub,badge=None):
 im=Image.open(path).convert('RGBA');w,h=im.size;dr=ImageDraw.Draw(im,'RGBA')
 wide=min(w-32,int(w*.81))
 dr.rounded_rectangle((18,15,wide,134),radius=13,fill=(4,17,29,246),outline=(41,223,250,255),width=2)
 titlefont=ImageFont.truetype(BOLD,39 if w>1900 else 26)
 subfont=ImageFont.truetype(FONT,20 if w>1800 else 17)
 dr.text((43,35),title,font=titlefont,fill=(237,248,255))
 dr.text((43,100),sub,font=subfont,fill=(131,219,241))
 if badge and w>1500:
  dr.rounded_rectangle((w-550,24,w-24,82),radius=10,fill=(8,23,39,241),outline=(255,173,72,255),width=2)
  dr.text((w-535,43),badge,font=ImageFont.truetype(BOLD,18),fill=(255,213,144))
 dr.text((w-20,h-20),'PROJECT SPARK   /   LEVEL 48   /   ACTUAL 3D GEOMETRY',font=ImageFont.truetype(BOLD,13),anchor='ra',fill=(138,218,235))
 im.convert('RGB').save(path)

def sheet(previews,models,cols=3):
 tw,th=610,442;rows=int(math.ceil(len(models)/cols));s=Image.new('RGB',(tw*cols,th*rows),(5,18,29))
 dr=ImageDraw.Draw(s)
 for i,(m,fn) in enumerate(zip(models,previews)):
  x=(i%cols)*tw+6;y=(i//cols)*th+5
  im=Image.open(fn).convert('RGB');im.thumbnail((tw-12,th-60),Image.Resampling.LANCZOS)
  s.paste(im,(x,y))
  dr.rounded_rectangle((x,y+th-61,x+tw-13,y+th-12),radius=8,fill=(9,32,50),outline=(43,219,250),width=2)
  name=m.key[3:].replace('_',' ').upper();dr.text((x+13,y+th-47),name,font=ImageFont.truetype(BOLD,19),fill=(241,247,252))
 dest=P/'Level48_All_12_Models_ContactSheet.png';s.save(dest);print('SHEET',dest,flush=True)


if __name__=='__main__':
 models=[fn() for fn in BUILDERS]
 hero=P/'Level48_Complete_12Piece_Kit_Preview.png'
 render(models,hero,POS,eye=(0,34,-39),look=(0,1.60,0),scale=14.9,size=(2540,1580))
 overlay(hero,'LEVEL 48  /  HIT THE MARK',
         'PRECISION PRINT REGISTRATION  |  12 UNITY FBX MODELS  |  AAA-STYLE ELECTRONICS',
         badge='13 PLAYER WIRES  /  22 SOCKETS')
 opts=[
  (8,17,-22,11.9),   # chassis
  (8.1,16.5,-18.2,10.3), # web
  (3.8,6.8,-11.2,3.15), # measuring roller
  (3.3,6.1,-10.3,3.3), # encoder
  (4.2,6.8,-10.3,4.2), # optical eye
  (5.2,7.2,-11.7,4.1), # motor
  (4.5,7.7,-12.4,4.7), # printhead
  (4.3,7.4,-11.1,4.4), # driver
  (5.3,7.7,-12.3,5.0), # controller
  (5.6,8.1,-12.6,4.85), # monitor
  (3.5,7.1,-11.3,4.4), # camera
  (4.1,6.4,-10.8,3.65), # supply
 ]
 shots=[]
 for i,m in enumerate(models):
  ex,ey,ez,sc=opts[i]
  dest=P/(m.key+'_Preview.png')
  render([m],dest,eye=(ex,ey,ez),look=(0,1.7,0),scale=sc,size=(1030,790))
  overlay(dest,m.key.split('_',2)[-1].replace('_',' ').upper(), 'LEVEL 48 / EXPORTED 3D FBX GEOMETRY')
  shots.append(dest)
 sheet(shots,models)
 print('ALL LEVEL 48 RENDERS COMPLETE',flush=True)
