PROJECT SPARK / LEVEL 48 — HIT THE MARK
AAA-inspired semi-HD visual FBX model pack

PURPOSE
12 independent FBX art models + 12 GLB backup models + 1 assembled FBX/GLB showcase.
Visual mesh assets ONLY. No motors, scanners, logical signal-processing,
electrical solver integration, print registration, or objective-evaluation system is included.
The existing Project Spark gameplay systems remain authoritative.

UNITY IMPORT
1. Unzip ProjectSpark_Level48_AAA_Models.zip.
2. Copy the Models/*.fbx into Assets/My_Assets/_Project_Spark/Art/Level48/Models (or your preferred asset folder).
3. Set Model import Scale Factor to an appropriate value for your workstation and disable unwanted mesh collider generation.
4. The FBXs use Y up and the local front side is negative Z. Separate pieces have their own local origins and named child groups.
5. Use the individual models for Level_48_Layout; use Level48_Complete_ArtKit_Showcase.fbx only as a placement guide.
6. Use Model_Manifest.json > showcase_placements to reproduce the showcase. Fit the entire assembly to your workbench using a common root transform.
7. Apply Unity-compatible PBR materials if desired. Mesh material colors and names are preserved in FBX. For beautiful metal: use Metalness ~0.7–0.9 and Smoothness ~0.6–0.8; for rubber and dark plastic reduce metalness.
8. Set up real SparkTerminal components in the scene at the corresponding breadboard holes and declare the corresponding actual binding IDs. The provided 3D socket geometry does NOT automatically become a SparkTerminal.
9. Connect actual electrical and digital-signal transport using existing Project Spark architecture. Use Exact_Wiring.csv, or the numbered table below.
10. Link the game's actual output to live displays via TextMeshPro/Renderer or your existing dashboard script. The registration and quality screens intentionally have no fabricated live value.
11. Optional: add SparkLevel48VisualRig.cs on a parent, find the named moving groups and assign them in the Inspector. Drive ApplyMotion/ApplyVisualSignals from REAL level gameplay state.
12. Test mark offset, print triggering and all 6/6 targets in Unity; this pack has not been imported into or tested inside your Unity project.

MODELS
00_L48_IndustrialFrame.fbx   — fixed machine base, mounting rails, breadboard perforations
01_L48_WebTransport.fbx     — printed film with distinct moving web group and registration marks
02_L48_DriveRoller.fbx      — rubber measuring drum, bearings, chrome precision surface
03_L48_WebEncoder.fbx      — 80-mark optical disc, fixed reader, separate encoder rotating group
04_L48_OpticalMarkSensor.fbx — +5 V/GND/SIG, scanner emitter and detection light
05_L48_PrintMotor.fbx       — geared motor, separate shaft and indexing pulley
06_L48_PrintHead.fbx        — gantry, guide columns, piston and moving stamp/pad
07_L48_PrintDriver.fbx      — 5 electrical sockets, 10 heatsink fins
08_L48_RegistrationController.fbx — 7 sockets, blank display and control buttons
09_L48_QualityMonitor.fbx   — blank print-quality display, 8 indicator bars
10_L48_InspectionCamera.fbx — adjustable camera with quality-pass/fail lenses; decorative
11_L48_5VSupply.fbx         — 5 V supply; positive and return each accept 3 wires

PLAYER WIRES / EXACT SOCKET IDs
W01 SUPPLY_PLUS       -> CTRL_PLUS
W02 SUPPLY_RETURN     -> CTRL_GND
W03 SUPPLY_PLUS       -> SENSOR_PLUS
W04 SUPPLY_RETURN     -> SENSOR_GND
W05 ENCODER_A         -> CTRL_ENC_A
W06 ENCODER_B         -> CTRL_ENC_B
W07 SENSOR_SIGNAL     -> CTRL_MARK_IN
W08 CTRL_INDEX_PWM    -> DRIVER_PWM
W09 DRIVER_MOTOR_PLUS -> PRINT_MOTOR_PLUS
W10 DRIVER_MOTOR_MINUS-> PRINT_MOTOR_MINUS
W11 CTRL_PRINT_TRIG   -> PRINT_HEAD_TRIG
W12 SUPPLY_PLUS       -> DRIVER_PLUS
W13 SUPPLY_RETURN     -> DRIVER_GND

The supply plus / return sockets each accept THREE player wires.
Distinct art socket IDs = 22. Player wires = 13.

SIMULATION NOTE
Proposed lesson uses 80 decoded counts per revolution, 20 mm measuring roller radius,
nominal 80-count scanner-to-print offset and 160-count registration pitch.
Those timing/geometry measurements must be mapped to the actual motor and web
simulation; the art meshes do not implement or guarantee these values.

MOVING PIVOTS / GROUPS
MEASURING_ROLLER_ROTATE_Z
ENCODER_DISC_ROTATE_Z
PRINT_MOTOR_SHAFT_ROTATE_X
PRINT_HEAD_STROKE_Y
WEB_TRANSLATE_X
SCAN_BEAM_ENABLE
MARK_DETECTED_LAMP
HEAD_READY_LENS, HEAD_TRIGGER_LENS
START_PRESS, STOP_PRESS, CAL_PRESS, RESET_PRESS
QUALITY_BAR_00 through QUALITY_BAR_07
CAMERA_PAN_Y, CAMERA_TILT_X

Files:
- Exact_Wiring.csv: 13 exact player wires
- Terminal_Anchors.csv: local model-relative coordinates
- World_Terminal_Anchors.csv: assembled showcase coordinates
- Animation_Rigs.csv: moving group names and pivot coordinates
- Model_Manifest.json: full named mesh and socket metadata
- Unity_Optional/SparkLevel48VisualRig.cs: visual-only position/actuator helper
- Sources: generator and VTK renderer if you want to regenerate or tweak the art

Verification is geometry/file-format only. No Unity compilation, scene import, runtime
motor simulation, actual sensor timing, printing mechanics, or level completion test has occurred.
