# Project Spark — Level 48: Hit the Mark

## Visual art specification

**12 individual FBX files** + a complete assembled FBX; Autodesk FBX 7.4 binary and GLB backup exports. Art style: CNC-machined metal housings, titanium and chrome machinery, cyan optical scanning and amber print-actuation accents.

**13 player wires and 22 unique art sockets** are mapped in `Exact_Wiring.csv` and `Terminal_Anchors.csv`. The 5 V supply positive and return each receive three player wires.

### Progression to test in Unity

1. Wire the 13 player connections; verify real power and actual graph connectivity.
2. Calibrate the optical registration eye with real marks and actual encoder motion.
3. Stamp accurately at 30 RPM using encoder distance, not a fixed delay.
4. Increase to 60 RPM and keep registration accurate.
5. Reject a short false optical mark without adding a stamp.
6. Detect a missing expected mark, inhibit printing, stop safely, restore sensor, reset and successfully resume.

**Art is not a working controller.** Only the actual Unity level script should accept/reject marks, trigger print actions, compute error and submit the six targets through `SparkLevelEvaluator` and `LevelGamePlayManager`. Do not spoof target pass states.

### Coordinate / material caveats

- Y is up; the front of each electrical module is local negative Z.
- The supplied `showcase_placements` in `Model_Manifest.json` reproduces the rendered assembly on the industrial base.
- Socket coordinates are offsets to **mesh reference sockets**, not to Project Spark circuit nodes. Create real terminal GameObjects aligned to your hole grid and bind them to actual component and terminal IDs.
- Keep the moving parts on their named FBX transforms so the printed labels, actuator, and scanning beam remain independently controllable.
- Screens are intentionally blank and suitable for live UI overlays.
- The 20 mm measuring roller radius is a proposed game physics parameter. The art dimensions use model-relative units and must be scaled and calibrated to your scene.

### Animation groups

The `SparkLevel48VisualRig` class is **purely visual**. Link it to authoritative encoder count, web displacement, motor angle, print stroke and sensor/print signals. To implement an endless belt, prefer shader UV scrolling over translating the entire finite web mesh.

### Validation checklist

- [ ] All imported FBXs have correct scene scale and material orientation.
- [ ] No duplicate `SparkElectricalComponent` or `SparkTerminal` is created from visual parts.
- [ ] All 22 terminal binding IDs are unique, declared and actually bound.
- [ ] W01–W13 match the real wiring graph.
- [ ] Optical sensor faces the web upstream of the print head.
- [ ] Encoder travel is measured, and prints use encoder events rather than fixed timer delays.
- [ ] No additional powered parts come from the decorative inspection camera or monitor.
- [ ] 6/6 objectives pass through the actual level manager after real Unity tests.
