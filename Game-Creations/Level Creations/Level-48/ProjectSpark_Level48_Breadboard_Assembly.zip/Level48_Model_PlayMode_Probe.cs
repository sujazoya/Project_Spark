#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AAAUI.VFX;
using ProjectSpark.Circuit;
using ProjectSpark.EditorTools;
using ProjectSpark.Gameplay;
using UnityEditor;
using UnityEngine;

using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;

[InitializeOnLoad]
internal static class Level48ModelPlayModeProbe
{
    private const string Request = "Temp/Level48ModelTest.request";
    private const string Report = "Temp/Level48ModelTest.txt";
    private const string Running = "Codex.Level48.ModelTest";
    private static LevelGamePlayManager manager;
    private static SparkLevel48Registration loop;

    static Level48ModelPlayModeProbe()
    {
        EditorApplication.update += CheckRequest;
        EditorApplication.playModeStateChanged += StateChanged;
    }

    private static void CheckRequest()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || !File.Exists(Request)) return;
        try { File.Delete(Request); }
        catch (IOException) { return; }
        File.WriteAllText(Report, "Level 48 — Breadboard assembly and Hit the Mark test\n");
        try
        {
            Check(SceneManager.GetActiveScene().path == SparkLevel48ModelInstaller.ScenePath, "Open MainMenu in Edit Mode.");
            SparkLevel48ModelInstaller.Install();
            Record("Installed the fitted assembly in the Level 48 prefab and registered the campaign.");
            SessionState.SetBool(Running, true);
            EditorApplication.EnterPlaymode();
        }
        catch (Exception error) { Record("FAIL: " + error); }
    }

    private static void StateChanged(PlayModeStateChange state)
    {
        if (!SessionState.GetBool(Running, false)) return;
        if (state == PlayModeStateChange.EnteredPlayMode) Run();
        if (state == PlayModeStateChange.EnteredEditMode)
        {
            SessionState.EraseBool(Running);
            Record("Returned to Edit Mode.");
        }
    }

    private static async void Run()
    {
        bool logEnabled = Debug.unityLogger.logEnabled;
        bool runInBackground = Application.runInBackground;
        try
        {
            Debug.unityLogger.logEnabled = false;
            Application.runInBackground = true;
            Record("Entered Play Mode.");
            await Wait(() => Object.FindFirstObjectByType<LevelGamePlayManager>() != null, "MainMenu manager");
            manager = Object.FindFirstObjectByType<LevelGamePlayManager>();
            var loader = Object.FindFirstObjectByType<SparkLevelLayoutLoader>();
            var wireBuilder = Object.FindFirstObjectByType<SignalWireBuilder>();
            var wirePaths = Object.FindFirstObjectByType<SignalPath_Manager>();
            var definition = AssetDatabase.LoadAssetAtPath<SparkLevelDefinition>(SparkLevel48ModelInstaller.Folder + "Level_48.asset");
            Check(definition != null && wireBuilder != null && loader != null, "Level definition, wire builder, or layout loader missing.");
            if (manager.LevelProgression != null) manager.LevelProgression.enabled = false;
            Write(manager, "enforceProgressionAccess", false);
            Write(manager, "autoAdvanceOnCompletion", false);
            Write(manager, "autoEvaluate", true);
            int levelIndex = Array.IndexOf(Read<SparkLevelDefinition[]>(manager, "levels"), definition);
            Check(levelIndex >= 0 && manager.StartLevel(levelIndex), "Level 48 is missing from the campaign or could not start.");
            await Wait(() => loader.ActiveLayout != null && manager.ActiveLevel == definition, "Level 48 loaded");
            loop = loader.ActiveLayout.GetComponent<SparkLevel48Registration>();
            await Wait(() => loop != null && Read<int>(loop, "topology") >= 0,
                "the active loop controller to check the empty circuit");

            var bench = loop.transform.Find("Registration Workbench");
            var camera = Read<Camera>(wireBuilder, "targetCamera");
            var grid = SparkLevel48ModelInstaller.FindBoard(SceneManager.GetActiveScene());
            var ids = SparkLevel48ModelInstaller.TerminalIds.ToArray();
            var pins = new Dictionary<string, SparkTerminal>();
            var holes = new HashSet<Vector2Int>();
            float maximumGap = 0;
            float lowestFoot = float.PositiveInfinity, highestFoot = float.NegativeInfinity;
            Physics.SyncTransforms();
            foreach (string id in ids)
            {
                Check(manager.SceneBindings.TryGetTerminal(id, out var terminal), "Missing " + id);
                pins.Add(id, terminal);
                var socket = terminal.transform;
                Vector3 foot = socket.TransformPoint(Vector3.down);
                float height = Vector3.Dot(foot, bench.up);
                lowestFoot = Mathf.Min(lowestFoot, height);
                highestFoot = Mathf.Max(highestFoot, height);
                Vector3 surface = SparkLevel48ModelInstaller.SurfacePoint(grid, foot, bench.up);
                maximumGap = Mathf.Max(maximumGap, Mathf.Abs(Vector3.Dot(surface - foot, bench.up)));
                Check(maximumGap < .001f, "Terminal base does not touch the breadboard: " + id);
                Check(grid.TryGetNearestHole(socket.position, .15f, out var hole, out int column, out int row) &&
                    holes.Add(new Vector2Int(column, row)) &&
                    Vector3.ProjectOnPlane(foot - hole, bench.up).magnitude < .001f,
                    "Terminal does not sit over its own wire hole: " + id);
            }
            Check(holes.Count == 22, "Expected 22 breadboard sockets.");
            Check(highestFoot - lowestFoot < .010f, $"Breadboard seating varies by {highestFoot-lowestFoot:F5} Unity units.");
            Record($"22/22 terminal feet touch the breadboard on distinct wire holes. Maximum seating error: {maximumGap:F6} Unity units.");
            var labels = bench.GetComponentsInChildren<TextMesh>();
            Check(labels.Length == 28 && Array.TrueForAll(labels, label => label.transform.localScale == Vector3.one * .20f),
                "TextMesh labels must use a local scale of 0.20.");
            Record("All 28 TextMesh labels use 0.20 local scale.");
            Capture(bench, pins, "Unwired", true);
            foreach (var pair in pins)
            {
                Vector3 point = camera.WorldToScreenPoint(pair.Value.transform.position);
                Check(point.z > 0 && point.x >= 0 && point.y >= 0 && point.x < camera.pixelWidth && point.y < camera.pixelHeight,
                    $"Terminal outside the active camera: {pair.Key} at {point}; camera {camera.pixelWidth}x{camera.pixelHeight}");
                Check(ReferenceEquals(pick.Invoke(wireBuilder, new object[] { (Vector2)point }), pair.Value),
                    "Wire tool cannot select " + pair.Key + " from the active game camera.");
            }
            Record("22/22 sockets picked by the real Wire tool from the active game camera.");
            void Connect(int from, int to, WirePolarity polarity = WirePolarity.Neutral)
            {
                Check(wireBuilder.BeginWire(pins[ids[from]], polarity), "Wire tool could not start at " + ids[from]);
                Check(wireBuilder.TryEndWire(camera.WorldToScreenPoint(pins[ids[to]].transform.position)),
                    "Wire tool could not finish " + ids[from] + " to " + ids[to]);
            }

            var wires = new (int from,int to)[] {(0,1),(2,3),(0,4),(2,5),(6,7),(8,9),(10,11),
                (12,13),(14,15),(16,17),(18,19),(0,20),(2,21)};
            for (int i=0;i< wires.Length-1;i++)
            {
                var (from,to)=wires[i];
                Connect(from,to,from==0 ? WirePolarity.Positive : from==2 ? WirePolarity.Negative : WirePolarity.Neutral);
            }
            await Wait(()=>loop.statusText.text.Contains("W13"),"missing driver return diagnostic");
            Check(!loop.startButton.interactable && !loop.calibrateButton.interactable && manager.SatisfiedTargetCount==0,
                "Transport or calibration available with no driver return.");
            Connect(2,21,WirePolarity.Negative);
            await At(1);
            Record("13/13 player wires placed with SignalWireBuilder. Incomplete wiring blocked both motion and calibration.");
            await Click(loop.calibrateButton);
            await At(2);
            Check(Read<int>(loop,"spacing")==160,"Two genuine marks did not measure 160 counts apart.");
            await Click(loop.startButton);
            await At(3);
            Check(Read<int>(loop,"accepted")==3 && Read<int>(loop,"rejected")==0,"Expected three clean 30 RPM prints.");
            Record($"30 RPM last error: {Read<float>(loop,"errorMm"):+0.00;-0.00;0.00} mm.");
            await Click(loop.fastButton);
            await At(4);
            Check(Read<bool>(loop,"transitioned") && Read<int>(loop,"accepted")>=6 && Read<int>(loop,"rejected")==0,
                "The line did not register correctly at both speeds.");
            Record($"60 RPM last error: {Read<float>(loop,"errorMm"):+0.00;-0.00;0.00} mm.");
            Capture(bench,pins,"Running",false);
            await Click(loop.glareButton);
            await At(5);
            Check(Read<int>(loop,"falsePulses")==1 && Read<int>(loop,"printsAfterGlare")==1 &&
                Read<int>(loop,"rejected")==0,"False optical pulse was not safely rejected.");
            await Click(loop.coverButton);
            await Wait(()=>loop.statusText.text.Contains("REGISTRATION MARK MISSING"),"missing mark safe stop");
            Check(!loop.resetButton.interactable && loop.printDrive.IsOpen && loop.transportDrive.IsOpen &&
                manager.SatisfiedTargetCount==5,"Stop, reset lockout or objective history failed.");
            int stoppedPrints=Read<int>(loop,"accepted");
            await Wait(()=>Read<float>(loop,"velocity")<.0005f,"web at rest");
            Check(Read<int>(loop,"accepted")==stoppedPrints,"Printed during safe stop.");
            Capture(bench,pins,"SensorFault",false);
            await Click(loop.coverButton);
            Check(!loop.startButton.interactable,"Restoring the eye bypassed the fault latch.");
            await Click(loop.resetButton);
            await Click(loop.startButton);
            await At(6);
            Check(Read<int>(loop,"printsAfterReset")==1,"Missing verified recovery print.");
            await Wait(()=>manager.IsCompleted,"campaign completion");
            Record("6/6 — Speed change, false pulse rejection and missing-mark recovery verified. Campaign manager reports Completed.");
            Capture(bench,pins,"Verified",false);

        }
        catch (Exception error)
        {
            Record("FAIL: " + error);
            if (loop != null) Record("Control panel: " + loop.statusText.text + " | " + loop.meterText.text + " | " + loop.detailText.text);
            if (manager != null) Record($"Evaluation {manager.SatisfiedTargetCount}/{manager.ActiveTargetCount}: {manager.LastEvaluationMessage}");
        }
        finally
        {
            Debug.unityLogger.logEnabled = logEnabled;
            Application.runInBackground = runInBackground;
            if (EditorApplication.isPlaying) EditorApplication.ExitPlaymode();
        }
    }

    private static readonly MethodInfo pick = typeof(SignalWireBuilder).GetMethod("FindTerminalAtScreenPosition",
        BindingFlags.Instance | BindingFlags.NonPublic);

    private static async Task At(int stage)
    {
        await Wait(() => Read<int>(loop, "stage") == stage && manager.SatisfiedTargetCount == stage, $"{stage}/6");
        Record($"{stage}/6 — {loop.statusText.text} | {loop.meterText.text}");
    }

    private static async Task Click(Button button)
    {
        await Wait(() => button.isActiveAndEnabled && button.interactable, button.name + " available");
        Check(button.onClick.GetPersistentEventCount() == 1 && button.onClick.GetPersistentTarget(0) == loop,
            "Missing Level 48 action on " + button.name);
        button.onClick.Invoke();
    }

    private static void Capture(Transform bench, Dictionary<string, SparkTerminal> pins, string name, bool overhead)
    {
        var view = new GameObject("Level 48 test camera");
        var camera = view.AddComponent<Camera>();
        camera.enabled = false;
        view.transform.position = bench.TransformPoint(new Vector3(0, 2.20f, overhead ? -.58f : -1.92f));
        view.transform.rotation = Quaternion.LookRotation(bench.TransformPoint(new Vector3(0, .04f, 0)) -
            view.transform.position, bench.up);
        camera.orthographic = true;
        camera.orthographicSize = bench.TransformVector(new Vector3(0, .90f, 0)).magnitude;
        const int width = 1600, height = 1050;
        var target = new RenderTexture(width, height, 24);
        var snapshot = new Texture2D(width, height, TextureFormat.RGB24, false);
        var previous = RenderTexture.active;
        try
        {
            camera.targetTexture = target;
            camera.Render();
            RenderTexture.active = target;
            snapshot.ReadPixels(new Rect(0, 0, width, height), 0, 0);
            snapshot.Apply();
            File.WriteAllBytes("Temp/Level48_" + name + ".png", snapshot.EncodeToPNG());
            if (!overhead) return;
            var rows = new List<string> { "Terminal,X,Y" };
            foreach (var pair in pins)
            {
                var p = camera.WorldToViewportPoint(pair.Value.transform.position);
                rows.Add($"{pair.Key},{Mathf.RoundToInt(p.x * width)},{Mathf.RoundToInt((1f - p.y) * height)}");
            }
            File.WriteAllLines("Temp/Level48_Pins.csv", rows);
        }
        finally
        {
            RenderTexture.active = previous;
            camera.targetTexture = null;
            Object.Destroy(target);
            Object.Destroy(snapshot);
            Object.Destroy(view);
        }
    }

    private static Task Wait(Func<bool> condition, string step)
    {
        if (condition()) return Task.CompletedTask;
        var completion = new TaskCompletionSource<bool>();
        var timeout = DateTime.UtcNow.AddSeconds(65);
        void Poll()
        {
            try
            {
                Check(EditorApplication.isPlaying, "Play Mode stopped while waiting for " + step);
                if (!condition())
                {
                    Check(DateTime.UtcNow < timeout, "Timed out waiting for " + step);
                    return;
                }
                EditorApplication.update -= Poll;
                completion.SetResult(true);
            }
            catch (Exception error)
            {
                EditorApplication.update -= Poll;
                completion.SetException(error);
            }
        }
        EditorApplication.update += Poll;
        return completion.Task;
    }

    private static FieldInfo Field(object target, string name) =>
        target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic) ?? throw new MissingFieldException(name);
    private static T Read<T>(object target, string name) => (T)Field(target, name).GetValue(target);
    private static void Write(object target, string name, object value) => Field(target, name).SetValue(target, value);
    private static void Record(string message) => File.AppendAllText(Report, message + Environment.NewLine);
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
#endif






