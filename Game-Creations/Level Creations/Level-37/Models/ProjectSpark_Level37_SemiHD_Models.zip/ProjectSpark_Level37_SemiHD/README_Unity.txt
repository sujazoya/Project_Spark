PROJECT SPARK — LEVEL 37: KELVIN TEST
Polished Semi-HD 3D FBX + GLB Model Collection
================================================

WHAT'S INCLUDED
---------------
Six primary electrical-module art models:
  01_5V_Regulated_Supply.fbx
  02_100Ohm_Current_Limiter.fbx
  03_Force_Lead_Positive.fbx
  04_5Ohm_Connector_Sample.fbx
  05_Force_Return_Negative.fbx
  06_Kelvin_Sense_Meter.fbx

Two optional visual-replacement models (NOT new circuits or extra terminals):
  07_OPTIONAL_Faulty_Force_Return.fbx
  08_OPTIONAL_Damaged_Connector_12Ohm.fbx

Matching .glb backups for each; assembled preview FBX+GLB, 8 individual previews,
a contact sheet, an actual rendered assembled-model preview, Terminal_Anchors.csv,
Exact_Wiring.csv, Model_Manifest.json, and editable generator sources.

CIRCUIT DESIGN — 7 WIRES / 12 ELECTRICAL SOCKETS
------------------------------------------------
W01  Battery_positive  -> LIMIT_IN
W02  LIMIT_OUT         -> LEAD_PLUS_IN
W03  LEAD_PLUS_OUT     -> CONNECTOR_PLUS
W04  CONNECTOR_MINUS   -> RETURN_IN
W05  RETURN_OUT        -> Battery_negative
W06  SENSE_PLUS        -> CONNECTOR_PLUS
W07  SENSE_MINUS       -> CONNECTOR_MINUS

The Kelvin sense taps are connected DIRECTLY TO THE CONNECTOR endpoints (not
at the outer ends of the force leads). This allows the reading to exclude the
series voltage drops in the high-current force leads.

IMPORTANT: The terminal strings in Terminal_Anchors.csv are descriptive IDs
based on the artwork's pin labels, NOT proof that they match your level
prefab's current SparkLevelSceneBindings. Reuse the EXISTING binding IDs in
Unity; do not change electrical IDs to match the art without checking.

REFERENCE RESULTS
-----------------
Condition                           Two-wire     Four-wire (Kelvin)
Healthy fixture                      25 Ohm             5 Ohm
Bad lead                             35 Ohm             5 Ohm
Bad lead + damaged connector         42 Ohm            12 Ohm
Connector repaired                   35 Ohm             5 Ohm
Lead replaced                        25 Ohm             5 Ohm

MODEL FEATURES
--------------
- A real 3D gold-contact connector sample with visible individual pin fingers.
- Acrylic protective rails, chrome fixtures, brushed metal edges, 3D labels.
- Separate color-coded sockets and the sample's green Kelvin contact probes.
- Red positive force lead and blue negative return with braided cable visuals.
- 100 Ohm precision axial resistor with 3D four-band color coding.
- Kelvin digital meter screen; 5.00 Ohm is baked-in STATIC ART, not a live value.
- Optional visibly damaged 12 Ohm connector and red-hot faulty return lead.
- GLB has vertex colors; FBX contains named Phong material sections. Blender is
  NOT required for importing the FBX into Unity.

UNITY INSTALLATION
------------------
1. Import Models/ into Assets/My_Assets/_Project_Spark/Models/Level37/.
2. Put individual art FBXs under the matching EXISTING level GameObjects.
   Preserve all SparkPowerSupply, SparkResistor, SparkSwitch, terminal, graph,
   wire and level objective components. These mesh files add visuals only.
3. Use Terminal_Anchors.csv to locate jack recesses. The 12 terminal anchors
   are local to their OWN model origin; Y is up and -Z faces the player.
   Positions assume visual root scale 1 and unchanged FBX orientation.
4. Move or parent the existing SparkTerminal transforms to align with socket
   faces, but verify serialized terminal references and wire hit colliders.
5. Remap dark metal, titanium, chrome, gold and copper to URP/HDRP Lit materials.
   Assign cyan emission to Neon/Status/Halo meshes selectively, not to housings.
   Acrylic rails can use Transparent; set suitable surface sorting if needed.
6. For the Kelvin display, replace or cover the static 5.00 Ohm mesh lettering
   with a runtime TextMeshPro readout if it must follow live measurements.
7. Keep defective variants inactive until the level's fault/recovery scenario.
   Swapping a FBX NEVER changes electrical resistance. Change the actual
   component parameter using your existing Level 37 logic.
8. The large Level37_Complete_ArtKit_Showcase.fbx is a presentation layout;
   don't instantiate its cloned electrical modules on top of your live puzzle.
9. The model parts' source FBX hierarchy has Groups such as
   KelvinProbeTip_VISUAL / ConnectorFault_VISUAL / BadLeadFault_VISUAL;
   animate or toggle these visual-only groups if desired.
10. Configure LODs/colliders according to your desktop/mobile targets.

No Unity project was available for a live import, so pivot/scale and material
appearance are structurally checked but not verified in the game. The reference
preview images are actual renders of the exported mesh source, not generated
concept art.

Asset source and re-export: Sources/build_level37_models.py
Dependencies: numpy, trimesh, shapely, matplotlib; optional vtk for previews.
