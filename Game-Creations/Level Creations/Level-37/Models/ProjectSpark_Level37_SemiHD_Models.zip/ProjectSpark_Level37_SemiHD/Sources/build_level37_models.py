"""Level 37 Kelvin Test — polished semi-HD FBX & GLB art assets.
Game scene visual only. Unity Y-up, sockets on -Z side. Uses reference diagram's 7 wires / 12 sockets.
Source code is editable and regenerates all models, manifests and anchors.
"""
import math,csv,json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import *
ROOT=Path(__file__).resolve().parents[1]; MODELS=ROOT/'Models'; PREV=ROOT/'Previews'
for d in (MODELS,PREV):d.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'pearl':(226,229,218,255), 'resistor':(227,192,138,255), 'lead_red':(242,65,80,255),
 'lead_blue':(34,130,240,255), 'emerald':(45,250,162,255), 'goldbright':(253,194,57,255),
 'gilt':(183,125,55,255), 'nickel':(185,198,211,255), 'darkglass':(64,185,219,64),
 'glass_soft':(110,205,239,76), 'lcdgreen':(75,255,176,255), 'fault':(246,93,48,255),
 'purple':(193,115,255,255),'charcoal':(33,40,52,255),
})
# Pin IDs for placement recommendations; these are art anchors, not registered SparkTerminal components.
PORTS={
 '01_5V_Regulated_Supply':('Battery_positive','Battery_negative'),
 '02_100Ohm_Current_Limiter':('LIMIT_IN','LIMIT_OUT'),
 '03_Force_Lead_Positive':('LEAD_PLUS_IN','LEAD_PLUS_OUT'),
 '04_5Ohm_Connector_Sample':('CONNECTOR_PLUS','CONNECTOR_MINUS'),
 '05_Force_Return_Negative':('RETURN_IN','RETURN_OUT'),
 '06_Kelvin_Sense_Meter':('SENSE_PLUS','SENSE_MINUS')
}
WIRES=[
 ('W01','Battery_positive','LIMIT_IN'),
 ('W02','LIMIT_OUT','LEAD_PLUS_IN'),
 ('W03','LEAD_PLUS_OUT','CONNECTOR_PLUS'),
 ('W04','CONNECTOR_MINUS','RETURN_IN'),
 ('W05','RETURN_OUT','Battery_negative'),
 ('W06','SENSE_PLUS','CONNECTOR_PLUS'),
 ('W07','SENSE_MINUS','CONNECTOR_MINUS')
]

def shell(m,t,title,sub='',w=3.04,d=1.90,h=1.18):
 m.base(t,w=w,d=d,bodyh=h,fronttext=title,status='')
 if sub:
  m.text(t+'_ModuleSubline',sub,.103,0,.91,-d/2-.057,'cyan',maxwidth=w-.47)
 # upper armor fasteners
 for x in (-w/2+.17,w/2-.17):
  for z in (-d/2+.17,d/2-.17):
   m.cyl(t+f'_CounterSunkHead_{x:.2f}_{z:.2f}',.064,.034,(x,.34+h+.098,z),'chrome',sections=18)
 m.box(t+'_MicroLightbar',(w*.36,.027,.037),(0,.32,-d/2-.071),'cyan',group='ModuleLight_VISUAL')

def sockets(m,t,ids,labels=('IN','OUT'),colors=('red','blue'),w=3.04,d=1.90,record=True):
 # Front-facing camera: left = negative x. All art anchors describe the black recess centroid.
 z=-d/2-.097
 for i,(pid,label,col) in enumerate(zip(ids,labels,colors)):
  x=(.77,-.77)[i]
  m.cyl(t+f'_{pid}_ChromeRing',.174,.052,(x,.49,z),'chrome',axis='z',sections=40)
  m.cyl(t+f'_{pid}_InsulatedJack',.139,.064,(x,.49,z-.037),col,axis='z',sections=36)
  m.cyl(t+f'_{pid}_Recess',.090,.066,(x,.49,z-.079),'void',axis='z',sections=32)
  m.cyl(t+f'_{pid}_SpringContact',.028,.021,(x,.49,z-.107),'gold',axis='z',sections=18)
  m.torus(t+f'_{pid}_Halo',.140,.013,(x,.49,z-.067),col,axis='z',segments=40,tube_segs=7)
  m.text(t+f'_{pid}_Label',label,.139,x,.78,z-.123,'white',maxwidth=.92)
  if record:m.anchors[pid]=[round(x,4),.49,round(z-.116,4)]

def screwtop(m,t,w=3.04,d=1.90, yy=1.55):
 for x in (-w*.34,w*.34):
  for z in (-d*.25,d*.25):m.cyl(t+f'_MachinedM5_{x:.2f}_{z:.2f}',.077,.045,(x,yy,z),'chrome',sections=22)

def acrylic_cage(m,t,xw=2.42,zw=1.30,y0=1.60,h=.76):
 for x in (-xw/2,xw/2):
  m.box(t+f'_CrystalSideWall_{x:.1f}',(.027,h,zw),(x,y0+h/2,.04),'glass_soft')
  for z in (-zw/2+.04,zw/2+.04):
   m.rod(t+f'_CageUpright_{x:.1f}_{z:.1f}',(x,y0,z+.04),(x,y0+h,z+.04),.025,'chrome',sections=10)
 for z in (-zw/2+.04,zw/2+.04):m.rod(t+f'_ClearRailing_{z:.2f}',(-xw/2,y0+h,z+.04),(xw/2,y0+h,z+.04),.031,'cyan',sections=12)

def resistor_axial(m,t,kind='100'):
 yy=2.0
 m.bevel(t+'_AxialResistor_CeramicCradle',(2.30,.105,1.01),(0,1.67,.07),'nickel',.05)
 m.cyl(t+'_PrecisionResistorBody',.220,1.37,(0,yy,.06),'resistor',axis='x',sections=40)
 for sign in (-1,1):
  m.cyl(t+f'_ResistorCap_{sign}',.231,.061,(sign*.69,yy,.06),'gold',axis='x',sections=32)
  m.rod(t+f'_NickelPigtail_{sign}',(sign*.71,yy,.06),(sign*1.17,yy,.06),.039,'nickel')
  m.cyl(t+f'_InsulatorStud_{sign}',.098,.23,(sign*1.18,1.78,.06),'gold',sections=20)
 bands=['resistor','void','resistor','gold'] if kind=='100' else ['red','red','red','gold']
 # brown black brown gold for 100 ohm
 bands=['gilt','void','gilt','gold'] if kind=='100' else bands
 for i,(x,col) in enumerate(zip((-.40,-.19,.11,.44),bands)):
  m.torus(t+f'_ResistorBand_{i}',.224,.031,(x,yy,.06),col,axis='x',segments=42,tube_segs=8)
 acrylic_cage(m,t)

def supply():
 m=Model('01_5V_Regulated_Supply');t='L37_SUPPLY'
 shell(m,t,'','',w=3.25,h=1.50)
 m.text(t+'_FrontUnitLabel','5 V SUPPLY',.169,0,1.19,-.992,'white',maxwidth=1.60)
 sockets(m,t,PORTS[m.key],('+','-'),('red','blue'))
 m.bevel(t+'_PowerDisplayChrome',(1.46,.37,.052),(0,1.55,-1.000),'chrome',.043)
 m.bevel(t+'_OLED_Black',(1.40,.31,.045),(0,1.55,-1.040),'screen',.043)
 m.text(t+'_DisplayDigits','5.00 V',.255,0,1.55,-1.072,'lcdgreen',maxwidth=1.22)
 for i in range(14):m.box(t+f'_Vent_{i:02d}',(.060,.02,.37),(-1.21+i*.185,1.962,.18),'void')
 m.box(t+'_GreenPowerLight_VISUAL',(.84,.039,.044),(0,2.02,-.40),'green',group='ReadyLight_VISUAL')
 return m

def limiter():
 m=Model('02_100Ohm_Current_Limiter');t='L37_LIMITER'
 shell(m,t,'100 Ohm LIMITER','CURRENT LIMIT / 100 Ohm')
 sockets(m,t,PORTS[m.key],('LIMIT IN','LIMIT OUT'),('red','amber'))
 resistor_axial(m,t,'100')
 return m

def force_lead():
 m=Model('03_Force_Lead_Positive');t='L37_FORCE_RED'
 shell(m,t,'FORCE LEAD +','CURRENT PATH / RED')
 sockets(m,t,PORTS[m.key],('LEAD + IN','LEAD + OUT'),('red','red'))
 m.bevel(t+'_HeavyCableSaddle',(2.30,.12,1.08),(0,1.62,.04),'steel',.05)
 # Heavy braided cable loop runs over dark polymer insulation
 for i in range(36):
  a=i/35; x=-1.03+2.06*a; y=1.98+.29*math.sin(math.pi*a); z=.02+.18*math.sin(math.pi*a)
  if i<35:
   b=(i+1)/35;q=(-1.03+2.06*b,1.98+.29*math.sin(math.pi*b),.02+.18*math.sin(math.pi*b))
   m.rod(t+f'_HeavyRedCable_{i:02d}',(x,y,z),q,.130,'lead_red',sections=12,group='RedCable_VISUAL')
   if i%3==0:
    m.rod(t+f'_SilverBraidHighlight_{i:02d}',(x,y+.09,z-.034),q,.019,'chrome',sections=8,group='RedCable_VISUAL')
 for k in (-1,1):
  m.cyl(t+f'_MachinedContactLug_{k}',.13,.23,(k*1.04,1.84,.02),'gold',sections=24)
  m.cyl(t+f'_CrimpInsulator_{k}',.18,.19,(k*.9,2.00,.02),'charcoal',axis='x',sections=28)
 acrylic_cage(m,t,xw=2.54,h=.83)
 return m

def connector(key='04_5Ohm_Connector_Sample',fault=False):
 m=Model(key);t='L37_CONNECTOR_FAULT' if fault else 'L37_CONNECTOR'
 shell(m,t,'CONNECTOR SAMPLE','12 Ohm FAULT' if fault else '5 Ohm CONTACT',w=3.27,h=1.19)
 sockets(m,t,PORTS['04_5Ohm_Connector_Sample'],('CONNECTOR +','CONNECTOR -'),('amber','amber'),record=not fault)
 m.bevel(t+'_TestFixtureSocket',(2.74,.145,1.20),(0,1.66,.06),'steel',.07)
 # physically visible golden mating comb: pins across the disconnect joint
 for k in range(13):
  x=-.83+.139*k
  c='fault' if fault and k in (5,6,7) else 'gold'
  m.rod(t+f'_MatingPin_{k:02d}',(x,1.86,-.34),(x,1.86,.46),.055,c,sections=11,group='ContactPins_VISUAL')
  m.cyl(t+f'_ContactFoot_{k:02d}',.080,.086,(x,1.81,-.40),c,sections=13)
 m.bevel(t+'_TwoPieceConnectorBody_L',(1.03,.28,.76),(-.93,1.85,.07),'charcoal',.05)
 m.bevel(t+'_TwoPieceConnectorBody_R',(1.03,.28,.76),(.93,1.85,.07),'charcoal',.05)
 if fault:
  m.box(t+'_OxidizedFaultContactVisual_ANIMATE',(.14,.08,.82),(.10,1.95,.065),'fault',group='ConnectorFault_VISUAL')
  m.box(t+'_WarningStrip_VISUAL',(.60,.027,.05),(0,.319,-1.042),'red',group='ConnectorFault_VISUAL')
 else:
  m.box(t+'_ContactHealthyGreen_VISUAL',(.60,.027,.05),(0,.319,-1.042),'green',group='ContactHealthy_VISUAL')
 # separate, unconnected four-wire clips on top of actual contact points
 for k in (-1,1):
  x=k*.76
  m.cyl(t+f'_KelvinSenseTip_{k}',.120,.075,(x,2.06,.29),'emerald',sections=22,group='KelvinProbeTip_VISUAL')
  m.rod(t+f'_KelvinSenseNeedle_{k}',(x,2.06,.29),(x,1.96,-.12),.040,'chrome',sections=12,group='KelvinProbeTip_VISUAL')
 acrylic_cage(m,t,xw=2.64,zw=1.41,h=.72)
 return m

def force_return(key='05_Force_Return_Negative',bad=False):
 m=Model(key);t='L37_FORCE_BLUE_BAD' if bad else 'L37_FORCE_BLUE'
 shell(m,t,'FORCE RETURN','10 Ohm LEAD FAULT' if bad else 'RETURN / BLUE')
 sockets(m,t,PORTS['05_Force_Return_Negative'],('RETURN IN','RETURN OUT'),('blue','blue'),record=not bad)
 m.bevel(t+'_CrimpBed',(2.30,.12,1.08),(0,1.62,.04),'steel',.055)
 for i in range(35):
  a=i/35; b=(i+1)/35
  p=lambda k:(-1.04+2.08*k,1.97+.26*math.sin(math.pi*k),.02-.16*math.sin(math.pi*k))
  m.rod(t+f'_BlueHighCurrentLead_{i:02d}',p(a),p(b),.120,'lead_blue',sections=12,group='BlueCable_VISUAL')
  if i%4==0:m.rod(t+f'_BraidNickelStrand_{i:02d}',tuple(np.array(p(a))+[0,.085,-.025]),tuple(np.array(p(b))+[0,.085,-.025]),.016,'chrome',sections=7)
 for k in (-1,1):m.cyl(t+f'_TerminalClamp_{k}',.16,.18,(k*1.04,1.78,.05),'gold',sections=28)
 if bad:
  for k in range(4):m.torus(t+f'_HeatingCollar_Fault_{k}',.125,.027,(-.18+k*.1,2.23,.0),'fault',axis='x',segments=29,tube_segs=7,group='BadLeadFault_VISUAL')
  m.box(t+'_WarningBanner_VISUAL',(.7,.027,.043),(0,.311,-1.04),'red',group='BadLeadFault_VISUAL')
 acrylic_cage(m,t,xw=2.52,h=.75)
 return m

def sense_meter():
 m=Model('06_Kelvin_Sense_Meter');t='L37_KELVIN_METER'
 shell(m,t,'','',w=3.35,d=2.02,h=1.48)
 m.text(t+'_FrontUnitLabel','KELVIN SENSE',.131,0,.993,-1.058,'white',maxwidth=1.72)
 sockets(m,t,PORTS[m.key],('SENSE +','SENSE -'),('green','green'),w=3.35,d=2.02)
 # Large inset electronic display; baseline reading is a preview, not a live electrical measurement
 m.bevel(t+'_DisplayChrome',(2.39,.62,.07),(0,1.47,-1.069),'chrome',.06)
 m.bevel(t+'_GlassLCD',(2.27,.52,.045),(0,1.47,-1.113),'screen',.046)
 m.text(t+'_LCD_Title','R KELVIN',.139,0,1.62,-1.151,'cyan',maxwidth=1.60)
 m.text(t+'_LCD_Digits_5_00_Ohm_STATIC','5.00 Ohm',.267,0,1.38,-1.156,'lcdgreen',maxwidth=1.94)
 for i,x in enumerate((-.73,-.17,.39,.90)):
  m.cyl(t+f'_TactileModeKey_{i}',.095,.042,(x,1.96,-.45),'gold' if i==0 else 'steel',sections=22,group='Buttons_VISUAL')
 for i in range(8):m.box(t+f'_ThermalVents_{i}',(.085,.019,.43),(-1.24+i*.35,1.88,.51),'void')
 m.torus(t+'_DigitalMeasurementHalo',.42,.028,(0,2.10,.14),'cyan',axis='y',segments=60,tube_segs=10,group='MeterStatus_VISUAL')
 m.cyl(t+'_ScopeRingCore',.29,.035,(0,2.11,.14),'void',sections=44,group='MeterStatus_VISUAL')
 return m

def board():
 m=Model('00_Showcase_Display_Board');t='L37_SHOWCASE'
 m.bevel(t+'_MatteBlack_Base',(22.1,.18,9.4),(0,.12,0),'rubber',.14)
 m.bevel(t+'_BrushedSteelFrame',(21.95,.14,9.23),(0,.26,0),'steel',.13)
 m.bevel(t+'_MagneticPaddedWorkSurface',(21.77,.08,9.04),(0,.35,0),'graphite',.07)
 for x in (-10.76,10.76):m.box(t+f'_BlueRimX_{x}',(.048,.037,8.74),(x,.41,0),'cyan')
 for z in (-4.45,4.45):m.box(t+f'_BlueRimZ_{z}',(21.48,.037,.048),(0,.41,z),'cyan')
 dots=[]
 for x in np.linspace(-10.30,10.30,46):
  for z in np.linspace(-4.22,4.22,18):
   b=trimesh.creation.cylinder(radius=.011,height=.004,sections=6)
   b.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]));b.apply_translation((float(x),.396,float(z)));dots.append(b)
 m.add(t+'_MagneticToolingHoleArray',trimesh.util.concatenate(dots),'mid_steel')
 return m

BUILDERS=[supply,limiter,force_lead,connector,force_return,sense_meter,
 lambda:force_return('07_OPTIONAL_Faulty_Force_Return',True),lambda:connector('08_OPTIONAL_Damaged_Connector_12Ohm',True)]
STAGING={
 '01_5V_Regulated_Supply':(7.22,0,2.0),
 '02_100Ohm_Current_Limiter':(2.38,0,2.0),
 '06_Kelvin_Sense_Meter':(-5.26,0,2.0),
 '03_Force_Lead_Positive':(7.22,0,-2.0),
 '04_5Ohm_Connector_Sample':(2.38,0,-2.0),
 '05_Force_Return_Negative':(-5.26,0,-2.0),
 '00_Showcase_Display_Board':(0,0,0)
}

def build():
 mods=[fn() for fn in BUILDERS]; base=mods[:6]
 ids=[pid for mod in base for pid in mod.anchors]
 assert len(ids)==len(set(ids))==12,ids
 assert len(WIRES)==7 and all(a in ids and b in ids for _,a,b in WIRES)
 manifest={}
 for mod in mods:
  pf=MODELS/(mod.key+'.fbx');pg=MODELS/(mod.key+'.glb')
  export_fbx(pf,[mod]);export_glb(pg,[mod])
  manifest[mod.key]={
   'fbx':pf.name,'glb':pg.name,'triangles':int(sum(len(p.mesh.faces) for p in mod.parts)),
   'mesh_objects':len(mod.parts),'terminal_anchors':mod.anchors,
   'named_groups':list(dict.fromkeys(p.group for p in mod.parts if p.group!='Static'))}
  print('EXPORTED',mod.key,manifest[mod.key]['triangles'], 'tris',len(mod.parts),'meshes',flush=True)
 assembled=[board()]+base
 path=MODELS/'Level37_Complete_ArtKit_Showcase.fbx';pg=MODELS/'Level37_Complete_ArtKit_Showcase.glb'
 export_fbx(path,assembled,positions=STAGING);export_glb(pg,assembled,positions=STAGING)
 manifest['Level37_Complete_ArtKit_Showcase']={'fbx':path.name,'glb':pg.name,
    'triangles':int(sum(len(p.mesh.faces) for m in assembled for p in m.parts)),
    'mesh_objects':sum(len(m.parts) for m in assembled)}
 manifest_doc={'level':37,'title':'Kelvin Test','individual_model_count':8,'core_electrical_models':6,
     'optional_fault_variant_models':2,'socket_count':12,'wire_count':7,'coordinate_system':'Y up, negative Z front, art-unit scale',
     'positions_in_showcase':STAGING,
     'wiring':[{'wire':n,'from':a,'to':b} for n,a,b in WIRES], 'models':manifest,
     'important':'3D model assets only. Model anchors do not register SparkTerminals. Use real electrical components and Unity runtime measurement.'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest_doc,indent=2),encoding='utf8')
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf8') as f:
  c=csv.writer(f);c.writerow(['Wire','From','To']);c.writerows(WIRES)
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf8') as f:
  c=csv.writer(f);c.writerow(['FBX filename','Suggested runtime terminal ID','Local X','Local Y','Local Z','GameObject name'])
  for m in base:
   for k,p in m.anchors.items():c.writerow([m.key+'.fbx',k,*p,k])
 print('SUCCESS: 8 FBX + 8 GLB + assembled FBX/GLB, 12 anchors / 7 wires',flush=True)
 return mods

if __name__=='__main__':build()
