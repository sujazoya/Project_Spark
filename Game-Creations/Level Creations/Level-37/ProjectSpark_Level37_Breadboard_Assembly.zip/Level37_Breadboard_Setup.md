# Level 37 | Kelvin Test

The FORCE loop sends test current through the fixture. The two-wire reading includes both leads and the connector. The Kelvin SENSE pair measures across the connector alone, so the two readings reveal where the resistance changed.

## Wire the FORCE loop first

| Wire | From | To |
| --- | --- | --- |
| W01 | Supply + | 100 Ω Limiter IN |
| W02 | 100 Ω Limiter OUT | Force Lead + IN |
| W03 | Force Lead + OUT | Connector + |
| W04 | Connector − | Force Return IN |
| W05 | Force Return OUT | Supply − |

Press **READ LOOP** to record **40.0 mA** and **25.00 Ω**. Then add the cyan SENSE wires to the connector sockets already used by W03 and W04.

| Wire | From | To |
| --- | --- | --- |
| W06 | Kelvin Sense + | Connector + |
| W07 | Kelvin Sense − | Connector − |

## Diagnose and repair

| Progress | Action | Two-wire | Kelvin |
| --- | --- | --- | --- |
| 1/6 | Wire the FORCE loop and press **READ LOOP**. | 25.00 Ω | — |
| 2/6 | Add both SENSE wires and press **READ KELVIN**. | 25.00 Ω | 5.00 Ω |
| 3/6 | Press **LOAD CASE** and choose **LEAD FAULT**. | 35.00 Ω | 5.00 Ω |
| 4/6 | Press **LOAD CASE** and choose **CONNECTOR FAULT**. | 42.00 Ω | 12.00 Ω |
| 5/6 | Press **FIT CONNECTOR**. The faulty lead remains. | 35.00 Ω | 5.00 Ω |
| 6/6 | Press **REPLACE LEAD** to restore the baseline. | 25.00 Ω | 5.00 Ω |

If the Kelvin reading stays blank, check + to + and − to −. Reversing the SENSE wires leaves the FORCE objective recorded and blocks **READ KELVIN** until the polarity is corrected.

## Install in another Project Spark checkout

Merge the included `Assets` folder into your Project Spark project and keep the `.meta` files. Use the existing Level 37 campaign, layout catalog and teaching drawing entries. If the MainMenu breadboard geometry changes, open MainMenu in Edit Mode and run **Tools → Project Spark → Level 37 → Fit Breadboard Assembly**.
