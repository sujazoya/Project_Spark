import os,math,csv,json,time,struct,zlib,zipfile,random
from pathlib import Path
from collections import Counter
import numpy as np
import trimesh
from PIL import Image,ImageDraw,ImageFont
ROOT=Path('/mnt/data/ProjectSpark_Level70_HD_AAA')
MD=ROOT/'Models';GD=ROOT/'GLB';PD=ROOT/'Previews';ED=ROOT/'Unity_Optional';SRC=ROOT/'Source'
for d in (MD,GD,PD,ED,SRC):d.mkdir(parents=True,exist_ok=True)
names=['IndustrialCleanroomBase', 'TransparentSemiconductorCleanroom', 'TransparentCleanroomAirlock', 'IndustrialCorridorFacade', 'SemiconductorInspectionBench', 'SiliconWaferCarrierRack', 'AutomatedWaferTransferRobot', 'IndustrialAirHandlingUnit', 'AirIntakePrefilter', 'ChilledWaterCoolingCoil', 'ElectricReheatCoil', 'PrecisionAirHumidifier', 'CondensateDrainAssembly', 'SupplyAirBlowerMotor', 'ReturnAirBlowerMotor', 'ExhaustAirBlowerMotor', 'CeilingFanFilterUnitA', 'CeilingFanFilterUnitB', 'ReplaceableHEPACartridgeA', 'ReplaceableHEPACartridgeB', 'LowLevelReturnAirGrille', 'TransparentSupplyDuctNetwork', 'TransparentReturnDuctNetwork', 'FreshAirMixingDamper', 'CleanroomSupplyDamperA', 'AirlockSupplyDamperB', 'MotorizedPressureReliefDamper', 'CleanroomDifferentialPressureSensor', 'AirlockDifferentialPressureSensor', 'AirVelocityMeasurementProbe', 'CleanroomParticleCounter', 'AirlockParticleCounter', 'CleanroomTemperatureHumiditySensor', 'AirlockTemperatureHumiditySensor', 'AirDewPointSensor', 'FilterDifferentialPressureTransmitter', 'IndustrialAirShowerModule', 'AirlockInnerSafetyDoor', 'AirlockOuterSafetyDoor', 'HEPASealFailureSimulator', 'EmergencyStopAndDoorSafetyStation', 'AirQualityDisturbanceSimulator', 'EnvironmentalControlPLCRack', 'EnvironmentalDigitalIOModule', 'CascadeAirPressurePIDController', 'PsychrometricControlModule', 'HolographicCleanroomSCADAMonitor', 'Regulated5VControlSupply']
P={'navy':(14,32,52,255),'steel':(66,101,126,255),'light':(139,177,195,255),'silver':(181,199,208,255),'dark':(27,50,69,255),'black':(13,21,30,255),'cyan':(37,211,246,255),'blue':(20,112,218,255),'ice':(133,224,245,255),'copper':(220,120,52,255),'amber':(248,162,45,255),'red':(226,63,70,255),'green':(47,219,139,255),'white':(220,238,248,255),'glass':(93,178,212,135),'frost':(205,235,247,255),'rubber':(34,38,42,255),'gold':(224,176,68,255)}
M={}
def addmesh(k,m,c):
 if m is None or len(m.faces)==0:return
 if k not in M:M[k]=[]
 m.visual.vertex_colors=np.tile(P[c],(len(m.vertices),1))
 M[k].append((m,c))
def box(k,xyz,ext,c,rot=None):
 m=trimesh.creation.box(extents=ext)
 if rot is not None:m.apply_transform(rot)
 m.apply_translation(xyz);addmesh(k,m,c)
def cyl(k,center,r,length,c,axis='z',sec=16):
 m=trimesh.creation.cylinder(radius=r,height=length,sections=sec)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 m.apply_translation(center);addmesh(k,m,c)
def pipe(k,pts,r=.045,c='copper',sec=10):
 for p,q in zip(pts[:-1],pts[1:]):
  p=np.asarray(p,float);q=np.asarray(q,float);v=q-p;L=np.linalg.norm(v)
  if L<1e-5:continue
  m=trimesh.creation.cylinder(radius=r,height=L,sections=sec);tf=trimesh.geometry.align_vectors([0,0,1],v/L);m.apply_transform(tf);m.apply_translation((p+q)/2);addmesh(k,m,c)
 for p in pts[1:-1]:
  m=trimesh.creation.icosphere(subdivisions=1,radius=r);m.apply_translation(p);addmesh(k,m,c)
def ring(k,center,r,inner,depth,axis='z',c='silver',sec=20):
 # ring as thin tube / annulus mesh
 verts=[];faces=[]
 for z in (-depth/2,depth/2):
  for rad in (r,inner):
   for i in range(sec):
    a=2*math.pi*i/sec;verts.append((rad*math.cos(a),rad*math.sin(a),z))
 for layer in range(4):
  for i in range(sec):
   j=(i+1)%sec; layer2={0:2,1:3,2:3,3:0}[layer]
   a=layer*sec+i;b=layer*sec+j;d=layer2*sec+i;e=layer2*sec+j
   faces.extend(((a,b,d),(b,e,d)))
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 m.apply_translation(center);addmesh(k,m,c)
def screen(k,xyz,w=.58,h=.32,c='blue'):
 box(k,xyz,(w,h,.065),'black');box(k,(xyz[0],xyz[1],xyz[2]+.039),(w*.88,h*.80,.01),c)
 for i in range(5): box(k,(xyz[0]-w*.32+i*w*.16,xyz[1]-h*.20+((i*7)%4)*h*.11,xyz[2]+.05),(.035,.017,.012),'cyan')
def knob(k,x,y,z,c='cyan'):
 cyl(k,(x,y,z),.045,.045,'silver');cyl(k,(x,y,z+.03),.025,.025,c)
def panel(k,center,ex=(.70,.60,.45),label='generic'):
 x,y,z=center;box(k,center,ex,'steel');box(k,(x,y,z+ex[2]/2+.01),(.84*ex[0],.77*ex[1],.015),'dark');screen(k,(x,y+.09,z+ex[2]/2+.05),ex[0]*.60,ex[1]*.34)
 for j in range(3):knob(k,x-.22+j*.21,y-ex[1]*.26,z+ex[2]/2+.035,('green','amber','red')[j])
 for j in range(5):box(k,(x-ex[0]*.36+j*ex[0]*.18,y+ex[1]*.34,z),(.05,.09,.07),'silver')
def fan(k,center,r=.38,axis='z'):
 x,y,z=center
 cyl(k,center,r*.75,.12,'dark',axis,24);ring(k,center,r,r*.88,.10,axis,'silver',24)
 # radial blades in plane XY for z; xz for y
 for i in range(7):
  a=i*2*math.pi/7
  if axis=='z':p=(x+.46*r*math.cos(a),y+.46*r*math.sin(a),z+.08);ang=a
  else:p=(x+.46*r*math.cos(a),y,z+.46*r*math.sin(a));ang=a
  m=trimesh.creation.box(extents=(r*.61,r*.16,.035))
  if axis=='z':m.apply_transform(trimesh.transformations.rotation_matrix(ang,[0,0,1]))
  else:m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]));m.apply_transform(trimesh.transformations.rotation_matrix(ang,[0,1,0]))
  m.apply_translation(p);addmesh(k,m,'light')
 cyl(k,center,r*.14,.18,'steel',axis)
def motor(k,xyz,scale=1):
 x,y,z=xyz
 cyl(k,(x,y,z),.46*scale,1.3*scale,'blue','x',24)
 for t in np.linspace(-.53,.53,11):ring(k,(x+t*scale,y,z),.48*scale,.455*scale,.045*scale,'x','steel',20)
 cyl(k,(x+.77*scale,y,z),.105*scale,.35*scale,'silver','x');cyl(k,(x-.76*scale,y,z),.38*scale,.09*scale,'dark','x')
 box(k,(x,y-.46*scale,z),(1.25*scale,.18*scale,.66*scale),'steel')
 box(k,(x,y+.50*scale,z),(.46*scale,.19*scale,.44*scale),'dark')
def compressor(k):
 x,y,z=(.25,1.27,.55)
 box(k,(x,y-.56,z),(3.0,.20,1.60),'steel')
 motor(k,(-.55,y,z),1.0)
 cyl(k,(1.10,y,z),.59,1.30,'blue','x',24)
 for t in np.linspace(.58,1.56,8):ring(k,(t,y,z),.61,.58,.075,'x','steel',24)
 cyl(k,(1.82,y,z),.40,.25,'dark','x')
 cyl(k,(1.2,y+.67,z),.20,.9,'silver','y')
 pipe(k,[(1.2,y+.74,z),(1.2,2.36,z),(.4,2.36,z)],.085,'copper')
 for i in range(5):box(k,(1.18+i*.09,1.26,z+.63),(.038,.17,.035),'amber')
def cooling_chamber(k,cx,cy,cz= -1.5,hot=False):
 # roomy 2.5x2x1.7 internal, glass front toward +z
 x,y,z=cx,cy,cz
 box(k,(x,y-.95,z),(2.65,.12,2.0),'steel')
 for dx in (-1.28,1.28):
  for dz in (-.96,.96):box(k,(x+dx,y,z+dz),(.09,1.95,.08),'silver')
 for yy in (-.89,.93):
  for dz in (-.96,.96):box(k,(x,y+yy,z+dz),(2.55,.07,.08),'silver')
 for yy in (-.89,.93):
  for dx in (-1.28,1.28):box(k,(x+dx,y+yy,z),(.08,.07,1.9),'silver')
 box(k,(x,y,z-.94),(2.4,1.74,.028),'ice')
 box(k,(x,y,z+.96),(2.45,1.7,.018),'glass')
 box(k,(x,y+.97,z),(2.68,.1,2.04),'steel')
 for xx in (-.76,.76):fan(k,(x+xx,y+.48,z-.76),.34)
 for i in range(3):
  box(k,(x,y-.70+i*.51,z-.20),(2.0,.046,.80),'silver')
  for j in range(4):box(k,(x-.75+j*.50,y-.54+i*.51,z-.15),(.33,.24,.32),'white' if not hot else 'ice')
 for i in range(2):box(k,(x-1.16+i*2.32,y,z+.99),(.07,1.72,.04),'steel')
 for i in range(5):box(k,(x-1.1+i*.54,y-.82,z+1.04),(.35,.035,.035),'cyan')

# LEVEL 70 custom modular cleanroom machinery: authored physical assembly in meters.
# The same scene-space coordinates are used for every individual model.

def rbox(k,c,e,col='steel',radius=.04):
    x,y,z=c; X,Y,Z=e
    box(k,c,e,col)
    # thin silver corner/edge strips give each cabinet mechanical definition
    for yy in (-Y/2+.035,Y/2-.035):
        for zz in (-Z/2+.035,Z/2-.035): box(k,(x,y+yy,z+zz),(X+.018,.025,.025),'silver')
    for xx in (-X/2+.035,X/2-.035):
        for zz in (-Z/2+.035,Z/2-.035): box(k,(x+xx,y,z+zz),(.025,Y+.018,.025),'silver')

def frame(k,center,ext,beam=.075,glass=True,glass_front=True):
    x,y,z=center;dx,dy,dz=ext
    for ax in (-1,1):
        for az in (-1,1):box(k,(x+ax*(dx-beam)/2,y,z+az*(dz-beam)/2),(beam,dy,beam),'silver')
    for ay in (-1,1):
        for az in (-1,1):box(k,(x,y+ay*(dy-beam)/2,z+az*(dz-beam)/2),(dx,beam,beam),'silver')
        for ax in (-1,1):box(k,(x+ax*(dx-beam)/2,y+ay*(dy-beam)/2,z),(beam,beam,dz),'silver')
    if glass:
        box(k,(x,y,z-dz/2+.04),(dx-.15,dy-.15,.021),'glass')
        if glass_front:box(k,(x,y,z+dz/2-.04),(dx-.15,dy-.15,.021),'glass')
        for ax in (-1,1):box(k,(x+ax*(dx/2-.055),y,z),(.021,dy-.15,dz-.15),'glass')

def grille(k,center,ext,axis='z',n=18):
    x,y,z=center;w,h,d=ext
    box(k,center,ext,'dark')
    for i in range(n):
        yy=y-h*.44+(i+.5)*h*.88/n
        box(k,(x,yy,z+d/2+.014),(w*.91,h*.45/n,.028),'silver')
    for xx in (x-w*.47,x+w*.47):box(k,(xx,y,z+d/2+.028),(.035,h,.035),'light')

def duct(k,pts,r=.13,cc='steel'):
    pipe(k,pts,r,cc,16)
    # couplings/flanges at endpoints
    for p in [pts[0],pts[-1]]:cyl(k,p,r*1.32,r*.23,'silver',axis='y',sec=18)

def compact_screen(k,center,w=.62,h=.37,c='blue'):
    box(k,center,(w,h,.075),'dark')
    box(k,(center[0],center[1],center[2]+.042),(w*.88,h*.8,.012),c)
    for j in range(5):box(k,(center[0]-w*.33+j*w*.17,center[1]-.08+((j*3)%5)*.035,center[2]+.055),(w*.07,.015,.012),'cyan')

def multisensor(k,x,y,z,kind='pressure',size=.26):
    rbox(k,(x,y,z),(size*1.8,size*1.3,size*.64),'steel')
    compact_screen(k,(x,y,z+size*.36),size*1.35,size*.75,'cyan' if kind!='particle' else 'green')
    for j,c in enumerate(('green','amber','red')):knob(k,x-size*.55+j*size*.55,y-size*.45,z+size*.38,c)
    cyl(k,(x,y-size*.74,z),size*.16,size*.46,'silver','y')
    duct(k,[(x-.12,y-size*.80,z),(x-.22,y-size*1.2,z)],.016,'copper')

def filter_pleats(k,x,y,z,w,h,depth=.16,n=29,filtercol='white'):
    box(k,(x,y,z),(w+.1,h+.1,depth+.06),'steel')
    box(k,(x,y,z+depth*.51),(w,h,.036),'dark')
    for i in range(n):
        px=x-w*.485+(i+.5)*(w*.97/n)
        box(k,(px,y,z+depth*.56+.026),(w*.66/n,h*.89,.028),filtercol if i%4 else 'light')
    for xx in (x-w*.49,x+w*.49):box(k,(xx,y,z+depth*.60+.04),(.025,h,.038),'silver')

def coil(k,x,y,z,w,h,heat=False):
    # dense fin pack + sinuous metal capillaries + perimeter frame
    box(k,(x,y,z),(w+.10,h+.13,.16),'dark')
    for i in range(43):
        px=x-w*.48+i*w*.96/42
        box(k,(px,y,z+.095),(.017,h*.9,.055),'copper' if heat and i%5==0 else 'light')
    for j in range(8):
        yy=y-h*.43+j*h*.86/7
        pipe(k,[(x-w*.52,yy,z+.16),(x+w*.52,yy,z+.16)],.023,'copper' if heat else 'blue',12)
    for px in (x-w*.55,x+w*.55):box(k,(px,y,z+.10),(.063,h+.14,.083),'steel')
    for py in (y-h*.55,y+h*.55):box(k,(x,py,z+.10),(w+.13,.052,.084),'steel')

def airfan(k,center,r=.43,axis='z',c='blue'):
    x,y,z=center
    fan(k,center,r,axis)
    for ax in (-1,1):
        for ay in (-1,1):box(k,(x+ax*r*.83,y+ay*r*.83,z),(.055,.055,.13),'silver')
    # protective fan grille with straight wire bars
    for n in range(-4,5):
        if axis=='z':box(k,(x+n*r/5,y,z+.09),(.013,1.79*r,.018),'light')

def concrete(k,center,e):
    box(k,center,e,'steel')
    for i in range(5):box(k,(center[0]-e[0]/2+.2+i*(e[0]-.4)/4,center[1]+e[1]/2+.014,center[2]),(.075,.028,e[2]*.90),'light')

# --------------------------------------------------------------
# 00 Main platform: grounded 15.6 x 8.4-m modular workbench.
k=names[0]
box(k,(0,-.31,0),(15.60,.54,8.35),'navy')
box(k,(0,-.015,0),(15.38,.060,8.10),'steel')
for zz in (-3.96,3.96):
    box(k,(0,.035,zz),(15.20,.045,.085),'cyan')
for xx in (-7.53,7.53):box(k,(xx,.035,0),(.075,.045,8.04),'cyan')
for xx in np.arange(-7.1,7.2,.51):
    box(k,(xx,-.055,4.02),(.19,.016,.047),'amber' if int(xx*10)%4==0 else 'cyan')
for xx in (-7.25,7.25):
    for zz in (-3.52,3.52):cyl(k,(xx,-.60,zz),.20,.16,'dark','y',20)
for xx in np.arange(-6.75,6.85,1.5):
    for zz in (-3.7,3.7):box(k,(xx,-.012,zz),(.14,.014,.075),'black')
# grated service/walkway area
for i in range(34):box(k,(-.3,-.015,-3.55+i*.20),(6.40,.014,.03),'dark')

# 01 Primary semiconductor cleanroom: large front glass wall and illuminated ceiling.
k=names[1]; frame(k,(-.15,1.95,-.88),(6.35,3.50,4.32),.095,glass=True)
box(k,(-.15,.21,-.88),(6.22,.11,4.22),'white')
box(k,(-.15,3.69,-.88),(6.25,.12,4.23),'steel')
for i in range(25):
    xx=-2.9+(i%5)*1.36;zz=-2.6+(i//5)*.82
    box(k,(xx,3.59,zz),(1.22,.018,.70),'white')
    box(k,(xx,3.54,zz),(1.05,.010,.075),'cyan')
for i in range(24):
    xx=-2.8+(i%6)*1.06;zz=-2.45+(i//6)*1.03
    box(k,(xx,.30,zz),(.94,.018,.93),'silver')
    for j in range(5):box(k,(xx-.36+j*.18,.313,zz),(.026,.006,.85),'dark')
for xx in (-2.95,2.64):
    for zz in (-2.65,-1.53,-.44,.75):
        box(k,(xx,1.82,zz),(.045,2.80,.042),'light')
for yy in (.90,2.03,3.10):
    box(k,(-.15,yy,1.31),(6.0,.035,.04),'silver')
box(k,(-.1,3.71,1.29),(5.8,.08,.07),'cyan')

# 02 Airlock module: separate glass chamber and door vestibule.
k=names[2]; frame(k,(4.89,1.76,-.88),(2.77,3.12,4.30),.083,glass=True)
box(k,(4.89,.215,-.88),(2.65,.085,4.16),'silver')
for x in (3.57,6.20):
    for z in (-2.45,-1.35,-.26,.84):box(k,(x,1.75,z),(.034,2.66,.047),'white')
for i in range(18):box(k,(3.72+i*.136,.30,.05),(.078,.013,1.45),'dark')
for yy in (3.13,3.19):box(k,(4.89,yy,1.16),(2.57,.027,.06),'cyan')

# 03 corridor façade and air return transition.
k=names[3]
box(k,(6.78,1.63,-1.66),(.16,3.0,3.95),'silver')
for i in range(4):
    box(k,(6.82,.8+i*.65,-1.7),(.07,.47,3.44),'dark')
    box(k,(6.87,.8+i*.65,-1.7),(.01,.35,3.1),'glass')
for z in np.arange(-3.45,.21,.7):box(k,(6.87,3.08,z),(.04,.085,.24),'cyan')

# 04 wafer inspection bench.
k=names[4];x,y,z=(.20,.82,-.58)
rbox(k,(x,y,z),(1.75,.17,1.18),'silver')
for xx in (-.72,.72):
    for zz in (-.44,.44):cyl(k,(x+xx,y-.47,z+zz),.055,.78,'steel','y')
box(k,(x,y+.23,z),(1.10,.05,.92),'dark')
ring(k,(x,y+.30,z),.38,.33,.055,'y','cyan',36)
cyl(k,(x,y+.33,z),.27,.024,'silver','y',40)
for i in range(10):box(k,(x-.75+i*.17,y+.13,z+.55),(.075,.032,.04),'cyan')
compact_screen(k,(x+.67,y+.50,z-.38),.40,.30,'blue')

# 05 wafer carrier rack with 15 individually visible silicon wafer discs.
k=names[5];x,y,z=(1.78,1.17,-1.65)
frame(k,(x,y,z),(1.10,1.66,1.05),.052,glass=False)
for j in range(14):
    yy=y-.65+j*.098
    cyl(k,(x,yy,z),.39,.018,'silver' if j%4 else 'ice','y',40)
    ring(k,(x,yy+.012,z),.34,.29,.010,'y','blue',36)
for xx in (x-.46,x+.46):box(k,(xx,y,z+0.55),(.046,1.46,.04),'cyan')

# 06 six-axis robot arm (art segments; reference pivots in CSV).
k=names[6];x,y,z=(-1.35,.45,-.83)
box(k,(x,y,z),(.77,.34,.78),'steel');cyl(k,(x,y+.28,z),.31,.23,'dark','y',28)
for cx,cy,cz,r in [(-1.40,.93,-.83,.22),(-.98,1.56,-.88,.20),(-.26,1.80,-.63,.17),(.22,1.50,-.40,.13)]:
    cyl(k,(cx,cy,cz),r,.18,'steel','z',22)
pipe(k,[(-1.40,1.02,-.83),(-1.0,1.55,-.88)],.18,'white',20)
pipe(k,[(-.98,1.56,-.88),(-.26,1.80,-.63)],.16,'white',20)
pipe(k,[(-.26,1.80,-.63),(.22,1.50,-.40)],.12,'white',20)
for i in range(7):cyl(k,(-1.39+.12*i,.78+.11*i,-.76),.028,.04,'blue','z',12)
box(k,(.40,1.41,-.40),(.37,.075,.17),'steel')
for xx in (.23,.57):box(k,(xx,1.30,-.40),(.05,.24,.07),'dark')

# 07 AHU chassis: open service window makes coils visible.
k=names[7];x,y,z=(-5.27,1.43,-1.37)
rbox(k,(x,y,z),(3.48,2.36,2.48),'steel')
box(k,(x,y,z+1.27),(3.26,2.10,.040),'glass')
for xx in (-6.92,-6.12,-5.31,-4.5,-3.68):box(k,(xx,1.43,z+1.29),(.065,2.14,.10),'light')
for yy in (.47,2.39):box(k,(x,yy,z+1.31),(3.32,.07,.10),'silver')
for i in range(4):box(k,(-6.82+i*.87,2.62,z),(0.65,.09,1.8),'navy')
box(k,(-3.54,1.40,z+1.28),(.30,2.10,.06),'dark')
for i in range(6):knob(k,-3.56,1.02+i*.20,z+1.34,'green' if i%2==0 else 'cyan')
box(k,(-5.30,.15,z),(3.10,.13,2.50),'navy')

# 08 Filter prefilter
k=names[8];filter_pleats(k,-6.40,1.46,-.06,.55,1.90,.12,18,'white')
for yy in (.55,2.35):box(k,(-6.40,yy,.06),(.71,.08,.08),'silver')

# 09 cooling coil
k=names[9];coil(k,-5.83,1.47,-.02,.66,1.85,False)
for j in range(3):duct(k,[(-5.75,1.2+j*.26,-.1),(-5.68,1.2+j*.26,.38)],.025,'copper')

# 10 reheat coil
k=names[10];coil(k,-5.05,1.47,-.02,.67,1.85,True)
for j in range(7):box(k,(-5.08,1.02+j*.15,.21),(.45,.018,.034),'amber')

# 11 humidifier
k=names[11];panel(k,(-4.34,1.27,-.04),(.65,.9,.48));cyl(k,(-4.34,1.88,-.18),.23,.48,'steel','y')
for i in range(4):duct(k,[(-4.48+.08*i,2.06,-.17),(-4.48+.08*i,2.33,-.17)],.020,'ice')
for i in range(3):knob(k,-4.52+i*.18,.91,.25,'cyan')

# 12 drain
k=names[12];box(k,(-5.46,.35,-.26),(1.15,.14,.48),'steel')
for j in range(9):box(k,(-5.88+j*.103,.435,-.22),(.055,.019,.40),'dark')
duct(k,[(-5.78,.42,-.34),(-5.78,.18,-.34),(-4.86,.18,-.34)],.045,'copper')
cyl(k,(-4.86,.24,-.34),.13,.06,'cyan','y')

# 13-15 blowers, separated physically from AHU cabinet outer geometry.
for idx,(x,y,z,sc) in [(13,(-3.86,1.67,-1.60,.71)),(14,(-3.86,.98,-2.50,.60)),(15,(-4.10,1.77,-3.02,.43))]:
    k=names[idx];motor(k,(x,y,z),sc)
    airfan(k,(x+.46*sc,y,z),.30*sc,'z')
    box(k,(x,y-.44*sc,z),(1.30*sc,.12*sc,.77*sc),'steel')
    for v in range(5):box(k,(x-.28*sc+v*.13*sc,y+.15*sc,z+.41*sc),(.053*sc,.045*sc,.03),'cyan')

# 16,17 ceiling FFUs, overhead HEPA media are independently modeled in 18-19.
for idx,x in ((16,-1.71),(17,1.06)):
    k=names[idx];y,z=(3.39,-.84)
    rbox(k,(x,y,z),(2.08,.36,1.65),'silver')
    for xx in (x-.65,x+.65):airfan(k,(xx,y+.22,z),.31,'y')
    for j in range(20):box(k,(x-0.93+j*.097,y-.21,z),(.035,.025,1.48),'ice')
    for zz in (-1.54,-.12):box(k,(x,y-.225,zz),(1.94,.025,.042),'cyan')
    box(k,(x,y-.06,z+0.84),(1.75,.13,.035),'blue')

# 18,19 HEPA modules separately replaceable. positions just below FFUs.
for idx,x in ((18,-1.71),(19,1.06)):
    k=names[idx];y,z=3.08,-.84
    rbox(k,(x,y,z),(1.98,.145,1.52),'silver')
    for i in range(38):
        xx=x-.89+i*.048
        box(k,(xx,3.00,z),(.026,.018,1.35),'white' if i%3 else 'light')
    for i in range(7):
        zz=z-.60+i*.20
        box(k,(x,2.99,zz),(1.86,.022,.016),'ice')
    for xx in (x-.88,x+.88):box(k,(xx,2.94,z),(.11,.12,.17),'gold')

# 20 Low-level return air grille
k=names[20];grille(k,(2.91,.84,.19),(.13,1.17,1.65),n=17)
for j in range(5):box(k,(2.80,.38+j*.24,-.63),(.16,.040,.10),'silver')

# 21 Main supply ducts; copper? use polished steel
k=names[21]
for pts,r in [([(-4.10,3.03,-2.78),(-3.63,3.03,-2.78),(-3.63,3.91,-2.78),(2.75,3.91,-2.78)],.18),([(-1.71,3.90,-2.78),(-1.71,3.70,-.84)],.13),([(1.06,3.90,-2.78),(1.06,3.70,-.84)],.13),([(2.70,3.91,-2.78),(5.16,3.91,-2.78),(5.16,3.40,-.90)],.12)]:duct(k,pts,r,'steel')
for xx in (-3.60,-1.70,1.06,2.80,5.17):ring(k,(xx,3.91,-2.78),.22,.18,.09,'x','cyan',24)

# 22 Return ducts behind/under cleanroom
k=names[22]
for pts in [[(2.94,.85,-.70),(2.94,.60,-2.95),(-3.60,.60,-2.95)],[(5.95,.75,-1.50),(5.95,.53,-3.42),(-3.65,.53,-3.42)],[(-3.65,.60,-2.95),(-3.96,1.08,-2.45)]]:
    duct(k,pts,.11,'steel')
for xx in (-2.7,-.8,1.2,3.0):box(k,(xx,.60,-2.95),(.13,.30,.18),'silver')

# 23,24,25,26 dampers with distinct mounting duct and louvers
for idx,center,clr in [(23,(-3.58,3.89,-2.78),'blue'),(24,(-.54,3.90,-2.76),'cyan'),(25,(4.55,3.88,-2.78),'cyan'),(26,(6.24,2.68,-2.66),'amber')]:
    k=names[idx];x,y,z=center
    box(k,(x,y,z),(.62,.54,.46),'steel')
    for j in range(6):
        yy=y-.19+j*.075
        box(k,(x,yy,z+.26),(.54,.035,.06),'light' if j%2==0 else 'dark')
    box(k,(x+.37,y+.10,z),(.23,.27,.34),'dark')
    cyl(k,(x+.38,y+.28,z),.07,.12,clr,'y',16)
    pipe(k,[(x+.38,y+.27,z+.12),(x+.38,y-.11,z+.28)],.014,'silver',8)

# 27 pressure cleanroom sensor
multisensor(names[27],2.78,1.73,1.48,'pressure',.32)
# 28 pressure airlock
multisensor(names[28],5.80,1.84,1.49,'pressure',.31)
# 29 velocity probe in duct
k=names[29];box(k,(-2.62,3.82,-2.48),(.32,.31,.26),'steel')
pipe(k,[(-2.62,3.87,-2.52),(-2.62,3.56,-2.52),(-2.62,3.46,-1.92)],.028,'silver')
for i in range(3):cyl(k,(-2.62,3.46,-1.92+i*.08),.038,.055,'cyan','z',10)

# 30 and 31 particle counters
multisensor(names[30],2.52,1.11,1.52,'particle',.34)
multisensor(names[31],5.60,1.13,1.52,'particle',.30)
for idx,x in ((30,2.52),(31,5.60)):
    k=names[idx];duct(k,[(x,1.30,1.45),(x,1.44,1.45),(x-.1,1.48,1.25)],.019,'cyan')

# 32 33 temp/humidity probes
multisensor(names[32],2.64,2.48,1.49,'thermal',.30)
multisensor(names[33],5.72,2.46,1.49,'thermal',.27)
for idx,x in ((32,2.64),(33,5.72)):
    k=names[idx];box(k,(x-.13,2.25,1.69),(.14,.08,.12),'white')

# 34 dew point sensor
multisensor(names[34],-2.93,2.10,1.48,'thermal',.27)
# 35 filter pressure transmitter mounted on AHU front
multisensor(names[35],-3.63,2.13,-.02,'pressure',.29)
duct(names[35],[(-3.73,1.93,-.05),(-4.88,1.93,-.05)],.019,'copper')

# 36 air shower in airlock
k=names[36];rbox(k,(4.88,1.59,-1.72),(1.64,2.28,.93),'silver')
box(k,(4.88,1.59,-1.18),(1.53,2.12,.038),'glass')
for xx in (4.18,5.58):
    for yy in np.arange(.73,2.60,.32):
        cyl(k,(xx,yy,-1.23),.070,.025,'cyan','z',14)
for i in range(8):box(k,(4.30+i*.17,2.76,-1.32),(.095,.025,.038),'blue')

# 37 inner door (between cleanroom and airlock)
k=names[37];frame(k,(3.55,1.67,-.10),(.17,2.64,1.55),.065,glass=True)
box(k,(3.66,1.65,-.10),(.10,2.44,1.36),'glass')
box(k,(3.76,1.73,.31),(.20,.56,.11),'dark')
for yy in (.47,1.65,2.80):ring(k,(3.53,yy,-.81),.11,.075,.035,'y','silver',12)

# 38 outer door (corridor-facing)
k=names[38];frame(k,(6.37,1.67,.15),(.17,2.64,1.50),.065,glass=True)
box(k,(6.45,1.65,.15),(.10,2.44,1.30),'glass')
box(k,(6.54,1.73,-.27),(.20,.55,.11),'dark')
for yy in (.48,1.64,2.80):ring(k,(6.40,yy,.82),.11,.075,.035,'y','silver',12)

# 39 seal failure simulator (physical module close to HEPA A)
k=names[39];panel(k,(-1.79,2.52,1.70),(.64,.56,.34))
for i in range(10):box(k,(-2.04+i*.052,2.16,1.85),(.022,.05,.12),'red' if i%4==0 else 'amber')
pipe(k,[(-1.95,2.34,1.86),(-1.95,2.63,1.86),(-1.71,3.01,1.10)],.025,'copper')

# 40 emergency-stop and door interlock
k=names[40];panel(k,(6.57,1.06,2.74),(.68,.78,.47))
cyl(k,(6.58,1.18,3.02),.14,.15,'red','z',24)
for i in range(4):box(k,(6.32+i*.15,.83,3.03),(.08,.055,.03),'amber')

# 41 particle event/disturbance test controller
k=names[41];panel(k,(5.60,.93,2.93),(.85,.83,.48))
for i in range(9):
    box(k,(5.28+i*.08,.58,3.19),(.035,.08,.045),'red' if i%3==0 else 'cyan')

# 42 PLC rack, high-detail industrial module rack
k=names[42];x,y,z=(-5.75,.89,3.00)
rbox(k,(x,y,z),(2.40,1.35,.75),'steel')
box(k,(x,y,z+.405),(2.24,1.18,.048),'dark')
for i in range(15):
    xx=x-1.05+i*.15
    box(k,(xx,.94,z+.43),(.115,.89,.09),'light' if i%4 else 'dark')
    for j in range(6):
        box(k,(xx,.62+j*.115,z+.49),(.04,.03,.019),('green' if (i+j)%4 else 'amber'))
    box(k,(xx,.46,z+.44),(.05,.11,.04),'blue')
for i in range(12):
    xx=x-1.0+i*.18
    duct(k,[(xx,.35,z+.46),(xx,.20,3.36),(xx+.05,.09,3.45)],.013,'copper' if i%2 else 'blue')

# 43 I/O module
k=names[43];x,y,z=(-3.82,.74,3.00)
rbox(k,(x,y,z),(1.14,1.05,.63),'steel')
for i in range(8):
    xx=x-.47+i*.135
    box(k,(xx,.77,z+.35),(.115,.70,.052),'dark')
    for j in range(5):box(k,(xx,.5+j*.135,z+.39),(.055,.03,.018),'green' if (j+i)%3 else 'cyan')

# 44 pressure cascade PID panel
k=names[44];panel(k,(-2.51,.85,3.00),(1.08,1.07,.46))
for j in range(7):box(k,(-2.91+j*.13,.57,3.29),(.074,.075,.025),'cyan' if j%3 else 'green')

# 45 psychrometric temperature/humidity controller
k=names[45];panel(k,(-1.24,.85,3.00),(1.11,1.07,.46))
for j in range(5):box(k,(-1.58+j*.17,.60,3.29),(.11,.055,.025),'blue' if j%2 else 'amber')

# 46 central holographic SCADA screen
k=names[46];x,y,z=(1.44,1.23,3.00)
rbox(k,(x,y,z),(3.59,1.66,.31),'steel')
box(k,(x,y,z+.18),(3.35,1.43,.034),'black')
box(k,(x-.70,y+.27,z+.21),(1.58,.58,.020),'blue')
box(k,(x+1.00,y+.27,z+.21),(.87,.58,.020),'dark')
for i in range(5):
    box(k,(x-.70,y-.21+i*.087,z+.231),(1.45,.018,.015),'cyan' if i%2 else 'blue')
for i in range(5):
    box(k,(x+.64+i*.17,y-.39,z+.226),(.09,.22+((i*7)%4)*.07,.015),'green' if i%2 else 'amber')
for i in range(8):knob(k,x-1.47+i*.41,y-.63,z+.25,'cyan' if i%3 else 'green')
box(k,(x,.32,z),(.22,.40,.32),'steel')
box(k,(x,.10,z),(.87,.13,.65),'dark')

# 47 control PSU
k=names[47];panel(k,(4.90,.64,3.05),(1.02,.78,.52))
for i in range(4):
    xx=4.53+i*.24
    cyl(k,(xx,.25,3.32),.078,.09,'red' if i%2 else 'blue','z',16)
    box(k,(xx,.39,3.35),(.13,.032,.035),'silver')

# Verify all 48 assets are distinct and populated.
assert len(names)==48
for i,k in enumerate(names):
    assert k in M and len(M[k])>0,(i,k)

pivots=[
 ('SupplyAirBlowerMotor','ANIM_SUPPLY_BLOWER',(-3.86,1.67,-1.60)),
 ('ReturnAirBlowerMotor','ANIM_RETURN_BLOWER',(-3.86,.98,-2.50)),
 ('ExhaustAirBlowerMotor','ANIM_EXHAUST_BLOWER',(-4.10,1.77,-3.02)),
 ('CeilingFanFilterUnitA','ANIM_FFU_A_FAN',(-1.71,3.61,-.84)),
 ('CeilingFanFilterUnitB','ANIM_FFU_B_FAN',(1.06,3.61,-.84)),
 ('FreshAirMixingDamper','ANIM_FRESH_AIR_DAMPER',(-3.58,3.89,-2.78)),
 ('CleanroomSupplyDamperA','ANIM_SUPPLY_DAMPER_A',(-.54,3.90,-2.76)),
 ('AirlockSupplyDamperB','ANIM_SUPPLY_DAMPER_B',(4.55,3.88,-2.78)),
 ('MotorizedPressureReliefDamper','ANIM_RELIEF_DAMPER',(6.24,2.68,-2.66)),
 ('AirlockInnerSafetyDoor','ANIM_INNER_DOOR',(3.55,1.67,-.10)),
 ('AirlockOuterSafetyDoor','ANIM_OUTER_DOOR',(6.37,1.67,.15)),
 ('AutomatedWaferTransferRobot','ANIM_WAFER_ROBOT_BASE',(-1.35,.73,-.83)),
 ('AutomatedWaferTransferRobot','ANIM_WAFER_ROBOT_ARM',(-.98,1.56,-.88)),
 ('AutomatedWaferTransferRobot','ANIM_WAFER_ROBOT_TOOL',(.22,1.50,-.40)),
 ('IndustrialAirShowerModule','ANIM_AIR_SHOWER',(4.89,1.59,-1.72)),
 ('ReplaceableHEPACartridgeA','ANIM_HEPA_SERVICE_LATCH_A',(-1.71,3.08,-.84)),
 ('ReplaceableHEPACartridgeB','ANIM_HEPA_SERVICE_LATCH_B',(1.06,3.08,-.84)),
 ('HolographicCleanroomSCADAMonitor','ANIM_CLEANROOM_SCADA',(1.44,1.23,3.00)),
 ('CleanroomParticleCounter','ANIM_PARTICLE_SAMPLER',(2.52,1.30,1.45)),
]
# FBX binary 7400 exporter; standard Nodes/Objects/Connections
class N:
 def __init__(self,name,*p,ch=None):self.name=name;self.p=p;self.ch=ch or []
def prop(v):
 if isinstance(v,bool):return b'C'+struct.pack('<?',v)
 if isinstance(v,int):return b'L'+struct.pack('<q',v)
 if isinstance(v,float):return b'D'+struct.pack('<d',v)
 if isinstance(v,str):
  b=v.encode('utf8');return b'S'+struct.pack('<I',len(b))+b
 if isinstance(v,bytes):return b'R'+struct.pack('<I',len(v))+v
 if isinstance(v,np.ndarray):
  if v.dtype.kind=='f':v=v.astype('<f8');t=b'd'
  elif v.dtype.kind in ('i','u'):v=v.astype('<i4');t=b'i'
  else:raise ValueError(v.dtype)
  raw=v.tobytes();comp=zlib.compress(raw,6)
  return t+struct.pack('<III',v.size,1,len(comp))+comp
 raise TypeError(type(v))
def encnode(node,start):
 name=node.name.encode('ascii');ps=b''.join(prop(x) for x in node.p)
 body=bytearray();p0=start+13+len(name)+len(ps)
 for child in node.ch:
  b=encnode(child,p0+len(body));body.extend(b)
 if node.ch:body.extend(bytes(13))
 end=start+13+len(name)+len(ps)+len(body)
 return struct.pack('<III',end,len(node.p),len(ps))+struct.pack('<B',len(name))+name+ps+body

def fbx(k,path):
 meshes=M[k];nobj=[];con=[];uid=100000
 def getid():
  nonlocal uid;uid+=1;return uid
 root=getid()
 props70=N('Properties70',ch=[N('P','Lcl Translation','Lcl Translation','','A',0.0,0.0,0.0),N('P','Lcl Rotation','Lcl Rotation','','A',0.0,0.0,0.0),N('P','Lcl Scaling','Lcl Scaling','','A',1.0,1.0,1.0)])
 nobj.append(N('Model',root,k+'\x00\x01Model','Null',ch=[N('Version',232),N('Properties70',ch=props70.ch),N('Shading','Y'),N('Culling','CullingOff')]))
 con.append(N('C','OO',root,0))
 colorMat={}
 for idx,(mesh,color) in enumerate(meshes):
  # vertex coordinates in meters scaled 100 for FBX centimeter convention, importer scale .01 -> meters
  vertices=np.array(mesh.vertices,dtype=np.float64)*100.0
  tris=np.array(mesh.faces,dtype=np.int32)
  faceindices=tris.copy();faceindices[:,-1]=-(faceindices[:,-1]+1)
  gid=getid();mid=getid();geo=N('Geometry',gid,f'{k}_Geom_{idx:03d}\x00\x01Geometry','Mesh',ch=[N('GeometryVersion',124),N('Vertices',vertices.reshape(-1)),N('PolygonVertexIndex',faceindices.reshape(-1)),N('LayerElementMaterial',0,ch=[N('Version',101),N('Name',''),N('MappingInformationType','AllSame'),N('ReferenceInformationType','IndexToDirect'),N('Materials',np.array([0],dtype=np.int32))]),N('Layer',0,ch=[N('Version',100),N('LayerElement',ch=[N('Type','LayerElementMaterial'),N('TypedIndex',0)])])])
  nobj.append(geo)
  nobj.append(N('Model',mid,f'{k}_Part_{idx:03d}\x00\x01Model','Mesh',ch=[N('Version',232),N('Properties70',ch=[N('P','Lcl Translation','Lcl Translation','','A',0.0,0.0,0.0),N('P','Lcl Rotation','Lcl Rotation','','A',0.0,0.0,0.0),N('P','Lcl Scaling','Lcl Scaling','','A',1.0,1.0,1.0)]),N('Shading','Y'),N('Culling','CullingOff')]))
  con.extend([N('C','OO',gid,mid),N('C','OO',mid,root)])
  if color not in colorMat:
   matid=getid();rgb=[q/255 for q in P[color][:3]]
   nobj.append(N('Material',matid,f'PS_{color}\x00\x01Material','',ch=[N('Version',102),N('ShadingModel','phong'),N('MultiLayer',0),N('Properties70',ch=[N('P','DiffuseColor','Color','','A',*rgb),N('P','AmbientColor','Color','','A',*(v*.28 for v in rgb)),N('P','SpecularColor','Color','','A',.6,.65,.68),N('P','Shininess','Number','','A',55.0),N('P','Opacity','Number','','A',P[color][3]/255.)])]))
   colorMat[color]=matid
  con.append(N('C','OO',colorMat[color],mid))
 top=[N('FBXHeaderExtension',ch=[N('FBXHeaderVersion',1003),N('FBXVersion',7400),N('Creator','Project Spark Procedural 3D Asset Builder')]),N('GlobalSettings',ch=[N('Version',1000),N('Properties70',ch=[N('P','UpAxis','int','Integer','',1),N('P','UpAxisSign','int','Integer','',1),N('P','FrontAxis','int','Integer','',2),N('P','FrontAxisSign','int','Integer','',1),N('P','CoordAxis','int','Integer','',0),N('P','CoordAxisSign','int','Integer','',1),N('P','UnitScaleFactor','double','Number','',1.0),N('P','OriginalUnitScaleFactor','double','Number','',1.0)])]),N('Definitions',ch=[N('Version',100),N('Count',len(nobj))]),N('Objects',ch=nobj),N('Connections',ch=con)]
 header=b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400)
 blob=bytearray(header)
 for node in top:blob.extend(encnode(node,len(blob)))
 blob.extend(bytes(13));blob.extend(bytes(160))
 path.write_bytes(blob)

def glb(k,path):
 sc=trimesh.Scene()
 for i,(m,c) in enumerate(M[k]):sc.add_geometry(m,geom_name=f'{k}_Part_{i:03d}')
 path.write_bytes(sc.export(file_type='glb'))


# ------------------------ deliverable export -----------------------
manifest=[]
for i,k in enumerate(names):
    bn=f'{i:02d}_L70_{k}'
    fbx(k,MD/(bn+'.fbx'))
    glb(k,GD/(bn+'.glb'))
    tri=sum(len(m.faces) for m,c in M[k])
    vv=np.concatenate([m.vertices for m,c in M[k]])
    manifest.append(dict(index=i,file=bn+'.fbx',glb=bn+'.glb',name='L70_'+k,triangle_count=tri,mesh_parts=len(M[k]),bbox_min=np.round(vv.min(axis=0),4).tolist(),bbox_max=np.round(vv.max(axis=0),4).tolist(),animation_pivots={p:list(xyz) for a,p,xyz in pivots if a==k}))
    print(f'{i:02d} {k:40s} {tri:5d} tris',flush=True)

# assembled display export for inspection: never also instantiate with individual models
M['Level70_Complete_ArtKit_Showcase']=[part for k in names for part in M[k]]
fbx('Level70_Complete_ArtKit_Showcase',MD/'Level70_Complete_ArtKit_Showcase.fbx')
glb('Level70_Complete_ArtKit_Showcase',GD/'Level70_Complete_ArtKit_Showcase.glb')
total=sum(v['triangle_count'] for v in manifest)

with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['Model','Pivot','X','Y','Z','Notes'])
    for k,p,xyz in pivots:w.writerow(['L70_'+k,p,*xyz,'World-space art reference only; split moving mesh and assign Transform in Unity.'])

with (ROOT/'Art_Assembly.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['Model','FBX','PositionX','PositionY','PositionZ','RotationX','RotationY','RotationZ','Scale','Notes'])
    for v in manifest:w.writerow([v['name'],v['file'],0,0,0,0,0,0,1,'All art assets authored in common world coordinates; identity local placement'])

palette={}
for col,rgba in P.items():
    palette['PS_'+col]={'rgba_255':list(rgba),'metallic':(.82 if col in ('steel','light','silver','copper','gold') else .12 if col in ('navy','dark','black') else .32),'smoothness':(.79 if col in ('steel','silver','copper','glass') else .49),'transparent':col=='glass'}
(ROOT/'Material_Palette.json').write_text(json.dumps({'level':'70','description':'Suggested Unity materials for geometry materials PS_*; not physically measured BRDF','materials':palette},indent=2))
(ROOT/'Model_Manifest.json').write_text(json.dumps({'level_id':'level_70','display_name':'Guard the Air','asset_kind':'HD procedural 3D modeled geometry (no functional gameplay)','individual_models':48,'individual_triangle_count':total,'individual_mesh_parts':sum(len(M[k]) for k in names),'planned_player_wires':86,'planned_unique_functional_terminals':134,'actual_player_wires_included':False,'functional_spark_terminals_included':False,'air_physics_included':False,'glb_scale':'meters','fbx_numeric_scale':'centimeters with UnitScaleFactor 1; verify FBX importer conversion','coordinate_system':'X=workstation width, Y=up, Z=front; 1 scene unit=1 m','assembled_showcase':'Models/Level70_Complete_ArtKit_Showcase.fbx','pivots_count':len(pivots),'models':manifest},indent=2))

# --------------------- Unity editor placement ----------------------
arr=',\n'.join('            "'+v['file'][:-4]+'"' for v in manifest)
cs=f'''#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.EditorTools
{{
    /// <summary>Only visual FBX placement. Does NOT create SparkTerminal sockets, 86 wires,
    /// environmental controls, HEPA filtration, air flow physics, or gameplay objectives.</summary>
    public static class SparkLevel70ArtPlacementEditor
    {{
        private const string ArtRoot = "L70_HD_VISUAL_ART";
        private static readonly string[] Models = {{
{arr}
        }};

        [MenuItem("Tools/Project Spark/Levels/70/Place HD Art Under Selected Layout")]
        public static void Place()
        {{
            GameObject destination = Selection.activeGameObject;
            if (destination == null)
            {{
                EditorUtility.DisplayDialog("Level 70 Visual Art", "Select the Level 70 layout root in the hierarchy.", "OK");
                return;
            }}
            GameObject[] prefabs = new GameObject[Models.Length];
            for (int i = 0; i < Models.Length; i++)
            {{
                string found = null;
                foreach (string guid in AssetDatabase.FindAssets(Models[i] + " t:Model"))
                {{
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    if (Path.GetExtension(path).Equals(".fbx", StringComparison.OrdinalIgnoreCase) &&
                        Path.GetFileNameWithoutExtension(path).Equals(Models[i], StringComparison.Ordinal))
                    {{
                        found = path;
                        break;
                    }}
                }}
                if (found == null || (prefabs[i] = AssetDatabase.LoadAssetAtPath<GameObject>(found)) == null)
                {{
                    EditorUtility.DisplayDialog("Missing Level 70 FBX", Models[i] + ".fbx is missing.\nImport all 48 numbered FBXs. No changes made.", "OK");
                    return;
                }}
            }}
            Transform existing = destination.transform.Find(ArtRoot);
            if (existing != null && !EditorUtility.DisplayDialog("Replace Level 70 art?",
                "Replace only the " + ArtRoot + " child? Gameplay objects outside this child are not touched.", "Replace Art", "Cancel")) return;
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Place Project Spark Level 70 HD Visual Assets");
            if (existing != null) Undo.DestroyObjectImmediate(existing.gameObject);
            var root = new GameObject(ArtRoot);
            Undo.RegisterCreatedObjectUndo(root, "Create Level 70 art root");
            root.transform.SetParent(destination.transform, false);
            root.transform.localPosition = Vector3.zero;
            root.transform.localRotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;
            for (int i = 0; i < Models.Length; i++)
            {{
                var instance = PrefabUtility.InstantiatePrefab(prefabs[i], root.transform) as GameObject;
                if (instance == null) throw new InvalidOperationException("Failed to instantiate " + Models[i]);
                Undo.RegisterCreatedObjectUndo(instance, "Place " + Models[i]);
                instance.name = Models[i];
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;
                instance.transform.localScale = Vector3.one;
            }}
            Undo.CollapseUndoOperations(group);
            EditorUtility.SetDirty(root);
            Debug.Log("[Project Spark L70] Placed 48 model prefabs at common origin under " + ArtRoot + ". Actual gameplay is separate.");
        }}
    }}
}}
#endif
'''
# Python triple string above emits literal newline in C# quoted display error; fix to C# escaped newline
cs=cs.replace(' is missing.\nImport all 48', ' is missing.\\nImport all 48')
(ED/'SparkLevel70ArtPlacementEditor.cs').write_text(cs)

matcs='''#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace ProjectSpark.EditorTools
{
    /// <summary>Creates editable Unity materials and maps them onto an already placed L70 art root.
    /// Uses available URP Lit or Standard shader. Non-destructive to FBX source files.</summary>
    public static class SparkLevel70MaterialUpgradeEditor
    {
        private const string Folder = "Assets/ProjectSpark/Level70/Materials";
        private static readonly string[] Names = {"navy","steel","light","silver","dark","black","cyan","blue","ice","copper","amber","red","green","white","glass","frost","rubber","gold"};
        private static readonly string[] Hex = {"#0E2034","#42657E","#8BB1C3","#B5C7D0","#1B3245","#0D151E","#25D3F6","#1470DA","#85E0F5","#DC7834","#F8A22D","#E23F46","#2FDB8B","#DCEEF8","#5DB2D4","#CDEBF7","#22262A","#E0B044"};
        [MenuItem("Tools/Project Spark/Levels/70/Create & Apply HD Materials To Selected Art")]
        public static void Apply()
        {
            if (Selection.activeGameObject == null)
            {
                EditorUtility.DisplayDialog("Level 70 Materials", "Select L70_HD_VISUAL_ART (or its parent) first.", "OK");
                return;
            }
            EnsureFolder(Folder);
            Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader == null)
            {
                EditorUtility.DisplayDialog("Material Shader Missing", "Neither URP Lit nor Standard shader is available.", "OK");
                return;
            }
            Material[] mats = new Material[Names.Length];
            for (int i = 0; i < Names.Length; i++)
            {
                string path = Folder + "/PS_" + Names[i] + ".mat";
                var mat = AssetDatabase.LoadAssetAtPath<Material>(path);
                if (mat == null)
                {
                    mat = new Material(shader) { name = "PS_" + Names[i] };
                    AssetDatabase.CreateAsset(mat, path);
                }
                Undo.RecordObject(mat, "Set Level 70 material");
                Color color;
                if (!ColorUtility.TryParseHtmlString(Hex[i], out color)) color = Color.gray;
                if (Names[i] == "glass") color.a = .32f;
                mat.color = color;
                if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
                float metallic = (Names[i] == "steel" || Names[i] == "silver" || Names[i] == "copper" || Names[i] == "gold") ? .82f : .16f;
                if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", metallic);
                if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", .78f);
                if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", .78f);
                if (Names[i] == "glass")
                {
                    if (mat.HasProperty("_Surface")) mat.SetFloat("_Surface", 1f);
                    if (mat.HasProperty("_Mode")) mat.SetFloat("_Mode", 3f);
                    mat.SetOverrideTag("RenderType", "Transparent");
                    mat.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
                    mat.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
                    mat.SetInt("_ZWrite", 0);
                    mat.EnableKeyword("_ALPHABLEND_ON");
                    mat.renderQueue = (int)RenderQueue.Transparent;
                }
                mats[i] = mat;
                EditorUtility.SetDirty(mat);
            }
            int changed = 0;
            foreach (Renderer r in Selection.activeGameObject.GetComponentsInChildren<Renderer>(true))
            {
                Material[] oldMats = r.sharedMaterials;
                Material[] newMats = new Material[oldMats.Length];
                bool diff = false;
                for (int j = 0; j < oldMats.Length; j++)
                {
                    newMats[j] = oldMats[j];
                    if (oldMats[j] == null) continue;
                    for (int i = 0; i < Names.Length; i++)
                    {
                        if (oldMats[j].name.IndexOf("PS_" + Names[i], StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            if (newMats[j] != mats[i]) { newMats[j] = mats[i]; diff = true; }
                            break;
                        }
                    }
                }
                if (diff) { Undo.RecordObject(r,"Apply Level 70 material"); r.sharedMaterials = newMats; changed++; }
            }
            AssetDatabase.SaveAssets();
            Debug.Log("[L70 Materials] Created/updated " + mats.Length + " editable materials; changed " + changed + " renderers. Glass transparency may need adjustment per render pipeline.");
        }
        private static void EnsureFolder(string path)
        {
            string[] parts = path.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
#endif
'''
(ED/'SparkLevel70MaterialUpgradeEditor.cs').write_text(matcs)

viscs='''using UnityEngine;

namespace ProjectSpark.Visuals
{
    /// <summary>Optional art-only rig adapter. Attach to L70_HD_VISUAL_ART and assign separated moving
    /// submeshes in the Inspector. Actual gameplay/controllers must call these methods.
    /// Never supplies authority for airflow, particle counts, pressure, doors, or safety.</summary>
    [DisallowMultipleComponent]
    public sealed class SparkLevel70VisualRig : MonoBehaviour
    {
        [Header("Optional moving mesh references - set after splitting imported FBX submeshes")]
        [SerializeField] private Transform supplyBlower;
        [SerializeField] private Transform returnBlower;
        [SerializeField] private Transform exhaustBlower;
        [SerializeField] private Transform fanFilterA;
        [SerializeField] private Transform fanFilterB;
        [SerializeField] private Transform innerDoor;
        [SerializeField] private Transform outerDoor;
        [SerializeField] private Transform supplyDamper;
        [SerializeField] private Transform airlockDamper;
        private readonly float[] rpm = new float[5];
        private float innerOpen, outerOpen, supplyOpen, airlockOpen;
        public void SetFanRPM(float supply, float ret, float exhaust, float ffuA, float ffuB)
        {
            rpm[0] = Mathf.Max(0,supply); rpm[1] = Mathf.Max(0,ret);
            rpm[2] = Mathf.Max(0,exhaust); rpm[3] = Mathf.Max(0,ffuA); rpm[4] = Mathf.Max(0,ffuB);
        }
        public void SetDoorOpenFractions(float inner, float outer)
        { innerOpen = Mathf.Clamp01(inner); outerOpen = Mathf.Clamp01(outer); }
        public void SetDamperOpenFractions(float supply, float airlock)
        { supplyOpen = Mathf.Clamp01(supply); airlockOpen = Mathf.Clamp01(airlock); }
        private void Update()
        {
            Transform[] fans = { supplyBlower, returnBlower, exhaustBlower, fanFilterA, fanFilterB };
            for (int i=0; i<fans.Length; i++)
                if (fans[i] != null) fans[i].Rotate(Vector3.forward, rpm[i] * 6f * Time.deltaTime, Space.Self);
            if (innerDoor != null) innerDoor.localRotation = Quaternion.Euler(0f, innerOpen*88f, 0f);
            if (outerDoor != null) outerDoor.localRotation = Quaternion.Euler(0f, -outerOpen*88f, 0f);
            if (supplyDamper != null) supplyDamper.localRotation = Quaternion.Euler(supplyOpen*85f,0f,0f);
            if (airlockDamper != null) airlockDamper.localRotation = Quaternion.Euler(airlockOpen*85f,0f,0f);
        }
    }
}
'''
(ED/'SparkLevel70VisualRig.cs').write_text(viscs)

readme='''PROJECT SPARK / LEVEL 70 - GUARD THE AIR
HD PROCEDURAL CLEANROOM 3D GEOMETRY — ACTUAL 3D FILES, NOT SPRITES

WHAT IS INSIDE
- Models/: 48 independent binary FBX 7400 art assets + 1 assembled reference FBX.
- GLB/: 48 GLB backups in meters + 1 assembled GLB reference.
- Animation_Rigs.csv: 19 spatial pivot references (NOT completed submesh joint rigs).
- Art_Assembly.csv: one row per equipment model, identity local transforms.
- Model_Manifest.json: model names, triangle/part counts, bounds, declared pivots.
- Material_Palette.json: suggested colors / metallic / roughness.
- Previews/: real software-rasterized geometry previews (only auxiliary preview files).
- Unity_Optional/SparkLevel70ArtPlacementEditor.cs: non-destructive visual assembly helper.
- Unity_Optional/SparkLevel70MaterialUpgradeEditor.cs: optional PBR-like material creation/remap.
- Unity_Optional/SparkLevel70VisualRig.cs: optional VISUAL-ONLY animation adapter (requires separated moving meshes).
- Source/build_level70.py: procedural generation/re-export source.
- Source/verify_level70.py: detailed binary FBX and GLB validation script.
- Verification_Report.json: export integrity report.

UNITY INSTALLATION
1. Extract the ZIP. Import ONLY 48 numbered Models/*.fbx into Assets/ProjectSpark/Level70/Models.
2. Put SparkLevel70ArtPlacementEditor.cs and SparkLevel70MaterialUpgradeEditor.cs into a Unity Editor folder, e.g. Assets/Editor/ProjectSpark/.
3. Select the Level 70 layout root in the Unity Hierarchy.
4. Use Tools/Project Spark/Levels/70/Place HD Art Under Selected Layout.
5. The helper creates L70_HD_VISUAL_ART under the selected transform and instantiates all 48 models with local identity transforms.
6. Optionally select that root and choose Tools/Project Spark/Levels/70/Create & Apply HD Materials To Selected Art.
7. Do NOT also instantiate Models/Level70_Complete_ArtKit_Showcase.fbx. It is only a composition reference and causes duplicate overlapping geometry.
8. For animated machinery, assign submeshes and pivot transforms to the visual rig, and call it from real gameplay/simulation.

COORDINATES & SCALE
X=workstation width, Y=up, Z=front. Authored layout spans ~15.6 m width.
GLB numeric units are meters. FBX vertices use numeric centimeters and FBX UnitScaleFactor 1.
Verify Unity FBX importer scaling: the 15.6-m wide workbench must import as approximately 15.6 Unity units.
If 100x too large, adjust the model import scale (e.g. 0.01) once. Do not double-apply conversion.

MODEL QUALITY / LIMITATIONS
- These are ORIGINAL procedurally modeled, textured-by-material-color, HD/AAA-INSPIRED geometry assets, not artisan-authored film-quality AAA assets.
- No baked normal maps, hand-painted PBR atlas, LOD pipeline, final collision meshes, UV texture atlas, or skeletal animation clips are included.
- Glass materials may require pipeline-specific alpha/surface settings in Unity.
- Animation_Rigs.csv provides art pivot reference positions only; FBX meshes are not automatically joint-rigged.
- Assets contain NO SparkTerminal components, 86 wire paths, 134 gameplay sockets, HEPA/particle physics, PID controller, PLC gameplay, or six objectives.
- The separate helper only places art and optionally changes render materials; it does not create the playable Level_70.asset or Layout.prefab.
- The optional runtime visual rig has no authority over HVAC control, pressure, particle concentration or interlocks.
- Unity native FBX importer and Play Mode have NOT been tested in this container.
- All equipment is conceptual educational visual art, not certified industrial engineering equipment.
'''
(ROOT/'README_Unity.txt').write_text(readme)

# Lightweight but actual rendered raster previews from source 3D triangles, not AI concept artwork.
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
F=lambda s:ImageFont.truetype(font,s)
def drawscene(keys,sz=(1500,850),omit_glass=True):
    w,h=sz
    im=Image.new('RGB',sz,(7,18,31));dr=ImageDraw.Draw(im)
    meshes=[(m,c) for k in keys for m,c in M[k] if not(omit_glass and c=='glass')]
    az=math.radians(30);el=math.radians(29)
    right=np.array([math.cos(az),0,-math.sin(az)])
    up=np.array([-math.sin(az)*math.sin(el),math.cos(el),-math.cos(az)*math.sin(el)])
    depth=np.cross(right,up)
    vv=np.concatenate([m.vertices for m,c in meshes]);xx=vv@right;yy=vv@up
    low=np.array([xx.min(),yy.min()]);high=np.array([xx.max(),yy.max()])
    dist=high-low
    scale=min((w-(100 if w>=500 else 16))/max(.1,dist[0]),(h-(130 if h>=500 else 16))/max(.1,dist[1]))
    mid=(low+high)/2
    polys=[]
    sun=np.array([.2,.85,.43]);sun/=np.linalg.norm(sun)
    for mesh,col in meshes:
        verts=mesh.vertices;faces=mesh.faces
        cent=(verts[faces[:,0]]+verts[faces[:,1]]+verts[faces[:,2]])/3
        depths=cent@depth
        for j,fi in enumerate(faces):
            p=verts[fi];n=np.cross(p[1]-p[0],p[2]-p[0]);nlen=np.linalg.norm(n)
            if nlen<1e-7:continue
            light=.60+.40*abs(np.dot(n/nlen,sun))
            color=tuple(int(q*light) for q in P[col][:3])
            pp=[(float(((pt@right)-mid[0])*scale+w/2),float((-(pt@up-mid[1]))*scale+h/2)) for pt in p]
            polys.append((float(depths[j]),pp,color))
    polys.sort(key=lambda z:z[0])
    for dep,pts,c in polys:dr.polygon(pts,fill=c)
    return im

hero=drawscene(names,(1500,900))
d=ImageDraw.Draw(hero)
d.rectangle((0,0,1500,95),fill=(7,19,30))
d.text((33,14),'PROJECT SPARK / LEVEL 70 — GUARD THE AIR',font=F(32),fill=(228,243,251))
d.text((35,59),'Semiconductor cleanroom • HEPA filtration • pressure cascade • environmental SCADA',font=F(16),fill=(125,209,226))
d.rectangle((0,854,1500,900),fill=(7,19,30))
d.text((34,863),f'48 REAL MODULAR FBX  •  48 GLB BACKUPS  •  {len(pivots)} PIVOT REFERENCES  •  {total:,} TRIANGLES',font=F(17),fill=(109,218,196))
hero.save(PD/'Level70_Hero_3D_Preview.png')

cellw,cellh=248,181
sheet=Image.new('RGB',(cellw*6,cellh*8),(7,20,32));sd=ImageDraw.Draw(sheet)
for i,k in enumerate(names):
    x=(i%6)*cellw;y=(i//6)*cellh
    thumb=drawscene([k],(244,135),omit_glass=False)
    sheet.paste(thumb,(x+2,y+2))
    sd.text((x+8,y+140),f'{i:02d} {k[:28]}',font=F(11),fill=(217,236,246))
    sd.rectangle((x+1,y+1,x+cellw-2,y+cellh-2),outline=(43,104,139),width=1)
sheet.save(PD/'Level70_48_Models_ContactSheet.png')

# Include reproducible source and verification before packaging.
import shutil
if Path(__file__).resolve() != (SRC/'build_level70.py').resolve():
    shutil.copy2(__file__, SRC/'build_level70.py')
print('EXPORTED',len(manifest),'models;',total,'triangles;',len(pivots),'pivot mappings')
