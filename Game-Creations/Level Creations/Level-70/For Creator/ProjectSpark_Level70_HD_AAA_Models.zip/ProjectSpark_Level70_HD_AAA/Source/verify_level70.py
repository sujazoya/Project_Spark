import json,zlib,struct,zipfile
from pathlib import Path
import numpy as np
import trimesh
ROOT=Path('/mnt/data/ProjectSpark_Level70_HD_AAA')
MAN=json.loads((ROOT/'Model_Manifest.json').read_text())
MAGIC=b'Kaydara FBX Binary  \x00\x1a\x00'

def decode_array(data,pos):
    typ=chr(data[pos]); n,encoding,nbytes=struct.unpack_from('<III',data,pos+1)
    data=data[pos+13:pos+13+nbytes]
    if encoding: data=zlib.decompress(data)
    dt={'d':'<f8','i':'<i4','f':'<f4','l':'<i8'}[typ]
    return np.frombuffer(data,dtype=dt,count=n)

def scan_fbx(path):
    data=path.read_bytes()
    assert data[:23]==MAGIC and struct.unpack_from('<I',data,23)[0]==7400,('Not binary FBX 7400',path)
    counter={'Vertices':0,'PolygonVertexIndex':0,'Geometry':0}
    top=[]
    def parse(start,limit,level=0):
        while start+13<=limit:
            end,nprops,proplen,namelen=struct.unpack_from('<IIIB',data,start)
            if end==0:return
            assert end<=len(data) and end<=limit and end>start,(start,end,limit)
            name=data[start+13:start+13+namelen].decode('ascii')
            if level==0:top.append(name)
            p=start+13+namelen
            if name=='Vertices':
                arr=decode_array(data,p);assert len(arr)%3==0 and np.isfinite(arr).all()
                counter[name]+=len(arr)//3
            elif name=='PolygonVertexIndex':
                arr=decode_array(data,p);assert len(arr)%3==0
                assert int(np.count_nonzero(arr<0))==len(arr)//3
                counter[name]+=int(np.count_nonzero(arr<0))
            elif name=='Geometry':counter[name]+=1
            child=p+proplen
            if child+13<end:parse(child,end,level+1)
            start=end
    parse(27,len(data))
    assert all(x in top for x in ('FBXHeaderExtension','Objects','Connections')),('Missing top nodes',path)
    assert counter['Geometry']>0 and counter['PolygonVertexIndex']>0
    return dict(vertices=counter['Vertices'],triangles=counter['PolygonVertexIndex'],geometries=counter['Geometry'],bytes=len(data))

report={'level_id':'level_70','individual_models_expected':48,'animation_pivot_mappings':MAN['pivots_count'],'individual_triangles':MAN['individual_triangle_count'],'binary_fbx_verified':[],'glb_verified':[],'errors':[]}
assert MAN['individual_models']==48
for m in MAN['models']:
    f=ROOT/'Models'/m['file'];g=ROOT/'GLB'/m['glb']
    assert f.is_file() and g.is_file()
    a=scan_fbx(f)
    assert a['triangles']==m['triangle_count'],(f.name,a['triangles'],m['triangle_count'])
    assert a['geometries']==m['mesh_parts']
    report['binary_fbx_verified'].append({'file':f.name,**a})
    scene=trimesh.load(g,force='scene');tris=sum(len(mesh.faces) for mesh in scene.geometry.values())
    assert tris==m['triangle_count'],(g,tris,m['triangle_count'])
    bounds=np.asarray(scene.bounds)
    assert np.all(np.isfinite(bounds))
    report['glb_verified'].append({'file':g.name,'triangles':tris,'geometries':len(scene.geometry),'bytes':g.stat().st_size})
for ext,d in (('fbx','Models'),('glb','GLB')):
    p=ROOT/d/f'Level70_Complete_ArtKit_Showcase.{ext}'
    if ext=='fbx':r=scan_fbx(p);assert r['triangles']==MAN['individual_triangle_count']
    else:
        sc=trimesh.load(p,force='scene');assert sum(len(m.faces) for m in sc.geometry.values())==MAN['individual_triangle_count']
    report[f'assembled_{ext}_verified']=True
assert len(report['binary_fbx_verified'])==48 and len(report['glb_verified'])==48
assert len(list((ROOT/'Models').glob('*.fbx')))==49
assert len(list((ROOT/'GLB').glob('*.glb')))==49
assert len(list((ROOT/'Unity_Optional').glob('*.cs')))==3
report['all_exports_verified']=True
(ROOT/'Verification_Report.json').write_text(json.dumps(report,indent=2))
print('VERIFIED',len(report['binary_fbx_verified']),'FBX +',len(report['glb_verified']),'GLB, assembled models; total',report['individual_triangles'],'triangles')
