import os, math, json, csv, struct, zlib, zipfile, io, time
from pathlib import Path
import numpy as np
import trimesh
from PIL import Image,ImageDraw,ImageFont

ROOT=Path('/mnt/data/ProjectSpark_Level67_HD_AAA'); (ROOT/'Models').mkdir(parents=True,exist_ok=True); (ROOT/'GLB').mkdir(exist_ok=True); (ROOT/'Previews').mkdir(exist_ok=True); (ROOT/'Unity_Optional').mkdir(exist_ok=True)
NAMES=['IndustrialProcessControlBase', 'TransparentSupplyTankA', 'TransparentSupplyTankB', 'CentralMixingVessel', 'FinishedProductTank', 'CentrifugalPumpA', 'CentrifugalPumpB', 'ProductTransferPump', 'PumpMotorA', 'PumpMotorB', 'TransferPumpMotor', 'VariableFrequencyDriveBank', 'ThreeChannelFlowMeterAssembly', 'FlowTransmitterA', 'FlowTransmitterB', 'ProductFlowTransmitter', 'UltrasonicLevelSensorA', 'UltrasonicLevelSensorB', 'ProductTankLevelSensor', 'PressureTransmitterA', 'PressureTransmitterB', 'MotorizedControlValveA', 'MotorizedControlValveB', 'ProductOutletControlValve', 'EmergencyIsolationValve', 'TransparentProcessPipelineNetwork', 'IndustrialMixingImpeller', 'MixingMotorDrive', 'LiquidRatioQualitySensor', 'CascadePIDController', 'FlowRatioController', 'TankLevelController', 'PumpProtectionRelay', 'CavitationDetectionSensor', 'ProcessSafetyPLC', 'IndustrialProcessPLCRack', 'ProcessDigitalIOModule', 'DownstreamDemandSimulator', 'HolographicSCADAMonitor', 'EmergencyStopAndAlarmStation', 'TransparentProcessSafetyEnclosure', 'Regulated5VControlSupply']
C={
'dark':(26,42,58,255),'navy':(19,35,57,255),'steel':(77,101,118,255),'silver':(164,184,196,255),'chrome':(207,220,226,255),'blue':(21,103,184,255),'cyan':(25,204,239,255),'teal':(24,144,162,255),'gold':(220,156,47,255),'copper':(227,108,39,255),'orange':(251,144,35,255),'red':(218,53,53,255),'green':(39,214,128,255),'yellow':(255,206,52,255),'glass':(73,139,168,100),'rubber':(29,35,42,255),'white':(226,236,239,255),'rust':(124,67,35,255),'water':(25,138,245,110),'amberwater':(251,165,40,115),'mixwater':(34,209,154,120),'screen':(7,36,56,255), 'black':(12,20,28,255)}
MODULES={}
class Part:
 def __init__(self,mesh,color,name,pivot=None): self.mesh=mesh;self.color=color;self.name=name;self.pivot=pivot
parts=[]; current=''; pivots={}
def push(mesh,c='steel',name='',pivot=None):
 if mesh is None:return
 if not isinstance(mesh,trimesh.Trimesh):return
 if len(mesh.faces)==0:return
 mesh=mesh.copy(); mesh.remove_unreferenced_vertices();parts.append(Part(mesh,c,name or c,pivot))
def box(pos,size,c='steel',name='',pivot=None):
 m=trimesh.creation.box(extents=size);m.apply_translation(pos);push(m,c,name,pivot)
def cyl(pos,r,length,axis='y',c='steel',sections=20,name='',pivot=None):
 m=trimesh.creation.cylinder(radius=r,height=length,sections=sections)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='z':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
 m.apply_translation(pos);push(m,c,name,pivot)
def sphere(pos,r,c='steel',sub=1,name=''):
 m=trimesh.creation.icosphere(subdivisions=sub,radius=r);m.apply_translation(pos);push(m,c,name)
def pipe(a,b,r,c='steel',sections=10,name='',pivot=None):
 a=np.array(a);b=np.array(b);d=b-a;L=np.linalg.norm(d)
 if L<1e-6:return
 m=trimesh.creation.cylinder(radius=r,height=L,sections=sections);m.apply_transform(trimesh.geometry.align_vectors([0,0,1],d/L));m.apply_translation((a+b)/2);push(m,c,name,pivot)
def ring(pos,outer,inner,length,axis='x',c='silver',sections=24,name='',pivot=None):
 # mesh hollow by annulus extruded local Z, transform orientation
 verts=[];faces=[]
 for z in [-length/2,length/2]:
  for r in [outer,inner]:
   for k in range(sections):
    t=2*math.pi*k/sections;verts.append([r*math.cos(t),r*math.sin(t),z])
 for k in range(sections):
  j=(k+1)%sections
  for a,b,c_,d in [(k,j,2*sections+j,2*sections+k),(sections+j,sections+k,3*sections+k,3*sections+j),(2*sections+k,2*sections+j,3*sections+j,3*sections+k),(j,k,sections+k,sections+j)]:faces.extend([(a,b,c_),(a,c_,d)])
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
 m.apply_translation(pos);push(m,c,name,pivot)
def gear(pos,r,width,teeth=18,axis='x',c='gold',pivot=None):
 cyl(pos,r*.82,width,axis,c,32,'GearCore',pivot)
 for k in range(teeth):
  a=2*math.pi*k/teeth
  if axis=='x':p=(pos[0],pos[1]+r*math.cos(a),pos[2]+r*math.sin(a));size=(width*.93,r*.27,r*.23);rot='x'
  elif axis=='y':p=(pos[0]+r*math.cos(a),pos[1],pos[2]+r*math.sin(a));size=(r*.25,width*.93,r*.27);rot='y'
  else:p=(pos[0]+r*math.cos(a),pos[1]+r*math.sin(a),pos[2]);size=(r*.25,r*.27,width*.93);rot='z'
  m=trimesh.creation.box(extents=size)
  if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(a,[1,0,0]))
  elif axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
  else:m.apply_transform(trimesh.transformations.rotation_matrix(a,[0,0,1]))
  m.apply_translation(p);push(m,c,'GearTooth',pivot)
 cyl(pos,r*.22,width+.04,axis,'chrome',20,'GearHub',pivot)
def bolt_line(pos,half_x,half_z,y,size=.07):
 x,y0,z=pos
 for dx in [-half_x,half_x]:
  for dz in [-half_z,half_z]:cyl((x+dx,y0,z+dz),size,.055,'y','chrome',10)
def leds(x,y,z,n=5,step=.16,colors=None):
 for i in range(n): sphere((x+i*step,y,z),.052,(colors or ['green','cyan','yellow','red'])[i%4],1)
def panel(pos,size,name='',screen=True,led=True):
 x,y,z=pos; box(pos,size,'dark','Enclosure');box((x,y,z+size[2]/2+.018),(size[0]*.9,size[1]*.88,.035),'steel','Faceplate')
 if screen:box((x,y+.12,z+size[2]/2+.048),(size[0]*.71,size[1]*.38,.025),'screen','Display');box((x,y+.12,z+size[2]/2+.065),(size[0]*.57,.028,.008),'cyan','DisplayCurve')
 if led:leds(x-size[0]*.32,y-size[1]*.29,z+size[2]/2+.065,min(5,max(2,int(size[0]*5))),max(.115,size[0]*.13))
 for dx in [-size[0]*.41,size[0]*.41]:
  for dy in [-size[1]*.39,size[1]*.39]:cyl((x+dx,y+dy,z+size[2]/2+.052),.025,.04,'z','silver',10)
def support(x,z,y=1.20):box((x,y-.27,z),(.16,.55,.16),'steel');box((x,y-.55,z),(.45,.10,.36),'dark')
def bearing(pos,damaged=False,replacement=False):
 x,y,z=pos
 col='rust' if damaged else 'chrome'
 ring(pos,.49,.30,.24,'x',col,32,'OuterRace')
 ring(pos,.33,.19,.28,'x','rust' if damaged else 'silver',32,'InnerRace')
 for k in range(12):
  a=2*math.pi*k/12;p=(x,y+.39*math.cos(a),z+.39*math.sin(a));sphere(p,.07,'rust' if damaged and k%4==0 else 'chrome',1,'Ball')
 if damaged:
  for k in range(4):
   a=k*1.33;box((x+.15,y+.48*math.cos(a),z+.48*math.sin(a)),(.08,.09,.08),'red','DamageMark')
 if replacement:box((x,y-.58,z),(.95,.11,.74),'green','NewPartTray')
def conveyor(x1,x2,z=0.2,y=1.35):
 mid=(x1+x2)/2;length=x2-x1
 box((mid,y-.18,z),(length,.16,1.18),'dark','ConveyorFrame')
 box((mid,y,z),(length-.16,.07,.98),'rubber','BeltTop')
 for x in np.arange(x1+.3,x2-.2,.38):cyl((float(x),y-.04,z),.105,.99,'z','chrome',12,'Roller')
 for z1 in [z-.63,z+.63]:box((mid,y+.06,z1),(length,.13,.09),'silver','GuideRail')
 for x in [x1+.3,x2-.3]:
  for zz in [z-.46,z+.46]:support(x,zz,y-.26)
def sensor(pos,color='cyan'):
 x,y,z=pos;box(pos,(.31,.3,.25),'dark');box((x,y,z+.135),(.20,.18,.035),color);cyl((x,y,z+.16),.045,.028,'z','chrome',12)
def motor(cx=-3.8,cy=1.53,cz=-.05):
 global pivots
 pivots['ANIM_MOTOR_ROTOR']=(cx+1.02,cy,cz)
 cyl((cx,cy,cz),.72,1.42,'x','blue',40,'MotorBody')
 for k in range(24):
  a=k*2*math.pi/24; y=cy+.735*math.cos(a);z=cz+.735*math.sin(a)
  m=trimesh.creation.box(extents=(1.20,.14,.10));m.apply_transform(trimesh.transformations.rotation_matrix(a,[1,0,0]));m.apply_translation((cx,y,z));push(m,'steel','CoolingFin')
 cyl((cx-.74,cy,cz),.77,.13,'x','dark',32,'RearEndCap');cyl((cx+.74,cy,cz),.76,.12,'x','silver',32,'FrontEndCap')
 cyl((cx-.87,cy,cz),.51,.055,'x','navy',32,'FanGrille')
 for k in range(10):
  a=k*2*math.pi/10;pipe((cx-.91,cy+.1*math.cos(a),cz+.1*math.sin(a)),(cx-.91,cy+.48*math.cos(a),cz+.48*math.sin(a)),.024,'chrome')
 box((cx,cy-.78,cz),(.82,.16,.86),'steel','MotorFoot');box((cx,cy-.9,cz),(1.1,.16,1.22),'dark','Mount')
 box((cx,cy+.49,cz+.66),(.63,.40,.36),'blue','TerminalBox');box((cx,cy+.49,cz+.855),(.54,.30,.03),'yellow','WarningPanel')
 cyl((cx+1.02,cy,cz),.15,.53,'x','chrome',20,'MotorShaft', 'ANIM_MOTOR_ROTOR')
 for x in [cx-.58,cx+.58]:bolt_line((x,cy-.85,cz),.3,.32,cy-.85)


# Project Spark L67: common-origin authored process rig. Liquid and pipes are visual surfaces,
# not a fluid solver. Each module is independently exported for Unity placement.
def tank(cx,cz,kind='water',rad=.72,height=2.55,bottom=1.40,fill=.62):
 y=bottom+height/2
 col={'water':'cyan','amberwater':'gold','mixwater':'teal'}[kind]
 for yy in [bottom+.06,bottom+height-.06]:
  ring((cx,yy,cz),rad+.065,rad-.025,.09,'y','chrome',32,'TankFlange')
 ring((cx,bottom+height/2,cz),rad,rad-.025,height-.10,'y','glass',40,'TransparentVessel')
 cyl((cx,bottom+height*fill/2,cz),rad*.94,height*fill,'y',kind,40,'ProcessLiquid')
 cyl((cx,bottom+height+.09,cz),rad+.075,.14,'y','steel',32,'TankTop')
 cyl((cx,bottom-.12,cz),rad+.075,.17,'y','steel',32,'TankFoot')
 for a in [0,math.pi/2,math.pi,3*math.pi/2]:
  x=cx+(rad+.14)*math.cos(a);z=cz+(rad+.14)*math.sin(a)
  pipe((x,bottom+.09,z),(x,bottom+height-.15,z),.03,'silver',10,'LevelRail')
 for k in range(6):box((cx+rad+.1,bottom+.33+k*.34,cz),(.07,.03,.15),'white','Graduation')
 for xx in [-.42,.42]:
  for zz in [-.42,.42]:support(cx+xx,cz+zz,bottom-.45)
 pipe((cx,bottom+height+.2,cz),(cx,bottom+height+.43,cz),.085,'silver',12,'TankVent')

def pump(cx,cz,rotor='ANIM_PUMP'):
 cy=1.18
 box((cx,cy-.47,cz),(1.36,.18,.75),'dark','PumpBed')
 cyl((cx-.25,cy,cz),.34,.50,'x','steel',32,'Volute')
 cyl((cx-.25,cy,cz),.27,.055,'x','chrome',28,'Cover')
 cyl((cx-.25,cy,cz),.22,.045,'x','cyan',24,'Impeller',rotor)
 for k in range(7):
  a=k*2*math.pi/7
  box((cx-.22,cy+.12*math.cos(a),cz+.12*math.sin(a)),(.028,.13,.075),'silver','ImpellerBlade',rotor)
 cyl((cx+.25,cy,cz),.31,.66,'x','blue',24,'Motor')
 for k in range(12):
  a=2*math.pi*k/12
  box((cx+.25,cy+.31*math.cos(a),cz+.31*math.sin(a)),(.48,.065,.05),'steel','MotorFin')
 cyl((cx+.60,cy,cz),.29,.10,'x','navy',22,'RearCap')
 pipe((cx-.46,cy+.33,cz),(cx-.46,cy+.70,cz),.13,'silver',14,'PumpDischarge')
 pipe((cx-.72,cy,cz),(cx-.45,cy,cz),.13,'silver',14,'PumpSuction')
 for xx in [cx-.45,cx+.45]:cyl((xx,cy-.50,cz),.045,.07,'y','chrome',10,'MountBolt')
 pivots[rotor]=(cx-.25,cy,cz)

def motor(cx,cz,pivot):
 cy=1.16
 cyl((cx,cy,cz),.33,.85,'x','blue',26,'PumpMotorBody')
 for k in range(16):
  t=2*math.pi*k/16
  box((cx,cy+.34*math.cos(t),cz+.34*math.sin(t)),(.70,.055,.052),'steel','MotorCoolingRib')
 cyl((cx+.46,cy,cz),.35,.12,'x','navy',26,'MotorRearCap')
 cyl((cx-.49,cy,cz),.09,.39,'x','chrome',16,'MotorShaft',pivot)
 box((cx,cy-.40,cz),(.67,.13,.52),'dark','MotorMount')
 pivots[pivot]=(cx-.49,cy,cz)

def valve(cx,cz,pivot,color='red'):
 y=1.4
 pipe((cx-.34,y,cz),(cx+.34,y,cz),.13,'steel',18,'ValveBody')
 cyl((cx,y,cz),.23,.20,'y','silver',24,'ValveBonnet')
 cyl((cx,y+.20,cz),.05,.39,'y','chrome',16,'ValveStem',pivot)
 cyl((cx,y+.47,cz),.25,.06,'y',color,20,'ValveHandwheel',pivot)
 for t in range(6):
  a=t*2*math.pi/6
  pipe((cx,y+.47,cz),(cx+.21*math.cos(a),y+.47,cz+.21*math.sin(a)),.021,'chrome',8,'HandwheelSpoke',pivot)
 box((cx,y+.31,cz+.19),(.22,.22,.15),'dark','ValveActuator')
 pivots[pivot]=(cx,y+.39,cz)

def instrument(cx,cy,cz,name='sensor',accent='cyan'):
 box((cx,cy,cz),(.43,.44,.34),'dark',name+'Casing')
 box((cx,cy+.045,cz+.19),(.32,.19,.025),'screen',name+'Screen')
 box((cx,cy+.04,cz+.21),(.23,.025,.012),accent,'ScreenTrace')
 leds(cx-.11,cy-.13,cz+.20,3,.11)
 cyl((cx,cy-.3,cz),.045,.21,'y','chrome',12,'SensorProbe')

def frame_panel(cx,cy,cz,w=1.1,h=1.1,d=.42,caption=''):
 panel((cx,cy,cz),(w,h,d),caption)
 for z in [cz-d*.7,cz+d*.7]:box((cx,cy-h/2-.15,z),(w*.85,.1,.09),'dark','Rail')

def make(i):
 global parts,pivots
 parts=[];pivots={}
 name=NAMES[i]
 if i==0:
  box((0,.26,0),(13.6,.36,6.2),'navy','BaseFrame')
  box((0,.48,0),(13.35,.085,5.92),'steel','Worksurface')
  for x in [-6.2,6.2]:
   for z in [-2.65,2.65]:box((x,.075,z),(.56,.23,.56),'dark','AdjustableFoot')
  for x in np.arange(-6.45,6.3,.35):box((float(x),.51,3.0),(.035,.04,.045),'cyan','FrontCyanLight')
  for x in [-5.4,-2.8,-.1,2.2,5.2]:
   for z in [-2.3,2.3]:cyl((x,.55,z),.045,.045,'y','chrome',10,'PanelFastener')
  box((0,.65,-1.15),(12.65,.25,3.12),'dark','ProcessSupport')
  box((0,.60,2.9),(12.9,.07,.07),'cyan','FrontLightStrip')
  box((5.0,.75,1.9),(2.4,.19,1.35),'steel','HMIConsoleBase')
 elif i in [1,2]:tank(-4.55 if i==1 else -2.05,-.95,'water' if i==1 else 'amberwater',.75,2.42,1.65,.68 if i==1 else .47)
 elif i==3:
  tank(.45,-.95,'mixwater',.89,1.73,1.40,.57)
  for y in [1.65,2.25]:ring((.45,y,-.95),.90,.83,.065,'y','gold',30,'MixingBands')
 elif i==4:tank(3.10,-.95,'mixwater',.81,2.14,1.54,.63)
 elif i in [5,6,7]:
  x,z=[(-4.55,.77),(-2.05,.77),(2.57,.75)][i-5]
  pump(x,z,['ANIM_PUMP_A_IMPELLER','ANIM_PUMP_B_IMPELLER','ANIM_TRANSFER_PUMP'][i-5])
 elif i in [8,9,10]:
  x,z=[(-4.05,1.18),(-1.53,1.18),(3.04,1.12)][i-8]
  motor(x,z,['ANIM_MOTOR_A','ANIM_MOTOR_B','ANIM_MOTOR_TRANSFER'][i-8])
 elif i==11:
  for k,x in enumerate([-5.55,-4.05,-2.55]):frame_panel(x,1.15,2.32,.99,.90,.36)
  box((-4.05,1.74,2.32),(4.8,.09,.55),'steel','DriveBankTop')
 elif i==12:
  box((-.75,.81,1.97),(2.55,.2,.64),'steel','ThreeMeterRack')
  for x in [-1.58,-.75,.08]:
   cyl((x,1.2,1.97),.24,.32,'y','chrome',24,'FlowMeterBody')
   box((x,1.48,1.97),(.41,.30,.35),'dark','FlowMeterHead')
   box((x,1.48,2.17),(.28,.13,.02),'screen','FlowDisplay')
 elif i in [13,14,15]:instrument(*[(-4.54,1.8,1.8),(-2.04,1.8,1.8),(2.65,1.85,1.95)][i-13],name='FlowTransmitter',accent=['cyan','gold','green'][i-13])
 elif i in [16,17,18]:
  x,z=[(-4.55,-.95),(-2.05,-.95),(3.1,-.95)][i-16]
  cyl((x,4.3,z),.14,.22,'y','steel',20,'LevelSensor')
  box((x,4.48,z),(.44,.32,.44),'dark','UltrasonicHead')
  box((x,4.48,z+.23),(.30,.12,.02),'cyan','EchoReadout')
  pipe((x,4.21,z),(x,3.86,z),.023,'cyan',10,'UltrasoundGuide')
 elif i in [19,20]:
  x=[-3.72,2.4][i-19];y=1.95;z=1.28
  pipe((x,y-.39,z),(x,y,z),.054,'chrome',12,'GaugeStem')
  cyl((x,y+.09,z),.29,.14,'z','steel',28,'Gauge')
  cyl((x,y+.09,z+.09),.22,.027,'z','white',24,'GaugeFace')
  box((x+.02,y+.13,z+.13),(.19,.025,.015),'red','GaugeNeedle')
 elif i in [21,22,23,24]:
  x,z=[(-3.74,.05),(-1.07,.05),(3.9,.13),(4.85,-1.24)][i-21]
  valve(x,z,['ANIM_VALVE_A','ANIM_VALVE_B','ANIM_OUTLET_VALVE','ANIM_ISOLATION_VALVE'][i-21],['cyan','gold','green','red'][i-21])
 elif i==25:
  # Three separate visible process routes, with physically plausible three-dimensional elbows
  for seq,c in [([(-4.55,1.58,.05),(-4.55,1.58,.70),(-3.73,1.58,.70),(-3.73,2.6,.70),(.15,2.6,.70),(.15,2.6,-.95)],'cyan'),([(-2.05,1.58,.05),(-2.05,1.58,.78),(-1.08,1.58,.78),(-1.08,2.23,.78),(.46,2.23,.78),(.46,2.23,-.95)],'gold'),([(.89,1.52,-.95),(1.65,1.52,-.95),(1.65,1.5,.75),(2.6,1.5,.75),(2.6,2.35,.75),(3.1,2.35,.75),(3.1,2.35,-.95)],'green')]:
   for a,b in zip(seq,seq[1:]):pipe(a,b,.075,c,12,'FlowLine')
  for x in [-4.55,-2.05,.45,3.10]:
   for y in [1.52,2.30]:cyl((x,y,-.95),.13,.04,'y','chrome',16,'PipeFlange')
 elif i==26:
  x,z=.45,-.95
  cyl((x,2.35,z),.055,1.62,'y','chrome',18,'ImpellerShaft','ANIM_MIXER_SHAFT')
  for yy in [1.75,2.25]:
   for t in range(4):
    a=t*math.pi/2;pipe((x,yy,z),(x+.46*math.cos(a),yy,z+.46*math.sin(a)),.065,'chrome',12,'ImpellerBlade','ANIM_MIXER_SHAFT')
  pivots['ANIM_MIXER_SHAFT']=(x,2.35,z)
 elif i==27:
  x,z=.45,-.95
  cyl((x,3.48,z),.29,.63,'y','blue',24,'MixerMotor')
  cyl((x,3.84,z),.31,.11,'y','navy',20,'MotorRear')
  box((x,3.14,z),(.57,.16,.57),'silver','MixerMount')
 elif i==28:instrument(1.08,2.0,1.5,'RatioQuality','green')
 elif i in [29,30,31,32,34,35,36]:
  x,y,z={29:(5.0,2.3,-1.85),30:(3.78,2.3,-1.85),31:(2.55,2.3,-1.85),32:(-5.54,1.40,2.35),34:(1.35,1.38,2.36),35:(.0,1.38,2.36),36:(-1.35,1.38,2.36)}[i]
  frame_panel(x,y,z,1.07,1.01,.41)
 elif i==33:instrument(-3.35,1.94,.97,'Cavitation','yellow')
 elif i==37:
  box((5.2,.97,-.25),(1.55,.18,1.15),'steel','DemandRig')
  cyl((5.2,1.17,-.25),.47,.34,'y','chrome',24,'LoadChamber')
  for j in range(5):
   pipe((4.82+j*.18,1.45,-.25),(4.82+j*.18,1.82,-.25),.05,'steel',10,'DemandTubes')
 elif i==38:
  x,y,z=4.93,3.1,-.30
  box((x,y,z),(2.85,1.62,.32),'navy','LargeHMI')
  box((x,y,z+.19),(2.61,1.36,.028),'screen','SCADAView')
  for yy in [3.25,3.05,2.85]:box((x-.15,yy,z+.225),(1.3,.029,.012),['cyan','gold','green'][round((3.25-yy)/.2)],'TrendGraph')
  for k in range(4):box((x+1.03,3.45-k*.29,z+.22),(.33,.12,.012),'green','StatusLight')
  box((x,2.07,z),(.15,.62,.23),'steel','HMIPost')
  pivots['ANIM_SCADA_MONITOR']=(x,3.12,z)
 elif i==39:
  x,y,z=5.52,1.08,2.05
  box((x,y,z),(.83,.79,.45),'yellow','EstopPanel')
  cyl((x,y+.14,z+.28),.18,.17,'z','red',24,'EmergencyStop','ANIM_ESTOP')
  box((x-.12,y-.18,z+.28),(.23,.12,.04),'black','ResetSwitch')
  pivots['ANIM_ESTOP']=(x,y+.14,z+.30)
 elif i==40:
  for x in [-5.95,5.95]:
   for z in [-2.2,2.02]:box((x,2.5,z),(.10,3.4,.10),'chrome','SafetyPost')
  for z in [-2.2,2.02]:
   box((0,4.2,z),(12,.10,.10),'chrome','SafetyTopRail')
   box((0,2.4,z),(11.9,3.2,.045),'glass','PolycarbonateWall')
  box((5.94,2.35,.1),(.05,2.95,3.9),'glass','SlidingSafetyDoor','ANIM_SAFETY_DOOR')
  pivots['ANIM_SAFETY_DOOR']=(5.94,2.35,.1)
 elif i==41:
  frame_panel(-5.95,1.12,2.2,.85,.78,.48)
  box((-5.95,1.55,2.2),(.66,.055,.51),'green','SupplyStatus')
 return parts,pivots
# FBX binary 7400 writer
class Node:
 def __init__(self,name,*props,children=None):self.name=name;self.props=list(props);self.children=children or []
class Prop:
 def __init__(self,typ,data):self.typ=typ;self.data=data

def encodeprop(p):
 if isinstance(p,Prop):
  if p.typ=='d':
   arr=np.asarray(p.data,dtype='<f8').tobytes();return b'd'+struct.pack('<III',len(p.data),0,len(arr))+arr
  if p.typ=='i':
   arr=np.asarray(p.data,dtype='<i4').tobytes();return b'i'+struct.pack('<III',len(p.data),0,len(arr))+arr
  raise Exception('prop')
 if isinstance(p,str):b=p.encode('utf-8');return b'S'+struct.pack('<I',len(b))+b
 if isinstance(p,bool):return b'C'+struct.pack('<?',p)
 if isinstance(p,int):return b'L'+struct.pack('<q',p)
 if isinstance(p,float):return b'D'+struct.pack('<d',p)
 raise TypeError(type(p))

def emit(node,start):
 name=node.name.encode();props=b''.join(map(encodeprop,node.props));head=13+len(name)+len(props)
 childstart=start+head;childdata=b''
 for ch in node.children:
  out=emit(ch,childstart+len(childdata));childdata+=out
 if node.children:childdata+=b'\x00'*13
 end=start+head+len(childdata)
 return struct.pack('<IIIb',end,len(node.props),len(props),len(name))+name+props+childdata

def p3(key,a,b,c):return Node('P',key,'Vector3D','Vector','','',float(a),float(b),float(c))
def pnum(key,v):return Node('P',key,'double','Number','',float(v))
def mesh_node(gid,name,mesh):
 v=mesh.vertices.astype('float64').flatten().tolist();faces=mesh.faces
 poly=np.column_stack([faces[:,0],faces[:,1],-(faces[:,2]+1)]).astype('int32').flatten().tolist()
 return Node('Geometry',gid, 'Geometry::'+name,'Mesh',children=[Node('Vertices',Prop('d',v)),Node('PolygonVertexIndex',Prop('i',poly)),Node('LayerElementNormal',0,children=[Node('Version',101),Node('Name',''),Node('MappingInformationType','ByPolygonVertex'),Node('ReferenceInformationType','Direct'),Node('Normals',Prop('d',mesh.face_normals.repeat(3,axis=0).flatten().tolist()))]),Node('LayerElementMaterial',0,children=[Node('Version',101),Node('Name',''),Node('MappingInformationType','AllSame'),Node('ReferenceInformationType','IndexToDirect'),Node('Materials',Prop('i',[0]))]),Node('Layer',0,children=[Node('Version',100),Node('LayerElement',children=[Node('Type','LayerElementNormal'),Node('TypedIndex',0)]),Node('LayerElement',children=[Node('Type','LayerElementMaterial'),Node('TypedIndex',0)])])])
def model_node(mid,name,typ='Mesh',pos=(0,0,0)):
 return Node('Model',mid,'Model::'+name,typ,children=[Node('Version',232),Node('Properties70',children=[Node('P','Lcl Translation','Lcl Translation','','A',*map(float,pos)),Node('P','Lcl Rotation','Lcl Rotation','','A',0.,0.,0.),Node('P','Lcl Scaling','Lcl Scaling','','A',1.,1.,1.)]),Node('Shading',True),Node('Culling','CullingOff')])
def material_node(mid,c):
 rgb=[x/255 for x in C[c][:3]]
 return Node('Material',mid,'Material::'+c,'',children=[Node('Version',102),Node('ShadingModel','phong'),Node('MultiLayer',False),Node('Properties70',children=[Node('P','DiffuseColor','Color','','A',*rgb),Node('P','AmbientColor','Color','','A',*(x*.25 for x in rgb)),Node('P','SpecularColor','Color','','A',.48,.51,.54),Node('P','Shininess','double','Number','A',50.),Node('P','Opacity','double','Number','A',C[c][3]/255.)])])
def fbx_export(parts,pivots,path,modelname):
 # group all static parts by color, and animated parts by pivot/color
 groups={}
 for p in parts:groups.setdefault((p.pivot,p.color),[]).append(p.mesh)
 objects=[];connections=[];nid=100000;rootid=nid;nid+=1
 connections.append(Node('C','OO',rootid,0))
 objects.append(model_node(rootid,modelname,'Null'))
 matids={}
 for c in sorted(set(p.color for p in parts)):
  matids[c]=nid;objects.append(material_node(nid,c));nid+=1
 pids={}
 for name,xyz in pivots.items():
  pids[name]=nid;objects.append(model_node(nid,name,'Null',xyz));connections.append(Node('C','OO',nid,rootid));nid+=1
 for k,(pivot,col) in enumerate(sorted(groups,key=lambda v:(v[0] or '',v[1]))):
  mesh=trimesh.util.concatenate(groups[(pivot,col)])
  if pivot is not None and pivot in pivots:mesh.apply_translation(-np.array(pivots[pivot]))
  geomid=nid;nid+=1;modelid=nid;nid+=1
  partname='L67_'+str(k).zfill(3)+'_'+col+('_'+pivot if pivot else '')
  objects.append(mesh_node(geomid,partname,mesh));objects.append(model_node(modelid,partname))
  connections.extend([Node('C','OO',geomid,modelid),Node('C','OO',modelid,pids.get(pivot,rootid)),Node('C','OO',matids[col],modelid)])
 head=[Node('FBXHeaderExtension',children=[Node('FBXHeaderVersion',1003),Node('FBXVersion',7400),Node('Creator','Project Spark Procedural FBX Geometry Exporter')]),Node('GlobalSettings',children=[Node('Version',1000),Node('Properties70',children=[Node('P','UpAxis','int','Integer','',1),Node('P','UpAxisSign','int','Integer','',1),Node('P','FrontAxis','int','Integer','',2),Node('P','FrontAxisSign','int','Integer','',1),Node('P','CoordAxis','int','Integer','',0),Node('P','CoordAxisSign','int','Integer','',1),Node('P','UnitScaleFactor','double','Number','',100.)])]),Node('Documents',children=[Node('Count',1),Node('Document',12345,'Scene','Scene',children=[Node('Properties70',children=[Node('P','SourceObject','object','',''),Node('P','ActiveAnimStackName','KString','','','')]),Node('RootNode',0)])]),Node('Definitions',children=[Node('Version',100),Node('Count',len(objects)),Node('ObjectType','Model',children=[Node('Count',1+len(groups)+len(pids))]),Node('ObjectType','Geometry',children=[Node('Count',len(groups))]),Node('ObjectType','Material',children=[Node('Count',len(matids))])]),Node('Objects',children=objects),Node('Connections',children=connections),Node('Takes',children=[Node('Current','')])]
 h=b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400)
 blob=bytearray(h)
 for node in head:blob.extend(emit(node,len(blob)))
 blob.extend(b'\x00'*13)
 # FBX trailing file footer
 blob.extend(b'\0' * 16)
 blob.extend(struct.pack('<I',7400))
 blob.extend(b'\0'*120)
 blob.extend(b'\xf8\x5a\x8c\x6a\xde\xf5\xd9\x7e\xec\xe9\x0c\xe3\x75\x8f\x29\x0b')
 path.write_bytes(blob)
 return len(blob)

def glb_export(parts,pivots,path):
 sc=trimesh.Scene()
 for k,part in enumerate(parts):
  m=part.mesh.copy();m.visual.face_colors=np.tile(np.array(C[part.color],dtype=np.uint8),(len(m.faces),1));sc.add_geometry(m,geom_name='part_'+str(k)+'_'+part.name.replace(' ','_'),node_name='part_'+str(k))
 sc.export(str(path),file_type='glb')

def grouped_for_scene(parts):
 groups={}
 for p in parts:groups.setdefault(p.color,[]).append(p.mesh)
 output=[]
 for c,arr in groups.items():
  m=trimesh.util.concatenate(arr);m.visual.face_colors=np.tile(C[c],(len(m.faces),1));output.append((c,m))
 return output

if __name__=='__main__':
 allparts=[];records=[];rigs=[]
 for i,name in enumerate(NAMES):
  pp,pv=make(i);pp=list(pp);pv=dict(pv)
  allparts.extend(pp)
  file=f'{i:02d}_L67_{name}.fbx';glb=f'{i:02d}_L67_{name}.glb'
  fbsize=fbx_export(pp,pv,ROOT/'Models'/file,'L67_'+name)
  glb_export(pp,pv,ROOT/'GLB'/glb)
  triangles=sum(len(p.mesh.faces) for p in pp)
  records.append(dict(file=file,glb=glb,name='L67_'+name,triangle_count=triangles,mesh_parts=len(pp),animation_pivots={k:list(v) for k,v in pv.items()}))
  for pname,xyz in pv.items():rigs.append([name,pname,*xyz,'Follow authoritative state; art pivot not gameplay physics'])
  print(i+1,name,triangles,len(pp),fbsize,flush=True)
 manifest={'level_id':'level_67','display_name':'Master the Flow','asset_kind':'procedural 3D art only, no gameplay','individual_models':42,'planned_player_wires':74,'planned_unique_sockets':116,'real_terminals_included':False,'physics_included':False,'coordinate_system':'X bench width, Y up, Z front; 1 length unit = 1 Unity unit at scale 1','models':records,'triangle_count':sum(d['triangle_count'] for d in records)}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['model','pivot_name','world_x','world_y','world_z','usage']);w.writerows(rigs)
 fbx_export(allparts,{},ROOT/'Models'/'Level67_Complete_ArtKit_Showcase.fbx','L67_Complete_ArtKit_Showcase')
 glb_export(allparts,{},ROOT/'GLB'/'Level67_Complete_ArtKit_Showcase.glb')
 print('FINAL',sum(d['triangle_count'] for d in records),'pivots',len(rigs),flush=True)
