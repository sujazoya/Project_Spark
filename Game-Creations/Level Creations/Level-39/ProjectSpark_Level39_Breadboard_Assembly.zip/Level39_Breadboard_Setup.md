# Level 39 | Across the Isolation Gap

Build two independently powered circuits. SEND lights the TX emitter, and the receiver pulls RX OUT low when its own supply is on. The optical beam shows the signal crossing the gap.

## Wire both sides

| Wire | From | To |
| --- | --- | --- |
| W01 | TX Supply + | SEND IN |
| W02 | SEND OUT | 470 Ω TX Limit IN |
| W03 | 470 Ω TX Limit OUT | TX Opto A |
| W04 | TX Opto K | TX Supply RET |
| W05 | RX Supply + | 1 kΩ Pull-Up IN |
| W06 | 1 kΩ Pull-Up OUT | RX Opto C |
| W07 | RX Opto E | RX Supply RET |

Leave the returns separate for normal operation. For the temporary **W08** test, connect **TX Supply RET → RX Supply RET** only when the level asks. After the test, use **Undo Last** to remove W08.

## Play to 6/6

| Progress | Action | Expected result |
| --- | --- | --- |
| 1/6 | Finish W01–W07. | SEND off. TX LED reads 0 mA, RX OUT reads 5.00 V and HIGH, and the gap reads ISOLATED. |
| 2/6 | Press **SEND ON**. | TX LED reads about 6.4 mA. The optical beam lights and RX OUT reads LOW. |
| 3/6 | Press **SEND OFF**. | The beam goes out and the pull-up returns RX OUT to HIGH. |
| 4/6 | Turn SEND on again. Turn **RX POWER OFF**, observe the monitor, then turn **RX POWER ON**. | TX keeps sending while RX OUT is UNPOWERED. RX returns LOW when its power is restored. |
| 5/6 | Add the temporary W08 return jumper. | The gap reads BRIDGED while RX OUT still reads LOW. |
| 6/6 | Undo W08. Press **SEND OFF**, then **SEND ON**. | The gap reads ISOLATED. RX goes HIGH and then LOW, and the campaign marks the level complete. |

The RX meter measures against RX Supply RET. The game models the optocoupler using solved TX LED current and a receiver contact. The isolation check evaluates the wiring separately from the receiver voltage.

## Install in another Project Spark checkout

Merge the included `Assets` folder into the project and keep the Unity `.meta` files. Use the existing Level 39 layout catalog entry and teaching drawing. If the campaign skips Level 39, open MainMenu in Edit Mode, run **Tools → Project Spark → Level 39 → Register in Open MainMenu**, then save the scene. If the breadboard geometry changes, run **Tools → Project Spark → Level 39 → Fit Breadboard Assembly**.
