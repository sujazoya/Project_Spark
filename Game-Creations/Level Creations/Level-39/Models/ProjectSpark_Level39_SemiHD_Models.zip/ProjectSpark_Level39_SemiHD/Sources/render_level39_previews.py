"""Offscreen VTK previews of the ACTUAL Level 38 3D meshes (not AI images)."""
from build_level39_models import *
from pathlib import Path
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from PIL import Image,ImageDraw,ImageFont
import numpy as np
import os
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
P=ROOT/'Previews'
P.mkdir(exist_ok=True)

def actor_for(p,offset=(0,0,0)):
    mesh=p.mesh;poly=vtk.vtkPolyData()
    verts=np.ascontiguousarray(np.asarray(mesh.vertices)+np.asarray(offset),dtype=np.float32)
    points=vtk.vtkPoints();points.SetData(numpy_to_vtk(verts,deep=1));poly.SetPoints(points)
    faces=np.ascontiguousarray(mesh.faces,dtype=np.int64)
    inds=np.column_stack([np.full(len(faces),3,dtype=np.int64),faces]).reshape(-1)
    cell=vtk.vtkCellArray();cell.SetCells(len(faces),numpy_to_vtkIdTypeArray(inds,deep=1));poly.SetPolys(cell)
    normals=vtk.vtkPolyDataNormals();normals.SetInputData(poly);normals.SplittingOff();normals.ConsistencyOn()
    mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(normals.GetOutputPort())
    actor=vtk.vtkActor();actor.SetMapper(mapper)
    rgb=np.array(PALETTE[p.mat][:3])/255.0
    prop=actor.GetProperty();prop.SetColor(*rgb);prop.SetAmbient(.40);prop.SetDiffuse(.64)
    metals=('chrome','titanium','steel','gold','copper','orange','mid_steel','sensor_ceramic')
    prop.SetSpecular(.69 if p.mat in metals else .23)
    prop.SetSpecularPower(78 if p.mat in metals else 25)
    if p.mat in ('cyan','green','blue','red','amber','acrylic_edge','white','laser_red','light_cyan','red_hot','amber_led','lcdgreen','screen_green','mint','magenta','violet','electric','emerald'):
        prop.SetAmbient(.80);prop.SetDiffuse(.30)
    if any(tag in p.name for tag in ('_Label','_Text','_Rating','_TerminalName','_Voltage_Display','_Engraved','_Title','_3DLettering')):
        prop.SetAmbient(.98);prop.SetDiffuse(.035);prop.SetSpecular(.01)
    if p.mat in ('glass','acrylic','water','glass_gold','glass_clear','glass_soft','darkglass'):
        prop.SetOpacity(.20 if p.mat!='water' else .6)
    prop.SetBackfaceCulling(False)
    return actor

def render(mods,path,offsets=None,eye=(13,15,-22),look=(0,1,0),scale=5.7,wh=(1700,1000)):
    offsets=offsets or {};ren=vtk.vtkRenderer()
    ren.SetBackground(.025,.043,.073);ren.SetBackground2(.006,.013,.030);ren.GradientBackgroundOn()
    window=vtk.vtkRenderWindow();window.SetOffScreenRendering(1);window.SetSize(*wh);window.SetMultiSamples(2)
    window.AddRenderer(ren)
    for mod in mods:
        for part in mod.parts:
            ren.AddActor(actor_for(part,offsets.get(mod.key,(0,0,0))))
    for pos,color,power in [((-14,18,-16),(1.0,.95,.85),1.04),((14,14,5),(.45,.76,1),1.12),((1,10,-6),(.62,.97,1),.63)]:
        l=vtk.vtkLight();l.SetLightTypeToSceneLight();l.SetPosition(*pos);l.SetFocalPoint(0,0,0)
        l.SetColor(*color);l.SetIntensity(power);ren.AddLight(l)
    cam=ren.GetActiveCamera();cam.SetPosition(*eye);cam.SetFocalPoint(*look);cam.SetViewUp(0,1,0)
    cam.ParallelProjectionOn();cam.SetParallelScale(scale)
    window.Render()
    fil=vtk.vtkWindowToImageFilter();fil.SetInput(window);fil.SetInputBufferTypeToRGB();fil.ReadFrontBufferOff();fil.Update()
    writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(fil.GetOutputPort());writer.Write()
    window.Finalize();print('RENDERED',path.name,path.stat().st_size,flush=True)

def overlay(path,title,subtitle,badge=None):
    img=Image.open(path).convert('RGBA');w,h=img.size;dr=ImageDraw.Draw(img,'RGBA')
    bw=min(w-50,int(w*.78))
    dr.rounded_rectangle((23,19,bw,140),radius=14,fill=(4,16,31,235),outline=(34,215,250,255),width=2)
    font1=ImageFont.truetype(BOLD,42 if w>=2000 else 26 if w<1200 else 36)
    font2=ImageFont.truetype(FONT,18 if w<1200 else 22)
    dr.text((50,35),title,font=font1,fill=(234,251,255))
    dr.text((50,104),subtitle,font=font2,fill=(114,223,238))
    if badge and w>=1500:
        dr.rounded_rectangle((w-460,24,w-25,94),radius=10,fill=(6,24,41,230),outline=(255,173,52,255),width=2)
        dr.text((w-446,48),badge,font=ImageFont.truetype(BOLD,18),fill=(255,210,120))
    dr.text((w-20,h-27),'PROJECT SPARK  /  LEVEL 39  /  SEMI-HD FBX MESH',font=ImageFont.truetype(BOLD,13),anchor='ra',fill=(133,227,242))
    img.convert('RGB').save(path)

if __name__=='__main__':
    mods=[f() for f in BUILDERS]
    showcase_board=board()
    hero=P/'Level39_Complete_10Piece_Kit_Preview.png'
    render([showcase_board]+mods,hero,POSITIONS,
           eye=(0,25,-27),look=(0,1.45,0),scale=7.9,wh=(2400,1500))
    overlay(hero,'LEVEL 39  /  ACROSS THE ISOLATION GAP',
        '10 POLISHED SEMI-HD MODELS   |   14 SOCKETS   |   7 + 1 TEST JUMPER',
        'TX / OPTICAL GAP / RX')
    for idx,m in enumerate(mods):
        h=max(p.mesh.bounds[1,1] for p in m.parts)
        sc=2.65 if h>3.0 else 2.33 if h>2.30 else 2.18
        if idx==0:sc=2.28
        if idx in (0,4):sc=2.36
        if idx in (3,6):sc=2.72
        if idx in (7,8):sc=2.18
        eye=(3.55,3.6,-6.9)
        out=P/(m.key+'_Preview.png')
        render([m],out,eye=eye,look=(0,1.20,0),scale=sc,wh=(1024,768))
        overlay(out,m.key[3:].replace('_',' ').upper(),
                'LEVEL 39  /  INDIVIDUAL FBX MODEL')
    cols=5;rows=2;tw=540;th=430
    sheet=Image.new('RGB',(cols*tw,rows*th),(5,16,31));dr=ImageDraw.Draw(sheet)
    for i,m in enumerate(mods):
        x=(i%cols)*tw+8;y=(i//cols)*th+4
        im=Image.open(P/(m.key+'_Preview.png')).convert('RGB')
        im.thumbnail((tw-16,th-67),Image.Resampling.LANCZOS)
        sheet.paste(im,(x,y))
        dr.rounded_rectangle((x,y+th-68,x+tw-16,y+th-14),radius=9,
                             fill=(8,30,48),outline=(34,215,248),width=2)
        name=m.key[3:].replace('_',' ').upper()
        if len(name)>37:name=name[:35]+'..'
        dr.text((x+14,y+th-56),name,
                font=ImageFont.truetype(BOLD,17),fill=(237,246,252))
    sheet.save(P/'Level39_All_10_Models_ContactSheet.png',quality=95)
    print('LEVEL 39 PREVIEWS + CONTACT SHEET COMPLETE',flush=True)
