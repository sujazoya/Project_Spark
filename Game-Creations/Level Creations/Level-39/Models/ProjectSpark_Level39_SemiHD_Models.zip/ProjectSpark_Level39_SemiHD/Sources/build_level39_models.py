"""Project Spark Level 39 — Across the Isolation Gap.
Procedural semi-HD FBX and GLB 3D model kit.
7 distinct electrical modules, 14 physical terminal sockets, 3 visual only modules.
Matches original W01-W07 wiring + optional W08 test jumper; no solver changes.
"""
from __future__ import annotations
import math, json, csv
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import *

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models'; PREV=ROOT/'Previews'
MODELS.mkdir(exist_ok=True,parents=True); PREV.mkdir(exist_ok=True,parents=True)
PALETTE.update({
 'ceramic':(230,202,149,255), 'nickel':(192,203,216,255),
 'brass':(232,174,76,255), 'oxide':(24,54,67,255),
 'mint':(50,245,185,255), 'teal':(39,221,210,255),
 'rose':(245,89,111,255), 'violet':(183,116,251,255),
 'glass_soft':(95,190,242,85), 'glass_body':(74,171,211,110),
 'opal':(202,233,244,170),'screen_green':(65,240,172,255),
 'pcb':(22,89,91,255), 'amber_glow':(255,193,69,255),
 'insulator':(52,62,78,255), 'ink':(236,242,235,255),
 'isolation':(116,75,219,255), 'brown':(128,68,36,255), 'yellow':(250,213,82,255),
})
PORTS={
 '01_TX_5V_Independent_Supply':[('TX_Positive','TX +','red'),('TX_Return','TX -','blue')],
 '02_TX_SEND_Switch':[('SEND_IN','SEND IN','red'),('SEND_OUT','SEND OUT','amber')],
 '03_TX_470Ohm_LED_Limiter':[('TX_R_IN','R IN','amber'),('TX_R_OUT','R OUT','amber')],
 '04_TX_Optocoupler_LED':[('OPTO_A','ANODE A','amber'),('OPTO_K','CATHODE K','blue')],
 '05_RX_5V_Independent_Supply':[('RX_Positive','RX +','red'),('RX_Return','RX -','violet')],
 '06_RX_1kOhm_Pullup':[('PULLUP_IN','PULLUP IN','red'),('PULLUP_OUT','PULLUP OUT','mint')],
 '07_RX_Optocoupler_Output':[('OPTO_C','COLLECTOR C','mint'),('OPTO_E','EMITTER E','violet')],
}
WIRES=[
 ('W01','TX_Positive','SEND_IN'),
 ('W02','SEND_OUT','TX_R_IN'),
 ('W03','TX_R_OUT','OPTO_A'),
 ('W04','OPTO_K','TX_Return'),
 ('W05','RX_Positive','PULLUP_IN'),
 ('W06','PULLUP_OUT','OPTO_C'),
 ('W07','OPTO_E','RX_Return'),
 ('W08','TX_Return','RX_Return'),
]

# Measurements are conceptual. W08 is intentionally shown disconnected.

def chassis(m,t,display,description='',w=3.22,d=1.95,h=1.31,side='TX'):
 m.base(t,w=w,d=d,bodyh=h,fronttext=display,status='')
 front=-d/2-.072
 accent='amber' if side=='TX' else 'mint'
 m.box(t+'_StatusFiberLeft',(.52,.042,.03),(-w*.31,.331,front),'orange',group='StatusLEDs_VISUAL')
 m.box(t+'_StatusFiberRight',(.52,.042,.03),(w*.31,.331,front),'cyan',group='StatusLEDs_VISUAL')
 if description:m.text(t+'_Subtitle',description,.131,0,.84,front-.009,'cyan',maxwidth=w-.26)
 # flange and four machined lid fasteners
 for x in (-w/2+.16,w/2-.16):
  for z in (-d/2+.16,d/2-.17):
   m.cyl(t+f'_TopFastener_{x:+.2f}_{z:+.2f}',.071,.044,(x,.32+h+.107,z),'chrome',sections=20)
   m.box(t+f'_Slot_{x:+.2f}_{z:+.2f}',(.058,.005,.013),(x,.32+h+.131,z),'void')
 m.box(t+'_TX_RX_EdgeTag',(w*.26,.028,.024),(0,.32+h+.103,-d/2+.18),accent,group='StatusLEDs_VISUAL')
 return front

def ports(m,t,rec=None,w=3.22,d=1.95):
 rec=PORTS[m.key] if rec is None else rec
 zz=-d/2-.102
 # +X on left on -Z-facing preview, same convention as prior levels
 for ix,(id,label,color) in enumerate(rec):
  x=.89 if ix==0 else -.89
  y=.47
  m.cyl(t+'_'+id+'_MetalFlange',.204,.072,(x,y,zz),'chrome',axis='z',sections=38)
  m.cyl(t+'_'+id+'_ColorSocket',.161,.085,(x,y,zz-.026),color,axis='z',sections=38)
  m.cyl(t+'_'+id+'_DeepHole',.109,.094,(x,y,zz-.074),'void',axis='z',sections=34)
  m.cyl(t+'_'+id+'_GoldPin',.042,.034,(x,y,zz-.104),'gold',axis='z',sections=22)
  m.torus(t+'_'+id+'_LuminousEdge',.167,.011,(x,y,zz-.055),color,axis='z',segments=36,tube_segs=7,group='SocketGlow_VISUAL')
  m.text(t+'_'+id+'_Label',label,.142,x,y+.27,zz-.120,'white',maxwidth=1.20)
  m.anchors[id]=[round(x,4),round(y,4),round(zz-.116,4)]

def capplate(m,t,x,y,z,label,col='white'):
 m.bevel(t+'_Badge_BG',(.73,.17,.08),(x,y,z),'bezel',.05)
 m.text(t+'_Badge_Text',label,.14,x,y,z-.052,col,maxwidth=.7)

def power(key,side):
 m=Model(key);t='L39_'+side+'_POWER'
 chassis(m,t,side+' 5 V','ISOLATED '+side+' SUPPLY',h=1.55,side=side)
 ports(m,t)
 m.bevel(t+'_DigitalBezel',(1.36,.38,.07),(0,1.62,-1.043),'titanium',.06)
 m.bevel(t+'_DigitalScreen',(1.23,.27,.061),(0,1.62,-1.085),'screen',.04)
 m.text(t+'_Voltage_Readout_VISUAL','5.00 V',.24,0,1.62,-1.126,'screen_green',maxwidth=1.13,group='VoltageReadout_STATIC_VISUAL')
 for i in range(12):
  m.box(t+f'_CoolVent_{i:02d}',(.07,.023,.45),(-1.11+i*.20,2.09,.18),'void')
 m.box(t+'_StatusNeon',(1.08,.041,.045),(0,2.03,-.54),'green' if side=='TX' else 'mint',group='StatusLEDs_VISUAL')
 for i,x in enumerate((-.90,.90)):
  m.cyl(t+f'_PowerHeatsinkBolt{i}',.115,.042,(x,1.96,.68),'steel',sections=18)
 return m

def send_switch():
 m=Model('02_TX_SEND_Switch');t='L39_SEND'
 chassis(m,t,'SEND SWITCH','ISOLATED TRANSMITTER',side='TX')
 ports(m,t)
 m.bevel(t+'_RockerMount',(1.41,.22,1.14),(0,1.72,.06),'titanium',.085)
 m.bevel(t+'_SwitchWell',(1.19,.14,.91),(0,1.84,.08),'void',.08)
 m.bevel(t+'_RedRocker_ANIMATE',(1.03,.24,.78),(0,1.975,.07),'red',.065,group='SwitchRocker_TILT_ANIMATE')
 m.box(t+'_RockerGloss_ANIMATE',(.68,.011,.04),(0,2.099,-.11),'rose',group='SwitchRocker_TILT_ANIMATE')
 m.text(t+'_ON_3D','I',.26,0,1.36,-.50,'white',maxwidth=.35,group='SwitchRocker_TILT_ANIMATE')
 m.box(t+'_StatusSending_VISUAL',(.65,.03,.028),(0,.32,-1.054),'amber',group='SwitchStatus_VISUAL')
 for s in (-1,1):
  m.cyl(t+f'_ContactBlock_{s}',.09,.20,(s*.73,1.83,.65),'gold',sections=22)
  m.rod(t+f'_ContactLeaf_{s}',(s*.73,1.9,.65),(s*.35,2.05,.55),.04,'chrome',sections=10,group='SwitchContacts_VISUAL')
 return m

def resistor():
 m=Model('03_TX_470Ohm_LED_Limiter');t='L39_LIMIT'
 chassis(m,t,'470 Ohm LIMIT','LED CURRENT LIMIT',side='TX');ports(m,t)
 m.bevel(t+'_ResistorMount',(2.56,.14,1.21),(0,1.68,.06),'steel',.06)
 m.box(t+'_BusBar',(2.29,.068,.24),(0,1.769,.07),'void')
 m.cyl(t+'_CeramicBody',.228,1.45,(0,2.03,.09),'ceramic',axis='x',sections=46)
 for i,(x,c) in enumerate(zip((-.39,-.17,.15,.44),('yellow','violet','brown','gold'))):
  m.torus(t+f'_Band_{i}_{c}',.236,.037,(x,2.03,.09),c,axis='x',segments=46,tube_segs=8)
 for s in (-1,1):
  m.cyl(t+f'_NickelEndCap_{s}',.239,.067,(s*.74,2.03,.09),'brass',axis='x',sections=30)
  m.rod(t+f'_SilverLead_{s}',(s*.77,2.03,.09),(s*1.23,2.03,.09),.036,'chrome',sections=12)
  m.cyl(t+f'_GoldStud_{s}',.116,.22,(s*1.24,1.85,.09),'gold',sections=20)
 for x in (-1.29,1.29):
  for z in (-.62,.74):m.rod(t+f'_Pillar_{x}_{z}',(x,1.8,z),(x,2.52,z),.026,'chrome',sections=10)
 for y in (1.8,2.52):
  for z in (-.62,.74):m.rod(t+f'_SafetyRim_{y}_{z}',(-1.29,y,z),(1.29,y,z),.018,'cyan',sections=8,group='SafetyCover_VISUAL')
 return m

def opto_led():
 m=Model('04_TX_Optocoupler_LED');t='L39_OPTO_LED'
 chassis(m,t,'OPTO LED','TRANSMITTER / LIGHT',side='TX');ports(m,t)
 m.bevel(t+'_LEDSeat',(2.24,.19,1.26),(0,1.74,.06),'titanium',.07)
 m.bevel(t+'_PCB',(1.76,.067,.94),(0,1.85,.065),'pcb',.06)
 m.box(t+'_ISOLATION_LED_Socket',(.88,.25,.34),(0,1.97,.1),'void')
 m.cyl(t+'_LEDBase',.34,.19,(0,2.19,.1),'chrome',sections=40)
 m.cyl(t+'_InfraredEmitter',.205,.25,(0,2.39,.1),'rose',sections=46,group='OpticalEmitter_Glow_VISUAL')
 m.torus(t+'_EmitterHalo',.235,.03,(0,2.525,.1),'amber',axis='y',segments=50,tube_segs=8,group='OpticalEmitter_Glow_VISUAL')
 for i in range(5):m.rod(t+f'_EmitterLightRays_{i}',(0,2.45,.1),(-.45+i*.22,2.64,.38),.017,'amber',sections=9,group='OpticalEmitter_Glow_VISUAL')
 # Open-front acrylic shielding, revealing the infra-red element
 for x in (-1.14,1.14):
  for z in (-.58,.70):m.rod(t+f'_AcrylicPost_{x}_{z}',(x,1.78,z),(x,2.65,z),.029,'glass_edge',sections=9,group='AcrylicGuard_VISUAL')
 for z in (-.58,.70):m.rod(t+f'_GuardTopRail_{z}',(-1.14,2.65,z),(1.14,2.65,z),.025,'glass_edge',sections=8,group='AcrylicGuard_VISUAL')
 m.text(t+'_OpticsFrontTag','IR TX',.18,0,1.93,-.81,'amber',maxwidth=.6)
 return m

def pullup():
 m=Model('06_RX_1kOhm_Pullup');t='L39_PULLUP'
 chassis(m,t,'1 kOhm PULL-UP','RECEIVER SIDE',side='RX');ports(m,t)
 m.bevel(t+'_ResistorBed',(2.54,.14,1.19),(0,1.70,.07),'steel',.05)
 m.cyl(t+'_ResistorCeramic',.225,1.45,(0,2.06,.05),'ceramic',axis='x',sections=42)
 for i,(x,c) in enumerate(zip((-.40,-.18,.15,.43),('brown','void','red','gold'))):
  if c=='brown':c='bronze' if 'bronze' in PALETTE else 'copper'
  m.torus(t+f'_Band_{i}_{c}',.236,.036,(x,2.06,.05),c,axis='x',segments=40,tube_segs=8)
 for s in (-1,1):
  m.cyl(t+f'_EndTerminal_{s}',.243,.07,(s*.75,2.06,.05),'brass',axis='x',sections=26)
  m.rod(t+f'_AxialLead_{s}',(s*.77,2.06,.05),(s*1.25,2.06,.05),.034,'chrome',sections=11)
  m.cyl(t+f'_Attachment_{s}',.13,.23,(s*1.24,1.84,.05),'gold',sections=20)
 for x in (-1.3,1.3):
  for z in (-.62,.68):m.rod(t+f'_GuardPost_{x}_{z}',(x,1.81,z),(x,2.48,z),.027,'glass_edge',sections=9)
 for z in (-.62,.68):m.rod(t+f'_GuardTop_{z}',(-1.3,2.48,z),(1.3,2.48,z),.024,'mint',sections=8,group='GlassCover_VISUAL')
 return m

def opto_output():
 m=Model('07_RX_Optocoupler_Output');t='L39_OPTO_RX'
 chassis(m,t,'OPTO OUTPUT','C / E PHOTO TRANSISTOR',side='RX');ports(m,t)
 m.bevel(t+'_CaptureBed',(2.28,.20,1.28),(0,1.75,.07),'titanium',.07)
 m.bevel(t+'_RX_PCB',(1.73,.065,.95),(0,1.86,.07),'pcb',.05)
 m.bevel(t+'_OptoChip',(1.04,.31,.51),(0,2.10,.09),'void',.07)
 m.box(t+'_Phototransistor_Lens_VISUAL',(.24,.12,.31),(0,2.30,-.06),'violet',group='LightSensitive_VISUAL')
 m.torus(t+'_ReceiverHalo',.30,.029,(0,2.30,.09),'mint',axis='y',segments=48,tube_segs=8,group='LightSensitive_VISUAL')
 for n,x in enumerate(np.linspace(-.71,.71,6)):
  m.box(t+f'_ChipPin_{n}',(.051,.038,.42),(x,1.96,.37),'gold')
 for x in (-1.14,1.14):
  for z in (-.58,.7):m.rod(t+f'_GuardPost_{x}_{z}',(x,1.78,z),(x,2.62,z),.027,'glass_edge',sections=9,group='OpticalGuard_VISUAL')
 for z in (-.58,.7):m.rod(t+f'_GuardTop_{z}',(-1.14,2.62,z),(1.14,2.62,z),.024,'glass_edge',sections=8,group='OpticalGuard_VISUAL')
 m.text(t+'_ModuleCaption','PHOTO RX',.17,0,1.95,-.84,'mint',maxwidth=.76)
 return m

def isolated_light_gap():
 m=Model('08_VISUAL_Optical_Isolation_Barrier');t='L39_ISO_GAP'
 m.bevel(t+'_BarrierPad',(3.22,.18,1.67),(0,.13,0),'titanium',.07)
 m.bevel(t+'_BlackPartition',(3.10,.064,1.55),(0,.26,0),'graphite',.06)
 for x in (-1.33,1.33):
  m.box(t+f'_BoundaryLED_{x}',(.054,.056,1.36),(x,.335,0),'violet',group='BoundaryLED_VISUAL')
 for z in (-.55,.55):m.box(t+f'_BoundaryLED_Z_{z}',(2.74,.044,.056),(0,.332,z),'violet',group='BoundaryLED_VISUAL')
 for x in (-1.12,1.12):
  m.rod(t+f'_OpticalPost_{x}',(x,.35,0),(x,1.65,0),.038,'chrome',sections=12)
 m.box(t+'_HolographicBeamShield_VISUAL',(.08,.9,1.07),(0,1.01,0),'glass_body',group='VisualIsolationPlane')
 for k in range(8):
  xx=-.75+k*.22
  m.rod(t+f'_PhotonBeamParticle_{k}',(xx,.75,-.19),(xx+.10,1.19,.16),.024,'amber',sections=9,group='OpticalBeam_Only_ANIMATE')
 for y in (.66,1.08,1.45):m.box(t+f'_HoloBeamBar_{y}',(2.18,.024,.025),(0,y,.0),'cyan',group='OpticalBeam_Only_ANIMATE')
 m.box(t+'_DividerCross',(2.23,.032,.08),(0,1.62,0),'orange',group='OpticalBeam_Only_ANIMATE')
 m.text(t+'_CaptionTitle','OPTICAL LINK',.245,0,.31,-.864,'white',maxwidth=2.8)
 m.text(t+'_CaptionNeverWire','NO ELECTRIC CONNECTION',.135,0,.16,-.865,'amber',maxwidth=2.9)
 return m

def jumper():
 m=Model('09_VISUAL_W08_Temporary_Jumper');t='L39_W08'
 m.bevel(t+'_JumperStorageCase',(3.19,.21,1.85),(0,.17,0),'graphite',.10)
 m.bevel(t+'_SiliconeRestPad',(2.93,.046,1.61),(0,.32,0),'mid_steel',.064)
 for side in (-1,1):
  x=side*.97
  m.cyl(t+f'_BananaGrip_{side}',.155,.48,(x,.55,-.08),'violet' if side==1 else 'blue',axis='x',sections=32,group='Jumper_Removable_ANIMATE')
  m.cyl(t+f'_GoldBananaPlug_{side}',.094,.33,(x+side*.32,.55,-.08),'gold',axis='x',sections=29,group='Jumper_Removable_ANIMATE')
  m.torus(t+f'_GripCollar_{side}',.165,.035,(x-side*.1,.55,-.08),'chrome',axis='x',segments=36,tube_segs=8,group='Jumper_Removable_ANIMATE')
 # coiled insulated jumper cable not physically connecting either independent supply
 ps=[(-.72,.56,-.08),(-.53,.58,.39),(-.23,.68,.51),(.02,.78,.19),(.26,.68,-.30),(.53,.59,-.29),(.72,.55,-.08)]
 for i in range(len(ps)-1):m.rod(t+f'_CableSeg_{i}',ps[i],ps[i+1],.073,'violet',sections=16,group='Jumper_Removable_ANIMATE')
 m.text(t+'_StorageLabel','W08 TEST ONLY',.174,0,.36,-1.01,'orange',maxwidth=2.3)
 m.text(t+'_DoNotFit','DISCONNECTED BY DEFAULT',.124,0,.20,-1.02,'fog',maxwidth=2.5)
 return m

def isolation_monitor():
 m=Model('10_VISUAL_Isolation_Logic_Monitor');t='L39_MONITOR'
 chassis(m,t,'ISOLATION MONITOR','RECEIVER TEST / VISUAL',w=3.25,d=2.02,h=1.61,side='RX')
 m.bevel(t+'_ReadoutFrame',(2.83,.91,.08),(0,1.35,-1.113),'titanium',.056)
 m.bevel(t+'_OLEDReadout',(2.67,.79,.058),(0,1.35,-1.162),'screen',.051)
 m.text(t+'_MeasuredVoltage_Static','5.00 V',.42,0,1.40,-1.208,'screen_green',maxwidth=1.8,group='LiveReading_REPLACE_VISUAL')
 m.text(t+'_StatusIsolated_Static','ISOLATED',.17,0,1.09,-1.209,'mint',maxwidth=1.8,group='LiveReading_REPLACE_VISUAL')
 for i,col in enumerate(('green','cyan','orange')):
  m.cyl(t+f'_SoftKey_{i}',.11,.06,(-.78+i*.78,1.94,.35),col,sections=25,group='MonitorButtons_VISUAL')
 return m

def board():
 m=Model('00_Showcase_Base');t='L39_BOARD'
 m.bevel(t+'_Rubber_Base',(23.3,.15,11.4),(0,.085,0),'rubber',.14)
 m.bevel(t+'_Titanium_Base',(23.14,.19,11.27),(0,.21,0),'steel',.11)
 m.bevel(t+'_Black_Perforated_Panel',(22.94,.07,11.0),(0,.35,0),'graphite',.085)
 for x in (-11.31,11.31):m.box(t+f'_CyanTrimSide_{x}',(.038,.040,10.70),(x,.39,0),'cyan',group='BoardEdge_VISUAL')
 for z in (-5.43,5.43):m.box(t+f'_CyanTrimEnd_{z}',(22.54,.038,.039),(0,.39,z),'cyan',group='BoardEdge_VISUAL')
 for x in np.linspace(-11,11,45):
  for z in np.linspace(-5.15,5.15,22):m.cyl(t+f'_PegboardHole_{x:+.2f}_{z:+.2f}',.012,.003,(x,.389,z),'mid_steel',sections=6)
 # physical separation stripe with visible, insulating purple separator
 m.bevel(t+'_HighIsolationZone',(22.22,.09,.34),(0,.423,-.12),'insulator',.05)
 for x in np.linspace(-10.73,10.73,30):
  m.box(t+f'_BarrierDash_{x:+.2f}',(.41,.022,.04),(x,.478,-.12),'violet',group='IsolationBoundary_VISUAL')
 m.text(t+'_TXSection','TRANSMITTER  /  TX',.25,0,.44,5.08,'amber',maxwidth=6)
 m.text(t+'_RXSection','RECEIVER  /  RX',.25,0,.44,-5.13,'mint',maxwidth=6)
 return m

BUILDERS=[
 lambda:power('01_TX_5V_Independent_Supply','TX'),
 send_switch,resistor,opto_led,
 lambda:power('05_RX_5V_Independent_Supply','RX'),
 pullup,opto_output,
 isolated_light_gap,jumper,isolation_monitor
]
POSITIONS={
 '01_TX_5V_Independent_Supply':(8.26,0,3.09),
 '02_TX_SEND_Switch':(3.54,0,3.09),
 '03_TX_470Ohm_LED_Limiter':(-1.20,0,3.09),
 '04_TX_Optocoupler_LED':(-5.96,0,3.09),
 '05_RX_5V_Independent_Supply':(8.26,0,-3.05),
 '06_RX_1kOhm_Pullup':(3.54,0,-3.05),
 '07_RX_Optocoupler_Output':(-1.20,0,-3.05),
 '08_VISUAL_Optical_Isolation_Barrier':(-5.96,0,-.10),
 '09_VISUAL_W08_Temporary_Jumper':(-5.96,0,-3.05),
 '10_VISUAL_Isolation_Logic_Monitor':(3.54,0,.09),
 '00_Showcase_Base':(0,0,0),
}

def build():
 models=[builder() for builder in BUILDERS]
 pins=[k for m in models[:7] for k in m.anchors]
 assert len(models)==10
 assert len(pins)==14 and len(set(pins))==14, pins
 assert len(WIRES)==8 and all(a in pins and b in pins for _,a,b in WIRES)
 catalog={}
 for m in models:
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m]);
  catalog[m.key]={'fbx':fbx.name,'glb':glb.name,'triangles':sum(len(p.mesh.faces) for p in m.parts),
    'mesh_objects':len(m.parts),'terminal_anchors':m.anchors,
    'animation_groups':list(dict.fromkeys(p.group for p in m.parts if p.group!='Static'))}
  print('EXPORTED',m.key,'triangles',catalog[m.key]['triangles'],'meshes',len(m.parts),flush=True)
 all_models=[board()]+models
 showcase=MODELS/'Level39_Complete_ArtKit_Showcase.fbx'
 showcaseglb=MODELS/'Level39_Complete_ArtKit_Showcase.glb'
 export_fbx(showcase,all_models,positions=POSITIONS)
 export_glb(showcaseglb,all_models,positions=POSITIONS)
 catalog['Level39_Complete_ArtKit_Showcase']={'fbx':showcase.name,'glb':showcaseglb.name,
 'triangles':sum(len(p.mesh.faces) for m in all_models for p in m.parts),
 'mesh_objects':sum(len(m.parts) for m in all_models)}
 manifest={'level':39,'name':'Across the Isolation Gap','theme':'Futuristic semi-HD electronic optocoupler trainer',
  'individual_models':10,'electrical_models':7,'visual_only_models':3,'electrical_terminal_anchors':14,
  'permanent_wires':7,'temporary_test_jumpers':1,
  'coordinate_system':'Y-up, front faces local -Z; art units; see CSV for positions',
  'wire_map':[{'id':wire,'from':src,'to':dst,'temporary':wire=='W08'} for wire,src,dst in WIRES],
  'showcase_positions':POSITIONS,'models':catalog,
  'warning':'Optical barrier is NOT a wire. W08 jumper is a detached display prop, not an installed wire. Meshes are visuals, not SparkTerminal or electrical components.'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['Wire','From','To','Notes']);
  for wire,a,b in WIRES:w.writerow([wire,a,b,'TEMPORARY ONLY: REMOVE TO VERIFY ISOLATION' if wire=='W08' else 'PERMANENT'])
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['FBX','Runtime terminal ID suggestion','Local X','Local Y','Local Z','Visual socket mesh only'])
  for m in models[:7]:
   for pin,xyz in m.anchors.items():w.writerow([m.key+'.fbx',pin,*xyz,'Create actual SparkTerminal here'])
 print('SUCCESS: 10 individual FBXs+GLBs, complete showcase, 14 ports, W01-W08',flush=True)

if __name__=='__main__':build()
