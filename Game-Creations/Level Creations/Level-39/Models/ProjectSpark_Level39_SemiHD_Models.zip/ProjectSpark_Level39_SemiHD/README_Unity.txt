PROJECT SPARK — LEVEL 39 / ACROSS THE ISOLATION GAP
POLISHED SEMI-HD FBX / GLB MODEL KIT
======================================

PACKAGE
-------
Ten individual art props as FBX 7.4 binary and matching GLB files.
One combined showcase assembly as FBX + GLB.
Actual rendered previews and contact sheet; a model/animation manifest;
Terminal_Anchors.csv; Exact_Wiring.csv; editable Python mesh/render source.

PLAYABLE ELECTRICAL ART PROPS (7 MODELS, 14 SOCKET LOCATIONS)
--------------------------------------------------------------
01_TX_5V_Independent_Supply.fbx       TX_Positive, TX_Return
02_TX_SEND_Switch.fbx                 SEND_IN, SEND_OUT
03_TX_470Ohm_LED_Limiter.fbx          TX_R_IN, TX_R_OUT
04_TX_Optocoupler_LED.fbx             OPTO_A, OPTO_K
05_RX_5V_Independent_Supply.fbx       RX_Positive, RX_Return
06_RX_1kOhm_Pullup.fbx                PULLUP_IN, PULLUP_OUT
07_RX_Optocoupler_Output.fbx          OPTO_C, OPTO_E

VISUAL-ONLY PROPS (3 MODELS, NO ELECTRICAL TERMINALS)
-----------------------------------------------------
08_VISUAL_Optical_Isolation_Barrier.fbx   Illuminated optical path, purple isolation divide
09_VISUAL_W08_Temporary_Jumper.fbx      Loose jumper stored OFF circuit by default
10_VISUAL_Isolation_Logic_Monitor.fbx   Reference OLED: 5.00 V / ISOLATED (static mesh)

WIRE MAP — MATCHES LEVEL39_Exact_Workbench_Wiring.png
------------------------------------------------------
W01 TX_Positive  -> SEND_IN
W02 SEND_OUT     -> TX_R_IN
W03 TX_R_OUT     -> OPTO_A
W04 OPTO_K       -> TX_Return
W05 RX_Positive  -> PULLUP_IN
W06 PULLUP_OUT   -> OPTO_C
W07 OPTO_E       -> RX_Return
W08 TX_Return    -> RX_Return  (TEMPORARY TEST-ONLY JUMPER; REMOVE)

IMPORTANT ISOLATION RULE
------------------------
TX and RX are entirely separate 5 V circuits, connected OPTICALLY through
an optocoupler, not by a copper wire. Keep TX_Return and RX_Return separate
except during the level's deliberate temporary bridge fault demonstration.
W08 model is a DISCONNECTED cable prop, NOT a permanently installed wire.
The displayed optical beam is LIGHT ONLY, NOT a SparkSingleWire.

EXPECTED RECEIVER TEST STATES (from provided Level 39 reference)
----------------------------------------------------------------
SEND off:  RX approx. 5 V, isolated
SEND on:   RX approx. 0 V, isolated
RX power off: receiver unpowered, isolated
Return jumper fitted: RX approx. 0 V, bridged

UNITY IMPORT STEPS
------------------
1. Import Models/ into Assets/My_Assets/_Project_Spark/Models/Level39/.
2. For gameplay, instantiate SEVEN INDIVIDUAL ELECTRICAL props, not the
   combined showcase. Showcase FBX is a display staging layout only.
3. This art uses local Y-up, front facing local -Z. If the FBX is rotated
   by Unity's importer, use a parent transform and preserve child local
   anchors; inspect scale against your existing workbench.
4. Put each actual SparkTerminal GameObject at positions listed in
   Terminal_Anchors.csv underneath the corresponding electrical object.
   SOCKET MESHES ARE VISUAL ONLY AND DO NOT CREATE TERMINALS.
5. Assign your existing electrical components and IDs, matching the
   Level_39_Layout's real SparkLevelSceneBindings and binding bridge.
   Suggested IDs in the CSV should be mapped to your actual IDs rather
   than copied blindly into fixed lists.
6. Where your simulation models the optocoupler as ONE four-terminal
   component, keep both LED and phototransistor half-meshes as children
   of that existing component/controller. Do not create TWO conflicting
   SparkElectricalComponent simulations just because there are 2 props.
7. Drive the SEND rocker using your existing switch input controller.
   Group "SwitchRocker_TILT_ANIMATE" contains the movable visual meshes.
8. "OpticalEmitter_Glow_VISUAL", "OpticalBeam_Only_ANIMATE", and
   "LightSensitive_VISUAL" can be enabled/intensified in response to the
   actual solved optocoupler state. Do not treat them as solver results.
9. The W08 jumper cable is optional visual/interaction content. When the
   test requires a real jumper, place a connection via SparkCircuitSystem;
   merely showing the mesh must NOT bridge the electrical grounds.
10. The monitor's "LiveReading_REPLACE_VISUAL" text is STATIC geometry.
    Hide it and use TMPro or a dynamic texture for actual RX voltage.
11. Apply project URP/HDRP/Standard materials to the imported material
    slots to achieve the intended polished semi-HD look: dark gunmetal,
    satin nickel, gold socket contacts, brushed aluminum, acrylic
    transparency, cyan/mint emissive strips, amber TX glow, purple barrier.

MODELING / FILE NOTES
---------------------
These are generated mesh assets with named animation groups and colored
material IDs, not ready-to-play prefabs or attached Unity scripts.
The exports have been structurally inspected as files and GLB meshes loaded;
Unity import, transparency, normals, colliders and actual animation
pivots have NOT been tested in the user's Unity project.

One FBX per model; FBX 7.4 binary; GLB backup; Python sources included.
FBX models intentionally avoid using shared solver modifications.

PROJECT SPARK — LEVEL 39 — VISUAL ASSET PACK
