PROJECT SPARK — LEVEL 61 / CLEAN THE WAVE
PROCEDURAL 3D VISUAL ASSET COLLECTION — ART ONLY

MODELS: 30 individual FBX 7.4 binary files plus assembled showcase FBX; 30 individual GLB backups plus showcase GLB.
IMPORT:
1. Copy Models/*.fbx into Assets/ProjectSpark/Level61/Art/ in Unity.
2. Inspect import scale and materials; meshes share a common coordinate system (X bench width, Y up, Z facing player).
3. Select your Level 61 layout GameObject in Unity hierarchy.
4. Copy Unity_Optional/SparkLevel61ArtPlacementEditor.cs into an Editor folder.
5. Choose Tools > Project Spark > Levels > 61 > Place HD Art Under Selected Layout.
6. Confirm import material setup and pivot grouping. The tool instantiates 30 FBXs under L61_HD_VISUAL_ART.
7. Do not enable the complete showcase mesh alongside the individual models.
8. Assign gameplay references, SparkTerminal anchors, source/load simulation, and objective evaluator separately.

The art kit has NO verified 50-wire electrical topology, 78 real SparkTerminal instances, harmonic simulation, or six working objectives.
Animation_Rigs.csv gives proposed art pivots for motor, contactors, fan, monitor and door.
Import and Play Mode were NOT tested inside Unity.
FBX contains named material regions, not finished production PBR textures. GLB uses vertex-color materials.
