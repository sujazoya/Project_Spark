import os,sys,json,csv,math,pathlib,zipfile,hashlib,shutil
import numpy as np,trimesh
sys.path.insert(0,'/mnt/data/ProjectSpark_Level57_HD_AAA/Source')
import l57_core as c
from l57_core import box,cyl,ann,tor,beam,bolt,led,text_geo,cable
ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level61_HD_AAA')
for d in ['Models','GLB','Previews','Unity_Optional','Source']:(ROOT/d).mkdir(parents=True,exist_ok=True)
c.ROOT=ROOT;c.assets=[]
NAMES=['IndustrialPowerQualityBase','ThreePhaseGridSource','ThreePhaseDistributionBus','MainPowerContactor','NonlinearVFDLoad','IndustrialMotorLoad','RectifierLoadModule','SwitchedModePowerLoad','ActiveHarmonicFilter','FilterPowerConverter','FilterInductorBank','FilterDCCapacitor','PowerFactorCapacitorBank','CapacitorSwitchingContactor','CapacitorProtectionModule','GridVoltageSensor','SourceCurrentTransformerBank','LoadCurrentTransformerBank','FilterCurrentTransformerBank','HarmonicSpectrumAnalyzer','PowerQualityMeter','PhaseReferencePLL','HarmonicDetectionController','ActiveFilterController','ReactivePowerController','ThermalCoolingAssembly','ProtectionRelayModule','HolographicWaveformMonitor','TransparentSafetyEnclosure','Regulated5VControlSupply']
c.MODELS=['L61_'+n for n in NAMES]
def b(n,x,y,z,w,h,d,mat='blue_steel',group=None):box(n,(x,y,z),(w,h,d),mat,group)
def txt(n,s,x,y,z,span=.8,size=.07,mat='white'):text_geo(n,s,(x,y,z),span,size,mat)
def jacks(n,x,y,z,count=5,span=.8):
 for i in range(count):
  xx=x+(i-(count-1)/2)*span/max(1,count-1)
  cyl(n+'_Bezel'+str(i),(xx,y,z),.064,.022,'z','chrome',20)
  cyl(n+'_Color'+str(i),(xx,y,z+.018),.047,.015,'z',['red','amber','electric','cyan','green'][i%5],18)
  cyl(n+'_Dark'+str(i),(xx,y,z+.03),.023,.008,'z','dark',14)
def chassis(n,x,y,z,w,h,d,accent='cyan',sockets=5):
 b(n+'_Housing',x,y,z,w,h,d,'blue_steel')
 b(n+'_FrontPanel',x,y,z+d/2+.012,w-.065,h-.085,.03,'navy')
 b(n+'_TopCap',x,y+h/2+.018,z,w+.035,.045,d+.04,'silver_dark')
 b(n+'_Accent',x,y+h/2+.046,z+d*.35,w-.12,.018,.026,accent)
 for sx in [-1,1]:
  for sy in [-1,1]:bolt(n+f'_Bolt{sx}{sy}',(x+sx*(w/2-.09),y+sy*(h/2-.10),z+d/2+.035),'z',.028)
 txt(n+'_Title',n.replace('_',' ').upper(),x-w*.43,y+h*.26,z+d/2+.041,w*.85,.062)
 led(n+'_PowerLED',(x-w*.37,y+.015,z+d/2+.042),'green',.035,'z')
 jacks(n+'_Jacks',x,y-h*.25,z+d/2+.045,sockets,w-.20)
def screen(n,x,y,z,w=.68,h=.27,accent='cyan'):
 b(n+'_DarkGlass',x,y,z,w,h,.022,'display')
 for q in range(11):
  px=x-w*.43+q*w*.086
  beam(n+f'_Wave{q}',(px,y+.027*math.sin(q*1.3)-.022,z+.016),(px+w*.07,y+.027*math.sin((q+1)*1.3)-.022,z+.016),.006,accent,6)
def inds(n,x,y,z,num=3,accent='copper'):
 for k in range(num):
  xx=x+(k-(num-1)/2)*.33
  b(n+f'_IronCore{k}',xx,y,z,.23,.48,.38,'silver_dark')
  for q in range(11):
   yy=y-.2+q*.04
   beam(n+f'_Winding{k}_{q}',(xx-.10,yy,z+.205),(xx+.10,yy,z+.205),.013,accent,8)
  b(n+f'_Foot{k}',xx,y-.27,z,.30,.075,.45,'dark')
def caps(n,x,y,z,num=5,accent='silver'):
 for k in range(num):
  xx=x+(k-(num-1)/2)*.22
  cyl(n+f'_CapBody{k}',(xx,y,z),.09,.50,'y',accent,24)
  cyl(n+f'_CapTop{k}',(xx,y+.26,z),.091,.025,'y','chrome',20)
  for delta in [-.042,.042]:cyl(n+f'_Terminal{k}_{delta}',(xx+delta,y+.30,z),.014,.08,'y','copper',12)
def ct_rings(n,x,y,z):
 for k in range(3):
  xx=x+(k-1)*.34
  ann(n+f'_Core{k}',(xx,y,z),.23,.135,.15,'z','silver_dark',48)
  ann(n+f'_CopperCoil{k}',(xx,y,z+.07),.192,.161,.068,'z','copper',44)
  for j in range(10):
   a=2*math.pi*j/10
   cyl(n+f'_WindStud{k}_{j}',(xx+.178*math.cos(a),y+.178*math.sin(a),z+.11),.012,.045,'z','amber',8)
 b(n+'_Base',x,y-.37,z,.98,.12,.55,'carbon')
# base
c.start(0)
b('BrushedTitaniumBench',0,.12,0,11.4,.38,6.45,'titanium');b('CarbonDeck',0,.35,0,11.22,.07,6.27,'carbon')
b('FrontPatchRail',0,.64,2.84,11.18,.46,.48,'navy')
for k in range(48):cyl(f'FrontSocket_{k}',(-5.4+k*.23,.61,3.095),.045,.015,'z','chrome',12)
for z in [-3.12,3.13]:b('CyanDeckEdge',0,.36,z,11.15,.033,.027,'cyan')
for x in [-5.5,5.5]:b('SilverSideEdge',x,.36,0,.045,.045,6.2,'chrome')
for x in [-5.25,5.25]:
 for z in [-2.85,2.85]:cyl('BenchRubberFoot',(x,-.18,z),.18,.26,'y','rubber',20)
txt('ProjectLogo','PROJECT SPARK / LEVEL 61 - CLEAN THE WAVE',-2.7,.73,3.09,5.6,.13)
# grid source
c.start(1);chassis('ThreePhaseGridSource',-4.83,1.41,-2.28,1.35,1.66,.82,'cyan',3);screen('ACWave',-4.83,1.57,-1.84,.82,.40)
for k,col in enumerate(['red','amber','electric']):cyl('PhasePlug',(-5.17+k*.35,1.03,-1.82),.07,.07,'z',col,20)
# bus
c.start(2);b('BusClearShield',0,2.10,-.95,8.7,1.17,.055,'acrylic')
for k,(yy,col,ph) in enumerate([(2.47,'red','L1'),(2.10,'amber','L2'),(1.73,'electric','L3')]):
 beam('PhaseCopper'+ph,(-4.48,yy,-.83),(4.48,yy,-.83),.073,col,24)
 for xx in [-4,-2,0,2,4]:
  b('CeramicBusInsulator',xx,yy-.14,-1.03,.20,.29,.26,'white');bolt('BusBolt',(xx,yy+.075,-.72),'y',.052)
 txt('PhaseLabel'+ph,ph,4.50,yy+.10,-.68,.42,.09)
for xx in [-4.52,4.52]:b('BusSupportTower',xx,2.08,-.96,.14,1.30,.28,'titanium')
# contactor
c.start(3);chassis('MainPowerContactor',-3.46,.99,.84,1.15,1.00,.71,'cyan',4)
for k in range(3):
 xx=-3.76+k*.30;b('ContactorBlade'+str(k),xx,1.18,1.26,.12,.29,.11,'chrome','ANIM_MAIN_CONTACTOR')
c.current.pivot('ANIM_MAIN_CONTACTOR',(-3.48,1.16,1.25))
# VFD
c.start(4);chassis('NonlinearVFDLoad',-5.03,1.11,.17,1.12,1.20,.74,'amber',5);screen('VFDfreq',-5.03,1.24,.56,.65,.28)
for k in range(2):tor('VFDCoolingFan',(-5.03+k*.28,.80,.57),.09,.018,'z','chrome',20,8)
# motor
c.start(5);b('MotorPlinth',-3.88,.68,-2.35,1.28,.28,1.08,'carbon')
cyl('MotorMainBody',(-3.91,1.21,-2.30),.38,1.07,'x','blue_steel',48,'ANIM_MOTOR_SPIN')
for k in range(17):b('MotorHeatsinkRib',-4.37+k*.058,1.58,-2.30,.027,.095,.65,'silver')
cyl('MotorOutputShaft',(-3.14,1.21,-2.30),.105,.51,'x','chrome',24,'ANIM_MOTOR_SPIN')
c.current.pivot('ANIM_MOTOR_SPIN',(-3.91,1.21,-2.30))
# rectifier
c.start(6);chassis('RectifierLoadModule',-2.61,1.01,-2.35,1.13,1.07,.76,'amber',5)
for k in range(6):b('RectifierFin',-3.04+k*.17,1.62,-2.35,.08,.26,.64,'silver_dark')
# SMPS
c.start(7);chassis('SwitchedModePowerLoad',-1.23,1.02,-2.35,1.18,1.11,.70,'amber',5)
for i in range(13):b('VentOpening',-1.71+i*.08,1.40,-1.96,.038,.085,.014,'silver')
# active filter main cabinet center
c.start(8);chassis('ActiveHarmonicFilter',.47,1.13,.78,2.22,1.30,.94,'cyan',7)
b('ActiveFilterInspectionWindow',.47,1.20,1.275,1.08,.64,.024,'acrylic')
for i in range(4):
 xx=.02+i*.29;cyl('PowerStageCapacitor',(xx,1.17,1.31),.072,.28,'y','copper',16)
for i in range(3):tor('FanIntake'+str(i),(-.18+i*.63,.69,1.29),.105,.02,'z','chrome',32,8)
screen('FilterStatus',1.03,1.22,1.31,.43,.43)
# converter separate
c.start(9);chassis('FilterPowerConverter',.34,1.19,-2.27,1.48,1.28,.78,'cyan',6)
for k in range(9):b('IGBTHeatsinkBlade',-.30+k*.16,1.88,-2.27,.055,.30,.66,'silver_dark')
# inductor bank
c.start(10);b('FilterInductorFoundation',2.25,.65,.98,1.42,.26,.88,'carbon');inds('LCL_FilterCoil',2.25,1.08,.97,3,'copper')
# dc cap
c.start(11);b('DCCapacitorMount',1.95,.64,-2.31,1.43,.23,.73,'carbon');caps('DCLink',1.95,1.12,-2.30,5,'silver')
# PF capacitor bank
c.start(12);chassis('PowerFactorCapacitorBank',4.45,1.04,.81,2.02,1.10,.82,'amber',6);caps('PFCStages',4.45,1.76,.80,7,'silver')
# cap switching contactor
c.start(13);chassis('CapacitorSwitchingContactor',3.55,1.06,-2.25,1.07,.99,.74,'amber',4)
for i in range(3):b('CapSwitchArmature',3.24+i*.30,1.20,-1.84,.10,.30,.08,'silver','ANIM_CAP_CONTACTOR')
c.current.pivot('ANIM_CAP_CONTACTOR',(3.55,1.18,-1.84))
# cap protection
c.start(14);chassis('CapacitorProtectionModule',4.92,.99,-2.25,1.17,.99,.74,'red',4)
for i in range(3):led('TripIndicator',(4.65+i*.26,.86,-1.83),['green','amber','red'][i],.045,'z')
# voltage sensor
c.start(15);chassis('GridVoltageSensor',-5.02,.91,1.90,1.10,.83,.68,'cyan',4);screen('GridVoltageLCD',-5.02,1.01,2.25,.60,.20)
# 3 CT groups
for idx,x,name in [(16,-3.47,'SourceCurrentTransformerBank'),(17,-1.88,'LoadCurrentTransformerBank'),(18,1.88,'FilterCurrentTransformerBank')]:
 c.start(idx);ct_rings(name,x,1.16,.13);jacks('CT_Signals',x,.62,.51,4,.65)
# harmonic spectrum analyzer
c.start(19);chassis('HarmonicSpectrumAnalyzer',-4.52,2.92,-2.40,1.66,1.11,.60,'cyan',5)
b('SpectrumScreen',-4.52,2.99,-2.075,1.17,.54,.025,'display')
for k in range(11):
 xx=-5.04+k*.104
 b('HarmonicBar'+str(k),xx,2.81+.08*(1+math.sin(k*1.11)), -2.05,.065,.16+.15*abs(math.sin(k*1.13)),.024,'cyan')
# PQ meter
c.start(20);chassis('PowerQualityMeter',-2.78,2.98,-2.38,1.58,1.09,.64,'cyan',4);screen('PQ_Measure',-2.78,3.10,-2.03,.85,.36)
# PLL
c.start(21);chassis('PhaseReferencePLL',-1.26,2.97,-2.39,1.12,1.04,.65,'cyan',4)
for k in range(2):ann('PLLPhaseRing'+str(k),(-1.26,3.01,-2.02+k*.018),.18,.17,.012,'z','cyan',40)
# harmonic detect controller
c.start(22);chassis('HarmonicDetectionController',.22,2.94,-2.35,1.59,1.02,.66,'cyan',5);screen('DetectionDisplay',.22,3.06,-1.99,.82,.28)
# active filter controller
c.start(23);chassis('ActiveFilterController',2.03,2.92,-2.31,1.63,1.08,.70,'cyan',7);screen('FilterControllerDisplay',2.03,3.05,-1.92,.93,.32)
# reactive controller
c.start(24);chassis('ReactivePowerController',3.96,2.91,-2.31,1.69,1.07,.68,'amber',6);screen('VarControlDisplay',3.96,3.04,-1.93,.87,.30)
# cooling
c.start(25);chassis('ThermalCoolingAssembly',5.02,.99,.11,1.20,.98,.86,'cyan',2)
for i in range(2):
 xx=4.75+i*.52
 tor('CoolingFanBezel'+str(i),(xx,1.10,.57),.21,.026,'z','silver',36,8)
 for j in range(5):
  a=2*math.pi*j/5
  b('CoolingBlade',xx+.105*math.cos(a),1.10+.105*math.sin(a),.60,.10,.055,.02,'electric','ANIM_COOLING_FANS')
c.current.pivot('ANIM_COOLING_FANS',(5.02,1.10,.57))
# protection
c.start(26);chassis('ProtectionRelayModule',5.00,2.96,-2.30,1.16,1.08,.68,'red',4);screen('ProtectionLCD',5.00,3.07,-1.91,.64,.22)
# display tower, right rear
c.start(27);b('MonitorStand',4.50,1.47,-.41,.18,1.76,.26,'silver_dark')
b('MonitorFrame',3.93,3.22,-.42,3.24,1.50,.20,'blue_steel')
b('DisplayGlass',3.93,3.22,-.30,3.05,1.31,.023,'display','ANIM_MONITOR_TILT')
txt('HolographicTitle','POWER QUALITY / HARMONIC ANALYSIS',2.49,3.75,-.275,2.88,.084)
for k in range(27):
 xx=2.54+k*.103
 for j in range(2):
  yy=3.41-j*.48
  amp=.14 if j==0 else .12
  wob=.045*math.sin(k*2.2) if j==0 else 0
  beam(f'Waveline_{j}_{k}',(xx,yy+amp*math.sin(k*.50)+wob,-.263),(xx+.101,yy+amp*math.sin((k+1)*.50)+(.045*math.sin((k+1)*2.2) if j==0 else 0),-.263),.007,'amber' if j==0 else 'cyan',6,'ANIM_MONITOR_TILT')
c.current.pivot('ANIM_MONITOR_TILT',(4.00,3.22,-.40))
# safety enclosure
c.start(28)
for xx in [-3.38,3.27]:
 for zz in [-1.35,1.54]:beam('EnclosurePost',(xx,.51,zz),(xx,2.38,zz),.031,'acrylic_rim',10)
for yy in [.51,2.38]:
 for zz in [-1.35,1.54]:beam('EnclosureBeam',(-3.38,yy,zz),(3.27,yy,zz),.027,'acrylic_rim',10)
 for xx in [-3.38,3.27]:beam('EnclosureSide', (xx,yy,-1.35),(xx,yy,1.54),.026,'acrylic_rim',10)
b('TransparentSlidingDoor',-.08,1.45,1.57,6.55,1.72,.017,'acrylic','ANIM_SAFETY_DOOR')
c.current.pivot('ANIM_SAFETY_DOOR',(-3.38,2.38,1.57))
# 5V
c.start(29);chassis('Regulated5VControlSupply',-4.98,.99,.99,1.14,.99,.67,'cyan',2)
screen('VoltageReadout',-4.98,1.12,1.36,.62,.28)
txt('Supply5Volts','5.00 V',-5.24,1.12,1.381,.52,.075)
# export
manifest={'levelId':'level_61','displayName':'Clean the Wave','subtitle':'Active Harmonic Filtering and Power Quality','models':[],'modelCount':30,'plannedPlayerWires':50,'plannedUniqueSockets':78,'electricalTerminalsImplemented':False,'electricalSimulationImplemented':False,'unityPlayModeTested':False,'assetType':'procedural modular 3D art; AAA-inspired, not hand-authored AAA PBR','coordinateSystem':'Y up, X bench width, Z front; common shared 3D coordinates, 1 art unit nominally 1 meter'}
for i,a in enumerate(c.assets):
 fn=f'{i:02d}_{a.name}'
 c.fbx_export([a],ROOT/'Models'/f'{fn}.fbx',a.name)
 c.glb_export(a,ROOT/'GLB'/f'{fn}.glb')
 nf=sum(len(p.mesh.faces) for p in a.parts)
 manifest['models'].append({'name':a.name,'fbx':fn+'.fbx','glb':fn+'.glb','triangles':nf,'meshParts':len(a.parts),'animationPivots':{k:v.tolist() for k,v in a.groups.items()}})
 print(fn,nf,flush=True)
c.fbx_export(c.assets,ROOT/'Models'/'Level61_Complete_ArtKit_Showcase.fbx','L61_ArtShowcase')
sc=trimesh.Scene()
for a in c.assets:
 for part in a.parts:
  m=part.mesh.copy();m.visual.vertex_colors=np.tile((np.array(c.C[part.mat])*255).astype('uint8'),(len(m.vertices),1))
  sc.add_geometry(m,geom_name=a.name+'__'+part.name)
(ROOT/'GLB'/'Level61_Complete_ArtKit_Showcase.glb').write_bytes(sc.export(file_type='glb'))
manifest['totalTriangles']=sum(m['triangles'] for m in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['model','pivot','x','y','z'])
 for a in c.assets:
  for nm,xyz in a.groups.items():wr.writerow([a.name,nm,*xyz.tolist()])
print('FINISHED',manifest['totalTriangles'])
