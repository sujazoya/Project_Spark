PROJECT SPARK — LEVEL 47: HOLD THE TENSION
AAA-STYLE POLISHED SEMI-HD FBX MODEL PACK

PACKAGE
14 independent FBX visual models + 14 matching GLBs.
1 assembled FBX and matching GLB. Showcase includes a decorative bench.
No solver modifications, gameplay authority, or level definition assets.

DESIGN
Active dancer-controlled roll-to-roll winding.
FEED (cyan) = unwind spool / DC motor / encoder + feed brake.
TAKE-UP (amber) = winding spool / DC motor / encoder.
Center = dancer roller + adjustable arm + spring + feedback sensor.
Back = tension controller, telemetry display and supply.
Front = dual motor driver and accessible socket region.

USING THE FBX FILES
1. Unzip the package into Assets/My_Assets/_Project_Spark/Art/Level47/.
2. Import the individual FBX meshes under Models/; keep the assembled FBX for layout reference.
3. FBX units are relative. Y axis is up, -Z is component/front-face direction.
4. In the Level_47_Layout prefab place the parts using Model_Manifest.json -> positions.
5. Scale / align meshes to your actual workbench BEFORE creating SparkTerminal references.
6. For each entry in Terminal_Anchors.csv create or position an actual SparkTerminal
   at that local art coordinate, then register the real Project Spark binding ID.
   These mesh sockets ARE NOT electrical SparkTerminal components.
7. Use World_Terminal_Anchors.csv for unscaled assembled showcase-space locations.
8. Wires W01-W15 are in Exact_Wiring.csv. W15 is the tension-sensor signal and must be
   added last if you want Undo Last to disconnect exactly that sensor signal.
9. Both +5V and RETURN supply sockets each accept multiple wire ends.
10. Driver and encoder power not covered by player wires must be implemented as valid
    project-specific FIXED connections, not assumed magically powered.

FBX ANIMATION GROUPS
Look in Animation_Rigs.csv for exact names and local pivots.
FeedMotorShaft_ROTATE_Z; TakeupMotorShaft_ROTATE_Z.
FeedSpool_ROTATE_Z; TakeupSpool_ROTATE_Z.
FeedWoundMaterial_ROTATE_Z_SCALE_XY; TakeupWoundMaterial_ROTATE_Z_SCALE_XY.
FeedEncoderDisc_ROTATE_Z; TakeupEncoderDisc_ROTATE_Z.
DancerArm_ROTATE_Z; DancerRoller_ROTATE_Z.
TensionSensorWiper_ROTATE_Y.
FeedBrakeRotor_ROTATE_Z; FeedBrakeLever_ROTATE_Z; FeedBrakePad_TRANSLATE_X.

The optional Unity_Optional/SparkLevel47VisualRig.cs reads actual RPM, dancer angle,
brake setting and material progress from YOUR gameplay system when SetVisualState is called.
It does not calculate electrical current, voltage, tension or objective completion.
Do not use this component to create fabricated simulator measurements.

TEXT / UI
The tension monitor, 5 V supply, controller and sensor have blank inset screen meshes.
Add TextMeshPro or a RenderTexture screen in Unity to display live tension voltage,
FEED RPM, TAKE-UP RPM, dancer angle, brake load, and 6-objective status.
Recommended physical label parent scale ~0.20 X/Y if compatible with your scene.
The colored LEDs are separate mesh groups for animations or MaterialPropertyBlock updates.

MATERIALS
The GLB files can serve as color-preserving visual backups if Unity's FBX materials
are not imported as intended. Rebuild physically-based materials in Unity for true AAA
surface appearance: dark titanium, nickel, brushed silver, cyan/amber emission,
matte belt rubber, translucent frosted film and spring steel.
Caution: FBX translucent film may render opaque depending on the Unity material shader.

PERFORMANCE
The showcase is approximately 154k triangles, with hundreds of individually named meshes.
Combine STATIC small decorative meshes (with care) for runtime draw-call reduction.
Do NOT combine rotating pivots, buttons, indicator lenses, moving rollers or wound layers.
Some FBX importers flip front orientation; verify in the imported model viewer.

VERIFICATION
All FBX files were structurally checked and matching GLB meshes loaded in this
runtime. Visuals were rendered from the actual procedural mesh geometry.
The package ZIP is independently checked for integrity.
Unity FBX import, exact material appearance, rig behavior and gameplay
integration remain untested inside YOUR Unity project.

SOURCE
Sources/build_level47_models.py — editable model generator.
Sources/spark_model_core.py — FBX/GLB writer and geometry utilities.
Sources/render_level47_previews.py — VTK renders of actual mesh objects.

LEVEL 47 PLAYER WIRING (ART SOCKET IDs — replace with actual runtime binding IDs)
W01: SUPPLY_PLUS_5V  -> CTRL_PLUS_5V
W02: SUPPLY_RETURN   -> CTRL_GND
W03: CTRL_FEED_PWM   -> DRIVER_FEED_PWM
W04: CTRL_TAKEUP_PWM -> DRIVER_TAKEUP_PWM
W05: DRIVER_FEED_PLUS -> FEED_MOTOR_PLUS
W06: DRIVER_FEED_MINUS -> FEED_MOTOR_MINUS
W07: DRIVER_TAKEUP_PLUS -> TAKEUP_MOTOR_PLUS
W08: DRIVER_TAKEUP_MINUS -> TAKEUP_MOTOR_MINUS
W09: FEED_ENC_A -> CTRL_FEED_A
W10: FEED_ENC_B -> CTRL_FEED_B
W11: TAKEUP_ENC_A -> CTRL_TAKEUP_A
W12: TAKEUP_ENC_B -> CTRL_TAKEUP_B
W13: SUPPLY_PLUS_5V -> SENSOR_PLUS_5V
W14: SUPPLY_RETURN  -> SENSOR_GND
W15: SENSOR_SIGNAL  -> CTRL_TENSION_IN

PROJECT SPARK — LEVEL 47 — VISUAL ART DELIVERY
