"""Actual Level 47 triangle mesh previews rendered offscreen using VTK.
No AI mockups: display corresponds to procedural FBX/GLB geometry.
"""
from build_level47_models import *
from pathlib import Path
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from PIL import Image,ImageFont,ImageDraw
import numpy as np
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
P=ROOT/'Previews'

def actor_for(part, offset=(0,0,0)):
 mesh=part.mesh;poly=vtk.vtkPolyData()
 xyz=np.ascontiguousarray(np.asarray(mesh.vertices,dtype=np.float32)+np.asarray(offset,dtype=np.float32),dtype=np.float32)
 pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(xyz,deep=1));poly.SetPoints(pts)
 faces=np.ascontiguousarray(mesh.faces,dtype=np.int64)
 cc=vtk.vtkCellArray();arr=np.column_stack((np.full(len(faces),3,dtype=np.int64),faces)).reshape(-1)
 cc.SetCells(len(faces),numpy_to_vtkIdTypeArray(arr,deep=1));poly.SetPolys(cc)
 norms=vtk.vtkPolyDataNormals();norms.SetInputData(poly);norms.SplittingOff();norms.ConsistencyOn()
 mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norms.GetOutputPort())
 actor=vtk.vtkActor();actor.SetMapper(mapper)
 rgb=np.asarray(PALETTE[part.mat][:3],dtype=float)/255.;prop=actor.GetProperty()
 prop.SetColor(*rgb);prop.SetAmbient(.43);prop.SetDiffuse(.59)
 reflective=part.mat in ('chrome','titanium','steel','gold','copper','orange','orange_hi','mid_steel','brass','aluminum','polished')
 prop.SetSpecular(.70 if reflective else .25);prop.SetSpecularPower(83 if reflective else 32)
 if part.mat in ('cyan','mint','green','blue','red','amber','violet','electric','icy','screen_green','orange_hi','gold'):
  prop.SetAmbient(.81);prop.SetDiffuse(.29)
 if any(v in part.name for v in ('_Name','_Label','_Engraving','_Title','_Sub','_Mark','_Text','_Percent','_Front','_STATIC','_STATIC')):
  if 'Plate' not in part.name and 'Chrome' not in part.name:
   prop.SetAmbient(.96);prop.SetDiffuse(.045);prop.SetSpecular(.003)
 if part.mat in ('glass','darkglass','glass_body','water'):
  prop.SetOpacity(.31)
 prop.SetBackfaceCulling(False)
 return actor

def render(models,path,positions=None,eye=(0,22,-25),look=(0,1.2,0),scale=8.0,size=(2500,1520)):
 positions=positions or {};ren=vtk.vtkRenderer()
 ren.SetBackground(.035,.053,.081);ren.SetBackground2(.005,.012,.028);ren.GradientBackgroundOn()
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(2);win.AddRenderer(ren)
 for model in models:
  for part in model.parts:ren.AddActor(actor_for(part,positions.get(model.key,(0,0,0))))
 for pos,col,inten in [((-14,20,-10),(1.0,.95,.88),1.10),((12,15,7),(.48,.80,1),1.22),((2,13,-6),(.67,.95,1),.71)]:
  li=vtk.vtkLight();li.SetLightTypeToSceneLight();li.SetPosition(*pos);li.SetFocalPoint(0,0,0)
  li.SetColor(*col);li.SetIntensity(inten);ren.AddLight(li)
 camera=ren.GetActiveCamera();camera.SetPosition(*eye);camera.SetFocalPoint(*look);camera.SetViewUp(0,1,0)
 camera.ParallelProjectionOn();camera.SetParallelScale(scale)
 win.Render()
 img=vtk.vtkWindowToImageFilter();img.SetInput(win);img.SetInputBufferTypeToRGB();img.ReadFrontBufferOff();img.Update()
 writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(img.GetOutputPort());writer.Write()
 win.Finalize()
 print('RENDERED',path.name,path.stat().st_size,flush=True)

def overlay(path,title,sub,badge=None):
 im=Image.open(path).convert('RGBA');w,h=im.size;dr=ImageDraw.Draw(im,'RGBA')
 wide=min(w-32,int(w*.81))
 dr.rounded_rectangle((18,15,wide,134),radius=13,fill=(4,17,29,246),outline=(41,223,250,255),width=2)
 titlefont=ImageFont.truetype(BOLD,39 if w>1900 else 26)
 subfont=ImageFont.truetype(FONT,20 if w>1800 else 17)
 dr.text((43,35),title,font=titlefont,fill=(237,248,255))
 dr.text((43,100),sub,font=subfont,fill=(131,219,241))
 if badge and w>1500:
  dr.rounded_rectangle((w-550,24,w-24,82),radius=10,fill=(8,23,39,241),outline=(255,173,72,255),width=2)
  dr.text((w-535,43),badge,font=ImageFont.truetype(BOLD,18),fill=(255,213,144))
 dr.text((w-20,h-20),'PROJECT SPARK   /   LEVEL 47   /   ACTUAL 3D GEOMETRY',font=ImageFont.truetype(BOLD,13),anchor='ra',fill=(138,218,235))
 im.convert('RGB').save(path)

def sheet(previews,models,cols=3):
 tw,th=610,442;rows=int(math.ceil(len(models)/cols));s=Image.new('RGB',(tw*cols,th*rows),(5,18,29))
 dr=ImageDraw.Draw(s)
 for i,(m,fn) in enumerate(zip(models,previews)):
  x=(i%cols)*tw+6;y=(i//cols)*th+5
  im=Image.open(fn).convert('RGB');im.thumbnail((tw-12,th-60),Image.Resampling.LANCZOS)
  s.paste(im,(x,y))
  dr.rounded_rectangle((x,y+th-61,x+tw-13,y+th-12),radius=8,fill=(9,32,50),outline=(43,219,250),width=2)
  name=m.key[3:].replace('_',' ').upper();dr.text((x+13,y+th-47),name,font=ImageFont.truetype(BOLD,19),fill=(241,247,252))
 dest=P/'Level47_All_14_Models_ContactSheet.png';s.save(dest);print('SHEET',dest,flush=True)

if __name__=='__main__':
 models=[fn() for fn in BUILDERS]
 hero=P/'Level47_Complete_14Piece_Kit_Preview.png'
 render([showcase_bench()]+models,hero,POS,eye=(1.2,29.5,-34),look=(0,1.45,0),scale=12.8,size=(2580,1460))
 overlay(hero,'LEVEL 47  /  HOLD THE TENSION',
         'AAA-STYLE DANCER-CONTROLLED WINDING  |  14 INDIVIDUAL FBX MODELS',
         badge='15 WIRES  /  28 SOCKETS  /  2 MOTORS')
 snapshots=[]
 opts=[
  (4.6,6.5,-9.5,3.45), # supply
  (4.5,5.8,-8.8,3.3), # feed motor
  (4.5,5.8,-8.8,3.3), # takeup motor
  (5.1,6.8,-11,4.42), # feed spool
  (5.1,6.8,-11,4.54), # takeup spool
  (2,11,-14,7.0), # web
  (5.8,8.2,-11.8,4.2), # dancer
  (4.6,7.3,-10.5,4.0), # sensor
  (4.5,13.3,-17.5,8.3), # encoder pair
  (4.8,8.2,-12.2,4.7), # driver
  (5.3,8.8,-12.7,5.4), # controller
  (5.0,6.3,-9.2,3.54), # feed brake
  (4.8,7.7,-11.3,4.3), # monitor
  (7.2,14.5,-19.0,8.9) # frame
 ]
 for i,m in enumerate(models):
  ex,ey,ez,sc=opts[i]
  dest=P/(m.key+'_Preview.png')
  render([m],dest,eye=(ex,ey,ez),look=(0,1.75,0),scale=sc,size=(1080,790))
  overlay(dest,m.key.split('_',2)[-1].replace('_',' ').upper(),'LEVEL 47 / ACTUAL FBX MESH / UNITY VISUAL ASSET')
  snapshots.append(dest)
 sheet(snapshots,models)
 print('ALL LEVEL 47 RENDERS COMPLETE',flush=True)
