"""Project Spark — Level 47 HOLD THE TENSION.
AAA-inspired polished semi-HD meshes. Fourteen models including reusable 5 V supply.
Real Autodesk FBX 7.4 binary / GLB. Y-up, front = local -Z. Visual art only.
No physical or electrical system is fabricated by these files.
"""
from __future__ import annotations
import math, json, csv
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb

ROOT=Path(__file__).resolve().parents[1]
MOD=ROOT/'Models'; PREV=ROOT/'Previews'
MOD.mkdir(parents=True,exist_ok=True);PREV.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'ice':(218,241,251,255),'mint':(43,246,194,255), 'cyanlit':(24,234,254,255),
 'polished':(195,218,226,255),'nickel':(169,181,190,255),'silver':(191,208,219,255),
 'blue_dark':(18,53,105,255),'motor_blue':(29,110,188,255),'bronze':(174,107,57,255),
 'brass':(227,162,74,255),'ceramic':(229,222,206,255),'holo':(62,171,236,95),
 'darkglass':(17,89,110,115),'orangehot':(255,128,49,255),'black':(8,12,22,255),
 'shadow':(9,20,33,255),'violet':(132,115,234,255),'lime':(113,255,112,255),
 'fabric':(112,136,150,255),'fabriclight':(200,219,230,255),
 'film':(202,229,232,205), 'filmshadow':(76,113,126,255),
 'insulation':(24,39,52,255),'warningdark':(93,38,22,255),
 'aluminum':(160,186,207,255),'amberglass':(255,178,75,130),
 'stainless':(187,211,219,255),'spring':(237,175,48,255),
})

def txt(m,name,words,x,y,z,sz=.17,col='ice',mw=None,group='Static'):
 m.text(name,words,sz,x,y,z,col,maxwidth=mw,group=group)
def bolt(m,n,x,y,z):m.cyl(n,.052,.027,(x,y,z),'chrome',sections=14)
def led(m,t,x,y,z,col='mint',group=None):
 g=group or (t+'_LENS');m.cyl(t+'_Bezel',.13,.055,(x,y,z),'chrome',sections=24,group=g)
 m.cyl(t+'_Lens',.102,.048,(x,y+.04,z),col,sections=22,group=g)
 m.torus(t+'_Halo',.137,.015,(x,y+.058,z),col,'y',24,6,group=g)
 m.group_pivots[g]=(x,y,z)

def jack(m,t,sid,label,x,y,z,col='cyan',mw=.9):
 m.cyl(t+'_'+sid+'_NickelFlange',.171,.078,(x,y,z),'chrome','z',28)
 m.cyl(t+'_'+sid+'_Plastic',.142,.093,(x,y,z-.045),col,'z',28)
 m.cyl(t+'_'+sid+'_Well',.093,.1,(x,y,z-.098),'void','z',26)
 m.cyl(t+'_'+sid+'_GoldPin',.029,.028,(x,y,z-.142),'gold','z',14)
 m.torus(t+'_'+sid+'_LitHalo',.159,.016,(x,y,z-.101),col,'z',28,6)
 txt(m,t+'_'+sid+'_FrontCaption',label,x,y+.24,z-.155,.105,'ice',mw)
 if sid in m.anchors:raise ValueError('duplicate socket '+sid)
 m.anchors[sid]=[round(float(x),5),round(float(y),5),round(float(z-.167),5)]

def case(m,t,title,w=4.2,d=2.7,h=1.65,accent='cyan',subtitle=''):
 m.base(t,w,d,h)
 z=-d/2-.09
 m.bevel(t+'_TitleInset',(w-.29,.36,.045),(0,.33+h*.80,z),'void',.029)
 txt(m,t+'_MainTitle',title,0,.33+h*.80,z-.04,.218,'white',w-.43)
 if subtitle:txt(m,t+'_SmallTitle',subtitle,0,.33+h*.61,z-.048,.105,accent,w-.38)
 m.box(t+'_TopNeonBlade',(w-.70,.029,.057),(0,.32+h+.113,-d/2+.20),accent)
 for x in (-w/2+.18,w/2-.18):
  m.box(t+'_SideAccent'+str(x),(.055,.40,.045),(x,.78,z),'orange')
  for zz in (-d/2+.2,d/2-.2):bolt(m,t+f'_Screw{x:+.1f}{zz:+.1f}',x,.32+h+.084,zz)
 return z

def rod(m,name,a,b,r=.07,col='chrome',group='Static'):
 m.rod(name,a,b,r,col,sections=16,group=group)

def make_supply():
 m=Model('00_L47_5VSupply');t='L47_5V_SUPPLY'
 z=case(m,t,'5 V REGULATED',4.10,2.65,1.54,'cyan','PRECISION DC POWER')
 jack(m,t,'SUPPLY_PLUS_5V','+5V',-.98,.51,z-.055,'red')
 jack(m,t,'SUPPLY_RETURN','RETURN',.98,.51,z-.055,'blue')
 m.bevel(t+'_TopScreenBezel',(2.85,.18,1.05),(0,2.04,.13),'nickel',.04)
 m.bevel(t+'_BlankScreen',(2.65,.025,.83),(0,2.145,.13),'screen',.04)
 led(m,t+'_PowerLamp',1.55,1.94,.81,'green','PowerLamp_VISUAL')
 for i in range(10):m.box(t+f'_Vent_{i}',(.075,.028,.33),(-1.25+i*.275,2.152,.94),'void')
 return m

def make_motor(side):
 isfeed=side=='Feed';co='cyan' if isfeed else 'orange';code='FEED' if isfeed else 'TAKEUP';num='01' if isfeed else '02'
 m=Model(f'{num}_L47_{side}Motor');t='L47_'+code+'_MOTOR';g=side+'MotorShaft_ROTATE_Z';cy=2.17
 m.bevel(t+'_RubberIsolation',(3.20,.17,3.32),(0,.12,0),'rubber',.10)
 m.bevel(t+'_Cradle',(3.12,.30,3.17),(0,.38,0),'steel',.10)
 for x in (-.83,.83):
  m.bevel(t+f'_RibSupport{x:+.2f}',(.38,1.30,2.64),(x,1.08,0),'mid_steel',.065)
  for zz in (-1.25,1.25):bolt(m,t+f'_Foundation_{x:+.1f}_{zz:+.1f}',x,.59,zz)
 m.cyl(t+'_CastMotorCan',.79,2.43,(0,cy,0),'silver','z',64)
 m.cyl(t+'_RearBlueCap',.81,.30,(0,cy,-1.34),'motor_blue' if isfeed else 'bronze','z',64)
 m.torus(t+'_RearColoredSeal',.789,.038,(0,cy,-1.5),co,'z',60,8)
 m.cyl(t+'_FrontBearing',.67,.13,(0,cy,1.30),'chrome','z',52)
 for i,z in enumerate(np.linspace(-.99,1.06,14)):
  m.torus(t+f'_CoolingRib_{i:02d}',.809,.026,(0,cy,z),'nickel' if i%3 else 'mid_steel','z',46,7)
 m.cyl(t+'_Shaft',.143,1.65,(0,cy,1.98),'chrome','z',36,g)
 m.cyl(t+'_SplineHub',.24,.32,(0,cy,1.56),'gold','z',32,g)
 for j in range(7):
  a=j*math.tau/7
  m.cyl(t+f'_SplinePin{j}',.050,.23,(.22*math.cos(a),cy+.22*math.sin(a),1.57),'nickel','z',10,g)
 m.group_pivots[g]=(0,cy,1.3)
 m.bevel(t+'_PortShield',(2.56,.60,.18),(0,.80,-1.56),'deep_steel',.06)
 jack(m,t,code+'_MOTOR_PLUS','MOTOR +',-.63,.78,-1.69,'red')
 jack(m,t,code+'_MOTOR_MINUS','MOTOR -',.63,.78,-1.69,'blue')
 txt(m,t+'_SideBadge',code+'  5V',0,.33,-1.77,.150,co,2.3)
 return m

def make_spool(side):
 feed=side=='Feed';co='cyan' if feed else 'orange';rad=1.66 if feed else 2.04
 m=Model(('03' if feed else '04')+'_L47_'+side+'Spool');t='L47_'+side.upper()+'_SPOOL';g=side+'Spool_ROTATE_Z';gw=side+'WoundMaterial_ROTATE_Z_SCALE_XY';y=3.08
 m.bevel(t+'_IsolatedFoot',(3.90,.17,4.01),(0,.10,0),'rubber',.11)
 m.bevel(t+'_CastFoot',(3.77,.31,3.86),(0,.35,0),'steel',.11)
 for zz in (-1.54,1.54):
  m.bevel(t+f'_Upright{zz:+.2f}',(1.60,2.17,.42),(0,1.50,zz),'mid_steel',.10)
  m.cyl(t+f'_BearingHousing{zz:+.2f}',.48,.15,(0,y,zz),'chrome','z',36)
  m.torus(t+f'_BearingRing{zz:+.2f}',.47,.039,(0,y,zz-.17),co,'z',36,7)
 for x in (-.66,.66):
  for zz in (-1.62,1.62):bolt(m,t+f'_FootBolt{x:+.1f}{zz:+.1f}',x,.59,zz)
 # Wound material roll. Front face -Z is textured with concentric spiral layers.
 m.cyl(t+'_WoundCore',rad,2.45,(0,y,0),'fabriclight' if feed else 'stainless','z',64,gw)
 m.cyl(t+'_ExposedFrontFace',rad-.07,.04,(0,y,-1.27),'silver','z',72,gw)
 m.cyl(t+'_SideEdgeCenter',.40,2.89,(0,y,0),'nickel','z',40,g)
 for j,r in enumerate(np.linspace(.43,rad-.12,18)):
  m.torus(t+f'_WindingLayer_{j:02d}',float(r),.025,(0,y,-1.305),'chrome' if j%3 else ('cyan' if feed else 'brass'),'z',64,6,gw)
 for j in range(28):
  a=j*math.tau/28
  # Outer near-front roll edge fine hatching
  m.cyl(t+f'_CircumferenceTexture_{j:02d}',.036,.025,(rad*.92*math.cos(a),y+rad*.92*math.sin(a),-1.321),'nickel','z',8,gw)
 for zz in (-1.38,1.38):
  m.cyl(t+f'_FlangeBillet_{zz:+.1f}',rad+.16,.105,(0,y,zz),'titanium','z',76,g)
  m.torus(t+f'_FlangeEdge_{zz:+.1f}',rad+.11,.067,(0,y,zz-.08),co,'z',68,7,g)
  m.torus(t+f'_InnerFlange{zz:+.1f}',rad-.12,.025,(0,y,zz-.09),'nickel','z',56,6,g)
 m.cyl(t+'_SolidAxle',.22,3.49,(0,y,0),'chrome','z',38,g)
 m.cyl(t+'_ChromeHub',.36,.22,(0,y,-1.63),'chrome','z',42,g)
 m.group_pivots[g]=(0,y,0)
 m.group_pivots[gw]=(0,y,0)
 m.bevel(t+'_FrontNameplate',(2.55,.36,.09),(0,.65,-1.92),'void',.034)
 txt(m,t+'_FrontCaption',side.upper()+(' UNWIND' if feed else ' WIND'),0,.65,-1.99,.139,co,2.35)
 return m

def mesh_strip(m,name,pts,z0=-1.22,z1=1.22,width=.045,mat='film',group='TransportWeb_SCROLL'):
 # A continuous ribbon with front/back/edge faces, following a smooth path in X/Y.
 v=[];f=[]
 for x,y in pts:
  for yy,zz in ((y-width/2,z0),(y-width/2,z1),(y+width/2,z0),(y+width/2,z1)):
   v.append((x,yy,zz))
 for i in range(len(pts)-1):
  p=4*i;q=4*(i+1)
  for a,b,c,d in [(p,p+1,q+1,q),(p+2,q+2,q+3,p+3),(p,p+2,q+2,q),(p+1,q+1,q+3,p+3)]:
   f.extend([(a,b,c),(a,c,d)])
 f += [(0,2,3),(0,3,1)]
 p=4*(len(pts)-1); f += [(p,p+1,p+3),(p,p+3,p+2)]
 mesh=trimesh.Trimesh(vertices=np.asarray(v),faces=np.asarray(f),process=False)
 m.add(name,mesh,mat,group)

def make_web():
 m=Model('05_L47_TransportWeb');t='L47_WEB';g='TransportWeb_SCROLL'
 # Not a rigid electrical connection. A sculpted ribbon across both spools and dancer.
 xs=np.linspace(-5.75,5.75,64)
 ys=[]
 for x in xs:
  q=abs(x)/5.75
  ys.append(3.42+1.69*q**1.7+0.12*math.sin(q*math.pi))
 pts=list(zip(xs,ys));mesh_strip(m,t+'_FrostedFilmRibbon',pts,mat='film',group=g)
 mesh_strip(m,t+'_CentralCarbonTint',[(x,y+.038) for x,y in pts],-.96,.96,.010,'fabriclight',g)
 for side,zz,col in [('Left',-1.20,'cyan'),('Right',1.20,'orange')]:
  # Continuous colored edge threads, segments follow the same path as fabric
  for j in range(0,len(pts)-1,2):
   a=pts[j];b=pts[min(j+2,len(pts)-1)]
   rod(m,t+f'_{side}_FineEdge_{j:02d}',(a[0],a[1]+.055,zz),(b[0],b[1]+.055,zz),.017,col,g)
 for k in range(21):
  i=k*3; x,y=pts[min(i,len(pts)-1)]
  m.box(t+f'_WovenRegistrationTick_{k:02d}',(.040,.007,2.13),(x,y+.070,0),'nickel' if k%3 else 'mint',g)
 m.group_pivots[g]=(0,0,0)
 return m

def make_dancer():
 m=Model('06_L47_DancerArm');t='L47_DANCER';gp='DancerArm_ROTATE_Z';gr='DancerRoller_ROTATE_Z';pivot=(0,1.34,0)
 m.bevel(t+'_MountFoot',(3.54,.23,2.97),(0,.13,0),'rubber',.10)
 m.bevel(t+'_AlloyPedestal',(3.45,.31,2.89),(0,.41,0),'mid_steel',.11)
 for zz in (-1.12,1.12):
  m.bevel(t+f'_StaticTriangularFrame_{zz:+.1f}',(.48,1.2,.32),(0,.97,zz),'steel',.055)
  m.cyl(t+f'_PivotBearing_{zz:+.1f}',.34,.23,(0,1.35,zz),'chrome','z',32)
 for zz in (-1.11,1.11):
  rod(m,t+f'_RigidArm_{zz:+.1f}',(0,1.34,zz),(.0,3.74,zz),.119,'nickel',gp)
  rod(m,t+f'_DiagonalBrace_{zz:+.1f}',(-.50,1.42,zz),(.0,3.63,zz),.065,'chrome',gp)
 m.cyl(t+'_RollerShell',.45,2.85,(0,3.73,0),'polished','z',48,gr)
 m.cyl(t+'_RollerRubberSkin',.39,2.65,(0,3.73,0),'insulation','z',48,gr)
 for j in np.linspace(-1.24,1.24,19):m.torus(t+f'_DancerRollerGroove_{j:+.2f}',.408,.013,(0,3.73,float(j)),'cyan','z',34,6,gr)
 m.cyl(t+'_RollerAxle',.14,3.12,(0,3.73,0),'chrome','z',24,gr)
 m.group_pivots[gr]=(0,3.73,0)
 m.group_pivots[gp]=pivot
 # Spring tower on right
 m.bevel(t+'_SpringGuidePlate',(.45,2.35,.38),(.92,1.75,-.4),'steel',.05)
 m.cyl(t+'_SpringGuide',.08,1.65,(.92,1.77,-.4),'chrome','y',22)
 for k in range(23):
  ay=1.1+k*.054; ang=k*.91
  m.torus(t+f'_SpringCoil_{k:02d}',.184,.028,(.92,ay,-.4),'spring','y',20,5)
 m.bevel(t+'_PositionScale',(.33,1.87,.09),(1.52,2.4,-1.11),'deep_steel',.035)
 for j in range(15):
  y=1.59+j*.112
  m.box(t+f'_TravelTick_{j:02d}',(.16 if j%5==0 else .075,.018,.014),(1.52,y,-1.19),'mint' if j%5==0 else 'white')
 led(m,t+'_CenteredLamp',1.04,.68,-1.10,'green','DancerCentered_LENS')
 txt(m,t+'_Title','DANCER TENSION',0,.55,-1.59,.15,'ice',2.8)
 return m

def make_tension_sensor():
 m=Model('07_L47_TensionSensor');t='L47_TENSION_SENSOR'
 z=case(m,t,'ANALOG TENSION SENSOR',5.40,2.90,1.68,'mint','DANCER FEEDBACK / 0 - 5 V')
 for x,sid,lab,col in [(-1.62,'SENSOR_PLUS_5V','+5V','red'),(0,'SENSOR_GND','GND','blue'),(1.62,'SENSOR_SIGNAL','SIGNAL','mint')]:
  jack(m,t,sid,lab,x,.47,z-.08,col,1.30)
 m.bevel(t+'_SensorTopPlate',(3.99,.14,1.24),(0,2.22,.17),'steel',.042)
 m.bevel(t+'_BlankLiveVoltageLCD',(3.72,.020,.97),(0,2.307,.17),'screen',.028)
 m.cyl(t+'_SensorWiperShaft',.17,.4,(1.52,2.35,-.30),'chrome','y',26)
 g='TensionSensorWiper_ROTATE_Y'
 m.box(t+'_RotaryWiper',(1.33,.13,.19),(.80,2.57,-.30),'gold',g)
 m.group_pivots[g]=(1.51,2.42,-.3)
 for x in (-1.52,-.96,-.40,.16,.72):m.box(t+f'_CalibrationTick_{x:+.2f}',(.05,.025,.12),(x,2.327,.54),'mint')
 led(m,t+'_Ready',1.88,1.67,1.03,'green','SensorReady_LENS')
 return m

def make_encoders():
 m=Model('08_L47_EncoderPair');t='L47_ENCODERS';cy=3.08
 for who,x,col in [('Feed',5.8,'cyan'),('Takeup',-5.8,'orange')]:
  g=who+'EncoderDisc_ROTATE_Z'
  m.cyl(t+'_'+who+'_OpticalDisc',.68,.106,(x,cy,2.82),'graphite','z',64,g)
  m.torus(t+'_'+who+'_SignalRing',.674,.041,(x,cy,2.89),col,'z',56,8,g)
  for k in range(20):
   a=k*math.tau/20
   m.cyl(t+f'_{who}_OpticalWindow_{k:02d}',.058,.022,(x+.55*math.cos(a),cy+.55*math.sin(a),2.91),'ice' if k%2 else col,'z',10,g)
  for k in range(80):
   a=k*math.tau/80
   m.cyl(t+f'_{who}_Graduation_{k:02d}',.012,.011,(x+.63*math.cos(a),cy+.63*math.sin(a),2.91),'gold' if k%10==0 else 'cyan','z',6,g)
  m.cyl(t+f'_{who}_DiscHub',.23,.15,(x,cy,2.96),'chrome','z',36,g)
  m.group_pivots[g]=(x,cy,2.83)
  m.bevel(t+f'_{who}_PickupStand',(1.60,.40,.56),(x,.69,3.08),'steel',.06)
  m.bevel(t+f'_{who}_OpticalFork',(.32,.36,.75),(x+.61,cy+.13,2.99),'deep_steel',.06)
  led(m,t+f'_{who}_PulseA',x-.35,.68,3.35,col,who+'PulseA_LENS')
  led(m,t+f'_{who}_PulseB',x+.35,.68,3.35,'mint',who+'PulseB_LENS')
 # Four ports in small accessory module at back of machine
 z=case(m,t+'_IO','DUAL ENCODER / 80 CPR',7.25,2.35,1.62,'mint','FEED  A/B    +    TAKE-UP  A/B')
 for p in m.parts:
  if p.name.startswith(t+'_IO'):p.mesh.apply_translation((0,0,5.22))
 for x,sid,lb,col in [(-2.61,'FEED_ENC_A','FEED A','cyan'),(-.87,'FEED_ENC_B','FEED B','mint'),(.87,'TAKEUP_ENC_A','WIND A','orange'),(2.61,'TAKEUP_ENC_B','WIND B','amber')]:
  jack(m,t,sid,lb,x,.49,5.22+z-.09,col,1.42)
 return m

def make_dual_driver():
 m=Model('09_L47_DualMotorDriver');t='L47_DRIVER'
 z=case(m,t,'PRECISION DUAL DRIVE',8.05,2.89,1.97,'orange','FEED  /  TAKE-UP  PWM MOTOR DRIVER')
 rows=[(1.06,[('DRIVER_FEED_PWM','F PWM','cyan'),('DRIVER_FEED_PLUS','F +','red'),('DRIVER_FEED_MINUS','F -','blue')]),
       (.46,[('DRIVER_TAKEUP_PWM','T PWM','orange'),('DRIVER_TAKEUP_PLUS','T +','red'),('DRIVER_TAKEUP_MINUS','T -','blue')])]
 for yy,row in rows:
  for x,(sid,cap,col) in zip((-2.72,0,2.72),row):jack(m,t,sid,cap,x,yy,z-.08,col,1.55)
 for side,x,col in [('FEED',-1.88,'cyan'),('TAKEUP',1.88,'orange')]:
  m.bevel(t+'_'+side+'_HeatsinkBackplate',(2.64,.11,1.67),(x,2.51,.18),'nickel',.035)
  for j,xx in enumerate(np.linspace(-1.04,1.04,9)):
   m.box(t+f'_{side}_HeatFin_{j}',(.10,.49,1.53),(x+xx,2.77,.18),'chrome' if j%3 else 'steel')
  led(m,t+'_'+side+'_DriveOn',x,3.02,-.92,col,side+'_PwmIndicator_LENS')
 return m

def make_controller():
 m=Model('10_L47_TensionController');t='L47_CONTROLLER'
 z=case(m,t,'ACTIVE DANCER CONTROL',10.42,3.23,1.99,'cyan','AUTO TENSION  /  FEED  /  TAKE-UP')
 rows=[(1.06,[('CTRL_PLUS_5V','+5V','red'),('CTRL_FEED_PWM','F PWM','cyan'),('CTRL_TAKEUP_PWM','T PWM','orange'),('CTRL_GND','GND','blue')]),
       (.45,[('CTRL_FEED_A','F A','mint'),('CTRL_FEED_B','F B','cyan'),('CTRL_TAKEUP_A','T A','orange'),('CTRL_TAKEUP_B','T B','amber'),('CTRL_TENSION_IN','T IN','green')])]
 for yy,row in rows:
  xs=np.linspace(-3.75,3.75,len(row))
  for x,(sid,lab,col) in zip(xs,row):jack(m,t,sid,lab,float(x),yy,z-.075,col,1.35)
 m.bevel(t+'_TopMonitorSurround',(7.83,.12,1.50),(0,2.61,.25),'nickel',.045)
 m.bevel(t+'_BlankRuntimeDisplay',(7.50,.021,1.27),(0,2.69,.25),'screen',.04)
 m.box(t+'_DisplayHighlight',(7.42,.014,.050),(0,2.708,-.35),'cyan')
 for i,(nm,col) in enumerate([('MANUAL','amber'),('AUTO','green'),('FAULT','red')]):
  led(m,t+'_'+nm+'_Indicator',-2.6+i*2.6,2.46,-1.08,col,nm+'_LENS')
 for i,(name,col) in enumerate([('AUTO','green'),('CALIBRATE','cyan'),('RESET','orange')]):
  g=name+'_Button_PRESS_Y';x=-1.30+i*1.30
  m.cyl(t+'_'+name+'_ButtonBezel',.24,.12,(x,2.29,1.40),'chrome',sections=24)
  m.cyl(t+'_'+name+'_MovableCap',.185,.12,(x,2.37,1.40),col,sections=20,group=g)
  m.group_pivots[g]=(x,2.29,1.40)
 return m

def make_feed_brake():
 m=Model('11_L47_FeedBrake');t='L47_FEED_BRAKE'
 m.bevel(t+'_IsolatedMount',(3.3,.20,3.15),(0,.12,0),'rubber',.12)
 m.bevel(t+'_AlloyMount',(3.15,.31,3.02),(0,.38,0),'steel',.11)
 m.bevel(t+'_CaliperSupport',(.41,1.64,.87),(.72,1.29,.44),'steel',.075)
 gr='FeedBrakeRotor_ROTATE_Z';ga='FeedBrakeLever_ROTATE_Z';gp='FeedBrakePad_TRANSLATE_X'
 m.cyl(t+'_PerforatedRotor',.88,.24,(-.26,2.08,.21),'silver','z',64,gr)
 m.torus(t+'_BrakingTrack',.84,.075,(-.26,2.08,.38),'orange','z',62,8,gr)
 for j in range(20):
  a=j*math.tau/20
  m.cyl(t+f'_RotorHole_{j:02d}',.05,.018,(-.26+.65*math.cos(a),2.08+.65*math.sin(a),.355),'void','z',12,gr)
 m.group_pivots[gr]=(-.26,2.08,.21)
 m.bevel(t+'_Piston',(1.10,.50,.80),(.80,2.04,.22),'nickel',.095)
 m.box(t+'_FrictionCeramicPad',(.18,.63,.73),(.39,2.03,.22),'ceramic',gp)
 m.box(t+'_PadHotTrim',(.10,.71,.79),(.54,2.03,.22),'orange',gp)
 m.group_pivots[gp]=(.54,2.03,.22)
 m.cyl(t+'_LeverPivot',.19,.30,(.98,2.70,-.27),'chrome','z',30)
 rod(m,t+'_LongActuatorLever',(.98,2.70,-.27),(1.33,3.64,-.27),.078,'gold',ga)
 m.cyl(t+'_RubberHandGrip',.145,.32,(1.35,3.65,-.27),'rubber','z',24,ga)
 m.group_pivots[ga]=(.98,2.70,-.27)
 led(m,t+'_LoadLight',-1.17,.66,-1.20,'amber','BrakeLoad_LENS')
 txt(m,t+'_BrakeTitle','FEED BRAKE',0,.62,-1.69,.165,'white',2.65)
 return m

def make_tension_monitor():
 m=Model('12_L47_TensionMonitor');t='L47_TENSION_MONITOR'
 z=case(m,t,'TENSION TELEMETRY',6.12,2.95,2.01,'mint','SENSOR  /  FEED RPM  /  TAKE-UP RPM')
 m.bevel(t+'_LargeScreenRim',(5.26,.16,1.56),(0,2.63,.10),'chrome',.055)
 m.bevel(t+'_BlankLiveTensionScreen',(5.02,.022,1.33),(0,2.72,.10),'screen',.035)
 m.box(t+'_ScreenCyanRail',(4.96,.016,.04),(0,2.735,-.50),'mint')
 for j in range(19):
  x=-2.1+j*.23
  m.box(t+f'_SpectrumBar_{j:02d}',(.12,.018,.13+.53*(1-abs(j-9)/10)),(x,2.743,.05),'mint' if j<12 else 'orange')
 for i,(lab,col) in enumerate([('SAFE','green'),('SLACK','amber'),('TRIP','red')]):
  led(m,t+'_'+lab,-1.68+i*1.68,2.39,-1.21,col,lab+'_StatusLens')
 txt(m,t+'_DecorativeOnly','BLANK LIVE SCREEN  -  UNITY TMP',0,1.10,z-.03,.117,'ice',5.4)
 return m

def make_frame():
 m=Model('13_L47_IndustrialFrame');t='L47_FRAME'
 m.bevel(t+'_NeopreneFloatingPad',(20.80,.18,10.25),(0,.10,0),'rubber',.17)
 m.bevel(t+'_PrecisionCastFloor',(20.62,.32,10.05),(0,.34,0),'steel',.14)
 m.bevel(t+'_CarbonDeck',(20.38,.12,9.85),(0,.57,0),'graphite',.12)
 for zz in (-4.75,4.75):m.box(t+f'_EdgeLight_{zz:+.1f}',(20.0,.044,.07),(0,.643,zz),'cyan')
 for xx in (-10,10):m.box(t+f'_AmberSafetyStripe_{xx:+.1f}',(.07,.051,9.3),(xx,.64,0),'orange')
 for zz in (-3.5,3.5):
  m.bevel(t+f'_TSlotRail_{zz:+.1f}',(18.95,.14,.35),(0,.74,zz),'mid_steel',.035)
  m.box(t+f'_BlackTChannel_{zz:+.1f}',(18.7,.018,.08),(0,.816,zz),'void')
 for xx in np.linspace(-9.0,9.0,15):
  m.bevel(t+f'_CrossRail_{xx:+.2f}',(.25,.11,7.45),(float(xx),.67,0),'steel',.025)
 for x,label,col in [(5.8,'FEED / UNWIND','cyan'),(-5.8,'TAKE UP / WIND','orange')]:
  m.bevel(t+'_'+label.split()[0]+'_NamePlate',(3.34,.055,.39),(x,.825,-4.21),'void',.029)
  txt(m,t+'_'+label.split()[0]+'_Lettering',label,x,.842,-4.43,.15,col,3.15)
 for xx in (-8.4,8.4):
  for zz in (-3.9,3.9):bolt(m,t+f'_FoundationBolt_{xx:+.1f}_{zz:+.1f}',xx,.642,zz)
 return m

def showcase_bench():
 m=Model('ART_ONLY_L47_ShowcaseBench');t='L47_BENCH'
 m.bevel(t+'_CNC_Border',(35.2,.19,24.1),(0,.08,0),'rubber',.14)
 m.bevel(t+'_ForgedMetal',(35.0,.24,23.9),(0,.29,0),'steel',.12)
 m.bevel(t+'_CarbonTop',(34.78,.07,23.65),(0,.47,0),'graphite',.085)
 for zz in (-11.46,11.46):m.box(t+f'_FrontNeon_{zz:+.2f}',(34.18,.054,.065),(0,.514,zz),'cyan')
 for xx in (-16.91,16.91):m.box(t+f'_OrangeEdge_{xx:+.2f}',(.061,.045,22.98),(xx,.514,0),'orange')
 for zz in (-10.86,-10.51,-10.16):
  for j,xx in enumerate(np.linspace(-15.9,15.9,48)):
   m.cyl(t+f'_BreadboardHole_{zz:.2f}_{j}',.023,.014,(xx,.519,zz),'void',sections=8)
 return m

BUILDERS=[make_supply,lambda:make_motor('Feed'),lambda:make_motor('Takeup'),
          lambda:make_spool('Feed'),lambda:make_spool('Takeup'),make_web,make_dancer,
          make_tension_sensor,make_encoders,make_dual_driver,make_controller,
          make_feed_brake,make_tension_monitor,make_frame]
POS={
 'ART_ONLY_L47_ShowcaseBench':(0,0,0),
 '00_L47_5VSupply':(-14.15,0,7.1),
 '01_L47_FeedMotor':(5.8,0,-4.8),
 '02_L47_TakeupMotor':(-5.8,0,-4.8),
 '03_L47_FeedSpool':(5.8,0,0),
 '04_L47_TakeupSpool':(-5.8,0,0),
 '05_L47_TransportWeb':(0,0,0),
 '06_L47_DancerArm':(0,0,0),
 '07_L47_TensionSensor':(0,0,4.9),
 '08_L47_EncoderPair':(0,0,0),
 '09_L47_DualMotorDriver':(0,0,-8.4),
 '10_L47_TensionController':(4.5,0,8.35),
 '11_L47_FeedBrake':(8.2,0,.10),
 '12_L47_TensionMonitor':(-7.0,0,8.30),
 '13_L47_IndustrialFrame':(0,0,0)
}
WIRES=[
 ('W01','SUPPLY_PLUS_5V','CTRL_PLUS_5V','Supply +5V to controller +5V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply return to controller GND'),
 ('W03','CTRL_FEED_PWM','DRIVER_FEED_PWM','Controller FEED PWM to driver feed PWM'),
 ('W04','CTRL_TAKEUP_PWM','DRIVER_TAKEUP_PWM','Controller TAKE-UP PWM to driver take-up PWM'),
 ('W05','DRIVER_FEED_PLUS','FEED_MOTOR_PLUS','Driver FEED+ to feed motor+'),
 ('W06','DRIVER_FEED_MINUS','FEED_MOTOR_MINUS','Driver FEED- to feed motor-'),
 ('W07','DRIVER_TAKEUP_PLUS','TAKEUP_MOTOR_PLUS','Driver TAKE-UP+ to take-up motor+'),
 ('W08','DRIVER_TAKEUP_MINUS','TAKEUP_MOTOR_MINUS','Driver TAKE-UP- to take-up motor-'),
 ('W09','FEED_ENC_A','CTRL_FEED_A','FEED encoder A to controller FEED A'),
 ('W10','FEED_ENC_B','CTRL_FEED_B','FEED encoder B to controller FEED B'),
 ('W11','TAKEUP_ENC_A','CTRL_TAKEUP_A','TAKE-UP encoder A to controller TAKE-UP A'),
 ('W12','TAKEUP_ENC_B','CTRL_TAKEUP_B','TAKE-UP encoder B to controller TAKE-UP B'),
 ('W13','SUPPLY_PLUS_5V','SENSOR_PLUS_5V','Supply +5V to tension sensor +5V'),
 ('W14','SUPPLY_RETURN','SENSOR_GND','Supply return to tension sensor GND'),
 ('W15','SENSOR_SIGNAL','CTRL_TENSION_IN','Tension sensor signal to controller, install LAST for fault challenge')
]

def build():
 models=[]
 for fn in BUILDERS:
  m=fn();models.append(m)
  fp=MOD/(m.key+'.fbx');gp=MOD/(m.key+'.glb')
  export_fbx(fp,[m]); export_glb(gp,[m]);
  assert fp.read_bytes().startswith(b'Kaydara FBX Binary  \x00'),fp
  assert len(trimesh.load_scene(gp).geometry)>0,gp
  print('MODEL',m.key,'tri',sum(len(p.mesh.faces) for p in m.parts),'parts',len(m.parts),'sockets',len(m.anchors),flush=True)
 ids=[sid for m in models for sid in m.anchors];wids={a for _,a,_,_ in WIRES}|{b for _,_,b,_ in WIRES}
 assert len(models)==14 and len(ids)==28 and len(set(ids))==28,(len(ids),ids)
 assert len(WIRES)==15 and wids==set(ids),('invalid mapping',wids^set(ids))
 assert all(m.key in POS for m in models)
 bench=showcase_bench();gallery=[bench]+models
 hero='Level47_Complete_ArtKit_Showcase'
 export_fbx(MOD/(hero+'.fbx'),gallery,positions=POS)
 export_glb(MOD/(hero+'.glb'),gallery,positions=POS)
 assert len(trimesh.load_scene(MOD/(hero+'.glb')).geometry)>0
 manifest={}
 for m in models:
  manifest[m.key]={'fbx':m.key+'.fbx','glb':m.key+'.glb',
    'triangles':sum(len(p.mesh.faces) for p in m.parts),'mesh_parts':len(m.parts),
    'socket_anchors_local_xyz':m.anchors,'animation_pivots':m.group_pivots,
    'named_groups':list(dict.fromkeys(p.group for p in m.parts))}
 total=sum(len(p.mesh.faces) for m in gallery for p in m.parts)
 doc={'level':47,'title':'Hold the Tension','theme':'Active Dancer-Controlled Winding',
  'scope':'VISUAL ASSETS ONLY; no solver/controller, live UI or electrical physics implemented',
  'model_count':14,'new_model_count':13,'reused_style_power_supply':1,
  'player_wires':15,'distinct_socket_anchors':28,'models':manifest,'positions':POS,
  'showcase':{'name':hero,'triangle_count':total},'wires':WIRES,
  'power_note':'Shared supply PLUS and RETURN each accept multiple wires. Real fixed driver and encoder power connections must be configured in Unity.',
  'coordinate_system':'Y up, front negative Z, local model coordinates in relative units; scale to workstation before creating real SparkTerminal anchors'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(doc,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBX Model','ArtSocketID','LocalX','LocalY','LocalZ','Unity action'])
  for m in models:
   for sid,(x,y,z) in m.anchors.items():w.writerow([m.key+'.fbx',sid,x,y,z,'Place real SparkTerminal with proper scene binding here'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBX','ID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for sid,at in m.anchors.items():w.writerow([m.key+'.fbx',sid,*[round(a+b,5) for a,b in zip(at,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['FBX','NamedGroup','PivotLocalX','PivotLocalY','PivotLocalZ','AnimationType'])
  for m in models:
   for n,(x,y,z) in m.group_pivots.items():w.writerow([m.key+'.fbx',n,x,y,z,'ROTATE' if 'ROTATE' in n else 'TRANSLATE / INDICATOR'])
 (ROOT/'VALIDATION.txt').write_text(f'Level 47: {len(models)} individual FBX + {len(models)} GLB; 1 assembled FBX + GLB.\n'
  f'{len(ids)} unique art socket locations. {len(WIRES)} exact wires. {total:,} showcase triangles.\n'
  'Binary FBX headers and GLB mesh content verified. NOT tested in Unity; no gameplay/electrical system included.\n')
 print('COMPLETE',len(models), 'models',total,'triangles', len(ids),'sockets',len(WIRES),'wires',flush=True)
 return models,gallery

if __name__=='__main__':build()
