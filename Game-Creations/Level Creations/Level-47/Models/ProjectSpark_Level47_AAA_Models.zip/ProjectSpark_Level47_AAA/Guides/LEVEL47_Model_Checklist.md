# Level 47 — AAA-Style Winding Kit Checklist

## Model scope

14 unique FBX models (13 level-specific models + a matching 5 V supply).

- [x] 5 V supply with terminals
- [x] Feed / take-up DC motors with independently named rotor groups
- [x] Feed / take-up spools with scalable material layers and non-scaling hubs
- [x] Material web ribbon with registration ticks
- [x] Dancer arm, roller, spring, travel markings
- [x] Dancer position sensor with 3 terminals
- [x] 2 encoder discs with A/B read heads, 80 graduations each
- [x] Dual-channel motor driver (6 sockets)
- [x] Tension controller (9 sockets)
- [x] Adjustable feed brake (arm, pad, rotor separated)
- [x] Telemetry monitor (visual only)
- [x] Metal industrial mounting frame

## Integration limits

- No electrical components or Unity level definition generated.
- Art socket ID positions are not live `SparkTerminal` objects.
- Blank sensor/controller/monitor faces are for live Unity UI overlays.
- Material winding progress must come from simulation; visual helper does not calculate tension.
- No Unity import/rig test has yet been executed.

## Verify in editor

1. Import individual FBXs and confirm Y-up / -Z-front orientation.
2. Ensure FEED is cyan and on camera-left; TAKE-UP is amber and camera-right.
3. Assign actual terminals at the imported FBX art socket locations.
4. Verify 28 distinct player socket positions and all 15 exact wire endpoints.
5. Confirm separate motor, spool, wound material, encoder, dancer and brake groups.
6. Configure live TextMeshPro screens, VFX and fault display.
7. Test both spools shrinking/growing visually without scaling their hardware.
