import os,sys,math,csv,json,pathlib,zipfile,hashlib,shutil
import numpy as np,trimesh
sys.path.insert(0,'/mnt/data/ProjectSpark_Level57_HD_AAA/Source')
import l57_core as c
ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level60_HD_AAA')
for s in ['Models','GLB','Previews','Unity_Optional','Source']:(ROOT/s).mkdir(parents=True,exist_ok=True)
c.ROOT=ROOT;c.assets=[]
names=['IndustrialResilienceBase','MainGridInterface','GridFormingInverter','BatteryStorageSystem','BatteryManagementUnit','BidirectionalPowerConverter','SolarPVSimulator','SolarMPPTController','BackupGenerator','GeneratorStarter','ThreePhaseDistributionBus','MainGridBreaker','GeneratorBreaker','BatteryInverterBreaker','RenewableSourceBreaker','EssentialLoadBreaker','PriorityLoadBreaker','IndustrialLoadBreaker','AuxiliaryLoadBreaker','CriticalServiceLoad','IndustrialMotorLoad','SmartProgrammableLoad','ProtectionRelayBank','VoltageCurrentSensorHub','ResilienceMasterController','HolographicSCADAMonitor','FaultScenarioSimulator','TransparentSafetyEnclosure']
c.MODELS=['L60_'+s for s in names]
from l57_core import box,cyl,tor,ann,beam,bolt,led,text_geo,cable

def b(n,x,y,z,w,h,d,mat='blue_steel',group=None):box(n,(x,y,z),(w,h,d),mat,group)
def txt(n,s,x,y,z,w=1,size=.070,mat='white',group=None):text_geo(n,s,(x,y,z),w,size,mat,group)
def jack(n,x,y,z,col='cyan'):
 cyl(n+'Bezel',(x,y,z),.075,.026,'z','chrome',20)
 cyl(n+'Insulator',(x,y,z+.017),.052,.022,'z',col,20)
 cyl(n+'Contact',(x,y,z+.029),.021,.018,'z','dark',14)
def enclosure(n,x,y,z,w,h,d,title,accent='cyan',ports=4,screen=True):
 b(n+'DiecastHousing',x,y,z,w,h,d,'blue_steel')
 b(n+'RecessedFace',x,y,z+d/2+.018,w-.075,h-.082,.027,'navy')
 b(n+'UpperChamferLip',x,y+h/2+.030,z,w+.015,.055,d+.02,'titanium')
 b(n+'EdgeStrip',x,y+h/2+.058,z+d*.32,w-.11,.016,.026,accent)
 for sx in [-1,1]:
  for sy in [-1,1]: bolt(n+'MountBolt'+str(sx)+str(sy),(x+sx*(w/2-.080),y+sy*(h/2-.084),z+d/2+.045),'z',.020)
 txt(n+'Name',title,x-w*.43,y+h*.25,z+d/2+.042,w*.86,.073)
 led(n+'StatusLED',(x-w*.39,y+.01,z+d/2+.044),'green',.029,'z')
 for k in range(ports):
  xx=x+(k-(ports-1)/2)*(w-.27)/max(1,ports-1)
  jack(n+'Port'+str(k),xx,y-h*.31,z+d/2+.05,['red','electric','cyan','green','amber','violet'][k%6])
 if screen and h>=.65:
  b(n+'LCDBezel',x+.10,y+.017,z+d/2+.050,w*.49,h*.30,.022,'silver_dark')
  b(n+'LCDGlass',x+.10,y+.017,z+d/2+.064,w*.44,h*.24,.009,'display')
  for j in range(5):
   xx=x-.09+j*w*.09
   beam(n+'LCDEnergyTrend'+str(j),(xx,y-.018,z+d/2+.076),(xx,y+.025+math.sin(j*1.3)*.030,z+d/2+.076),.006,accent,8)
def breaker(idx,x,z,name,col='green'):
 c.start(idx);enclosure(name.replace(' ','')+'Module',x,.94,z,.81,.78,.68,name,col,2,False)
 b(name+'SwitchHousing',x,1.0,z+.39,.32,.36,.095,'silver_dark')
 b(name+'AnimatedRocker',x,1.04,z+.448,.12,.26,.11,'chrome','ANIM_BREAKER_HANDLE')
 b(name+'RockerCap',x,1.17,z+.50,.20,.072,.12,'red','ANIM_BREAKER_HANDLE')
 c.current.pivot('ANIM_BREAKER_HANDLE',(x,1.00,z+.47))
 b(name+'LowerStateLamp',x,.72,z+.426,.26,.07,.022,col)
def load(idx,x,z,name,kind):
 c.start(idx);enclosure(name+'Case',x,.85,z,1.15,.63,.78,name,'green',3,True)
 if kind=='critical':
  for k in range(5):b('CriticalServerBlade'+str(k),x-.42+k*.21,1.30,z-.10,.15,.24,.40,'dark')
  for k in range(5):led('CriticalRunningLED'+str(k),(x-.42+k*.21,1.37,z+.12),'green',.020)
 if kind=='motor':
  cyl('MotorStator',(x,1.37,z-.1),.255,.78,'x','electric',40)
  for j in range(15):b('CoolingFin'+str(j),x-.35+j*.05,1.63,z-.10,.033,.105,.47,'silver')
  cyl('MotorShaft',(x+.53,1.37,z-.10),.060,.31,'x','chrome',24,'ANIM_MOTOR_SPIN')
  c.current.pivot('ANIM_MOTOR_SPIN',(x,1.37,z-.10))
 if kind=='programmable':
  for k in range(8):b('LoadHeatSink'+str(k),x-.43+k*.125,1.29,z-.15,.055,.20,.46,'silver')
  for k in range(3):led('LoadStage'+str(k),(x-.23+k*.23,1.04,z+.42),'amber',.031)

# 00 Industrial Base
c.start(0)
b('MonolithicTitaniumBed',0,.10,0,11.7,.34,6.65,'titanium')
b('DeckCarbonLaminate',0,.306,0,11.5,.070,6.40,'carbon')
b('FrontTerminalPanel',0,.67,2.93,11.45,.53,.55,'navy')
for z in [-3.14,3.14]:b('LongMachineEdgeLight',0,.355,z,11.40,.023,.040,'cyan')
for x in [-5.66,5.66]:b('SideMachineRail',x,.355,0,.07,.058,6.37,'silver')
for x in [-5.44,5.44]:
 for z in [-2.96,2.96]:cyl('IsolationFoot',(x,-.19,z),.18,.18,'y','rubber',18)
for j in range(40):
 x=-5.42+j*.278;cyl('VisualTerminalRing'+str(j),(x,.66,3.219),.066,.020,'z','silver',16);cyl('VisualJack'+str(j),(x,.66,3.236),.044,.017,'z',['red','electric','cyan','green','amber'][j%5],16)
for j in range(24):b('DeckFrontMachinedSlots'+str(j),-5.36+j*.46,.347,2.48,.033,.014,.31,'silver_dark')
txt('WorkstationBrand','PROJECT SPARK / RESILIENCE LAB',-2.6,.88,3.224,5.0,.125)
# 01 grid
c.start(1);enclosure('UtilityInterface',-5.00,1.66,-1.90,1.10,1.61,.78,'UTILITY GRID','cyan',3)
b('GridGlassIllumination',-5.00,1.87,-1.485,.69,.47,.015,'display')
for j in range(3):beam('PowerTowerLine'+str(j),(-5.27+j*.27,2.02,-1.468),(-5.27+j*.27,1.72,-1.468),.012,'cyan',8)
# 02 inverter
c.start(2);enclosure('GridFormingInverter',-2.48,1.60,-1.96,1.58,1.54,.96,'GRID-FORMING INV','cyan',5)
for j in range(12):b('InverterHeatFin'+str(j),-3.13+j*.118,2.45,-1.95,.048,.34,.74,'silver')
for j in range(3):jack('ThreePhaseOut'+str(j),-2.88+j*.37,1.26,-1.42,['red','amber','electric'][j])
# 03 Battery Rack
c.start(3)
b('BatteryRackFrame',1.12,1.59,-2.01,1.70,1.92,1.25,'blue_steel')
b('RackRecess',1.12,1.62,-1.364,1.54,1.65,.035,'dark')
for row in range(4):
 for k in range(4):
  xx=.52+k*.40;yy=.93+row*.38
  b(f'L60Battery_{row}_{k}',xx,yy,-1.29,.30,.28,.29,'electric')
  b(f'CellLight_{row}_{k}',xx,yy+.12,-1.13,.24,.029,.022,'cyan')
  for sh in [-1,1]:bolt('BatteryStud',(xx+sh*.105,yy+.14,-1.29),'y',.024)
for j in range(4):beam('BatteryCopperBus'+str(j),(.53+j*.39,.85,-1.08),(.53+j*.39,2.18,-1.08),.021,'copper',10)
txt('BatteryRackLabel','BATTERY STORAGE',.42,2.56,-1.35,1.45,.088)
# 04 BMS
c.start(4);enclosure('BMSPanel',2.47,1.61,-1.84,1.07,1.03,.77,'BATTERY BMS','green',4)
for j in range(5):b('SOCBar'+str(j),2.18+j*.15,1.74,-1.428,.10,.14,.016,'green')
# 05 bidirectional converter
c.start(5);enclosure('BidirectionalConverter',-.86,1.62,-1.95,1.18,1.24,.83,'BIDIRECTIONAL','mint',5)
for j in range(9):b('ConverterFin'+str(j),-1.30+j*.112,2.32,-1.92,.043,.30,.55,'silver')
for j in range(2):beam('BidirectionalArrow'+str(j),(-1.04,1.77,-1.501),(-.68,1.77,-1.501),.017,'mint',8)
# 06 Solar panel and support
c.start(6)
b('SolarPedestal',-3.84,1.30,-.63,.27,1.32,.34,'silver_dark')
b('SolarPanelBack',-3.84,2.26,-.85,1.78,.12,1.10,'blue_steel')
b('SolarPanelGlass',-3.84,2.344,-.85,1.68,.022,1.02,'navy')
for row in range(4):
 for k in range(7):b(f'PhotovoltaicCell_{row}_{k}',-4.50+k*.218,2.363,-1.21+row*.24,.19,.007,.19,'electric')
for j in range(2):b('PVSupportRail'+str(j),-3.84,2.28,-1.32+j*.90,1.76,.052,.045,'silver')
c.current.pivot('ANIM_SOLAR_TILT',(-3.84,2.25,-.85))
# 07 MPPT
c.start(7);enclosure('MPPTSolarController',-4.14,1.02,-1.87,.87,.73,.66,'SOLAR MPPT','violet',3)
# 08 generator
c.start(8)
b('GeneratorAntiVibrationSkid',4.18,.61,-2.14,2.63,.29,1.34,'carbon')
for x in [3.29,5.03]:
 for z in [-2.70,-1.57]:b('GenRubberMount',x,.82,z,.22,.22,.20,'rubber')
cyl('GeneratorAlternatorBody',(4.78,1.39,-2.17),.44,1.06,'x','electric',48)
for j in range(14):b('AlternatorAluminiumFin'+str(j),4.29+j*.067,1.85,-2.17,.034,.095,.74,'silver')
cyl('GeneratorRotor',(4.65,1.39,-2.17),.16,1.58,'x','chrome',32,'ANIM_GENERATOR_ROTOR')
cyl('PrimeMoverBlock',(3.58,1.39,-2.17),.36,1.12,'x','blue_steel',36)
for j in range(4):cyl('PrimeMoverCylinder'+str(j),(3.16+j*.23,1.78,-2.17),.107,.25,'y','silver_dark',16)
cyl('GeneratorCoupling',(4.14,1.39,-2.17),.26,.24,'x','amber',28,'ANIM_GENERATOR_ROTOR')
for j in range(6):beam('GeneratorGrille'+str(j),(5.28,1.18+j*.076,-2.43),(5.28,1.18+j*.076,-1.91),.014,'silver_dark',8)
c.current.pivot('ANIM_GENERATOR_ROTOR',(4.65,1.39,-2.17))
# 09 starter
c.start(9);enclosure('GeneratorStartUnit',3.28,.91,-.91,.86,.70,.66,'GEN STARTER','amber',3)
cyl('StarterPinion',(3.40,1.39,-1.20),.16,.22,'x','chrome',22,'ANIM_STARTER_PINION')
c.current.pivot('ANIM_STARTER_PINION',(3.40,1.39,-1.20))
# 10 three phase bus
c.start(10)
b('ThreePhaseBusProtectiveBack',0,1.14,-.40,10.8,.98,.080,'acrylic')
for j,(y,col) in enumerate([(1.43,'red'),(1.16,'amber'),(.89,'electric')]):
 beam('ACPowerBus'+str(j),(-5.13,y,-.33),(5.13,y,-.33),.058,col,14)
 for k in range(12):b('BusCeramicSupport_'+str(j)+'_'+str(k),-4.95+k*.90,y-.09,-.47,.10,.21,.12,'white')
for x in [-5.26,-3.16,-1.05,1.06,3.17,5.26]:b('BusMetallicStrut',x,1.16,-.46,.08,1.12,.16,'titanium')
# 11-18 eight breaker panels, front positions
for idx,x,name,color in [(11,-5.03,'GRID BREAKER','red'),(12,-3.78,'GEN BREAKER','amber'),(13,-2.53,'INV BREAKER','green'),(14,-1.28,'PV BREAKER','violet'),(15,-.03,'ESSENTIAL CB','green'),(16,1.22,'PRIORITY CB','green'),(17,2.47,'MOTOR CB','amber'),(18,3.72,'AUX CB','amber')]:breaker(idx,x,1.13,name,color)
# 19-21 loads, front
load(19,-3.47,2.08,'CRITICAL SERVICE','critical')
load(20,.18,2.07,'MOTOR DRIVE','motor')
load(21,2.14,2.07,'PROGRAM LOAD','programmable')
# 22 protection relays
c.start(22);enclosure('ProtectionRelayBank',4.93,1.29,.45,1.27,1.24,.69,'PROTECTION','amber',4)
for j in range(5):b('RelayCartridge'+str(j),4.47+j*.225,1.65,.825,.16,.38,.09,'navy')
for j in range(5):led('ProtectionStatus'+str(j),(4.47+j*.225,1.50,.841),'green',.027)
# 23 sensor hub
c.start(23);enclosure('SensorHub',-4.94,.89,-.62,1.08,.72,.68,'SENSOR HUB','cyan',5)
for j in range(3):tor('CTRing'+str(j),(-5.22+j*.28,1.39,-.74),.11,.035,'x','copper',28,8)
# 24 master controller
c.start(24);enclosure('ResilienceMaster',-.22,2.20,-1.92,1.83,.88,.65,'RESILIENCE MASTER','cyan',5)
for j in range(5):led('ControllerMode'+str(j),(-.83+j*.31,2.38,-1.566),'green' if j<3 else 'amber',.038)
# 25 SCADA monitor
c.start(25)
b('SCADASupportColumn',4.25,1.23,1.78,.21,1.30,.29,'silver_dark')
b('SCADAFoot',4.25,.56,1.78,1.42,.13,.83,'titanium')
b('SCADAMonitorFrame',4.25,2.62,1.67,2.85,1.81,.22,'blue_steel')
b('SCADAInteractiveGlass',4.25,2.62,1.793,2.65,1.60,.025,'display','ANIM_MONITOR_TILT')
for j in range(5):
 xx=3.28+j*.49;b('SCADAMiniStatus'+str(j),xx,2.96,1.811,.38,.18,.016,['green','cyan','amber','electric','violet'][j], 'ANIM_MONITOR_TILT')
for j in range(16):
 xx=3.05+j*.15
 beam('SCADAMeterHistory'+str(j),(xx,2.24,1.813),(xx,2.35+.13*math.sin(j*.80),1.813),.009,'cyan',8,'ANIM_MONITOR_TILT')
txt('SCADAHeader','MICROGRID SCADA',3.12,3.27,1.818,2.27,.105,'white','ANIM_MONITOR_TILT')
c.current.pivot('ANIM_MONITOR_TILT',(4.25,2.62,1.67))
# 26 fault module
c.start(26);enclosure('FaultScenarioUnit',-5.03,.89,1.96,1.04,.71,.74,'FAULT TEST','red',3)
for j in range(3):led('FaultArm'+str(j),(-5.28+j*.26,1.16,2.347),'red' if j==1 else 'amber',.030)
# 27 enclosure around generator
c.start(27)
for x in [2.91,5.48]:
 for z in [-2.93,-1.33]:beam('SafetyEnclosureUpright',(x,.44,z),(x,2.66,z),.037,'acrylic_rim',10)
for y in [.44,2.66]:
 for z in [-2.93,-1.33]:beam('EnclosureCrossbeam',(2.91,y,z),(5.48,y,z),.033,'acrylic_rim',10)
 for x in [2.91,5.48]:beam('EnclosureDepthBeam',(x,y,-2.93),(x,y,-1.33),.030,'acrylic_rim',10)
b('SafetyDoorPolycarbonate',4.19,1.54,-1.306,2.50,2.18,.014,'acrylic','ANIM_SAFETY_DOOR')
c.current.pivot('ANIM_SAFETY_DOOR',(2.91,2.66,-1.306))
led('SafetyDoorLimitSwitch',(3.05,2.48,-1.285),'green',.033)

manifest={'level_id':'level_60','display_name':'The Grid Must Survive','asset_kind':'procedural modular 3D art; gameplay integration not included','individual_models':28,'planned_player_wires':46,'planned_unique_terminals':72,'functional_terminals_included':False,'ac_network_simulation_included':False,'coordinate_system':'X width Y up Z toward front electronics; scale 1','models':[]}
for i,a in enumerate(c.assets):
 stem=f'{i:02d}_{a.name}';fbx=ROOT/'Models'/(stem+'.fbx');glb=ROOT/'GLB'/(stem+'.glb')
 c.fbx_export([a],fbx,a.name);c.glb_export(a,glb)
 triangles=sum(len(p.mesh.faces) for p in a.parts)
 manifest['models'].append({'index':i,'name':a.name,'file':fbx.name,'glb':glb.name,'triangle_count':triangles,'mesh_parts':len(a.parts),'animation_pivots':{k:v.tolist() for k,v in a.groups.items()}})
 print('exported',stem,triangles,flush=True)
c.fbx_export(c.assets,ROOT/'Models'/'Level60_Complete_ArtKit_Showcase.fbx','showcase')
scene=trimesh.Scene()
for asset in c.assets:
 for part in asset.parts:
  m=part.mesh.copy();m.visual.vertex_colors=np.tile((np.array(c.C[part.mat])*255).astype('uint8'),(len(m.vertices),1));scene.add_geometry(m,geom_name=asset.name+'__'+part.name)
(ROOT/'GLB'/'Level60_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
manifest['triangle_count']=sum(x['triangle_count'] for x in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with open(ROOT/'Animation_Rigs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['model','pivot','x','y','z'])
 for a in c.assets:
  for k,v in a.groups.items():w.writerow([a.name,k,*v.tolist()])
print('COMPLETE',len(c.assets),manifest['triangle_count'],flush=True)
