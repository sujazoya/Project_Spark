#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.Level95.BoardOnly
{
    public static class SparkLevel95MaterialBuilder
    {
        [MenuItem("Tools/Project Spark/Levels/95/Board Only/4. Create Native PBR Materials")]
        public static void CreateMaterials()
        {
            string[] materials = {"BoardSoldermask", "ICBlack", "CeramicChip", "GoldContacts", "SolderSilver", "ConnectorBlack"};
            string output="Assets/ProjectSpark/Level95BoardOnly/GeneratedMaterials";
            Directory.CreateDirectory(output);
            AssetDatabase.Refresh();
            Shader shader=Shader.Find("Universal Render Pipeline/Lit");
            if(shader==null) shader=Shader.Find("HDRP/Lit");
            if(shader==null) shader=Shader.Find("Standard");
            if(shader==null) {Debug.LogError("No supported Lit shader found"); return;}
            foreach(var name in materials)
            {
                Texture2D albedo=FindTexture(name+"_Albedo");
                Texture2D normal=FindTexture(name+"_Normal");
                Texture2D packed=FindTexture(name+"_MetallicRoughness");
                if(albedo==null) {Debug.LogWarning("Missing " + name + " albedo texture");continue;}
                var mat=new Material(shader){name="L95_"+name};
                if(mat.HasProperty("_BaseMap"))mat.SetTexture("_BaseMap",albedo);
                if(mat.HasProperty("_MainTex"))mat.SetTexture("_MainTex",albedo);
                if(mat.HasProperty("_BumpMap") && normal!=null){mat.SetTexture("_BumpMap",normal);mat.EnableKeyword("_NORMALMAP");}
                if(mat.HasProperty("_MetallicGlossMap") && packed!=null){mat.SetTexture("_MetallicGlossMap",packed);mat.EnableKeyword("_METALLICGLOSSMAP");}
                string p=output+"/L95_"+name+".mat";
                var old=AssetDatabase.LoadAssetAtPath<Material>(p);
                if(old==null)AssetDatabase.CreateAsset(mat,p);
                else {EditorUtility.CopySerialized(mat,old);UnityEngine.Object.DestroyImmediate(mat);}
            }
            AssetDatabase.SaveAssets();
            Debug.Log("[L95] Native material assets created. Assign using FBX source material slots / remap before production.");
        }
        static Texture2D FindTexture(string name)
        {
            foreach(string guid in AssetDatabase.FindAssets(name+" t:Texture2D"))
            {
                var p=AssetDatabase.GUIDToAssetPath(guid);
                if(Path.GetFileNameWithoutExtension(p)==name)return AssetDatabase.LoadAssetAtPath<Texture2D>(p);
            }
            return null;
        }
    }
}
#endif
