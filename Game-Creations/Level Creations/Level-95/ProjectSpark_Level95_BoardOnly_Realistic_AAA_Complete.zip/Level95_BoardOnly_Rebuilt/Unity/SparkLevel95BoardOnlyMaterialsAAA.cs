#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.Level95.BoardOnly
{
    /// <summary>Non-destructive auto material setup. Search assets by name, not fixed installation paths.</summary>
    public static class SparkLevel95BoardOnlyMaterialsAAA
    {
        const string M = "Tools/Project Spark/Levels/95/Board Only/";
        [MenuItem(M + "5. Generate ALL Materials + Remap FBX Slots")]
        public static void GenerateAndRemap()
        {
            string outDir = "Assets/ProjectSpark/L95BoardOnlyGeneratedMaterials";
            Directory.CreateDirectory(outDir);
            AssetDatabase.Refresh();
            var names = new[] { "FR4", "Soldermask", "Copper", "Gold", "Solder", "Chip", "Ceramic", "CapTan", "ResBody", "LEDGreen", "LEDAmber", "White", "Black", "Connector", "RedPlastic", "Glass", "Ink", "BoardArtwork", "LabelArt" };
            Color[] colors = {
                new Color(.13f,.31f,.28f), new Color(.016f,.115f,.18f), new Color(.66f,.34f,.12f), new Color(.88f,.63f,.23f),
                new Color(.64f,.70f,.75f), new Color(.022f,.027f,.038f), new Color(.73f,.73f,.67f),new Color(.70f,.47f,.18f),
                new Color(.10f,.12f,.15f),new Color(.08f,.88f,.30f),new Color(1f,.52f,.08f),new Color(.84f,.88f,.93f),
                new Color(.025f,.030f,.043f),new Color(.055f,.12f,.075f),new Color(.76f,.055f,.06f),new Color(.2f,.39f,.49f),
                new Color(.75f,.88f,.89f),Color.white,Color.white};
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (!shader) shader = Shader.Find("HDRP/Lit");
            if (!shader) shader = Shader.Find("Standard");
            if (!shader) { Debug.LogError("[L95] No Lit shader found"); return; }
            var mats = new System.Collections.Generic.Dictionary<string,Material>();
            for(int i=0;i<names.Length;i++)
            {
                string n=names[i]; string path=outDir+"/L95_"+n+".mat";
                var mat=AssetDatabase.LoadAssetAtPath<Material>(path);
                if (!mat) { mat=new Material(shader); AssetDatabase.CreateAsset(mat,path); }
                mat.shader=shader;mat.name="L95_"+n;
                if(mat.HasProperty("_Color"))mat.SetColor("_Color",colors[i]);
                if(mat.HasProperty("_BaseColor"))mat.SetColor("_BaseColor",colors[i]);
                string texName=TextureNameFor(n);
                var albedo=FindTexture(texName);
                if(albedo){
                   if(mat.HasProperty("_BaseMap"))mat.SetTexture("_BaseMap",albedo);
                   if(mat.HasProperty("_MainTex"))mat.SetTexture("_MainTex",albedo);
                }
                var normal=FindTexture((texName??"").Replace("_Albedo", "_Normal"));
                if(normal && mat.HasProperty("_BumpMap")){
                   var import=AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(normal)) as TextureImporter;
                   if(import && import.textureType!=TextureImporterType.NormalMap){import.textureType=TextureImporterType.NormalMap;import.SaveAndReimport();}
                   mat.SetTexture("_BumpMap",normal);mat.EnableKeyword("_NORMALMAP");
                }
                var metallic=FindTexture((texName??"").Replace("_Albedo","_UnityMetallicSmoothness"));
                if(metallic && mat.HasProperty("_MetallicGlossMap")){
                    mat.SetTexture("_MetallicGlossMap", metallic);mat.EnableKeyword("_METALLICGLOSSMAP");
                }
                if(n=="LEDGreen" || n=="LEDAmber"){
                    mat.EnableKeyword("_EMISSION");
                    if(mat.HasProperty("_EmissionColor"))mat.SetColor("_EmissionColor",colors[i]*1.3f);
                }
                EditorUtility.SetDirty(mat);mats[n]=mat;
            }
            // Attempt safe importer material remaps without modifying geometry or level gameplay.
            int remapped=0;
            foreach(string guid in AssetDatabase.FindAssets("t:Model"))
            {
                string p=AssetDatabase.GUIDToAssetPath(guid);
                if(!p.EndsWith(".fbx",StringComparison.OrdinalIgnoreCase))continue;
                if(!Path.GetFileName(p).Contains("L95_"))continue;
                var importer=AssetImporter.GetAtPath(p) as ModelImporter;
                if(!importer)continue;
                foreach(var pair in mats){
                    importer.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material),pair.Key),pair.Value);
                }
                importer.SaveAndReimport();remapped++;
            }
            AssetDatabase.SaveAssets();
            Debug.Log("[L95 Board Only] Generated " + mats.Count + " materials; inspected/remapped " + remapped + " FBX files. Verify board silk-screen and IC label atlas in Scene view.");
        }
        static string TextureNameFor(string mat)
        {
            switch(mat)
            {
                case "BoardArtwork":return "L95_Board_Top_SilkScreen_FactoryOnly";
                case "LabelArt":return "L95_IC_LaserEtch_Atlas";
                case "Soldermask":return "BoardSoldermask_Albedo";
                case "Chip":case "Black":case "ResBody":case "Ink":return "ICBlack_Albedo";
                case "Ceramic":return "CeramicChip_Albedo";
                case "Gold":case "Copper":case "CapTan":return "GoldContacts_Albedo";
                case "Solder":return "SolderSilver_Albedo";
                case "Connector":return "ConnectorBlack_Albedo";
                default:return null;
            }
        }
        static Texture2D FindTexture(string name)
        {
            if(string.IsNullOrEmpty(name))return null;
            foreach(string guid in AssetDatabase.FindAssets(name+" t:Texture2D"))
            {
                string p=AssetDatabase.GUIDToAssetPath(guid);
                if(Path.GetFileNameWithoutExtension(p)==name)return AssetDatabase.LoadAssetAtPath<Texture2D>(p);
            }
            return null;
        }
    }
}
#endif
