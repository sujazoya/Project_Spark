#if UNITY_EDITOR
using System;
using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.Level95.BoardOnly
{
    /// <summary>Board-only art assembler: DOES NOT create electrical connectivity, solder joints or objective successes.</summary>
    public static class SparkLevel95BoardOnlyBuilder
    {
        const string Menu = "Tools/Project Spark/Levels/95/Board Only/";
        [MenuItem(Menu + "1. Build Empty Precision PCB")]
        public static void BuildEmptyBoard()
        {
            GameObject parent = Selection.activeGameObject;
            if (parent == null) { Debug.LogError("Select a Level 95 art root first."); return; }
            var root = new GameObject("L95_PCB_BOARD_ONLY__NO_GAMEPLAY_CERTIFICATION");
            Undo.RegisterCreatedObjectUndo(root, "Build L95 board-only art");
            root.transform.SetParent(parent.transform, false);
            string board = FindModel("L95_PCB_120x80mm_RealScale");
            if (string.IsNullOrEmpty(board)) { Debug.LogError("Board FBX not found. Import Models_FBX first."); return; }
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(board);
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab, root.transform);
            instance.name = "PCB_Substrate_Only";
            instance.transform.localPosition=Vector3.zero;
            instance.transform.localRotation=Quaternion.identity;
            instance.transform.localScale=Vector3.one;
            root.AddComponent<SparkLevel95BoardVisualTargets>();
            Selection.activeGameObject = root;
            Debug.Log("[Project Spark L95] Empty art board created; components, 48 player routes and 10 vias remain UNINSTALLED.");
        }
        [MenuItem(Menu + "2. Place Reference Showcase (visual ONLY)")]
        public static void BuildShowcase()
        {
            if(Selection.activeGameObject==null) {Debug.LogError("Select an art root.");return;}
            var path=FindModel("L95_COMPLETE_BOARD_REFERENCE_VISUAL_ONLY");
            if (string.IsNullOrEmpty(path)) {Debug.LogError("Showcase FBX missing.");return;}
            var obj=AssetDatabase.LoadAssetAtPath<GameObject>(path);
            var go=(GameObject)PrefabUtility.InstantiatePrefab(obj,Selection.activeGameObject.transform);
            go.name="L95_VISUAL_REFERENCE__DO_NOT_USE_FOR_PLAYER_START";
            go.SetActive(false);
            Debug.Log("[L95] Reference board created INACTIVE. Do not use to certify gameplay.");
        }
        [MenuItem(Menu + "3. Validate Board-Only Models")]
        public static void Validate()
        {
            string path=FindModel("L95_PCB_120x80mm_RealScale");
            if(string.IsNullOrEmpty(path)){Debug.LogError("Missing board model");return;}
            int count=0;string[] guids=AssetDatabase.FindAssets("t:Model");
            foreach(string guid in guids)if(AssetDatabase.GUIDToAssetPath(guid).Contains("L95_"))count++;
            Debug.Log($"[Project Spark L95] Found {count} L95 board-only model files. Check mm-to-m import dimensions; no electrical claims.");
        }
        static string FindModel(string token)
        {
            foreach(string guid in AssetDatabase.FindAssets("t:Model"))
            {
                string p=AssetDatabase.GUIDToAssetPath(guid);
                if(p.EndsWith(".fbx",StringComparison.OrdinalIgnoreCase) && p.Contains(token))return p;
            }
            return null;
        }
    }
}
#endif
