using UnityEngine;

namespace ProjectSpark.Level95.BoardOnly
{
    /// <summary>
    /// Purely visual reference points. Use the existing electrical solver for all gameplay state.
    /// No direct calls to LevelGamePlayManager are made by this component.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SparkLevel95BoardVisualTargets : MonoBehaviour
    {
        [SerializeField] private float presentationScale = 12f;
        [SerializeField] private bool applyVisualScaleAtRuntime = false;
        public float PhysicalWidthMeters => .120f;
        public float PhysicalDepthMeters => .080f;
        public int RequiredPlayerRoutes => 48;
        public int RequiredVias => 10;
        public bool CriticalW049StartsConnected => false;
        private void Awake()
        {
            // Keep electrical dimensions and connectivity separate from art-only enlargement.
            if (applyVisualScaleAtRuntime) transform.localScale=Vector3.one * presentationScale;
        }
    }
}
