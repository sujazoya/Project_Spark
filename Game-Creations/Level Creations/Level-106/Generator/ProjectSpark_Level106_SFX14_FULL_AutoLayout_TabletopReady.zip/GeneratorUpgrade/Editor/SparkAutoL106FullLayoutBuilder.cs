#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ProjectSpark.AutoLevelGenerator.Editor
{
    /// <summary>
    /// Full source-art and gameplay-binding layout for Level 106 SFX-14 First Boot.
    /// Requires the installed Universal Auto Level Generator V2 runtime/editor classes.
    /// Prefers GLB-derived mesh-bearing OBJ fallback over unrenderable FBX.
    /// The imported OBJ is a VISUAL asset; no pin netlist or completed gameplay is inferred.
    /// </summary>
    public static class SparkAutoL106FullLayoutBuilder
    {
        private const int LevelId = 106;
        private const string RecipeFile = "Level106_SFX14.recipe.json";
        private const string LayoutName = "Level_106_Layout";
        private const float TableWidth = 15.79f;
        private const float TableDepth = 8.54f;
        private const float TargetWidth = 10.13f;
        private const float TargetDepth = 7.51f;
        private const int PartTotal = 106, RouteTotal = 140, ViaTotal = 42;
        private const int FaultTotal = 3, ObjectiveTotal = 6;
        // Binding anchors only: existing Project Spark systems own the actual actions and state.
        private static readonly string[] VirtualTools = {
            "Multimeter", "CurrentLimitedPowerSource", "Oscilloscope", "LogicAnalyzer",
            "POSTAnalyzer", "FirmwareProgrammer", "DDR4Trainer", "PCIeAnalyzer",
            "StorageTester", "ThermalScanner", "NetTracer", "Microscope",
            "SolderDesolder", "ComponentReplacement", "TenLayerViewer",
            "BootSequenceViewer", "EvidenceNotebook"
        };
        private static readonly string[] Controls = {
            "INSPECT", "ASSEMBLE", "ROUTE", "VIA", "SELECT", "MEASURE", "CALIBRATE",
            "POWER_OFF", "CURRENT_LIMITED_POWER_ON", "READ_POWER_RAILS", "VERIFY_RESET_TIMING",
            "TRAIN_DDR4", "READ_SPI_FIRMWARE", "VERIFY_FIRMWARE", "RUN_POST",
            "ENUMERATE_PCIE", "VERIFY_EMMC", "BOOT_TO_VIRTUAL_OS", "REPAIR_F1_PGOOD",
            "REPAIR_F2_SPI", "REPAIR_F3_EMMC", "W141_DISCONNECT", "W141_RECONNECT",
            "W141_RESET_SAFETY", "RUN_FRESH_QUALIFICATION", "SHOW_OBJECTIVES",
            "SAVE_LEVEL", "RELOAD_LEVEL"
        };
        private static readonly string[] FirstBootSystems = {
            "PowerInput12VAndStandby", "CurrentLimitedStartup", "CPU_VCORE_Regulation",
            "DDR4_VDD_VPP", "PowerGoodAndResetSequencing", "CPU_ClockQualification",
            "DDR4_FourByteLaneTraining", "SPI_FirmwareVerification",
            "VirtualUEFI_SEC_PEI_DXE_BDS", "PCIeLinkTrainingAndEnumeration",
            "eMMC_StorageVerification", "VirtualOSBootHandoff", "POSTStateMachine",
            "F1_CPU_PGOOD_TIMING", "F2_SPI_FLASH_CONTACT", "F3_eMMC_CONTACT",
            "W141_IndependentSafety", "EvidenceRevisionsAndPersistence",
            "ExistingLevelGamePlayManagerBinding"
        };

        [MenuItem("Tools/Project Spark/Automatic Level Generator/106/1. Build FULL Level_106_Layout")]
        public static void BuildFullLevel106()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                Debug.LogError("[L106 Layout] Stop Play Mode before generating.");
                return;
            }
            SparkAutoLevelBlueprint transient = null;
            var report = new SparkAutoLevelBuildReport();
            try
            {
                SparkAutoLevelRecipe recipe = SparkAutoLevelSourceImporter.LoadRecipe(RecipeFile);
                if (recipe.levelId != LevelId) throw new InvalidOperationException("Level 106 recipe expected");
                transient = SparkAutoLevelSourceImporter.Import(recipe, report);
                if (report.Errors != 0)
                    throw new InvalidOperationException("Source validation failed:\n" + report.Render());
                if (transient.Parts.Count != 136 || transient.InstallableCount != PartTotal ||
                    transient.Routes.Count != RouteTotal || transient.Vias.Count != ViaTotal ||
                    transient.Faults.Count != FaultTotal || transient.Objectives.Count != ObjectiveTotal)
                    throw new InvalidOperationException("Level 106 source counts have changed. Refusing partial build.");

                var modelPaths = ResolveModels(recipe, transient, report);
                string bareAsset;
                if (!modelPaths.TryGetValue(recipe.bareBoardId, out bareAsset))
                    throw new FileNotFoundException("Missing renderable EMPTY SFX-14 PCB: " + recipe.bareBoardId);
                int missing = 0;
                foreach (SparkAutoPart part in transient.Parts)
                    if (part.Installable && !modelPaths.ContainsKey(part.Id)) missing++;
                if (missing > 0) throw new FileNotFoundException(missing + " installable FBX/OBJ models failed import. Build cancelled.");

                string output = recipe.generatedAssetsFolder.TrimEnd('/');
                SparkAutoLevelSceneBuilder.EnsureFolder(output);
                string prefabPath = output + "/" + LayoutName + ".prefab";
                string scenePath = output + "/" + LayoutName + ".unity";
                if ((AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath) != null ||
                     AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath) != null) &&
                    !EditorUtility.DisplayDialog("Regenerate Level 106?",
                        "This will overwrite ONLY the generated Level_106_Layout prefab and scene. " +
                        "Keep hand edits in a separate prefab. Previous levels are untouched.",
                        "Overwrite generated Level 106", "Cancel")) return;

                string blueprintPath = output + "/L106_SourceBlueprint.asset";
                SparkAutoLevelBlueprint persistent = AssetDatabase.LoadAssetAtPath<SparkAutoLevelBlueprint>(blueprintPath);
                if (persistent == null)
                {
                    persistent = transient;
                    transient = null;
                    AssetDatabase.CreateAsset(persistent, blueprintPath);
                }
                else
                {
                    EditorUtility.CopySerialized(transient, persistent);
                    EditorUtility.SetDirty(persistent);
                }
                foreach (SparkAutoPart part in persistent.Parts)
                {
                    string path;
                    if (modelPaths.TryGetValue(part.Id, out path)) part.AssetPath = path;
                }
                EditorUtility.SetDirty(persistent);
                AssetDatabase.SaveAssets();
                Dictionary<string, Material> materials = SparkAutoURPMaterialBuilder.Build(recipe, report);
                BuildLayoutScene(recipe, persistent, modelPaths, materials, prefabPath, scenePath, report);
                File.WriteAllText(SparkAutoLevelSourceImporter.ToAbsolute(output + "/L106_Layout_Validation.txt"),
                    report.Render() + "\nGeometry centered and workshop footprint 10.13 x 7.51 units. " +
                    "Electrical pins/nets and gameplay service bindings still require authoritative design.\n");
                AssetDatabase.Refresh();
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                if (prefab != null) { Selection.activeObject = prefab; EditorGUIUtility.PingObject(prefab); }
                Debug.Log("[L106 Layout] Generated " + prefabPath + "\n" + report.Render());
            }
            catch (Exception e)
            {
                Debug.LogError("[L106 Layout] " + e);
                EditorUtility.DisplayDialog("Level 106 generation stopped", e.Message, "OK");
            }
            finally
            {
                if (transient != null) UnityEngine.Object.DestroyImmediate(transient);
            }
        }

        [MenuItem("Tools/Project Spark/Automatic Level Generator/106/2. Place Level 106 on SELECTED tabletop")]
        public static void PlaceOnSelectedTabletop()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            GameObject table = Selection.activeGameObject;
            if (table == null) { EditorUtility.DisplayDialog("Select the table", "Select your tabletop GameObject in the Hierarchy first.", "OK"); return; }
            string expected = "Assets/ProjectSpark/AutoGeneratedLevels/Level106/" + LayoutName + ".prefab";
            GameObject source = AssetDatabase.LoadAssetAtPath<GameObject>(expected);
            if (source == null) { EditorUtility.DisplayDialog("Missing layout", "Build FULL Level 106 layout first.", "OK"); return; }
            // An artist-authored tabletop may be a plain Transform with no mesh or Collider.
            // Support that as an explicitly confirmed placement anchor. Its Transform.scale
            // is NOT the tabletop's measured size; scaling the board by it would be wrong.
            Bounds top;
            bool hasBounds = TryTableBounds(table, out top);
            Vector3 placement;
            float actualTableWidth;
            float actualTableDepth;
            if (hasBounds)
            {
                actualTableWidth = top.size.x;
                actualTableDepth = top.size.z;
                if (actualTableWidth + 0.001f < TargetWidth || actualTableDepth + 0.001f < TargetDepth)
                {
                    EditorUtility.DisplayDialog("Table too small",
                        "Selected object's bounds are " + actualTableWidth.ToString("F2") +
                        " x " + actualTableDepth.ToString("F2") +
                        ". Select the actual tabletop (15.79 x 8.54 units) or use a Transform-only tabletop anchor.", "OK");
                    return;
                }
                if (Mathf.Abs(actualTableWidth - TableWidth) > 0.75f ||
                    Mathf.Abs(actualTableDepth - TableDepth) > 0.75f)
                {
                    bool goAhead = EditorUtility.DisplayDialog("Different tabletop dimensions",
                        "Expected 15.79 x 8.54. Measured " + actualTableWidth.ToString("F2") +
                        " x " + actualTableDepth.ToString("F2") +
                        ". Board footprint remains 10.13 x 7.51. Place anyway?",
                        "Place", "Cancel");
                    if (!goAhead) return;
                }
                // Board prefab was built with its base at local Y = 0.
                placement = new Vector3(top.center.x, top.max.y, top.center.z);
            }
            else
            {
                // The selected object (e.g. Table_top) is an anchor, not geometry.
                // Use the user-supplied real tabletop dimensions for clearance checks.
                actualTableWidth = TableWidth;
                actualTableDepth = TableDepth;
                placement = table.transform.position;
                if (!EditorUtility.DisplayDialog("Use Transform as tabletop anchor?",
                    "'" + table.name + "' has no enabled Renderer or Collider.\n\n" +
                    "Use its world position as the tabletop SURFACE CENTER?\n" +
                    "X=" + placement.x.ToString("F3") + ", Y=" + placement.y.ToString("F3") +
                    ", Z=" + placement.z.ToString("F3") + "\n\n" +
                    "The board will be 10.13 x 7.51 world units, centered on the supplied " +
                    "15.79 x 8.54 tabletop. The anchor's Transform SCALE will be ignored.\n\n" +
                    "Cancel if the anchor's Y is not the tabletop surface height.",
                    "Place on anchor", "Cancel")) return;
            }

            GameObject placed = (GameObject)PrefabUtility.InstantiatePrefab(source);
            Undo.RegisterCreatedObjectUndo(placed, "Place Level 106 on tabletop");
            placed.name = LayoutName;
            placed.transform.position = placement;
            placed.transform.rotation = Quaternion.identity;
            // The layout scale was already calculated from imported PCB geometry at build time.
            // Never inherit an arbitrary Table_top Transform scale.
            placed.transform.localScale = Vector3.one;
            Selection.activeGameObject = placed;
            Debug.Log("[L106 Layout] Placed " + LayoutName + " at " + placement +
                (hasBounds ? " using tabletop geometry." : " using confirmed Transform anchor.") +
                " Expected centered margins: " +
                ((actualTableWidth - TargetWidth) * 0.5f).ToString("F3") + " each side and " +
                ((actualTableDepth - TargetDepth) * 0.5f).ToString("F3") +
                " each end. Verify actual top-surface height in Scene view.");
        }

        private static bool TryTableBounds(GameObject table, out Bounds bounds)
        {
            Collider col = table.GetComponent<Collider>();
            if (col != null && col.enabled) { bounds = col.bounds; return true; }
            Renderer renderer = table.GetComponent<Renderer>();
            if (renderer != null && renderer.enabled) { bounds = renderer.bounds; return true; }
            Collider[] colliders = table.GetComponentsInChildren<Collider>();
            for (int i = 0; i < colliders.Length; i++)
                if (colliders[i].enabled) { bounds = colliders[i].bounds; return true; }
            Renderer[] renderers = table.GetComponentsInChildren<Renderer>();
            for (int i = 0; i < renderers.Length; i++)
                if (renderers[i].enabled) { bounds = renderers[i].bounds; return true; }
            bounds = default(Bounds);
            return false;
        }

        // Unity occasionally imports the original procedurally exported ASCII FBX as an
        // empty hierarchy.  This method selects real mesh-bearing OBJ fallbacks generated
        // from the package's matching GLBs, preserving native millimeter coordinates.
        // Prefer OBJ for ALL parts to keep the unit/axis conventions consistent.
        private static Dictionary<string, string> ResolveModels(SparkAutoLevelRecipe recipe,
            SparkAutoLevelBlueprint blueprint, SparkAutoLevelBuildReport report)
        {
            var paths = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string sourceRoot = recipe.sourceAssetsFolder.TrimEnd('/');
            string fallbackRoot = sourceRoot + "/Models_OBJ_Fallback/";
            foreach (SparkAutoPart part in blueprint.Parts)
            {
                string obj = fallbackRoot + part.Id + ".obj";
                if (HasMeshGeometry(obj))
                {
                    paths[part.Id] = obj;
                    continue;
                }

                string direct = sourceRoot + "/" + (part.AssetPath ?? "").TrimStart('/');
                if (HasMeshGeometry(direct))
                {
                    paths[part.Id] = direct;
                    continue;
                }

                string[] guids = AssetDatabase.FindAssets(part.Id + " t:Model", new[] { sourceRoot });
                string match = null;
                foreach (string guid in guids)
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    string filename = Path.GetFileNameWithoutExtension(path);
                    if (!(path.EndsWith(".fbx", StringComparison.OrdinalIgnoreCase) ||
                          path.EndsWith(".obj", StringComparison.OrdinalIgnoreCase)) ||
                        !(filename == part.Id || filename.EndsWith("_" + part.Id, StringComparison.OrdinalIgnoreCase)) ||
                        !HasMeshGeometry(path)) continue;
                    if (match != null) { report.Warn("Ambiguous usable mesh for " + part.Id); match = null; break; }
                    match = path;
                }
                if (match != null) paths[part.Id] = match;
                else report.Warn("No renderable imported model found for " + part.Id +
                    ". Install Models_OBJ_Fallback or repair the original FBX import.");
            }
            string assembled = recipe.assembledBoardModelName;
            string assembledObj = fallbackRoot + assembled + ".obj";
            string assembledFbx = sourceRoot + "/Models_FBX/" + assembled + ".fbx";
            if (HasMeshGeometry(assembledObj)) paths[assembled] = assembledObj;
            else if (HasMeshGeometry(assembledFbx)) paths[assembled] = assembledFbx;
            else report.Warn("Optional assembled model has no imported mesh; modular assembled reference will be constructed instead.");
            return paths;
        }

        private static bool HasMeshGeometry(string assetPath)
        {
            GameObject asset = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (asset == null) return false;
            MeshFilter[] filters = asset.GetComponentsInChildren<MeshFilter>(true);
            for (int i = 0; i < filters.Length; ++i)
                if (filters[i].sharedMesh != null && filters[i].sharedMesh.vertexCount > 0)
                    return true;
            SkinnedMeshRenderer[] skinned = asset.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            for (int i = 0; i < skinned.Length; ++i)
                if (skinned[i].sharedMesh != null && skinned[i].sharedMesh.vertexCount > 0)
                    return true;
            return false;
        }

        private static void BuildLayoutScene(SparkAutoLevelRecipe recipe, SparkAutoLevelBlueprint data,
            Dictionary<string, string> models, Dictionary<string, Material> materials,
            string prefabPath, string scenePath, SparkAutoLevelBuildReport report)
        {
            Scene previous = SceneManager.GetActiveScene();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            try
            {
                SceneManager.SetActiveScene(scene);
                GameObject root = new GameObject(LayoutName);
                root.AddComponent<SparkAutoGeneratedMarker>().Configure(LevelId, false);
                root.AddComponent<SparkAutoLevelRuntime>().Configure(data, false);
                Meta(root, "L106", "LEVEL_LAYOUT", "AUTHORING_GENERATED", "Gameplay starts empty. Authority integration required.");
                var fitConfig = root.AddComponent<SparkAutoL106WorkshopFit>();

                Transform fit = Child(root.transform, "L106_TabletopFittedBoard_10_13x7_51");
                Transform modelSpace = Child(fit, "L106_NativeFBXModelSpace");
                Transform board = Child(modelSpace, "L106_BoardArtRoot");
                Transform slots = Child(modelSpace, "L106_ComponentSlots_106_UNINSTALLED");
                Transform pads = Child(modelSpace, "L106_PhysicalPads_SCHEMATIC_REQUIRED");
                Transform topology = Child(modelSpace, "L106_SolverTopology_SCHEMATIC_REQUIRED");
                Transform routes = Child(modelSpace, "L106_PlayerCopper_140_UNROUTED");
                Transform vias = Child(modelSpace, "L106_ViaSockets_42_UNASSIGNED");
                Transform layers = Child(modelSpace, "L106_CopperLayers_10_VisualOnly");
                Transform service = Child(modelSpace, "L106_ServiceableHardwareReferences_NotInstalled");
                Transform structural = Child(modelSpace, "L106_StructuralReferences");
                Transform faultVisual = Child(modelSpace, "L106_FaultOverlays_Disabled");
                Transform reference = Child(modelSpace, "L106_CompleteAssembledReference_NoProgress");
                Transform assembledFBX = Child(reference, "L106_CompleteAssembledModel");
                Transform modular = Child(reference, "L106_CompleteModularComposition");
                Transform systems = Child(root.transform, "L106_ElectricalBootAndRepairSystems_UNBOUND");
                Transform safety = Child(root.transform, "L106_W141_IndependentSafety_UNBOUND");
                Transform objectives = Child(root.transform, "L106_Objectives_6_UNBOUND");
                Transform faults = Child(root.transform, "L106_RepairTargets_3_UNBOUND");
                Transform instruments = Child(root.transform, "L106_WorldSpaceVirtualInstruments_UNBOUND");
                Transform controls = Child(root.transform, "L106_WorldSpaceLevelControls_UNBOUND");

                GameObject empty = PlaceModel(models[recipe.bareBoardId], recipe.bareBoardId, board);
                SparkAutoURPMaterialBuilder.Apply(empty, materials);
                Meta(empty, recipe.bareBoardId, "EMPTY_PCB", "VISIBLE_AT_START", "Primary PCB geometry; does not certify nets.", true);

                Bounds measured;
                if (!GetRendererBounds(empty, out measured))
                    throw new InvalidOperationException("Empty PCB has no MeshRenderer. Import the Models_OBJ_Fallback folder from the Level 106 mesh repair package and retry.");
                bool originalPlaneXY = measured.size.y > measured.size.z * 2.0f;
                if (originalPlaneXY) modelSpace.localRotation = Quaternion.Euler(-90f, 0f, 0f);
                if (!GetRendererBounds(empty, out measured) || measured.size.x < 0.00001f || measured.size.z < 0.00001f)
                    throw new InvalidOperationException("Empty PCB has invalid XZ bounds after axis correction.");
                float mmToNative = measured.size.x / recipe.widthMm;
                float scaleX = TargetWidth / measured.size.x;
                float scaleZ = TargetDepth / measured.size.z;
                float scaleY = (scaleX + scaleZ) * 0.5f;
                fit.localScale = new Vector3(scaleX, scaleY, scaleZ);
                fit.localPosition = new Vector3(0f, -measured.min.y * scaleY, 0f);
                fitConfig.Configure(fit, TableWidth, TableDepth, TargetWidth, TargetDepth,
                    measured.size.x, measured.size.z, originalPlaneXY, mmToNative);

                int extra = 0;
                foreach (SparkAutoPart part in data.Parts)
                {
                    if (part.Installable || part.Id == recipe.bareBoardId) continue;
                    string path;
                    if (!models.TryGetValue(part.Id, out path)) continue;
                    Transform destination = structural;
                    string type = (part.Type ?? "").ToUpperInvariant();
                    if (type.Contains("LAYER") || type.Contains("PLANE")) destination = layers;
                    else if (type.Contains("HEATSINK") || type.Contains("SPREADER") ||
                             type.Contains("HEATPIPE") || type.Contains("THERMAL_PAD")) destination = service;
                    else if (type.Contains("FAULT") || type.Contains("OVERLAY")) destination = faultVisual;
                    GameObject mesh = PlaceModel(path, part.Id, destination);
                    SetPartPose(mesh.transform, part, mmToNative, originalPlaneXY);
                    SparkAutoURPMaterialBuilder.Apply(mesh, materials);
                    Meta(mesh, part.Id, part.Type, "ART_ONLY", part.Notes, true);
                    extra++;
                }
                layers.gameObject.SetActive(false);
                service.gameObject.SetActive(false);
                faultVisual.gameObject.SetActive(false);

                int placedSlots = 0;
                SparkAutoLevelRuntime runtime = root.GetComponent<SparkAutoLevelRuntime>();
                foreach (SparkAutoPart part in data.Parts)
                {
                    if (!part.Installable) continue;
                    string modelPath = models[part.Id];
                    var go = Child(slots, part.Id).gameObject;
                    SetPartPose(go.transform, part, mmToNative, originalPlaneXY);
                    BoxCollider collider = go.AddComponent<BoxCollider>();
                    Vector2 sizeMm = FootprintSize(part.Type);
                    float nativeHeight = 3.0f * mmToNative;
                    collider.size = originalPlaneXY
                        ? new Vector3(sizeMm.x * mmToNative, sizeMm.y * mmToNative, nativeHeight)
                        : new Vector3(sizeMm.x * mmToNative, nativeHeight, sizeMm.y * mmToNative);
                    collider.center = originalPlaneXY
                        ? new Vector3(0f, 0f, nativeHeight * 0.5f)
                        : new Vector3(0f, nativeHeight * 0.5f, 0f);
                    var placement = go.AddComponent<SparkAutoPlacementTarget>();
                    placement.Configure(part.Id, part.Type, runtime, false,
                        AssetDatabase.LoadAssetAtPath<GameObject>(modelPath));
                    Meta(go, part.Id, "COMPONENT_SLOT", "UNINSTALLED", "Footprint target; exact pin mapping required for certification.", false, true);
                    GameObject visual = PlaceModel(modelPath, part.Id, modular);
                    SetPartPose(visual.transform, part, mmToNative, originalPlaneXY);
                    SparkAutoURPMaterialBuilder.Apply(visual, materials);
                    placedSlots++;
                }
                int routeCount = 0;
                foreach (SparkAutoRoute route in data.Routes)
                {
                    Transform group = GetOrAdd(routes, "SUBSYSTEM_" + SafeName(route.Subsystem));
                    Transform entry = Child(group, route.Id);
                    Meta(entry.gameObject, route.Id, "COPPER_ROUTE", "NOT_CERTIFIABLE",
                        "Net=" + route.NetId + "; source=" + route.SourceComponent + "; destination=" +
                        route.DestinationComponent + "; layer=" + route.Layer + "; status=" + route.SourceStatus,
                        false, true);
                    routeCount++;
                }
                int viaCount = 0;
                foreach (SparkAutoVia via in data.Vias)
                {
                    Transform entry = Child(vias, via.Id);
                    Meta(entry.gameObject, via.Id, "VIA_TASK", "NOT_CERTIFIABLE",
                        "Net=" + via.NetId + "; layer=" + via.FromLayer + " to " + via.ToLayer +
                        "; XY=" + via.Xmm + "," + via.Ymm + "; status=" + via.SourceStatus,
                        false, true);
                    viaCount++;
                }
                for (int layer = 1; layer <= data.CopperLayers; layer++)
                    Meta(Child(layers, "COPPER_LAYER_" + layer.ToString("D2")).gameObject,
                        "L" + layer.ToString("D2"), "LAYER_REFERENCE", "ART_ONLY", "Not real electrical connectivity.", true);
                Meta(pads.gameObject, "L106_PADS", "PADS", "SCHEMATIC_REQUIRED",
                    "The art source has no approved pad/terminal definitions: cannot create electrical contacts.", false, true);
                Meta(topology.gameObject, "L106_TOPOLOGY", "ELECTRICAL_GRAPH", "SCHEMATIC_REQUIRED",
                    "Do not synthesize arbitrary connections to meet route counts.", false, true);

                foreach (SparkAutoFault fault in data.Faults)
                    Meta(Child(faults, fault.Id + "_" + SafeName(fault.Title)).gameObject,
                        fault.Id, "REPAIR_SCENARIO", "NOT_STARTED",
                        "Mechanism=" + fault.Mechanism + "; Repair=" + fault.Repair, false, true);
                foreach (SparkAutoObjective objective in data.Objectives)
                    Meta(Child(objectives, "OBJ_" + objective.Id + "_" + SafeName(objective.Title)).gameObject,
                        objective.Id, "OBJECTIVE", "NOT_STARTED", objective.Criterion, false, true);
                foreach (string name in FirstBootSystems)
                    Meta(Child(systems, name).gameObject, name, "SYSTEM_BINDING", "UNBOUND",
                        "Bind to existing Project Spark power, firmware, DDR4, PCIe, eMMC, repairs and objective services.");
                foreach (string name in VirtualTools)
                    Meta(Child(instruments, name).gameObject, name, "WORLD_SPACE_TOOL", "UNBOUND",
                        "Bind existing virtual tool; no physical laboratory instrument is generated.");
                foreach (string name in Controls)
                    Meta(Child(controls, name).gameObject, name, "UI_CONTROL_BINDING", "UNBOUND",
                        "Use the existing World-Space Canvas UI/actions.");
                Meta(safety.gameObject, "W141", "INDEPENDENT_BOOT_SAFETY", "DISCONNECTED",
                    data.Safety.LogicalSource + " -> " + data.Safety.LogicalDestination +
                    "; physicalPins=" + data.Safety.PhysicalPinStatus + "; requires fresh data and explicit reset.", false, true);
                Meta(Child(safety, "W141_Jumper_Removal_And_Recovery").gameObject,
                    "W141", "REMOVABLE_JUMPER", "NOT_AUTHORIZED",
                    "Physical contacts and supervisor logic must be verified before enabling safety certification.", false, true);

                string assembledPath;
                bool hasAssembled = models.TryGetValue(recipe.assembledBoardModelName, out assembledPath);
                if (hasAssembled)
                {
                    GameObject mesh = PlaceModel(assembledPath, recipe.assembledBoardModelName, assembledFBX);
                    SparkAutoURPMaterialBuilder.Apply(mesh, materials);
                    Meta(mesh, "L106_ASSEMBLED", "COMPLETE_BOARD_MESH", "REFERENCE_ONLY",
                        "Never count this artwork as installed parts or completed objectives.", true);
                }
                else
                {
                    // Build an art-only assembled board from 136 imported modular models.
                    foreach (SparkAutoPart part in data.Parts)
                    {
                        if (part.Installable || part.Id == recipe.bareBoardId) continue;
                        string path;
                        if (!models.TryGetValue(part.Id, out path)) continue;
                        GameObject mesh = PlaceModel(path, part.Id, modular);
                        SetPartPose(mesh.transform, part, mmToNative, originalPlaneXY);
                        SparkAutoURPMaterialBuilder.Apply(mesh, materials);
                    }
                    GameObject boardCopy = PlaceModel(models[recipe.bareBoardId], recipe.bareBoardId, modular);
                    SparkAutoURPMaterialBuilder.Apply(boardCopy, materials);
                    report.Warn("One-piece assembled mesh absent. Generated modular assembled art-only fallback.");
                }
                assembledFBX.gameObject.SetActive(hasAssembled);
                modular.gameObject.SetActive(!hasAssembled);
                reference.gameObject.SetActive(false);

                if (placedSlots != PartTotal || routeCount != RouteTotal || viaCount != ViaTotal)
                    throw new InvalidOperationException("Generated layout counts do not match imported Level 106 manifest.");
                report.Info("Level_106_Layout: 106 uninstalled part targets, 140 unapproved routes, 42 unapproved vias, " +
                    "3 faults, 6 objectives, 10 copper layer references, " + extra + " supplemental meshes.");
                report.Info("Model axis: " + (originalPlaneXY ? "XY rotated to XZ" : "native XZ") +
                    "; native import width=" + measured.size.x.ToString("F6", CultureInfo.InvariantCulture) +
                    "; native depth=" + measured.size.z.ToString("F6", CultureInfo.InvariantCulture));
                report.Info("WORKSHOP BOARD: " + TargetWidth + " x " + TargetDepth + " units; table " + TableWidth +
                    " x " + TableDepth + " units; margins (centered) " + ((TableWidth - TargetWidth) / 2f) +
                    " left/right, " + ((TableDepth - TargetDepth) / 2f) + " front/back.");
                report.Warn("106 physical terminal mappings, routes W001-W140, vias V01-V42 and W141 physical pins " +
                    "are not approved; W141 U14 source is missing from the BOM. All electrical and final objective authority remains BLOCKED.");
                report.Warn("W141 logical source L106_SystemBootMonitor_U14 is absent from the 106-part BOM; NEVER silently bind it to another IC.");
                bool saved;
                PrefabUtility.SaveAsPrefabAsset(root, prefabPath, out saved);
                if (!saved) throw new IOException("Could not save prefab " + prefabPath);
                if (!EditorSceneManager.SaveScene(scene, scenePath))
                    throw new IOException("Could not save scene " + scenePath);
            }
            finally
            {
                EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
            }
        }

        private static Vector2 FootprintSize(string type)
        {
            string name = (type ?? "").ToUpperInvariant();
            if (name.Contains("CPU")) return new Vector2(45f, 45f);
            if (name.Contains("DDR")) return new Vector2(13f, 13f);
            if (name.Contains("INDUCTOR")) return new Vector2(11f, 11f);
            if (name.Contains("MOSFET")) return new Vector2(7f, 7f);
            if (name.Contains("CONTROLLER") || name.Contains("MONITOR")) return new Vector2(9f, 9f);
            if (name.Contains("CONNECTOR")) return new Vector2(10f, 6f);
            if (name.Contains("CAP")) return new Vector2(3.2f, 2.4f);
            if (name.Contains("RES")) return new Vector2(2.5f, 1.8f);
            return new Vector2(5f, 5f);
        }
        private static void SetPartPose(Transform transform, SparkAutoPart part, float nativePerMm, bool planeXY)
        {
            transform.localPosition = planeXY
                ? new Vector3(part.Xmm, part.Ymm, part.Zmm) * nativePerMm
                : new Vector3(part.Xmm, part.Zmm, -part.Ymm) * nativePerMm;
            if (Mathf.Abs(part.OrientationDegrees) > 0.001f)
                transform.localRotation *= planeXY
                    ? Quaternion.Euler(0f, 0f, part.OrientationDegrees)
                    : Quaternion.Euler(0f, part.OrientationDegrees, 0f);
        }
        private static GameObject PlaceModel(string path, string name, Transform parent)
        {
            GameObject asset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (asset == null) throw new FileNotFoundException("Imported FBX/OBJ missing or invalid: " + path);
            GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(asset);
            instance.name = name;
            instance.transform.SetParent(parent, false);
            return instance;
        }
        private static bool GetRendererBounds(GameObject root, out Bounds bounds)
        {
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>(true);
            bool found = false;
            bounds = default(Bounds);
            foreach (Renderer renderer in renderers)
            {
                if (!found) { bounds = renderer.bounds; found = true; }
                else bounds.Encapsulate(renderer.bounds);
            }
            return found;
        }
        private static Transform Child(Transform parent, string name)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            return go.transform;
        }
        private static Transform GetOrAdd(Transform parent, string name)
        {
            Transform child = parent.Find(name);
            return child != null ? child : Child(parent, name);
        }
        private static string SafeName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "Unnamed";
            return name.Replace(' ', '_').Replace('/', '_').Replace('\\', '_').Replace(':', '_').Replace('&', '_');
        }
        private static void Meta(GameObject go, string id, string category, string status, string notes,
            bool isReference = false, bool schematic = false)
        {
            go.AddComponent<SparkAutoL106LayoutRecord>().Configure(id, category, status, notes, isReference, schematic);
        }
    }
}
#endif
