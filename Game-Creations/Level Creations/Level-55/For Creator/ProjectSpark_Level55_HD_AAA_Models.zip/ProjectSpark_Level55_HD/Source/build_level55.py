"""Project Spark Level 55 procedural HD 3D model generator.
Creates 20 independent, colored and named triangle-mesh assets plus FBX 7.4 binary and GLB backups.
Visual assets only: no electrical measurements or objectives fabricated.
"""
from __future__ import annotations
import os, math, csv, json, zlib, struct, zipfile, pathlib, textwrap
from collections import defaultdict
from dataclasses import dataclass
import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level55_HD')
for d in ['Models','GLB','Previews','Unity_Optional','Source']: (ROOT/d).mkdir(parents=True,exist_ok=True)
R = math.pi/180
C = {
 'titanium':(0.27,0.38,0.46,1),'blue_steel':(.17,.29,.38,1),'navy':(.045,.093,.155,1),
 'carbon':(.035,.065,.095,1),'dark':(.065,.10,.145,1),'chrome':(.74,.85,.90,1),
 'silver':(.49,.65,.75,1),'silver_dark':(.32,.44,.54,1),'copper':(.77,.34,.12,1),
 'bronze':(.84,.49,.18,1),'gold':(.96,.68,.25,1),'amber':(1,.66,.21,1),
 'cyan':(.18,.89,1,1),'electric':(.05,.56,.98,1),'mint':(.2,1,.72,1),
 'green':(.1,.93,.43,1),'red':(1,.18,.27,1),'white':(.82,.95,1,1),
 'acrylic':(.33,.71,.86,.15),'acrylic_rim':(.43,.69,.83,1),'rubber':(.035,.05,.075,1),
 'display':(.017,.066,.106,1),'grid':(.08,.22,.29,1),'warning':(.95,.65,.08,1),
 'violet':(.55,.35,.93,1)
}
@dataclass
class Part:
 name:str
 mesh:trimesh.Trimesh
 mat:str
 group:str|None=None
@dataclass
class Asset:
 name:str
 parts:list
 groups:dict
 def __init__(self,name):self.name=name;self.parts=[];self.groups={}
 def add(self,name,mesh,mat,group=None):
  if mesh is None or len(mesh.faces)==0: return
  mesh=mesh.copy(); mesh.remove_unreferenced_vertices()
  assert mat in C,mat
  self.parts.append(Part(name,mesh,mat,group))
 def pivot(self,name,loc): self.groups[name]=np.array(loc,dtype=float)

assets=[]; current=None
MODELS=[
'L55_IndustrialBase','L55_LevitationRotor','L55_LeftMagneticBearing','L55_RightMagneticBearing',
'L55_LeftTouchdownBearing','L55_RightTouchdownBearing','L55_DriveMotor','L55_EncoderABZ',
'L55_PositionSensorHub','L55_LeftGapSensors','L55_RightGapSensors','L55_LeftMagneticDriver',
'L55_RightMagneticDriver','L55_MotorDriver','L55_LevitationController','L55_HolographicMonitor',
'L55_DisturbanceActuator','L55_SafetyEnclosure','L55_AxialGuide','L55_5VSupply']
def start(i):
 global current
 current=Asset(MODELS[i]);assets.append(current)
 return current

def add(n,m,mat,group=None):current.add(n,m,mat,group)
def T(mesh,pos):
 m=mesh.copy();m.apply_translation(pos);return m

def box(n,pos,size,mat,group=None):
 m=trimesh.creation.box(extents=size)
 add(n,T(m,pos),mat,group)
def cyl(n,pos,r,l,axis='y',mat='silver',sections=32,group=None):
 mesh=trimesh.creation.cylinder(radius=r,height=l,sections=sections)
 if axis=='x':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':mesh.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 add(n,T(mesh,pos),mat,group)
def tor(n,pos,rad,tube,axis='x',mat='silver',seg=64,minor=10,group=None):
 mesh=trimesh.creation.torus(major_radius=rad,minor_radius=tube,major_sections=seg,minor_sections=minor)
 if axis=='x':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':mesh.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 add(n,T(mesh,pos),mat,group)
def ann(n,pos,outer,inner,depth,axis='x',mat='silver',seg=56,group=None):
 # explicit annular extrusion, open bore
 angles=np.linspace(0,2*math.pi,seg,endpoint=False)
 pts=[]
 for x in [-depth/2,depth/2]:
  for rad in [outer,inner]:
   for a in angles:
    if axis=='x':p=[x,rad*math.cos(a),rad*math.sin(a)]
    elif axis=='y':p=[rad*math.cos(a),x,rad*math.sin(a)]
    else:p=[rad*math.cos(a),rad*math.sin(a),x]
    pts.append(p)
 faces=[]
 for k in range(seg):
  j=(k+1)%seg
  for a,b,c,d in [(k,j,seg+j,seg+k), (2*seg+k,3*seg+k,3*seg+j,2*seg+j),
                  (k,2*seg+k,2*seg+j,j),(seg+k,seg+j,3*seg+j,3*seg+k)]:
   faces.extend([[a,b,c],[a,c,d]])
 m=trimesh.Trimesh(vertices=np.array(pts),faces=np.array(faces),process=False)
 add(n,T(m,pos),mat,group)
def bolt(n,pos,axis='y',size=.038):
 cyl(n+'_Head',pos,size,size*.5,axis,'chrome',12)
 cyl(n+'_Mark',np.array(pos)+([0,size*.23,0] if axis=='y' else [size*.23,0,0]),size*.38,size*.09,axis,'dark',6)
def beam(n,a,b,r,mat='silver',seg=10,group=None):
 a=np.array(a,float);b=np.array(b,float)
 d=b-a; length=np.linalg.norm(d)
 if length<1e-5:return
 m=trimesh.creation.cylinder(radius=r,height=length,sections=seg)
 m.apply_transform(trimesh.geometry.align_vectors([0,0,1],d/length))
 add(n,T(m,(a+b)/2),mat,group)
def cable(n,points,r=.018,mat='rubber',seg=9):
 for j,(a,b) in enumerate(zip(points[:-1],points[1:])): beam(n+f'_{j:02d}',a,b,r,mat,seg)
def led(n,pos,mat='cyan',r=.045,axis='z'):
 cyl(n+'_Bezel',pos,r*1.35,.017,axis,'chrome',18)
 d={'x':[.010,0,0],'y':[0,.010,0],'z':[0,0,.010]}[axis]
 cyl(n+'_Lens',np.array(pos)+d,r,.015,axis,mat,20)
def feet(n,x,z):
 cyl(n+'_Rubber',(x,-.35,z),.14,.12,'y','rubber',16)
 cyl(n+'_Top',(x,-.28,z),.12,.035,'y','silver',20)
def panel(n,pos,w=1.25,header='DRIVE',color='cyan',socket_names=None):
 # Front-facing electronic module at z=2.13, sockets are front face (+Z)
 x,y,z=pos; width=w
 box(n+'_Body',(x,y,z),[width,.56,.48],'navy')
 box(n+'_Face',(x,y,z+.245),[width-.06,.48,.018],'dark')
 box(n+'_AnodizedTop',(x,y+.291,z),[width,.025,.48],'blue_steel')
 box(n+'_TopLight',(x,y+.308,z),[width-.07,.010,.033],color)
 for sign in [-1,1]:
  for signy in [-1,1]: bolt(n+f'_Screw_{sign}_{signy}',(x+sign*(width/2-.09),y+signy*.18,z+.263),'z',.023)
 text_geo(n+'_Label',header,(x-width*.42,y+.13,z+.264),max_width=width*.84,size=.055,mat='white')
 led(n+'_PowerStatus',(x-width*.40,y-.01,z+.264),'green',.029,'z')
 if socket_names:
  m=len(socket_names); spacing=min(.25,(width-.20)/max(1,m));first=x-(m-1)*spacing/2
  for i,s in enumerate(socket_names):
   xx=first+i*spacing; zz=z+.277
   cyl(n+f'_JackOuter_{s}',(xx,y-.145,zz),.072,.024,'z','chrome',18)
   cyl(n+f'_JackInner_{s}',(xx,y-.145,zz+.014),.048,.024,'z',('red' if s in ['+5V','M+','PWR+'] else 'electric' if s in ['GND','0V','M-','PWR-'] else color),18)
   cyl(n+f'_JackHole_{s}',(xx,y-.145,zz+.028),.018,.011,'z','dark',12)

def text_geo(n,st,pos,max_width=1.2,size=.08,mat='white',group=None):
 try:
  import vtk
  v=vtk.vtkVectorText();v.SetText(st);v.Update();p=v.GetOutput();N=p.GetNumberOfPoints();F=p.GetNumberOfCells()
  if not N or not F:return
  arr=np.array([p.GetPoint(i) for i in range(N)])
  fs=[]
  for i in range(F):
   c=p.GetCell(i)
   if c.GetNumberOfPoints()==3: fs.append([c.GetPointId(j) for j in range(3)])
  if not fs:return
  arw=arr[:,0].max()-arr[:,0].min()
  scl=min(size,max_width/max(arw,.01))
  arr[:,:2]*=scl;arr[:,0]-=arr[:,0].min();arr[:,1]-=arr[:,1].min();
  arr+=np.array(pos)
  add(n,trimesh.Trimesh(vertices=arr,faces=np.array(fs),process=False),mat,group)
 except Exception as ex: print('text geo skipped',st,str(ex)[:100])

# Layout fixed reference coordinates (meters in mesh-art space, 1 Unity unit per art unit by default)
Y=1.74; Z=0.0
# 00 base
start(0)
box('Base_MachinedChassis',(0,-.11,0),[10.0,.30,5.75],'titanium')
box('Base_TopBlackInset',(0,.055,0),[9.78,.060,5.49],'carbon')
for z in [-1.34,1.24]:
 box('LinearMount_Rail_'+str(z),(0,.135,z),[9.6,.16,.15],'blue_steel')
 box('Rail_ChromeInsert_'+str(z),(0,.225,z),[9.3,.035,.055],'chrome')
for x in [-4.45,-2.5,0,2.5,4.45]:
 for z in [-2.38,2.38]:
  cyl('AnchorBolt_'+str(x)+'_'+str(z),(x,.091,z),.048,.035,'y','chrome',12)
for x in [-4.45,4.45]:
 for z in [-2.5,2.5]:feet('Foot'+str(x)+str(z),x,z)
for z in [-2.74,2.74]:
 box('Base_LuminousTrim'+str(z),(0,.082,z),[9.9,.02,.035],'cyan')
box('BackWireDuct',(0,.18,-1.67),[9.1,.15,.28],'navy')
for i in range(32):
 x=-4.35+i*.28
 box('BackWireDuct_Slot'+str(i),(x,.266,-1.67),[.04,.009,.22],'silver_dark')
box('FrontTerminalShelf',(0,.18,2.13),[9.5,.25,1.22],'blue_steel')
box('FrontTerminal_Inset',(0,.311,2.13),[9.35,.025,1.10],'carbon')
for i in range(46):
 x=-4.48+i*.195
 cyl('FrontBenchGrid'+str(i),(x,.333,2.51),.011,.008,'y','silver_dark',8)
for x in [-4.63,4.63]:
 box('EndProtect'+str(x),(x,.13,0),[.08,.39,5.38],'chrome')

# 01 rotor
start(1);current.pivot('ANIM_ROTOR_SPIN',(0,Y,Z))
cyl('Rotor_ChromeShaft_Main',(0,Y,0),.155,7.40,'x','chrome',72,'ANIM_ROTOR_SPIN')
for j,x in enumerate([-3.38,-2.78,-2.07,-1.04,.96,2.08,2.83,3.42]):
 tor('Rotor_ShaftMachinedSeam'+str(j),(x,Y,0),.159,.014,'x','silver_dark',48,8,'ANIM_ROTOR_SPIN')
# central flywheel, stepped circular surfaces
for i,(x,r,th,mt) in enumerate([(-.04,.70,.34,'chrome'),(-.26,.51,.06,'blue_steel'),(.18,.51,.06,'blue_steel'),(-.25,.62,.026,'cyan'),(.18,.62,.026,'cyan')]):
 if i<3:ann('Rotor_Flywheel_'+str(i),(x,Y,0),r,.17,th,'x',mt,88,'ANIM_ROTOR_SPIN')
 else:tor('Rotor_IlluminatedCircumferentialRing'+str(i),(x,Y,0),r,.022,'x',mt,96,10,'ANIM_ROTOR_SPIN')
for j in range(24):
 a=j*math.tau/24
 px=-.22
 ry=Y+.59*math.sin(a);rz=.59*math.cos(a)
 cyl('Rotor_FlywheelPrecisionMark_'+str(j),(px,ry,rz),.012,.035,'x', 'cyan' if j%6==0 else 'silver_dark',10,'ANIM_ROTOR_SPIN')
for j in range(12):
 a=j*math.tau/12
 yc=Y+.43*math.cos(a);zc=.43*math.sin(a)
 cyl('Rotor_Bolt_'+str(j),(.196,yc,zc),.029,.022,'x','gold',12,'ANIM_ROTOR_SPIN')
# rotor steel engagement and raised collars
for j,x in enumerate([-2.18,-1.00,1.07,2.12]):
 ann('Rotor_BearingSleeve_'+str(j),(x,Y,0),.245,.155,.09,'x','silver',48,'ANIM_ROTOR_SPIN')

# both magnetic stators
for index,x,col,title in [(2,-1.55,'cyan','LEFT'),(3,1.58,'amber','RIGHT')]:
 start(index)
 tag=title
 current.pivot('ANIM_'+title+'_COIL_LIGHTS',(x,Y,0))
 ann(tag+'_StatorOuterFrame',(x,Y,0),.80,.505,.32,'x','titanium',88)
 ann(tag+'_InnerMagneticCore',(x,Y,0),.61,.443,.355,'x','blue_steel',80)
 tor(tag+'_FrontHalo',(x+.188,Y,0),.74,.025,'x',col,96,12)
 tor(tag+'_RearHalo',(x-.188,Y,0),.74,.018,'x','electric',72,10)
 tor(tag+'_InnerClearanceHighlight',(x+.182,Y,0),.448,.012,'x','chrome',96,8)
 # radial coil stators, 4 poles plus copper windings on face of ring
 for j,a in enumerate([0,math.pi/2,math.pi,3*math.pi/2]):
  yy=Y+.63*math.cos(a);zz=.63*math.sin(a)
  beam(tag+f'_PoleCore_{j}',(x, Y+.47*math.cos(a),.47*math.sin(a)),(x, Y+.80*math.cos(a),.80*math.sin(a)),.078,'silver',14)
  for k in range(7):
   xx=x-.125+k*.040
   tor(tag+f'_CopperCoil_{j}_{k}',(xx,yy,zz),.078,.014,'x','copper',24,7)
  cyl(tag+f'_CoilEndCap_{j}',(x+.176,yy,zz),.10,.028,'x', 'gold' if j%2==0 else 'bronze',16)
  led(tag+f'_PolarityLED_{j}',(x+.205,yy,zz),col,.024,'x')
 # support feet arch and inspection plates
 box(tag+'_Pedestal',(x,.66,0),[.72,1.03,.75],'titanium')
 box(tag+'_PedestalNeck',(x,1.12,0),[.56,.25,.49],'blue_steel')
 box(tag+'_FootPad',(x,.26,0),[.90,.20,1.00],'navy')
 for z in [-.39,.39]:
  cyl(tag+'_FootScrew'+str(z),(x,.37,z),.058,.022,'y','chrome',12)
 box(tag+'_StatusStripe',(x+.36,.78,.385),[.026,.36,.026],col)

# backup bearings
for index,x,label in [(4,-2.26,'LEFT'),(5,2.32,'RIGHT')]:
 start(index)
 ann(label+'_TouchdownOuterRing',(x,Y,0),.43,.245,.18,'x','silver_dark',64)
 tor(label+'_CeramicBackupRace',(x+.11,Y,0),.30,.028,'x','chrome',60,12)
 tor(label+'_TouchdownElastomer',(x-.12,Y,0),.36,.035,'x','rubber',60,10)
 for j in range(16):
  a=j*math.tau/16
  cyl(label+'_RaceRoller'+str(j),(x+.103,Y+.32*math.sin(a),.32*math.cos(a)),.034,.048,'x','silver',12)
 box(label+'_BackupPedestal',(x,.77,0),[.48,1.15,.56],'titanium')
 box(label+'_BackupFoot',(x,.19,0),[.66,.13,.78],'navy')
 led(label+'_ContactIndicator',(x+.28,.60,.34),'red',.042,'z')

# 06 drive motor
start(6)
box('DriveMotor_Stand',(-3.63,.43,0),[1.29,.52,1.33],'titanium')
box('DriveMotor_Mount',(-3.63,.74,0),[1.22,.13,1.2],'navy')
cyl('DriveMotor_Body',(-3.68,Y,0),.46,1.40,'x','blue_steel',72)
for i in range(13):
 x=-4.28+i*.105
 ann('Motor_FinnedBand'+str(i),(x,Y,0),.525,.455,.047,'x','silver_dark',60)
for x in [-4.34,-3.02]:
 ann('Motor_MachinedEndBell'+str(x),(x,Y,0),.50,.16,.10,'x','chrome',64)
tor('Motor_FrontGlow',(-2.99,Y,0),.31,.024,'x','electric',64)
for j in range(8):
 a=j*math.tau/8
 cyl('Motor_FrontFastener_'+str(j),(-2.955,Y+.42*math.sin(a),.42*math.cos(a)),.028,.028,'x','gold',12)
box('Motor_TerminalBox',(-3.69,2.20,-.04),[.54,.31,.46],'navy')
box('Motor_Cover',(-3.69,2.371,-.04),[.45,.028,.39],'chrome')
led('Motor_Power',(-3.38,2.25,.14),'green',.039,'z')

# 07 encoder
start(7);current.pivot('ANIM_ENCODER_DISC',(-2.95,Y,0))
ann('Encoder_RotatingDisc',(-2.95,Y,0),.39,.164,.062,'x','blue_steel',80,'ANIM_ENCODER_DISC')
tor('Encoder_OuterHalo',(-2.90,Y,0),.39,.025,'x','cyan',80,10,'ANIM_ENCODER_DISC')
for j in range(80):
 a=j*math.tau/80;yy=Y+.346*math.sin(a);zz=.346*math.cos(a)
 cyl('Encoder_Slot_'+str(j),(-2.914,yy,zz),.008,.013,'x', 'white' if j%10==0 else 'silver',8,'ANIM_ENCODER_DISC')
box('Encoder_OpticalHead',(-2.91,2.20,.17),[.36,.18,.23],'navy')
led('Encoder_IndexZLED',(-2.67,2.22,.20),'green',.034,'x')
box('Encoder_Pedestal',(-2.95,.83,0),[.42,1.25,.39],'titanium')
box('Encoder_BaseFoot',(-2.95,.20,0),[.64,.16,.64],'blue_steel')

# 08 sensor hub front left-center
start(8)
panel('PositionHub',(-1.42,.72,2.18),1.45,'POSITION SENSOR HUB','mint',['XL','YL','XR','YR'])
for j in range(4):
 led('HubChannel'+str(j),(-1.90+j*.28,.87,2.456),'mint',.024,'z')

# 09/10 gap sensor rigs x -1.55 and +1.58
for index,x,label,mat in [(9,-1.55,'LEFT','cyan'),(10,1.58,'RIGHT','amber')]:
 start(index)
 for j,(axis,ang) in enumerate([('X',0),('Y',math.pi/2)]):
  ry=Y+.95*math.sin(ang);rz=.95*math.cos(ang)
  cyl(label+'_GapSensor_'+axis+'_Probe',(x+.16,ry,rz),.105,.35,'x','titanium',28)
  cyl(label+'_GapSensor_'+axis+'_OpticalTip',(x+.38,ry,rz),.06,.085,'x',mat,24)
  tor(label+'_GapSensor_'+axis+'_Retainer',(x+.03,ry,rz),.11,.021,'x','chrome',28)
  box(label+'_GapSensor_'+axis+'_CableConnector',(x-.10,ry,rz),[.16,.13,.15],'navy')
  # brackets down to the stator
  if axis=='Y':beam(label+'_ProbeYArm',(x+.13,Y+.95,0),(x+.13,Y+.84,0),.055,'silver',10)
  else:beam(label+'_ProbeXArm',(x+.13,Y,.95),(x+.13,Y,.81),.053,'silver',10)
  led(label+'_SensorLamp_'+axis,(x+.35,ry+.14,rz),mat,.027,'z')
 cable(label+'_Lead',[(x-.1,Y+.95,.0),(x-.2,Y+1.18,-.22),(x-.25,1.60,-1.02),(x-.25,.6,-1.36)],.014,'rubber')

# 11 12 magnetic drivers
start(11);panel('LeftMagneticDriver',(-3.43,.72,2.18),1.52,'MAGNETIC DRIVE A','cyan',['CMD','PWR+','PWR-'])
for i in range(8):
 box('LeftDrive_HeatSink'+str(i),(-3.99+i*.14,1.10,2.00),[.057,.23,.34],'silver')
start(12);panel('RightMagneticDriver',(.49,.72,2.18),1.52,'MAGNETIC DRIVE B','amber',['CMD','PWR+','PWR-'])
for i in range(8):
 box('RightDrive_HeatSink'+str(i),(-.08+i*.14,1.10,2.00),[.057,.23,.34],'silver')
#13 motor driver
start(13);panel('DriveElectronics',(2.10,.72,2.18),1.26,'MOTOR DRIVER','electric',['PWM','M+','M-'])
for i in range(7):box('Drive_HeatFin'+str(i),(1.75+i*.11,1.09,2.03),[.044,.23,.34],'silver_dark')
#14 controller front right
start(14);panel('LevitationController',(3.73,.72,2.18),1.66,'LEVITATION CTRL','mint',['A','B','Z','SAFE','TD'])
for i,n in enumerate(['LIFT','SPIN','RESET']):
 x=3.19+i*.42
 box('CTRL_ButtonBase_'+n,(x,1.10,2.10),[.30,.065,.21],'titanium')
 box('CTRL_ButtonGlow_'+n,(x,1.15,2.10),[.24,.028,.15],['mint','electric','amber'][i])

#15 holographic monitor rear left and center
start(15)
box('HoloMonitor_Foot',(0,.18,-2.28),[3.90,.24,.53],'blue_steel')
for x in [-1.65,1.65]:
 box('HoloMonitor_RaisedBracket_'+str(x),(x,1.43,-2.30),[.19,2.44,.24],'chrome')
box('HoloMonitor_Body',(0,2.68,-2.32),[4.35,1.48,.20],'titanium')
box('HoloMonitor_BlackGlass',(0,2.68,-2.195),[4.12,1.24,.028],'display')
for yy in np.arange(2.17,3.22,.20):box('HUD_GraphGridY'+str(yy),(0,yy,-2.167),[3.93,.005,.003],'grid')
for xx in np.arange(-1.95,2.0,.3):box('HUD_GraphGridX'+str(xx),(xx,2.68,-2.167),[.005,1.16,.003],'grid')
for k,x in enumerate([-1.52,-.33,.84]):
 tor('HUD_OrbitRing'+str(k),(x,2.64,-2.148),.28,.012,'z',('cyan' if k==0 else 'amber' if k==1 else 'mint'),56,7)
text_geo('MonitorTitle','SHAFT LEVITATION / 4-AXIS',(-2.03,3.285,-2.154),3.95,.106,'white')
for i,(st,col) in enumerate([('LEFT X/Y','cyan'),('RIGHT X/Y','amber'),('STABLE','mint')]):
 text_geo('MonitorLegend_'+str(i),st,(-1.79+i*1.19,2.27,-2.148),1.14,.069,col)
led('Monitor_GreenState',(1.8,3.26,-2.135),'green',.045,'z')

#16 disturbance test actuator behind center
start(16);current.pivot('ANIM_DISTURBANCE_PLUNGER',(.34,1.75,-.82))
box('Disturbance_Bracket',(.35,.66,-.80),[.52,1.08,.48],'titanium')
box('Disturbance_ElectromagnetBase',(.34,1.45,-.86),[.46,.32,.52],'blue_steel')
for k in range(10):
 tor('Disturbance_CopperWinding'+str(k),(.15+k*.044,1.57,-.86),.13,.013,'x','copper',30,7)
beam('Disturbance_MovablePlunger',(.34,1.72,-.80),(.34,1.72,-.28),.065,'chrome',14,'ANIM_DISTURBANCE_PLUNGER')
led('Disturbance_Status',(.6,1.49,-.56),'amber',.048,'z')

#17 enclosure, open sides aesthetically transparent from vtk, 2 panels side w/ lightframe
start(17);current.pivot('ANIM_SAFETY_DOOR',(0,2.89,1.30))
for x in [-4.70,4.70]:
 for z in [-1.37,1.28]:beam('Guard_VerticalSupport'+str(x)+str(z),(x,.24,z),(x,3.28,z),.027,'acrylic_rim',10)
for y in [.35,3.28]:
 for z in [-1.37,1.28]:beam('Guard_LongBeam'+str(y)+str(z),(-4.75,y,z),(4.75,y,z),.032,'silver_dark',10)
 for x in [-4.70,4.70]:beam('Guard_EndBeam'+str(y)+str(x),(x,y,-1.38),(x,y,1.31),.025,'silver_dark',10)
# rear and ends acrylic, front swinging door has no roof for enhanced camera view
box('Guard_BackAcrylic',(0,1.83,-1.39),[9.28,2.82,.016],'acrylic')
for x in [-4.69,4.69]:box('Guard_EndAcrylic'+str(x),(x,1.83,-.04),[.016,2.82,2.59],'acrylic')
box('Guard_SwingDoorFront',(0,2.05,1.32),[8.92,2.28,.018],'acrylic','ANIM_SAFETY_DOOR')
beam('Guard_DoorHandle',(3.95,1.58,1.38),(4.25,1.58,1.38),.035,'chrome',12,'ANIM_SAFETY_DOOR')
box('Guard_DoorLowerLip',(0,.90,1.34),[9,.038,.08],'electric','ANIM_SAFETY_DOOR')
for x in [-4.54,4.54]:
 led('Guard_Interlock'+str(x),(x,2.95,1.35),'green',.038,'z')

#18 axial guide
start(18)
ann('AxialGuide_Stator',(2.95,Y,0),.32,.164,.20,'x','titanium',64)
tor('AxialGuide_NonContactLiner',(3.06,Y,0),.255,.026,'x','cyan',64)
box('AxialGuide_Stand',(2.95,.90,0),[.47,1.44,.44],'blue_steel')
box('AxialGuide_Anchor',(2.95,.20,0),[.61,.18,.65],'navy')
led('AxialGuide_AxialOK',(3.23,.90,.24),'green',.037,'z')

#19 supply front far left? current front shelf x -1.42 hub, -3.43 driver, .49 driver,2.1 motor, 3.73 ctrl; supply elevated back right
start(19)
box('Supply_MainCase',(3.62,.84,-2.07),[1.51,1.10,.70],'navy')
box('Supply_ChromeTop',(3.62,1.41,-2.07),[1.44,.045,.64],'chrome')
box('Supply_FrontScreen',(3.62,.98,-1.705),[1.33,.47,.022],'display')
text_geo('Supply_5VLabel','5.00 V',(3.18,1.06,-1.686),1.15,.17,'mint')
text_geo('Supply_Designation','REGULATED 5V',(3.17,.83,-1.686),1.20,.066,'white')
for i,mt in enumerate(['red','electric']):
 x=3.23+i*.80
 cyl('PowerTerm_'+str(i),(x,.59,-1.68),.086,.068,'z','chrome',24)
 cyl('PowerTermColored_'+str(i),(x,.59,-1.635),.060,.018,'z',mt,24)
led('Supply_RegulatedOK',(4.16,1.28,-1.69),'green',.037,'z')
for i in range(7):
 box('Supply_HeatSink'+str(i),(3.08+i*.18,1.44,-2.09),[.073,.08,.55],'silver_dark')

print('Created parts:',sum(len(a.parts) for a in assets),'triangles:',sum(len(p.mesh.faces) for a in assets for p in a.parts))
assert len(assets)==20

# Electrical anchor layout. Every label is a declaration / art position only, NOT a SparkTerminal.
connections=[
('W01','Supply +5 V','Levitation Controller +5 V'),
('W02','Supply RETURN','Levitation Controller GND'),
('W03','Supply +5 V','Motor Driver +5 V'),
('W04','Supply RETURN','Motor Driver GND'),
('W05','Supply +5 V','Left Magnetic Driver +5 V'),
('W06','Supply RETURN','Left Magnetic Driver GND'),
('W07','Supply +5 V','Right Magnetic Driver +5 V'),
('W08','Supply RETURN','Right Magnetic Driver GND'),
('W09','Supply +5 V','Position Sensor Hub +5 V'),
('W10','Supply RETURN','Position Sensor Hub GND'),
('W11','Sensor Hub XL OUT','Controller XL IN'),
('W12','Sensor Hub YL OUT','Controller YL IN'),
('W13','Sensor Hub XR OUT','Controller XR IN'),
('W14','Sensor Hub YR OUT','Controller YR IN'),
('W15','Encoder A','Controller ENC A'),
('W16','Encoder B','Controller ENC B'),
('W17','Encoder Z','Controller ENC Z'),
('W18','Controller MOTOR PWM','Motor Driver PWM'),
('W19','Motor Driver M+','Rotor Motor +'),
('W20','Motor Driver M-','Rotor Motor -'),
('W21','Controller LEFT CMD','Left Magnetic Driver CMD'),
('W22','Controller RIGHT CMD','Right Magnetic Driver CMD'),
('W23','Left Driver POWER+','Left Magnetic Ring POWER+'),
('W24','Left Driver POWER-','Left Magnetic Ring POWER-'),
('W25','Right Driver POWER+','Right Magnetic Ring POWER+'),
('W26','Right Driver POWER-','Right Magnetic Ring POWER-'),
('W27','Safety Guard NC OUT','Controller SAFE IN'),
('W28','Touchdown Sensor OUT','Controller TOUCHDOWN IN')]

# Stable IDs for game-side manifest; not assumed existing runtime component IDs.
endpoints={
'Supply +5 V':('SUPPLY_POS',19),'Supply RETURN':('SUPPLY_RET',19),
'Levitation Controller +5 V':('CTRL_POS',14),'Levitation Controller GND':('CTRL_GND',14),
'Controller XL IN':('CTRL_XL',14),'Controller YL IN':('CTRL_YL',14),
'Controller XR IN':('CTRL_XR',14),'Controller YR IN':('CTRL_YR',14),
'Controller ENC A':('CTRL_ENC_A',14),'Controller ENC B':('CTRL_ENC_B',14),'Controller ENC Z':('CTRL_ENC_Z',14),
'Controller MOTOR PWM':('CTRL_PWM',14),'Controller LEFT CMD':('CTRL_CMD_LEFT',14),
'Controller RIGHT CMD':('CTRL_CMD_RIGHT',14),'Controller SAFE IN':('CTRL_SAFE',14),
'Controller TOUCHDOWN IN':('CTRL_TOUCHDOWN',14),
'Motor Driver +5 V':('MD_POS',13),'Motor Driver GND':('MD_GND',13),
'Motor Driver PWM':('MD_PWM',13),'Motor Driver M+':('MD_MPLUS',13),'Motor Driver M-':('MD_MMINUS',13),
'Left Magnetic Driver +5 V':('LD_POS',11),'Left Magnetic Driver GND':('LD_GND',11),
'Left Magnetic Driver CMD':('LD_CMD',11),'Left Driver POWER+':('LD_PWRPOS',11),'Left Driver POWER-':('LD_PWRNEG',11),
'Right Magnetic Driver +5 V':('RD_POS',12),'Right Magnetic Driver GND':('RD_GND',12),
'Right Magnetic Driver CMD':('RD_CMD',12),'Right Driver POWER+':('RD_PWRPOS',12),'Right Driver POWER-':('RD_PWRNEG',12),
'Position Sensor Hub +5 V':('HUB_POS',8),'Position Sensor Hub GND':('HUB_GND',8),
'Sensor Hub XL OUT':('HUB_XL',8),'Sensor Hub YL OUT':('HUB_YL',8),
'Sensor Hub XR OUT':('HUB_XR',8),'Sensor Hub YR OUT':('HUB_YR',8),
'Encoder A':('ENC_A',7),'Encoder B':('ENC_B',7),'Encoder Z':('ENC_Z',7),
'Rotor Motor +':('MOTOR_PLUS',6),'Rotor Motor -':('MOTOR_MINUS',6),
'Left Magnetic Ring POWER+':('MAG_A_PWRPOS',2),'Left Magnetic Ring POWER-':('MAG_A_PWRNEG',2),
'Right Magnetic Ring POWER+':('MAG_B_PWRPOS',3),'Right Magnetic Ring POWER-':('MAG_B_PWRNEG',3),
'Safety Guard NC OUT':('GUARD_NC_OUT',17),'Touchdown Sensor OUT':('TOUCHDOWN_OUT',5)
}
assert len(endpoints)==48,(len(endpoints),set(k for _,a,b in connections for k in [a,b])-set(endpoints))
assert len(connections)==28
assert set(endpoints)=={k for _,a,b in connections for k in [a,b]}
positions={}
# Art sockets along two small rows, facing the front towards +Z.
module_arrangements={
14:(3.73,.72,2.45,7),13:(2.10,.72,2.45,5),11:(-3.43,.72,2.45,5),
12:(.49,.72,2.45,5),8:(-1.42,.72,2.45,6),
}
module_names=defaultdict(list)
for label,(sid,mi) in endpoints.items():module_names[mi].append((label,sid))
for mi,(base_x,cy,cz,cols) in module_arrangements.items():
 a=module_names[mi]
 # controller two rows of 7 (module face intentionally densely populated)
 if mi==14:spacing=.198; row_y=[.69,.45]
 else:spacing=min(.23,1.22/(max(1,len(a)-1))); row_y=[.48]
 for i,(label,sid) in enumerate(a):
  col=i%cols;row=i//cols
  count=min(cols,len(a)-row*cols)
  px=base_x+(col-(count-1)/2)*spacing
  positions[sid]=(px,row_y[row],cz+.015)
positions.update({
'SUPPLY_POS':(3.22,.60,-1.63),'SUPPLY_RET':(4.02,.60,-1.63),
'ENC_A':(-2.67,2.24,.07),'ENC_B':(-2.69,2.18,.25),'ENC_Z':(-2.68,2.08,.07),
'MOTOR_PLUS':(-3.50,2.39,.11),'MOTOR_MINUS':(-3.85,2.39,.11),
'MAG_A_PWRPOS':(-1.55,2.36,.60),'MAG_A_PWRNEG':(-1.55,2.36,-.60),
'MAG_B_PWRPOS':(1.58,2.36,.60),'MAG_B_PWRNEG':(1.58,2.36,-.60),
'GUARD_NC_OUT':(4.60,1.12,1.39),'TOUCHDOWN_OUT':(2.40,.68,.37)
})
assert len(positions)==48,(len(positions),set(v[0] for v in endpoints.values())-set(positions))
# Each anchor appears as an actual colored jack with a named FBX Null pivot and two mesh rings.
for label,(sid,mi) in endpoints.items():
 a=assets[mi];p=np.array(positions[sid]);a.pivot('SOCKET_'+sid,p)
 # artistic visual jack aligned with front face. For top and side positions, locator manifest is authoritative.
 v1=trimesh.creation.torus(major_radius=.064,minor_radius=.012,major_sections=20,minor_sections=7)
 v1.apply_translation(p);a.add('SOCKET_'+sid+'_MetalBezel',v1,'silver')
 v2=trimesh.creation.torus(major_radius=.036,minor_radius=.011,major_sections=20,minor_sections=7)
 v2.apply_translation(p+[0,0,.016]); color='red' if ('POS' in sid or 'PLUS' in sid) else 'electric' if ('GND' in sid or 'NEG' in sid or 'MINUS' in sid or 'RET' in sid) else 'cyan'
 a.add('SOCKET_'+sid+'_SignalRing',v2,color)
# Socket FBX null pivots are distinct and independently accessible in Unity.

with open(ROOT/'Exact_Wiring.csv','w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['Wire','From','From_ID','To','To_ID'])
 for wire,src,dest in connections:w.writerow([wire,src,endpoints[src][0],dest,endpoints[dest][0]])
with open(ROOT/'Terminal_Anchors.csv','w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['Terminal_ID','Label','Model','X','Y','Z','Node'])
 for label,(sid,mi) in endpoints.items():
  xyz=positions[sid];w.writerow([sid,label,MODELS[mi],*(round(float(x),6) for x in xyz),'SOCKET_'+sid])
with open(ROOT/'Animation_Rigs.csv','w',newline='',encoding='utf-8') as fh:
 w=csv.writer(fh);w.writerow(['FBX_Model','Pivot_Name','Pivot_X','Pivot_Y','Pivot_Z','Axis','Purpose'])
 rigs=[(1,'ANIM_ROTOR_SPIN','X','Shaft and central rotor spin'),(7,'ANIM_ENCODER_DISC','X','A/B/Z incremental encoder rotation'),
 (2,'ANIM_LEFT_COIL_LIGHTS','X','Stationary left magnetic bearing indicator group'),
 (3,'ANIM_RIGHT_COIL_LIGHTS','X','Stationary right magnetic bearing indicator group'),
 (16,'ANIM_DISTURBANCE_PLUNGER','Z','Non-contact perturbation plunger position'),
 (17,'ANIM_SAFETY_DOOR','X','Safety enclosure pivot; reparent around actual hinge if door opening needed')]
 for mi,grp,axis,purpose in rigs:
  loc=assets[mi].groups[grp];w.writerow([MODELS[mi],grp,*[round(float(v),6) for v in loc],axis,purpose])

# ---- FBX 7400 binary writer ------------------------------------------------
class N:
 def __init__(self,name,*props,children=None):self.name=name;self.props=list(props);self.children=children or []
class Arr:
 def __init__(self,typ,arr):self.typ=typ;self.arr=arr
class I64:
 def __init__(self,n):self.n=int(n)
def prop_data(v):
 if isinstance(v,Arr):
  dtype={'d':np.dtype('<f8'),'f':np.dtype('<f4'),'i':np.dtype('<i4'),'l':np.dtype('<i8')}[v.typ]
  arr=np.asarray(v.arr,dtype=dtype);data=arr.tobytes();compressed=zlib.compress(data,5)
  return v.typ.encode()+struct.pack('<III',len(arr),1,len(compressed))+compressed
 if isinstance(v,I64):return b'L'+struct.pack('<q',v.n)
 if isinstance(v,bool):return b'C'+struct.pack('<?',v)
 if isinstance(v,int):return b'I'+struct.pack('<i',v)
 if isinstance(v,float):return b'D'+struct.pack('<d',v)
 if isinstance(v,str):
  b=v.encode('utf-8');return b'S'+struct.pack('<I',len(b))+b
 raise TypeError((type(v),v))
def write_node(n,offset):
 name=n.name.encode('utf8');props=b''.join(prop_data(p) for p in n.props)
 out=bytearray();children_offset=offset+13+len(name)+len(props)
 for child in n.children:
  childdata=write_node(child,children_offset+len(out));out.extend(childdata)
 if n.children:out.extend(b'\0'*13)
 end=offset+13+len(name)+len(props)+len(out)
 return struct.pack('<IIIB',end,len(n.props),len(props),len(name))+name+props+out

def P(name,typ,value,kind='Number'):
 # standard FBX Properties70 declaration
 if isinstance(value,(tuple,list,np.ndarray)):
  return N('P',name,typ,kind,'',*[float(x) for x in value])
 return N('P',name,typ,kind,'',value)
def model_node(i,name,mode,trans=(0,0,0)):
 return N('Model',I64(i),'Model::'+name,mode,children=[N('Version',232),N('Properties70',children=[P('Lcl Translation','Lcl Translation',trans,'A'),P('Lcl Rotation','Lcl Rotation',(0,0,0),'A'),P('Lcl Scaling','Lcl Scaling',(1,1,1),'A')]),N('Shading',True),N('Culling','CullingOff')])

def fbx_export(items,path,model_root):
 """Input: list Asset. Each mesh exported as independent geometry and Mesh model. Binary FBX7.4."""
 all_parts=[(a,p) for a in items for p in a.parts]
 material_names=sorted(set(p.mat for a,p in all_parts))
 matids={name:10000+i for i,name in enumerate(material_names)}
 obj=[];conn=[];gid=200000
 rootid=gid;gid+=1
 obj.append(model_node(rootid,'PROJECT_SPARK_LEVEL55_VISUAL_ROOT','Null'))
 conn.append(N('C','OO',I64(rootid),I64(0)))
 for name in material_names:
  rr,gg,bb,alpha=C[name];rr=float(rr);gg=float(gg);bb=float(bb)
  props=[P('DiffuseColor','Color',(rr,gg,bb)),P('AmbientColor','Color',(rr*.23,gg*.23,bb*.23)),
   P('SpecularColor','Color',(.43,.48,.52)),P('Shininess','double',38.0),P('Opacity','double',float(alpha))]
  obj.append(N('Material',I64(matids[name]),'Material::'+name,'',children=[N('Version',102),N('ShadingModel','phong'),N('MultiLayer',0),N('Properties70',children=props)]))
 for asset in items:
  aid=gid;gid+=1
  obj.append(model_node(aid,asset.name,'Null'))
  conn.append(N('C','OO',I64(aid),I64(rootid)))
  parents={None:aid}
  for group,loc in asset.groups.items():
   ig=gid;gid+=1;parents[group]=ig
   obj.append(model_node(ig,group,'Null',loc))
   conn.append(N('C','OO',I64(ig),I64(aid)))
  for part in asset.parts:
   m=part.mesh
   parent_loc=asset.groups.get(part.group,np.zeros(3))
   vertices=np.asarray(m.vertices,dtype=np.float64)-parent_loc
   faceindex=np.asarray(m.faces,dtype=np.int32).copy();faceindex[:,-1]=-faceindex[:,-1]-1
   # Explicit averaged normals: FBX ByVertice Direct
   normals=np.asarray(m.vertex_normals,dtype=np.float64)
   g_id=gid;mo_id=gid+1;gid+=2
   g_children=[N('GeometryVersion',124),N('Vertices',Arr('d',vertices.reshape(-1))),
    N('PolygonVertexIndex',Arr('i',faceindex.reshape(-1))),
    N('LayerElementNormal',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','ByVertice'),N('ReferenceInformationType','Direct'),N('Normals',Arr('d',normals.reshape(-1)))]),
    N('LayerElementMaterial',0,children=[N('Version',101),N('Name',''),N('MappingInformationType','AllSame'),N('ReferenceInformationType','IndexToDirect'),N('Materials',Arr('i',[0]))]),
    N('Layer',0,children=[N('Version',100),N('LayerElement',children=[N('Type','LayerElementNormal'),N('TypedIndex',0)]),N('LayerElement',children=[N('Type','LayerElementMaterial'),N('TypedIndex',0)])])]
   obj.append(N('Geometry',I64(g_id),'Geometry::'+asset.name+'__'+part.name,'Mesh',children=g_children))
   obj.append(model_node(mo_id,asset.name+'__'+part.name,'Mesh'))
   conn.extend([N('C','OO',I64(g_id),I64(mo_id)),N('C','OO',I64(mo_id),I64(parents[part.group])),N('C','OO',I64(matids[part.mat]),I64(mo_id))])
 globs=N('GlobalSettings',children=[N('Version',1000),N('Properties70',children=[
 P('UpAxis','int',1,'Integer'),P('UpAxisSign','int',1,'Integer'),
 P('FrontAxis','int',2,'Integer'),P('FrontAxisSign','int',1,'Integer'),
 P('CoordAxis','int',0,'Integer'),P('CoordAxisSign','int',1,'Integer'),
 P('UnitScaleFactor','double',100.0)])])
 defs=N('Definitions',children=[N('Version',100),N('Count',len(obj)),
 N('ObjectType','Model',children=[N('Count',sum(o.name=='Model' for o in obj))]),
 N('ObjectType','Geometry',children=[N('Count',sum(o.name=='Geometry' for o in obj))]),
 N('ObjectType','Material',children=[N('Count',len(material_names))])])
 nodes=[N('FBXHeaderExtension',children=[N('FBXHeaderVersion',1003),N('FBXVersion',7400),N('Creator','Project Spark Level55 Procedural HD Asset Generator')]),globs,defs,N('Objects',children=obj),N('Connections',children=conn),N('Takes',children=[N('Current','')])]
 out=bytearray(b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400))
 for node in nodes:out.extend(write_node(node,len(out)))
 out.extend(b'\0'*13);out.extend(b'\0'*160)
 path.write_bytes(out)
 return len(out),len(obj)

def glb_export(asset,path):
 scene=trimesh.Scene()
 for grp,loc in asset.groups.items():
  # Empty node with meaningful pivot, retained in GLB graph.
  scene.graph.update(frame_to=grp,frame_from='world',matrix=trimesh.transformations.translation_matrix(loc))
 for p in asset.parts:
  m=p.mesh.copy()
  if p.group:
   m.apply_translation(-asset.groups[p.group]);parent=p.group
  else:parent='world'
  rgba=np.array(C[p.mat])*255
  m.visual.vertex_colors=np.tile(rgba.astype(np.uint8),(len(m.vertices),1))
  scene.add_geometry(m,geom_name=p.name,node_name=p.name,parent_node_name=parent)
 path.write_bytes(scene.export(file_type='glb'))

triangles=sum(len(p.mesh.faces) for a in assets for p in a.parts)
for i,asset in enumerate(assets):
 bn=f'{i:02d}_{asset.name}'
 fbx_export([asset],ROOT/'Models'/f'{bn}.fbx',asset.name)
 glb_export(asset,ROOT/'GLB'/f'{bn}.glb')
 print(f'EXPORT {i+1:02d}/20 {asset.name} {len(asset.parts)} meshes, {sum(len(p.mesh.faces) for p in asset.parts):,} tris',flush=True)
fbx_export(assets,ROOT/'Models'/'Level55_Complete_ArtKit_Showcase.fbx','ALL')
# keep GLB assembled for Unity glTF import fallback
# for performance, assembled GLB uses merged material mesh; names individual models are in the separate files.
scene=trimesh.Scene()
for a in assets:
 for p in a.parts:
  mesh=p.mesh.copy();mesh.visual.vertex_colors=np.tile((np.array(C[p.mat])*255).astype(np.uint8),(len(mesh.vertices),1))
  scene.add_geometry(mesh,geom_name=a.name+'__'+p.name,node_name=a.name+'__'+p.name)
(ROOT/'GLB'/'Level55_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
print('EXPORT complete, geometry triangles=',triangles,flush=True)

manifest={
'levelId':'level_55','displayName':'Float the Shaft','subtitle':'Intelligent Active Magnetic Bearing System',
'description':'Visual HD art kit; does not include simulated magnetic bearing physics or a playable Unity level.',
'individual_models':20,'wire_count':28,'distinct_socket_count':48,'triangle_count':int(triangles),
'coordinate_system':'X along the rotor, Y upward, Z toward the front control electronics; 1 source length unit corresponds to 1 Unity import unit if scale=1.',
'models':[{'file':f'{i:02d}_{a.name}.fbx','model':a.name,'triangle_count':int(sum(len(p.mesh.faces) for p in a.parts)),
 'mesh_part_count':len(a.parts),'animation_pivots':{k:[float(x) for x in v] for k,v in a.groups.items() if not k.startswith('SOCKET_')},
 'socket_ids':[sid for label,(sid,mi) in endpoints.items() if mi==i]} for i,a in enumerate(assets)],
'wiring_file':'Exact_Wiring.csv','socket_file':'Terminal_Anchors.csv','animation_file':'Animation_Rigs.csv',
'material_palette':{k:[float(v) for v in vals] for k,vals in C.items()}
}
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
