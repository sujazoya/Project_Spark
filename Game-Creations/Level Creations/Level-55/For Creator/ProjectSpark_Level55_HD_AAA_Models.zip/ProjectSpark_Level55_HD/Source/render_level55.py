"""Review rendered GLB exports in headless VTK and create contact sheets."""
import os, math,pathlib, numpy as np, trimesh
from PIL import Image,ImageDraw,ImageFont
import vtk
from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray
ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level55_HD')
GLB=ROOT/'GLB'; OUT=ROOT/'Previews'
DARK=(6,15,27);LIGHT=(216,239,250); CYAN=(103,218,239)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FBOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def mesh_to_poly(m):
 verts=np.asarray(m.vertices,dtype=np.float32).copy()
 faces=np.asarray(m.faces,dtype=np.int64)
 vp=vtk.vtkPoints();vp.SetData(numpy_to_vtk(verts,deep=True))
 cells=vtk.vtkCellArray();packed=np.empty((len(faces),4),dtype=np.int64);packed[:,0]=3;packed[:,1:]=faces
 cells.SetCells(len(faces),numpy_to_vtkIdTypeArray(packed.ravel(),deep=True))
 pd=vtk.vtkPolyData();pd.SetPoints(vp);pd.SetPolys(cells)
 # smooth small curves but preserve box edges
 normals=vtk.vtkPolyDataNormals();normals.SetInputData(pd);normals.SetFeatureAngle(58);normals.SplittingOn();normals.ConsistencyOn();normals.AutoOrientNormalsOff();normals.Update()
 return normals.GetOutput()

def load_scene(p):
 scene=trimesh.load_scene(str(p));groups={};bmin=np.array([1e9]*3);bmax=-bmin
 # p contains GLB with transforms applied via .dump
 for m in scene.dump():
  if not isinstance(m,trimesh.Trimesh) or not len(m.faces):continue
  col=tuple(int(x) for x in m.visual.vertex_colors[0]) if m.visual.kind=='vertex' else (180,199,209,255)
  groups.setdefault(col,[]).append(m)
  bmin=np.minimum(bmin,m.bounds[0]);bmax=np.maximum(bmax,m.bounds[1])
 return groups,(bmin,bmax)

def make_render(path,sz=(1250,690),view='hero',model_name='',with_enclosure=True):
 groups,bounds=load_scene(path)
 ren=vtk.vtkRenderer();rw=vtk.vtkRenderWindow();rw.SetOffScreenRendering(1);rw.SetMultiSamples(4);rw.AddRenderer(ren)
 rw.SetSize(int(sz[0]),int(sz[1])); ren.SetBackground(.018,.051,.087)
 ren.SetBackground2(.055,.105,.158);ren.GradientBackgroundOn()
 ren.SetUseDepthPeeling(False)
 ren.SetAutomaticLightCreation(False)
 for loc,color,intensity in [((6,11,9),(1,.92,.81),1.00),((-8,5,5),(.41,.73,1.0),.75),((2,7,-9),(.77,1,1),.58)]:
  light=vtk.vtkLight();light.SetLightTypeToSceneLight();light.SetPosition(*loc);light.SetFocalPoint(0,1.2,0);light.SetColor(*color);light.SetIntensity(intensity);ren.AddLight(light)
 n=0
 for rgba,items in groups.items():
  if rgba[3]<90 and not with_enclosure:continue
  merged=trimesh.util.concatenate(items) if len(items)>1 else items[0]
  pd=mesh_to_poly(merged)
  mp=vtk.vtkPolyDataMapper();mp.SetInputData(pd)
  a=vtk.vtkActor();a.SetMapper(mp)
  r,g,b=rgba[:3];alpha=rgba[3]
  prop=a.GetProperty();prop.SetColor(r/255.,g/255.,b/255.)
  prop.SetOpacity(max(.11,alpha/255.))
  prop.SetInterpolationToPhong();prop.SetAmbient(.35);prop.SetDiffuse(.75);prop.SetSpecular(.5 if alpha>240 else .15);prop.SetSpecularPower(60)
  ren.AddActor(a);n+=1
 lo,hi=bounds; ctr=(lo+hi)/2;span=np.linalg.norm(hi-lo);diag=np.maximum(hi-lo,.01)
 ren.ResetCamera()
 camera=ren.GetActiveCamera()
 if view=='top':
  camera.SetPosition(float(ctr[0]),float(hi[1]+span*1.2),float(ctr[2]+.001));camera.SetViewUp(0,0,-1)
  camera.SetFocalPoint(float(ctr[0]),float(ctr[1]),float(ctr[2]));camera.ParallelProjectionOn();camera.SetParallelScale(float(max(diag[0]*.37,diag[2]*1.05)))
 elif view=='detail':
  ctr=np.array([.01,1.68,-.08]);camera.SetFocalPoint(*ctr)
  camera.SetPosition(7.7,5.2,6.5);camera.SetViewUp(0,1,0);camera.SetViewAngle(36)
 else:
  if view=='thumb' or sz[0]/sz[1]<1.3: # thumbnails
   camera.SetPosition(float(ctr[0]+max(diag[0],1)*1.10),float(ctr[1]+max(diag[1],1)*1.25),float(ctr[2]+max(diag[2],1)*1.65))
   camera.ParallelProjectionOn();camera.SetParallelScale(float(max(diag[1]*0.74, diag[0]*0.47, diag[2]*0.65, .28)))
  else:
   camera.SetPosition(10.5,7.8,11.8);camera.SetViewAngle(33)
  camera.SetFocalPoint(float(ctr[0]),float(ctr[1]),float(ctr[2]));camera.SetViewUp(0,1,0)
 rw.Render();ren.ResetCameraClippingRange();rw.Render()
 win=vtk.vtkWindowToImageFilter();win.SetInput(rw);win.ReadFrontBufferOff();win.Update()
 import vtk.util.numpy_support as vn
 arr=vn.vtk_to_numpy(win.GetOutput().GetPointData().GetScalars())
 width,height=sz;arr=arr.reshape(height,width,-1);arr=np.flipud(arr).copy()
 if arr.shape[-1]==4:arr=arr[:,:,:3]
 im=Image.fromarray(arr.astype(np.uint8),'RGB')
 rw.Finalize()
 return im

def add_heading(img,title,sub,foot,header=100,footer=48):
 out=Image.new('RGB',(img.width,img.height+header+footer),(7,17,30));out.paste(img,(0,header))
 d=ImageDraw.Draw(out)
 d.rectangle((0,header-2,img.width,header),fill=(44,93,117))
 d.text((35,22),title,font=ImageFont.truetype(FBOLD,29),fill=(225,243,255))
 d.text((37,63),sub,font=ImageFont.truetype(FONT,15),fill=(130,202,224))
 d.rectangle((0,out.height-footer,img.width,out.height-footer+1),fill=(31,78,97))
 d.text((36,out.height-footer+13),foot,font=ImageFont.truetype(FBOLD,16),fill=(139,232,210))
 return out
print('Rendering hero',flush=True)
hero=make_render(GLB/'Level55_Complete_ArtKit_Showcase.glb',(1670,800),with_enclosure=False)
hero=hero.crop((0,65,hero.width,hero.height))
hero=add_heading(hero,'PROJECT SPARK / LEVEL 55 — FLOAT THE SHAFT','HD active-magnetic-bearing art kit  •  Dual radial supports  •  Contactless rotor  •  5 V DC','20 INDIVIDUAL FBX MODELS   /   28 PLAYER WIRES   /   48 TERMINAL ANCHORS',header=95,footer=50)
hero.save(OUT/'Level55_Hero_Polished_Preview.png',optimize=True)
print('Rendering detail',flush=True)
detail=make_render(GLB/'Level55_Complete_ArtKit_Showcase.glb',(1450,780),view='detail',with_enclosure=False)
detail=add_heading(detail,'LEVITATION RIG — MECHANICAL DETAIL','Magnetic bearing A  /  suspended rotor  /  magnetic bearing B  /  calibrated gap sensors','SEPARATE ROTATION PIVOTS  •  COIL MODULES  •  TOUCHDOWN BEARINGS',header=85,footer=42)
detail.save(OUT/'Level55_Levitation_Detail_Preview.png',optimize=True)
print('Rendering top',flush=True)
top=make_render(GLB/'Level55_Complete_ArtKit_Showcase.glb',(1540,810),view='top',with_enclosure=False)
top=add_heading(top,'LEVEL 55 — TOP-DOWN UNITY ART PLACEMENT','Rotating hardware in center  •  magnetic driver and sensor modules at front  •  live monitor at back','ART AND ANCHOR COORDINATES INCLUDED IN MODEL MANIFEST',header=86,footer=41)
top.save(OUT/'Level55_TopDown_Layout_Preview.png',optimize=True)
print('Contact sheet',flush=True)
W,H=1560,1610;cellw,cellh=368,280;g=17;offx=38;offy=105
sheet=Image.new('RGB',(W,H),(7,17,30));draw=ImageDraw.Draw(sheet)
draw.text((44,25),'LEVEL 55 / ALL 20 INDIVIDUAL HD ASSETS',font=ImageFont.truetype(FBOLD,29),fill=(226,246,255))
draw.text((46,66),'FBX 7.4  •  GLB backup  •  3D geometry, not sprites',font=ImageFont.truetype(FONT,16),fill=(135,213,232))
models=sorted([p for p in GLB.glob('[0-9][0-9]_*.glb')])
for i,p in enumerate(models):
 r=i//4;c=i%4;x=offx+c*(cellw+g);y=offy+r*(cellh+g)
 im=make_render(p,(cellw-8,cellh-45),view='thumb',with_enclosure=False)
 draw.rounded_rectangle((x-2,y-2,x+cellw-2,y+cellh-2),radius=9,fill=(21,43,60),outline=(57,117,136),width=2)
 sheet.paste(im,(x+2,y+3))
 name=p.stem.split('_',1)[-1].replace('L55_','').replace('Bearing',' Bearing').replace('Driver',' Driver').replace('Sensor',' Sensor')
 text=f'{i+1:02d}  {name}'
 font=ImageFont.truetype(FBOLD,16)
 if draw.textbbox((0,0),text,font=font)[2]>cellw-15:font=ImageFont.truetype(FBOLD,13)
 draw.text((x+10,y+cellh-34),text,font=font,fill=(216,239,247))
sheet.save(OUT/'Level55_All_20_Models_ContactSheet.png',optimize=True)
print('Saved previews',flush=True)
