"""Structural FBX 7.4 / GLB and circuit-art manifest checks (not Unity runtime validation)."""
from pathlib import Path
import struct,zlib,json,csv,zipfile
from collections import Counter
import trimesh
ROOT=Path('/mnt/data/ProjectSpark_Level55_HD')
manifest=json.loads((ROOT/'Model_Manifest.json').read_text())
assert manifest['individual_models']==20 and manifest['wire_count']==28 and manifest['distinct_socket_count']==48
wires=list(csv.DictReader((ROOT/'Exact_Wiring.csv').open()))
anchors=list(csv.DictReader((ROOT/'Terminal_Anchors.csv').open()))
assert len(wires)==28,len(wires)
assert [w['Wire'] for w in wires]==[f'W{i:02d}' for i in range(1,29)]
assert len(anchors)==48 and len(set(a['Terminal_ID'] for a in anchors))==48
allids={x['Terminal_ID'] for x in anchors}
assert all(row['From_ID'] in allids and row['To_ID'] in allids for row in wires)
assert len({id for row in wires for id in (row['From_ID'],row['To_ID'])})==48
assert sum(w['From_ID']=='SUPPLY_POS' or w['To_ID']=='SUPPLY_POS' for w in wires)==5
assert sum(w['From_ID']=='SUPPLY_RET' or w['To_ID']=='SUPPLY_RET' for w in wires)==5

# Read FBX 7400 record headers and check property records, compressed arrays and mesh names.
def validate_fbx(path):
 b=path.read_bytes();header=b'Kaydara FBX Binary  \x00\x1a\x00';assert b.startswith(header),path
 assert struct.unpack_from('<I',b,23)[0]==7400
 count=Counter();geom_count=0;vertex_count=0;face_count=0;model_count=0
 def validate_props(off,qty,plen):
  nonlocal vertex_count,face_count
  i=off
  props=[]
  for _ in range(qty):
   t=chr(b[i]);i+=1
   if t in 'YCI': i+={'Y':2,'C':1,'I':4}[t]
   elif t in 'LFD':i+={'L':8,'F':4,'D':8}[t]
   elif t in 'SR':
    length=struct.unpack_from('<I',b,i)[0];i+=4+length
   elif t in 'fdil':
    length,encoding,size=struct.unpack_from('<III',b,i);i+=12
    raw=b[i:i+size];i+=size
    if encoding==1:
     dec=zlib.decompress(raw)
     assert len(dec)==length*{'f':4,'d':8,'i':4,'l':8}[t]
    else: assert size==length*{'f':4,'d':8,'i':4,'l':8}[t]
   else:raise AssertionError(f'Bad type {t} at {i} in {path}')
   assert i<=len(b)
  assert i==off+plen,(i,off,plen,path)
 def walk(pos,limit):
  nonlocal geom_count,model_count,vertex_count,face_count
  p=pos
  while p+13<=limit:
   end,qty,plen,nlen=struct.unpack_from('<IIIB',b,p)
   if end==0:return
   assert p<end<=limit,(path,p,end,limit)
   name=b[p+13:p+13+nlen].decode('utf8','replace');count[name]+=1
   props_at=p+13+nlen;validate_props(props_at,qty,plen)
   if name=='Geometry':geom_count+=1
   if name=='Model':model_count+=1
   child_pos=props_at+plen
   if child_pos<end-13:walk(child_pos,end-13)
   p=end
 walk(27,len(b)-160)
 assert geom_count>0 and model_count>0
 assert count['Vertices']==count['PolygonVertexIndex']==geom_count
 return len(b),geom_count,model_count

files=sorted((ROOT/'Models').glob('*.fbx'))
glb=sorted((ROOT/'GLB').glob('*.glb'))
assert len(files)==21 and len(glb)==21
report={'fbx':[],'glb':[],'wire_count':len(wires),'terminal_count':len(anchors)}
for p in files:
 size,g,m=validate_fbx(p)
 report['fbx'].append({'file':p.name,'bytes':size,'geometry_meshes':g,'model_nodes':m})
 print('FBX VALID',p.name,'geometry',g,'models',m)
total=0
for p in glb:
 scene=trimesh.load_scene(p)
 tris=sum(len(m.faces) for m in scene.geometry.values())
 assert tris>0 and scene.is_empty is False,p
 report['glb'].append({'file':p.name,'bytes':p.stat().st_size,'mesh_count':len(scene.geometry),'triangles':tris})
 if p.name != 'Level55_Complete_ArtKit_Showcase.glb':total+=tris
 print('GLB VALID',p.name,'triangles',tris)
assert total==manifest['triangle_count'],(total,manifest['triangle_count'])
assert next(x for x in report['glb'] if x['file']=='Level55_Complete_ArtKit_Showcase.glb')['triangles']==total
for p in [ROOT/'Previews'/'Level55_Hero_Polished_Preview.png',ROOT/'Previews'/'Level55_All_20_Models_ContactSheet.png',ROOT/'Previews'/'Level55_Levitation_Detail_Preview.png',ROOT/'Previews'/'Level55_TopDown_Layout_Preview.png']:
 assert p.is_file() and p.stat().st_size>20000,p
report['total_triangles']=total
(ROOT/'Verification_Report.json').write_text(json.dumps(report,indent=2))
print('VERIFIED: 21 FBX files, 21 GLB files,',total,'triangles,',len(wires),'wires,',len(anchors),'socket IDs')
