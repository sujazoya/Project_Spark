"""Project Spark Level 51 — Predict the Failure.
Actual procedural, colored 3D triangle geometry; FBX 7.4 binary + GLB.
Visual assets only. Does not implement machine physics or electrical bindings.
Y up, front -Z; one art unit is arbitrary (scale against your real workbench).
"""
from __future__ import annotations
import math, csv, json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb
ROOT=Path(__file__).resolve().parents[1]
MOD=ROOT/'Models'
PALETTE.update({
 'nickel':(149,174,195,255),'aluminum':(178,194,211,255),'mirror':(221,232,239,255),
 'darksteel':(37,55,73,255),'carbon':(17,32,45,255),'coal':(10,19,29,255),
 'aqua':(36,222,244,255),'mint':(58,250,185,255),'electric':(39,129,243,255),
 'scarlet':(254,66,82,255),'safety':(251,187,61,255), 'amberlit':(255,201,96,255),
 'brass':(199,158,74,255),'bronze':(172,99,52,255),'gunmetal':(70,91,113,255),
 'glassblue':(110,200,239,64),'screenback':(8,32,44,255),
 'smokeglass':(95,133,160,75),'greenmetal':(25,102,85,255), 'ambermetal':(136,78,40,255),
 'pale':(217,235,242,255),'copperlight':(224,141,82,255), 'teal':(44,145,152,255)
})

def label(m,key,s,x,y,z,size=.15,col='pale',maxw=None,group='Static'):
 m.text(key,s,size,x,y,z,col,maxwidth=maxw,group=group)

def screw(m,n,x,y,z):
 m.cyl(n+'.metal',.060,.026,(x,y,z),'chrome','y',16)
 m.box(n+'.slot',(.069,.008,.017),(x,y+.020,z),'darksteel')

def glow(m,n,x,y,z,mat='mint',group=None):
 grp=group or n+'_LAMP'
 m.cyl(n+'_rim',.135,.045,(x,y,z),'chrome','z',28,grp)
 m.cyl(n+'_lens',.104,.043,(x,y,z-.055),mat,'z',28,grp)
 m.torus(n+'_outline',.143,.019,(x,y,z-.079),mat,'z',32,6,grp)
 m.group_pivots[grp]=(x,y,z)

def jack(m,n,code,caption,x,y,z,color='aqua'):
 grp='SOCKET_'+code
 m.cyl(n+'_'+code+'_rim',.165,.058,(x,y,z),'chrome','z',32,grp)
 m.cyl(n+'_'+code+'_ring',.131,.067,(x,y,z-.039),color,'z',30,grp)
 m.cyl(n+'_'+code+'_recess',.088,.075,(x,y,z-.091),'void','z',28,grp)
 m.cyl(n+'_'+code+'_contact',.031,.026,(x,y,z-.146),'gold','z',16,grp)
 m.torus(n+'_'+code+'_halo',.163,.012,(x,y,z-.105),color,'z',32,5,grp)
 label(m,n+'_'+code+'_label',caption,x,y+.223,z-.165,.11,'pale',.90)
 if code in m.anchors: raise RuntimeError('duplicate terminal '+code)
 m.anchors[code]=(round(x,4),round(y,4),round(z-.170,4))

def plinth(m,n,w=5.2,d=4.4,accent='aqua'):
 m.bevel(n+'_vibration_isolator',(w+.17,.14,d+.17),(0,.14,0),'rubber',.09)
 m.bevel(n+'_plinth',(w,.35,d),(0,.37,0),'darksteel',.14)
 m.box(n+'_brushed_top',(w-.17,.075,d-.19),(0,.59,0),'nickel')
 m.box(n+'_front_illumination',(w-.39,.048,.06),(0,.69,-d/2-.052),accent)
 for xx in (-w/2+.29,w/2-.29):
  for zz in (-d/2+.30,d/2-.30):screw(m,n+f'_bolt_{xx:.1f}_{zz:.1f}',xx,.665,zz)

def panel(m,n,title,w=4.7,d=2.8,h=1.65,sub='',accent='aqua'):
 m.base(n,w,d,h)
 f=-d/2-.094
 m.box(n+'_header',(w-.3,.30,.03),(0,.32+h*.80,f-.04),'coal')
 label(m,n+'_title',title,0,.32+h*.80,f-.066,.206,'pale',w-.45)
 if sub: label(m,n+'_subtitle',sub,0,.32+h*.60,f-.06,.119,accent,w-.48)
 m.box(n+'_edge_light',(w-.5,.036,.035),(0,.32+h+.087,-d/2+.16),accent)
 for xx in (-w/2+.23,w/2-.23):
  for zz in (-d/2+.27,d/2-.27):screw(m,n+f'_topbolt_{xx:.1f}_{zz:.1f}',xx,.32+h+.13,zz)
 return f

def bearing_machinery(m,n,axis='x',center=(0,1.7,0),size=1.05,group='Static',worn=False):
 x,y,z=center
 m.tube(n+'_machined_housing',size+.23,size-.14,.66,(x,y,z),'nickel',axis,48,group)
 m.tube(n+'_outer_race',size+.07,size-.15,.68,(x,y,z),'chrome',axis,48,group)
 m.tube(n+'_inner_race',size*.51,size*.29,.74,(x,y,z),'mirror',axis,48,group)
 rad=(size*.51+size*.82)/2
 for i in range(14):
  a=math.tau*i/14
  if axis=='x':p=(x,y+rad*math.sin(a),z+rad*math.cos(a))
  else:p=(x+rad*math.sin(a),y+rad*math.cos(a),z)
  m.cyl(n+f'_ball_{i:02d}',.105 if not worn else .095,.15,p,'chrome' if not worn else 'bronze',axis,14,group)
 for xx in [-1,1]:
  m.cyl(n+f'_sealing_ring_{xx}',size*.94,.043,(x+xx*.365,y,z),'carbon',axis,36,group)


def make_base():
 m=Model('00_L51_IndustrialBase');t='L51_LAB_FRAME'
 m.bevel(t+'_dark_rubber',(41.0,.22,23.3),(0,.12,0),'rubber',.20)
 m.bevel(t+'_machined_platform',(40.6,.55,22.8),(0,.47,0),'graphite',.26)
 m.box(t+'_brushed_top',(40.0,.065,21.7),(0,.78,0),'darksteel')
 for xx in [-19.8,19.8]:
  m.box(t+f'_side_alloy_{xx:.1f}',(.22,.40,22.2),(xx,.92,0),'nickel')
  m.box(t+f'_side_light_{xx:.1f}',(.05,.046,21.6),(xx,1.15,0),'aqua')
 for zz in [-10.9,10.9]:
  m.box(t+f'_cross_brace_{zz}',(40.0,.28,.25),(0,.96,zz),'gunmetal')
  m.box(t+f'_brace_light_{zz}',(39.1,.025,.043),(0,1.116,zz),'mint' if zz>0 else 'safety')
 for x in np.linspace(-18.7,18.7,15):
  for z in (-9.45,-8.96,-8.48):m.cyl(t+f'_BreadboardHole_{x:.1f}_{z:.2f}',.045,.015,(float(x),.827,z),'coal','y',8)
 for x in (-19.1,19.1):
  for z in (-10.4,10.4):m.bevel(t+f'_foot_{x}_{z}',(1.18,.28,1.20),(x,.15,z),'rubber',.08)
 for k,x in enumerate(np.linspace(-17.5,17.5,8)):
  m.box(t+f'_lab_safety_band_{k}',(.52,.03,.85),(float(x),.841,-10.55),'safety' if k%2 else 'coal')
 label(m,t+'_name','PREDICT THE FAILURE  /  LEVEL 51',0,1.16,-11.20,.34,'pale',22)
 return m


def make_motor():
 m=Model('01_L51_DCMotorAssembly');t='L51_DC_MOTOR';plinth(m,t,5.3,4.5,'aqua')
 yy=2.27;zz=0
 for xx in (-1.38,1.38):
  m.box(t+f'_MountStand_{xx}',(.37,1.30,2.1),(xx,1.36,0),'gunmetal')
  m.bevel(t+f'_FootSaddle_{xx}',(.66,.23,2.45),(xx,.82,0),'chrome',.08)
 m.cyl(t+'_motor_can',1.04,3.48,(0,yy,zz),'nickel','x',64)
 m.cyl(t+'_dark_front_endcap',1.135,.23,(1.73,yy,zz),'carbon','x',52)
 m.cyl(t+'_rear_endcap',1.095,.31,(-1.76,yy,zz),'gunmetal','x',50)
 for k in range(24):
  ang=math.tau*k/24
  h=yy+1.04*math.cos(ang);z=zz+1.04*math.sin(ang)
  m.rod(t+f'_CoolingRib_{k:02d}',(-1.49,h,z),(1.49,h,z),.050,'aluminum',12)
 for xx in [-1.9,1.87]:
  m.torus(t+f'_EndcapTrim_{xx}',1.04,.053,(xx,yy,zz),'aqua' if xx>0 else 'steel','x',64,8)
 for k in range(8):
  a=math.tau*k/8
  m.cyl(t+f'_EndbellBolt_{k}',.052,.046,(1.88,yy+.85*math.sin(a),zz+.85*math.cos(a)),'mirror','x',12)
 gg='MOTOR_SHAFT_ROTATE_X'
 m.cyl(t+'_exposed_shaft',.195,2.21,(2.37,yy,zz),'chrome','x',32,gg)
 m.cyl(t+'_coupling',.37,.53,(3.24,yy,zz),'brass','x',32,gg)
 m.group_pivots[gg]=(2.4,yy,zz)
 for k in (-.75,.75):m.cyl(t+f'_CopperTerminal_{k}',.15,.19,(-1.6,yy+.49,k*.7),'copperlight','y',24)
 m.bevel(t+'_WireTerminalDock',(3.18,.75,.65),(0,.59,-2.50),'carbon',.06)
 jack(m,t,'MOTOR_PLUS','MOTOR +',-.70,.70,-2.88,'scarlet')
 jack(m,t,'MOTOR_MINUS','MOTOR -',.70,.70,-2.88,'void')
 label(m,t+'_front_logo','5 V DC HEALTH MOTOR',0,.99,-2.54,.167,'pale',2.9)
 return m


def make_rotor():
 m=Model('02_L51_DiagnosticRotor');t='L51_BALANCE_ROTOR';plinth(m,t,4.30,4.20,'mint')
 y=2.35;zz=0;gr='DIAGNOSTIC_ROTOR_ROTATE_X'
 m.cyl(t+'_hub_axis',.27,4.05,(0,y,zz),'chrome','x',38,gr)
 m.cyl(t+'_flywheel_body',1.66,.52,(0,y,zz),'nickel','x',70,gr)
 m.cyl(t+'_recessed_face',1.46,.54,(0,y,zz),'gunmetal','x',70,gr)
 for xx in (-.30,.30):
  m.torus(t+f'_machined_outer_rim_{xx}',1.57,.078,(xx,y,zz),'mirror','x',76,11,gr)
  m.torus(t+f'_cyan_balance_line_{xx}',1.39,.018,(xx,y,zz),'aqua','x',72,6,gr)
  m.torus(t+f'_hub_steel_ring_{xx}',.40,.09,(xx,y,zz),'chrome','x',64,9,gr)
 for i in range(16):
  a=math.tau*i/16;h=y+1.09*math.sin(a);z=zz+1.09*math.cos(a)
  m.cyl(t+f'_RotorBolt_{i:02d}',.090,.032,(.32,h,z),'mirror','x',20,gr)
  m.cyl(t+f'_BalanceHole_{i:02d}',.153,.013,(.348,h,z),'coal','x',22,gr)
 for i in range(80):
  a=math.tau*i/80
  m.cyl(t+f'_FineIndex_{i:02d}',.022 if i%5 else .035,.024,(.33,y+1.48*math.sin(a),zz+1.48*math.cos(a)),'mint' if i%10==0 else 'pale','x',9,gr)
 m.group_pivots[gr]=(0,y,zz)
 gw='ECCENTRIC_TEST_WEIGHT_DETACH'
 m.cyl(t+'_UnbalanceSteelWeight',.19,.13,(.53,y+1.08,zz),'safety','x',25,gw)
 m.cyl(t+'_UnbalanceLockNut',.094,.145,(.64,y+1.08,zz),'coal','x',12,gw)
 m.group_pivots[gw]=(.5,y+1.08,zz)
 for xx in (-1.6,1.6):
  m.box(t+f'_saddle_{xx}',(.36,1.20,1.53),(xx,1.22,0),'gunmetal')
  bearing_machinery(m,t+f'_hub_{xx}',center=(xx,y,0),size=.48)
 label(m,t+'_label','BALANCE ROTOR  /  80 MARKS',0,.98,-2.19,.155,'pale',3.6)
 return m


def make_bearing():
 m=Model('03_L51_ServiceBearing');t='L51_BEARING';plinth(m,t,3.95,3.9,'safety')
 y=2.15
 m.bevel(t+'_MountPillar',(1.30,1.14,1.31),(0,1.20,0),'gunmetal',.10)
 bearing_machinery(m,t+'_removable_cartridge',center=(0,y,0),size=1.00,group='SERVICE_BEARING_CARTRIDGE_REMOVABLE')
 m.group_pivots['SERVICE_BEARING_CARTRIDGE_REMOVABLE']=(0,y,0)
 m.torus(t+'_retaining_amber_ring',1.10,.046,(.42,y,0),'safety','x',56,8)
 for k in range(6):
  a=math.tau*k/6;m.cyl(t+f'_BearingBolts_{k}',.070,.11,(.46,y+.91*math.sin(a),.91*math.cos(a)),'chrome','x',16)
 label(m,t+'_plate','REPLACEABLE BEARING',0,.99,-2.03,.17,'pale',3.55)
 glow(m,t+'_bearing_status',1.34,1.10,-2.07,'safety')
 return m


def make_encoder():
 m=Model('04_L51_EncoderAssembly');t='L51_ENCODER';plinth(m,t,3.5,3.8,'mint')
 y=2.24;g='ENCODER_DISC_ROTATE_X'
 m.cyl(t+'_axle',.17,2.6,(0,y,0),'chrome','x',28,g)
 m.cyl(t+'_index_disc',1.10,.09,(0,y,0),'carbon','x',60,g)
 m.torus(t+'_neon_annulus',.98,.037,(.076,y,0),'mint','x',64,8,g)
 for k in range(80):
  a=math.tau*k/80
  m.cyl(t+f'_80_Count_Tick_{k:02d}',.019 if k%5 else .032,.022,(.071,y+.88*math.cos(a),.88*math.sin(a)),'mint' if k%5==0 else 'pale','x',8,g)
 m.group_pivots[g]=(0,y,0)
 m.box(t+'_FixedOpticalReadHead',(1.0,.36,.66),(0,3.24,0),'nickel')
 m.cyl(t+'_OpticWindow',.12,.20,(0,3.02,0),'aqua','y',24)
 m.box(t+'_SupportPost',(.28,1.45,.39),(-1.15,1.71,0),'gunmetal')
 m.bevel(t+'_SocketDock',(2.4,.72,.66),(0,.58,-2.08),'carbon',.07)
 jack(m,t,'ENCODER_A','ENC A',-.59,.68,-2.49,'aqua')
 jack(m,t,'ENCODER_B','ENC B',.59,.68,-2.49,'mint')
 label(m,t+'_label','QUADRATURE 80 CPR',0,1.04,-2.1,.135,'pale',2.55)
 return m


def make_vibration():
 m=Model('05_L51_VibrationSensor');t='L51_VIB_SENSOR';f=panel(m,t,'VIBRATION PICKUP',4.35,2.8,1.77,'TRIAXIAL MEASUREMENT','mint')
 m.box(t+'_SensorArm',(.28,1.40,.31),(0,2.59,.22),'nickel')
 m.bevel(t+'_SensorHead',(1.20,.61,1.06),(0,3.28,.18),'aluminum',.12)
 m.bevel(t+'_CeramicProbe',(.69,.18,.81),(0,3.69,.20),'mint',.03)
 for xx in (-.44,.44):m.cyl(t+f'_CapScrew_{xx}',.065,.024,(xx,3.66,.20),'brass','y',16)
 m.box(t+'_ProbeCable',(1.37,.15,.18),(0,2.20,.20),'rubber')
 m.box(t+'_AnalogStatusFace',(2.70,.43,.027),(0,1.65,f-.08),'screenback')
 label(m,t+'_ValueBlankLabel','RMS / 1X / BEARING',0,1.65,f-.13,.12,'mint',2.47)
 for sid,c,x,col in [('VIB_PLUS','+5V',-1.35,'scarlet'),('VIB_GND','GND',0,'void'),('VIB_OUT','OUT',1.35,'mint')]:
  jack(m,t,sid,c,x,.72,f,col)
 return m


def make_temperature():
 m=Model('06_L51_TemperatureSensor');t='L51_TEMP_SENSOR';f=panel(m,t,'THERMAL SENSOR',4.3,2.8,1.77,'METAL PROBE  /  NTC','safety')
 m.box(t+'_StainlessClampingArm',(.34,1.65,.28),(0,2.57,.20),'nickel')
 m.cyl(t+'_ProbeStem',.14,1.03,(0,3.19,.16),'chrome','y',24)
 m.cyl(t+'_ProbeTip',.22,.37,(0,3.67,.16),'brass','y',24)
 for i in range(6):m.torus(t+f'_ProbeGoldRing_{i}',.144,.027,(0,2.85+i*.128,.16),'safety','y',28,6)
 m.box(t+'_LiveThermFace',(2.80,.45,.024),(0,1.65,f-.079),'screenback')
 label(m,t+'_ThermLabel','DEG C / DELTA T',0,1.65,f-.114,.13,'safety',2.48)
 for sid,c,x,col in [('TEMP_PLUS','+5V',-1.35,'scarlet'),('TEMP_GND','GND',0,'void'),('TEMP_OUT','OUT',1.35,'safety')]:
  jack(m,t,sid,c,x,.72,f,col)
 return m


def make_shunt():
 m=Model('07_L51_CurrentShunt');t='L51_SHUNT';f=panel(m,t,'CURRENT SHUNT',5.0,2.85,1.90,'FOUR-TERMINAL / SERIES','safety')
 for z in [-.54,.50]:
  m.box(t+f'_CopperBus_{z}',(3.8,.105,.32),(0,2.48,z),'copperlight')
  for xx in np.linspace(-1.6,1.6,7):m.cyl(t+f'_SilverContact_{z}_{xx:.1f}',.09,.04,(float(xx),2.57,z),'mirror','y',16)
 m.box(t+'_ResistiveSensingElement',(2.6,.11,.75),(0,2.45,0),'nickel')
 m.box(t+'_VoltageDropWindow',(3.65,.47,.028),(0,1.75,f-.077),'screenback')
 label(m,t+'_ShuntRuler','LOW-OHM MEASUREMENT',0,1.75,f-.115,.122,'amberlit',3.4)
 for sid,c,x,col in [('SHUNT_IN','IN+',-1.77,'scarlet'),('SHUNT_OUT','OUT+',-.60,'scarlet'),('SHUNT_SENSE_PLUS','S+',.60,'safety'),('SHUNT_SENSE_MINUS','S-',1.77,'void')]:jack(m,t,sid,c,x,.72,f,col)
 return m


def make_driver():
 m=Model('08_L51_MotorDriver');t='L51_DRIVER';f=panel(m,t,'PWM MOTOR DRIVER',5.4,3.0,1.95,'5 V  /  H-BRIDGE','aqua')
 m.box(t+'_MainDrivePCB',(4.4,.1,1.90),(0,2.38,.08),'greenmetal')
 for i in range(15):m.box(t+f'_HeatsinkRib_{i:02d}',(.095,.73,1.32),(-1.68+i*.24,2.67,.26),'aluminum')
 m.box(t+'_PowerStage',(1.9,.50,.92),(.6,2.66,-.48),'darksteel')
 for xx in np.linspace(-.2,1.3,7):m.cyl(t+f'_Fastener_{xx:.1f}',.04,.015,(float(xx),2.93,-.48),'brass','y',10)
 glow(m,t+'_DriverPowerLamp',1.95,1.63,f-.11,'mint')
 for sid,lab,x,c in [('DRIVER_PLUS','+5V',-1.89,'scarlet'),('DRIVER_GND','GND',-.94,'void'),('DRIVER_PWM_IN','PWM',0,'safety'),('DRIVER_MOTOR_PLUS','M+',.94,'scarlet'),('DRIVER_MOTOR_MINUS','M-',1.89,'void')]:jack(m,t,sid,lab,x,.72,f,c)
 return m


def make_controller():
 m=Model('09_L51_HealthController');t='L51_CONTROLLER';f=panel(m,t,'MACHINE HEALTH CONTROLLER',8.45,3.5,2.20,'VIBRATION  /  CURRENT  /  THERMAL  /  RPM','aqua')
 m.box(t+'_CentralElectronicsScreen',(5.30,.55,.028),(0,2.015,f-.073),'screenback')
 label(m,t+'_ScreenLegend','BASELINE    ANALYZE    MAINTAIN    CERTIFY',0,2.015,f-.113,.15,'mint',5.15)
 for i,(x,word) in enumerate([(-2.70,'BASELINE'),(-.90,'ANALYZE'),(.90,'SERVICE'),(2.70,'RESET')]):
  m.bevel(t+f'_ButtonBody_{i}',(1.12,.22,.10),(x,2.59,-1.42),'carbon',.04)
  m.bevel(t+f'_ButtonCap_{i}',(.91,.08,.08),(x,2.74,-1.43),'mint' if i<2 else 'safety',.025,group='CTRL_BUTTON_'+word)
  m.group_pivots['CTRL_BUTTON_'+word]=(x,2.74,-1.43)
  label(m,t+f'_ButtonCaption_{i}',word,x,2.86,-1.46,.092,'pale',1.05)
 # Two rows x five terminal sockets; allow front-facing interaction and readable labels
 portA=[('CTRL_PLUS','+5V','scarlet'),('CTRL_GND','GND','void'),('CTRL_PWM_OUT','PWM','safety'),('CTRL_VIB_IN','VIB','mint'),('CTRL_TEMP_IN','TEMP','safety')]
 portB=[('CTRL_CURRENT_PLUS','I+','safety'),('CTRL_CURRENT_MINUS','I-','void'),('CTRL_ENC_A','ENC A','aqua'),('CTRL_ENC_B','ENC B','mint'),('CTRL_SAFETY_IN','SAFE','scarlet')]
 xs=[-3.22,-1.60,0,1.60,3.22]
 for (sid,cap,col),xx in zip(portA,xs):jack(m,t,sid,cap,xx,1.30,f,col)
 for (sid,cap,col),xx in zip(portB,xs):jack(m,t,sid,cap,xx,.58,f,col)
 glow(m,t+'_HealthLamp',3.91,2.07,f-.09,'mint')
 return m


def make_monitor():
 m=Model('10_L51_ConditionMonitor');t='L51_MONITOR';f=panel(m,t,'MACHINE HEALTH ANALYTICS',9.30,2.55,2.22,'4 LIVE SIGNALS  /  BASELINE COMPARISON','mint')
 m.box(t+'_WaveformScreen',(8.66,1.07,.04),(0,1.67,f-.081),'screenback',group='CONDITION_SCREEN_FACE')
 m.box(t+'_SignalCenterLine',(8.20,.015,.012),(0,1.58,f-.109),'gunmetal')
 for j,col in enumerate(['aqua','safety','scarlet','mint']):
  yy=1.99-j*.23
  m.box(t+f'_WaveformLane_{j}',(8.1,.008,.015),(0,yy,f-.12),'gunmetal')
  # Embossed static waveform motifs; actual readings provided by UI
  xs=np.linspace(-3.85,3.75,44)
  for k in range(len(xs)-1):
   x0=float(xs[k]);x1=float(xs[k+1]);z=f-.133
   a=yy+.025*math.sin(k*.59+j)+(.045 if j==0 else .015)*math.sin(k*2.5)
   b=yy+.025*math.sin((k+1)*.59+j)+(.045 if j==0 else .015)*math.sin((k+1)*2.5)
   m.rod(t+f'_IllustrativeGraph_{j}_{k}',(x0,a,z),(x1,b,z),.008,col,6)
 m.group_pivots['CONDITION_SCREEN_FACE']=(0,1.65,f-.08)
 label(m,t+'_PanelBottom','VIBRATION   CURRENT   TEMPERATURE   ENCODER SPEED',0,.92,f-.08,.14,'mint',7.80)
 return m


def make_weights():
 m=Model('11_L51_BalanceWeightKit');t='L51_WEIGHT_TRAY';plinth(m,t,4.7,3.45,'safety')
 m.bevel(t+'_LinedStorageTray',(4.22,.36,2.60),(0,.93,0),'carbon',.1)
 for j in range(2):
  for i in range(5):
   x=-1.61+i*.81;z=-.55+j*.93
   m.cyl(t+f'_WeightSocket_{j}_{i}',.33,.045,(x,1.15,z),'void','y',28)
   group=f'WEIGHT_{j*5+i:02d}_PICKUP'
   m.cyl(t+f'_CalibratedTestWeight_{j}_{i}',.18+(i%3)*.025,.16,(x,1.30,z),'brass' if j==0 else 'nickel','y',25,group)
   m.cyl(t+f'_WeightCenterBore_{j}_{i}',.068,.17,(x,1.32,z),'coal','y',14,group)
   m.group_pivots[group]=(x,1.30,z)
 label(m,t+'_ident','ROTOR BALANCE WEIGHT SET',0,.86,-1.84,.145,'pale',4.4)
 return m


def make_service_station():
 m=Model('12_L51_BearingServiceStation');t='L51_SERVICE_TRAY';plinth(m,t,5.3,4.1,'mint')
 for x,condition,col in [(-1.27,'HEALTHY','mint'),(1.26,'WORN','safety')]:
  m.bevel(t+f'_Holder_{condition}',(1.82,.27,2.25),(x,.95,.28),'carbon',.10)
  group='SERVICE_BEARING_'+condition+'_PICKUP'
  bearing_machinery(m,t+'_'+condition,center=(x,1.78,.20),size=.64,group=group,worn=condition=='WORN')
  m.group_pivots[group]=(x,1.78,.20)
  m.box(t+f'_StatusColor_{condition}',(1.46,.042,.08),(x,1.13,-1.50),col)
  label(m,t+'_name_'+condition,condition,x,.88,-2.15,.14,col,1.48)
 for i in range(4):m.rod(t+f'_MaintenanceTool_{i}',(-2.18+i*1.40,.83,1.70),(-2.1+i*1.40,.93,1.23),.06,'brass',10)
 return m


def make_guard():
 m=Model('13_L51_SafetyEnclosure');t='L51_GUARD'
 w=23.6;d=7.0
 for x in (-w/2,w/2):
  for z in (-d/2,d/2):m.box(t+f'_ChromedGuardPost_{x:.1f}_{z:.1f}',(.15,4.45,.15),(x,2.80,z),'mirror')
 for yy in (.79,5.03):
  for zz in (-d/2,d/2):m.box(t+f'_LongRail_{yy:.1f}_{zz:.1f}',(w+.19,.16,.19),(0,yy,zz),'nickel')
  for xx in (-w/2,w/2):m.box(t+f'_SideRail_{yy:.1f}_{xx:.1f}',(.19,.16,d+.20),(xx,yy,0),'nickel')
 for xx in (-w/2,w/2):m.box(t+f'_ClearSidePanel_{xx:.1f}',(.045,3.9,d-.4),(xx,2.84,0),'glassblue')
 for yy in (1.05,4.94):m.box(t+f'_PillarBridge_{yy:.1f}',(.15,.09,6.9),(0,yy,-d/2),'gunmetal')
 g='FRONT_SAFETY_DOOR_HINGE_Y'
 m.box(t+'_FrontClearSwingDoor',(w-.55,3.62,.055),(0,2.80,-d/2),'glassblue',g)
 m.box(t+'_FrontDoorHandle',(.25,.55,.28),(w/2-.87,2.49,-d/2-.17),'mirror',g)
 m.group_pivots[g]=(-w/2+.28,2.80,-d/2)
 for j,x in enumerate(np.linspace(-11.0,11.0,9)):
  m.box(t+f'_GuardRoofRod_{j}',(.08,.07,d),(float(x),5.08,0),'chrome')
 m.bevel(t+'_SafetySwitchDock',(2.05,.79,.89),(w/2-.86,.63,-d/2-.3),'carbon',.08)
 jack(m,t,'GUARD_NC_OUT','NC OUT',w/2-.86,.76,-d/2-.84,'safety')
 glow(m,t+'_GuardReadyLED',w/2-2.42,1.34,-d/2-.09,'mint')
 label(m,t+'_SafetyWarning','GUARDED TEST CELL',0,5.19,-d/2-.11,.225,'safety',7.4)
 return m


def make_supply():
 m=Model('14_L51_5VSupply');t='L51_SUPPLY';f=panel(m,t,'REGULATED 5 V DC',4.40,2.8,1.84,'DIAGNOSTIC POWER','aqua')
 m.box(t+'_meter_screen',(2.50,.49,.027),(0,1.53,f-.085),'screenback')
 label(m,t+'_VoltageLabel','5.00 V',0,1.53,f-.133,.26,'mint',2.23)
 glow(m,t+'_powerLED',1.66,1.58,f-.07,'mint')
 for i in range(10):m.box(t+f'_lid_vent_{i}',(.07,.015,1.21),(-1.70+i*.37,2.61,.28),'coal')
 jack(m,t,'SUPPLY_PLUS','+5V',-.93,.72,f,'scarlet')
 jack(m,t,'SUPPLY_RETURN','RETURN',.93,.72,f,'void')
 return m

BUILDERS=[make_base,make_motor,make_rotor,make_bearing,make_encoder,make_vibration,make_temperature,make_shunt,make_driver,make_controller,make_monitor,make_weights,make_service_station,make_guard,make_supply]
POS={
 '00_L51_IndustrialBase':(0,0,0),
 '01_L51_DCMotorAssembly':(-13.05,0,.90),
 '02_L51_DiagnosticRotor':(-6.4,0,.90),
 '03_L51_ServiceBearing':(-.70,0,.90),
 '04_L51_EncoderAssembly':(4.25,0,.90),
 '05_L51_VibrationSensor':(-13.00,0,6.55),
 '06_L51_TemperatureSensor':(-.70,0,6.55),
 '07_L51_CurrentShunt':(7.00,0,-7.05),
 '08_L51_MotorDriver':(-13.45,0,-7.00),
 '09_L51_HealthController':(-3.90,0,-7.15),
 '10_L51_ConditionMonitor':(-6.35,0,8.40),
 '11_L51_BalanceWeightKit':(13.25,0,-.50),
 '12_L51_BearingServiceStation':(13.10,0,5.85),
 '13_L51_SafetyEnclosure':(-5.70,0,.90),
 '14_L51_5VSupply':(15.15,0,-7.10),
}
WIRES=[
 ('W01','SUPPLY_PLUS','CTRL_PLUS','Supply +5 V > Health Controller +5 V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply RETURN > Controller GND'),
 ('W03','SUPPLY_PLUS','DRIVER_PLUS','Supply +5 V > Driver +5 V'),
 ('W04','SUPPLY_RETURN','DRIVER_GND','Supply RETURN > Driver GND'),
 ('W05','CTRL_PWM_OUT','DRIVER_PWM_IN','Controller PWM > Motor Driver PWM'),
 ('W06','DRIVER_MOTOR_PLUS','SHUNT_IN','Driver MOTOR+ > Current Shunt IN'),
 ('W07','SHUNT_OUT','MOTOR_PLUS','Shunt OUT > DC Motor +'),
 ('W08','DRIVER_MOTOR_MINUS','MOTOR_MINUS','Driver MOTOR- > DC Motor -'),
 ('W09','SUPPLY_PLUS','VIB_PLUS','Supply +5 V > Vibration Sensor +5 V'),
 ('W10','SUPPLY_RETURN','VIB_GND','Supply RETURN > Vibration Sensor GND'),
 ('W11','VIB_OUT','CTRL_VIB_IN','Vibration OUT > Controller VIB IN'),
 ('W12','SUPPLY_PLUS','TEMP_PLUS','Supply +5 V > Temperature Sensor +5 V'),
 ('W13','SUPPLY_RETURN','TEMP_GND','Supply RETURN > Temperature Sensor GND'),
 ('W14','TEMP_OUT','CTRL_TEMP_IN','Temperature OUT > Controller TEMP IN'),
 ('W15','SHUNT_SENSE_PLUS','CTRL_CURRENT_PLUS','Shunt S+ > Controller I+'),
 ('W16','SHUNT_SENSE_MINUS','CTRL_CURRENT_MINUS','Shunt S- > Controller I-'),
 ('W17','ENCODER_A','CTRL_ENC_A','Encoder A > Controller ENC A'),
 ('W18','ENCODER_B','CTRL_ENC_B','Encoder B > Controller ENC B'),
 ('W19','GUARD_NC_OUT','CTRL_SAFETY_IN','Safety Guard NC OUT > Controller SAFE IN'),
]

def build():
 models=[]
 for maker in BUILDERS:
  m=maker();models.append(m)
  fn=MOD/(m.key+'.fbx');glb=MOD/(m.key+'.glb')
  export_fbx(fn,[m]);export_glb(glb,[m])
  assert fn.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  assert len(trimesh.load_scene(glb).geometry)>0
  print('MODEL',m.key,'TRIS',sum(len(p.mesh.faces) for p in m.parts),'PARTS',len(m.parts),'SOCKETS',len(m.anchors),flush=True)
 all_sock=[s for m in models for s in m.anchors]
 assert len(models)==15
 assert len(all_sock)==len(set(all_sock))==32,(len(all_sock),all_sock)
 wired=set()
 for _,a,b,_ in WIRES:wired.add(a);wired.add(b)
 assert len(WIRES)==19 and wired==set(all_sock),(len(wired),set(all_sock)^wired)
 assert set(POS)=={m.key for m in models}
 showcase='Level51_Complete_ArtKit_Showcase'
 export_fbx(MOD/(showcase+'.fbx'),models,positions=POS)
 export_glb(MOD/(showcase+'.glb'),models,positions=POS)
 assert len(trimesh.load_scene(MOD/(showcase+'.glb')).geometry)>0
 manifest={m.key:{'fbx':m.key+'.fbx','glb':m.key+'.glb','triangle_count':sum(len(p.mesh.faces) for p in m.parts),'part_count':len(m.parts),'local_socket_anchors':m.anchors,'animation_pivots':m.group_pivots} for m in models}
 total=sum(v['triangle_count'] for v in manifest.values())
 blob={'level':51,'name':'Predict the Failure','theme':'Predictive Maintenance / Motor Diagnostic Laboratory',
       'scope':'VISUAL ASSETS ONLY — does not implement solver/level gameplay',
       'model_count':15,'art_socket_count':32,'player_wires':19,'triangles':total,
       'assembled_fbx':showcase+'.fbx','parts':manifest,'showcase_positions':POS,'wires':WIRES,
       'coordinate_system':'Y up; front -Z; project-relative units; scale and align in Unity',
       'assembly_note':'Assembly is an art arrangement. Anchor points are on model faces, not validated breadboard holes.',
       'electrical_note':'W01–W19 are design connections; digital signals need valid Project Spark binding/signal integration'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(blob,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','SocketID','LocalX','LocalY','LocalZ','Note'])
  for m in models:
   for s,xyz in m.anchors.items():w.writerow([m.key+'.fbx',s,*xyz,'Visual socket; snap real SparkTerminal separately'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','SocketID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for s,xyz in m.anchors.items():w.writerow([m.key+'.fbx',s,*[round(a+b,4) for a,b in zip(xyz,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','GroupName','PivotX','PivotY','PivotZ','DriveFrom'])
  for m in models:
   for g,xyz in m.group_pivots.items():w.writerow([m.key+'.fbx',g,*xyz,'Authoritative mechanical/interaction state, visual only'])
 (ROOT/'VALIDATION.txt').write_text(f'LEVEL 51 — PREDICT THE FAILURE\n15 individual FBXs + 15 individual GLBs; 1 assembled FBX + GLB.\n{total:,} total triangles. 19 exact connections / 32 socket anchors.\nAll FBX binary headers and GLB decodes checked; all wiring socket IDs validated.\nUnity import, material setup, physical component and evaluator integration NOT TESTED.\n')
 print('SUCCESS',total,'triangles','15 models','32 sockets','19 wires',flush=True)
 return models

if __name__=='__main__':build()
