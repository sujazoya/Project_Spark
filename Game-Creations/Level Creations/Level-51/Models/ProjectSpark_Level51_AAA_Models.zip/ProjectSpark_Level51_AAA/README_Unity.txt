PROJECT SPARK — LEVEL 51 "PREDICT THE FAILURE"
AAA-INSPIRED SEMI-HD FBX 7.4 / GLB VISUAL MODEL PACK
========================================================

CONTENTS
  Models/                15 individual FBX + 15 GLB backup files
                         1 complete assembled FBX + 1 complete GLB
  Previews/              Actual rendered exported geometry; assembly, closeups,
                         all-model contact sheet, 15 individual model images
  Sources/               Python generator and Autodesk FBX 7.4 binary writer
  Unity_Optional/        SparkLevel51VisualRig.cs (VISUAL ONLY)
  Exact_Wiring.csv       19 required conceptual connections
  Terminal_Anchors.csv   32 unique art socket IDs, LOCAL model coordinates
  World_Terminal_Anchors.csv    32 showcase positions
  Animation_Rigs.csv     Per-FBX named animated mesh groups and pivots
  Model_Manifest.json    Full asset metadata, model placement and anchor map
  VALIDATION.txt         Scope and verification summary

IMPORTANT — WHAT IS IMPLEMENTED
These are 3D geometry FBXs, not a compiled Unity gameplay level. The models have
colored mesh material regions; final URP/HDRP material and shader choices belong
in your Unity project. NO SparkElectricalComponent, SparkTerminal, circuits,
objectives, temperature/vibration/RPM simulation, or repair logic is provided by
this model pack. Existing game systems must own those values and outcomes.

IMPORT
1. Extract the ZIP and copy Models/*.fbx into Assets/My_Assets/_Project_Spark/
   Models/Level51/ (adjust folder to your game's existing conventions).
2. Use each of the 15 individual FBXs as a child of Level_51_Layout.
   Complete showcase FBX = placement reference, not the playable single prefab.
3. Unity Model Importer: retain model hierarchy, calculate normals as needed,
   keep Scale Factor consistent with your workbench. All geometry is Y-up.
4. Match showcase positions using Model_Manifest.json showcase_positions.
   The CSV/manifest coordinates are ART COORDINATES, not guaranteed breadboard
   hole positions. Snap actual SparkTerminal objects to existing hole centers.
5. Assign existing electronic prefabs, signal handlers, electrical components,
   and objective tracker using actual project APIs; do NOT attach duplicates to
   visual-only mesh components.
6. Material names / face colors transfer differently across Unity importers.
   Create/assign suitable lit metal, rubber, cyan/amber emission, safety-glass,
   and screen materials. Treat preview as reference for final art-direction.
7. For dynamic screens, add correctly oriented TextMeshPro text or a render
   texture to the display faces. Screen graph bars are embossed STATIC motifs;
   use real sensor readings for new live graphical overlays.

SCENE ARRANGEMENT
Back row: health monitor + vibration & temperature sensor docks + bearing service.
Middle: guarded motor test cell, precision rotor, bearing, A/B optical encoder.
Front row: supply, PWM driver, four-wire shunt and health controller. Balance
weight tray and healthy/worn cartridge station stay near the service area.
Every wireable module exposes an art socket; see the terminal CSVs.

19 PLAYER CONNECTIONS / 32 UNIQUE TERMINAL ART ANCHORS
  W01 Supply +5V -> Controller +5V
  W02 Supply RETURN -> Controller GND
  W03 Supply +5V -> Motor Driver +5V
  W04 Supply RETURN -> Motor Driver GND
  W05 Controller PWM OUT -> Driver PWM IN
  W06 Driver MOTOR+ -> Current Shunt IN
  W07 Current Shunt OUT -> Motor +
  W08 Driver MOTOR- -> Motor -
  W09 Supply +5V -> Vibration Sensor +5V
  W10 Supply RETURN -> Vibration Sensor GND
  W11 Vibration Sensor OUT -> Controller VIB IN
  W12 Supply +5V -> Temperature Sensor +5V
  W13 Supply RETURN -> Temperature Sensor GND
  W14 Temperature Sensor OUT -> Controller TEMP IN
  W15 Shunt SENSE+ -> Controller CURRENT+
  W16 Shunt SENSE- -> Controller CURRENT-
  W17 Encoder A -> Controller ENC A
  W18 Encoder B -> Controller ENC B
  W19 Safety Guard NC OUT -> Controller SAFETY IN
Supply + and RETURN each accept 4 wires. 38 connection endpoints minus 6
reused supply endpoints = 32 distinct socket objects.

ANIMATION GROUPS (FBX transforms)
  MOTOR_SHAFT_ROTATE_X                  MOTOR shaft
  DIAGNOSTIC_ROTOR_ROTATE_X             rotor and engraved 80 index marks
  ECCENTRIC_TEST_WEIGHT_DETACH          rotor mounted balance weight
  SERVICE_BEARING_CARTRIDGE_REMOVABLE   cartridge in main bearing fixture
  ENCODER_DISC_ROTATE_X                 80-count optical wheel
  SERVICE_BEARING_HEALTHY_PICKUP        healthy spare in service tray
  SERVICE_BEARING_WORN_PICKUP           worn spare in service tray
  FRONT_SAFETY_DOOR_HINGE_Y             transparent safety door
  WEIGHT_00_PICKUP ... WEIGHT_09_PICKUP balance weight storage
  CONDITION_SCREEN_FACE                screen overlay target
  CTRL_BUTTON_*                        separate controller controls
Most indicator lamps and socket groups also have dedicated named transforms.
Use Animation_Rigs.csv for exact source group names and local pivot XYZ.

OPTIONAL VISUAL SCRIPT
Add Unity_Optional/SparkLevel51VisualRig.cs to your project. It is a small,
level-local adapter that expects real measured RPMs and fault states from your
own gameplay controller. Drag imported FBX animation transforms into its
Inspector. It DOES NOT generate encoder counts, simulate electrical readings,
detect a worn bearing, repair an item, or complete the level.

SUGGESTED LEVEL 51 PLAY SEQUENCE
  1/6 Connect real motor/driver/shunt/sensor/encoder/safety circuit.
  2/6 Observe a 45 RPM healthy baseline.
  3/6 Diagnose eccentric rotor mass from the simulated vibration signature.
  4/6 Diagnose worn bearing using actual mechanical friction/current/heat.
  5/6 Make a predictive service stop before an unsafe failure.
  6/6 Replace the bearing, balance rotor, and certify renewed safe operation.
Do not award historical objectives by setting fake meter readings or aliases.
Integrate stateful targets with SparkLevelEvaluator/LevelGamePlayManager as
supported by the actual installed codebase. No Level_51.asset is included here.

ASSET SPECIFICATION
15 individual FBXs, one assembled FBX, matching GLB files.
32 modeled sockets and exactly 19 wiring manifest records.
Triangle and part counts are in Model_Manifest.json.

KNOWN LIMITATIONS
- Geometry-only kit; Unity import/shaders/collision/physics not test-run.
- Transparent safety-glass rendering depends on Unity transparent shader.
- No actual FBX skeletal rig: distinct movable transforms have correct pivots.
- Model units must be scaled to the existing Project Spark breadboard scene.
- Reference layout is not a preconnected electrical circuit.
