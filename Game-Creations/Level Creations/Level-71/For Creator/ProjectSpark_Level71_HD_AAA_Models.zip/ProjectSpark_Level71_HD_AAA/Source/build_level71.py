import os,math,csv,json,time,struct,zlib,zipfile,random
from pathlib import Path
from collections import Counter
import numpy as np
import trimesh
from PIL import Image,ImageDraw,ImageFont
ROOT=Path('/mnt/data/ProjectSpark_Level71_HD_AAA')
MD=ROOT/'Models';GD=ROOT/'GLB';PD=ROOT/'Previews';ED=ROOT/'Unity_Optional';SRC=ROOT/'Source'
for d in (MD,GD,PD,ED,SRC):d.mkdir(parents=True,exist_ok=True)
names=['IndustrialPlasmaFabricationBase', 'TransparentPlasmaEtchReactor', 'ReactorServiceLid', 'QuartzPlasmaObservationViewport', 'InductivelyCoupledRFCoil', 'PrecisionGasDistributionShowerhead', 'WaferBiasElectrode', 'ElectrostaticWaferChuck', 'PrecisionWaferLiftAssembly', 'SiliconWafer', 'WaferThinFilmLayer', 'PatternedWaferMask', 'WaferCarrierCassette', 'VacuumLoadLockChamber', 'LoadLockGateValve', 'AutomatedWaferTransferRobot', 'TurbomolecularVacuumPump', 'VacuumBackingPump', 'IndustrialVacuumForeline', 'VacuumIsolationValve', 'AutomaticVacuumThrottleValve', 'CapacitancePressureManometer', 'RoughVacuumPressureGauge', 'HighVacuumPressureGauge', 'ResidualGasAnalyzer', 'VirtualProcessGasSupplyA', 'VirtualProcessGasSupplyB', 'MassFlowControllerA', 'MassFlowControllerB', 'VacuumGasMixingManifold', 'HighFrequencyRFGenerator', 'AutomaticRFMatchingNetwork', 'RFVariableCapacitorA', 'RFVariableCapacitorB', 'ForwardReflectedPowerCoupler', 'RFVoltageCurrentSensor', 'RFArcProtectionModule', 'WaferTemperatureController', 'PrecisionWaferChiller', 'EmergencyPlasmaSafetyStation', 'OpticalEmissionSpectrometer', 'OpticalFiberViewportModule', 'AutomaticEtchEndpointController', 'PlasmaUniformityAnalyzer', 'ThinFilmThicknessMetrology', 'VacuumPressurePIDController', 'PlasmaProcessPLCRack', 'PlasmaDigitalIOModule', 'HolographicPlasmaSCADAMonitor', 'Regulated5VControlSupply']
P={'navy':(14,32,52,255),'steel':(66,101,126,255),'light':(139,177,195,255),'silver':(181,199,208,255),'dark':(27,50,69,255),'black':(13,21,30,255),'cyan':(37,211,246,255),'blue':(20,112,218,255),'ice':(133,224,245,255),'copper':(220,120,52,255),'amber':(248,162,45,255),'red':(226,63,70,255),'green':(47,219,139,255),'white':(220,238,248,255),'glass':(93,178,212,135),'frost':(205,235,247,255),'rubber':(34,38,42,255),'gold':(224,176,68,255)}
P.update({'violet':(172,81,244,255),'plasma':(186,73,247,180),'purpleglass':(138,77,211,128),'teal':(66,213,199,255),'ceramic':(230,225,220,255),'iridescent':(106,200,242,255),'warning':(255,105,71,255)})
M={}
def addmesh(k,m,c):
 if m is None or len(m.faces)==0:return
 if k not in M:M[k]=[]
 m.visual.vertex_colors=np.tile(P[c],(len(m.vertices),1))
 M[k].append((m,c))
def box(k,xyz,ext,c,rot=None):
 m=trimesh.creation.box(extents=ext)
 if rot is not None:m.apply_transform(rot)
 m.apply_translation(xyz);addmesh(k,m,c)
def cyl(k,center,r,length,c,axis='z',sec=16):
 m=trimesh.creation.cylinder(radius=r,height=length,sections=sec)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 m.apply_translation(center);addmesh(k,m,c)
def pipe(k,pts,r=.045,c='copper',sec=10):
 for p,q in zip(pts[:-1],pts[1:]):
  p=np.asarray(p,float);q=np.asarray(q,float);v=q-p;L=np.linalg.norm(v)
  if L<1e-5:continue
  m=trimesh.creation.cylinder(radius=r,height=L,sections=sec);tf=trimesh.geometry.align_vectors([0,0,1],v/L);m.apply_transform(tf);m.apply_translation((p+q)/2);addmesh(k,m,c)
 for p in pts[1:-1]:
  m=trimesh.creation.icosphere(subdivisions=1,radius=r);m.apply_translation(p);addmesh(k,m,c)
def ring(k,center,r,inner,depth,axis='z',c='silver',sec=20):
 # ring as thin tube / annulus mesh
 verts=[];faces=[]
 for z in (-depth/2,depth/2):
  for rad in (r,inner):
   for i in range(sec):
    a=2*math.pi*i/sec;verts.append((rad*math.cos(a),rad*math.sin(a),z))
 for layer in range(4):
  for i in range(sec):
   j=(i+1)%sec; layer2={0:2,1:3,2:3,3:0}[layer]
   a=layer*sec+i;b=layer*sec+j;d=layer2*sec+i;e=layer2*sec+j
   faces.extend(((a,b,d),(b,e,d)))
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
 if axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
 if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]))
 m.apply_translation(center);addmesh(k,m,c)
def screen(k,xyz,w=.58,h=.32,c='blue'):
 box(k,xyz,(w,h,.065),'black');box(k,(xyz[0],xyz[1],xyz[2]+.039),(w*.88,h*.80,.01),c)
 for i in range(5): box(k,(xyz[0]-w*.32+i*w*.16,xyz[1]-h*.20+((i*7)%4)*h*.11,xyz[2]+.05),(.035,.017,.012),'cyan')
def knob(k,x,y,z,c='cyan'):
 cyl(k,(x,y,z),.045,.045,'silver');cyl(k,(x,y,z+.03),.025,.025,c)
def panel(k,center,ex=(.70,.60,.45),label='generic'):
 x,y,z=center;box(k,center,ex,'steel');box(k,(x,y,z+ex[2]/2+.01),(.84*ex[0],.77*ex[1],.015),'dark');screen(k,(x,y+.09,z+ex[2]/2+.05),ex[0]*.60,ex[1]*.34)
 for j in range(3):knob(k,x-.22+j*.21,y-ex[1]*.26,z+ex[2]/2+.035,('green','amber','red')[j])
 for j in range(5):box(k,(x-ex[0]*.36+j*ex[0]*.18,y+ex[1]*.34,z),(.05,.09,.07),'silver')
def fan(k,center,r=.38,axis='z'):
 x,y,z=center
 cyl(k,center,r*.75,.12,'dark',axis,24);ring(k,center,r,r*.88,.10,axis,'silver',24)
 # radial blades in plane XY for z; xz for y
 for i in range(7):
  a=i*2*math.pi/7
  if axis=='z':p=(x+.46*r*math.cos(a),y+.46*r*math.sin(a),z+.08);ang=a
  else:p=(x+.46*r*math.cos(a),y,z+.46*r*math.sin(a));ang=a
  m=trimesh.creation.box(extents=(r*.61,r*.16,.035))
  if axis=='z':m.apply_transform(trimesh.transformations.rotation_matrix(ang,[0,0,1]))
  else:m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]));m.apply_transform(trimesh.transformations.rotation_matrix(ang,[0,1,0]))
  m.apply_translation(p);addmesh(k,m,'light')
 cyl(k,center,r*.14,.18,'steel',axis)
def motor(k,xyz,scale=1):
 x,y,z=xyz
 cyl(k,(x,y,z),.46*scale,1.3*scale,'blue','x',24)
 for t in np.linspace(-.53,.53,11):ring(k,(x+t*scale,y,z),.48*scale,.455*scale,.045*scale,'x','steel',20)
 cyl(k,(x+.77*scale,y,z),.105*scale,.35*scale,'silver','x');cyl(k,(x-.76*scale,y,z),.38*scale,.09*scale,'dark','x')
 box(k,(x,y-.46*scale,z),(1.25*scale,.18*scale,.66*scale),'steel')
 box(k,(x,y+.50*scale,z),(.46*scale,.19*scale,.44*scale),'dark')
def compressor(k):
 x,y,z=(.25,1.27,.55)
 box(k,(x,y-.56,z),(3.0,.20,1.60),'steel')
 motor(k,(-.55,y,z),1.0)
 cyl(k,(1.10,y,z),.59,1.30,'blue','x',24)
 for t in np.linspace(.58,1.56,8):ring(k,(t,y,z),.61,.58,.075,'x','steel',24)
 cyl(k,(1.82,y,z),.40,.25,'dark','x')
 cyl(k,(1.2,y+.67,z),.20,.9,'silver','y')
 pipe(k,[(1.2,y+.74,z),(1.2,2.36,z),(.4,2.36,z)],.085,'copper')
 for i in range(5):box(k,(1.18+i*.09,1.26,z+.63),(.038,.17,.035),'amber')
def cooling_chamber(k,cx,cy,cz= -1.5,hot=False):
 # roomy 2.5x2x1.7 internal, glass front toward +z
 x,y,z=cx,cy,cz
 box(k,(x,y-.95,z),(2.65,.12,2.0),'steel')
 for dx in (-1.28,1.28):
  for dz in (-.96,.96):box(k,(x+dx,y,z+dz),(.09,1.95,.08),'silver')
 for yy in (-.89,.93):
  for dz in (-.96,.96):box(k,(x,y+yy,z+dz),(2.55,.07,.08),'silver')
 for yy in (-.89,.93):
  for dx in (-1.28,1.28):box(k,(x+dx,y+yy,z),(.08,.07,1.9),'silver')
 box(k,(x,y,z-.94),(2.4,1.74,.028),'ice')
 box(k,(x,y,z+.96),(2.45,1.7,.018),'glass')
 box(k,(x,y+.97,z),(2.68,.1,2.04),'steel')
 for xx in (-.76,.76):fan(k,(x+xx,y+.48,z-.76),.34)
 for i in range(3):
  box(k,(x,y-.70+i*.51,z-.20),(2.0,.046,.80),'silver')
  for j in range(4):box(k,(x-.75+j*.50,y-.54+i*.51,z-.15),(.33,.24,.32),'white' if not hot else 'ice')
 for i in range(2):box(k,(x-1.16+i*2.32,y,z+.99),(.07,1.72,.04),'steel')
 for i in range(5):box(k,(x-1.1+i*.54,y-.82,z+1.04),(.35,.035,.035),'cyan')

# LEVEL 70 custom modular cleanroom machinery: authored physical assembly in meters.
# The same scene-space coordinates are used for every individual model.

def rbox(k,c,e,col='steel',radius=.04):
    x,y,z=c; X,Y,Z=e
    box(k,c,e,col)
    # thin silver corner/edge strips give each cabinet mechanical definition
    for yy in (-Y/2+.035,Y/2-.035):
        for zz in (-Z/2+.035,Z/2-.035): box(k,(x,y+yy,z+zz),(X+.018,.025,.025),'silver')
    for xx in (-X/2+.035,X/2-.035):
        for zz in (-Z/2+.035,Z/2-.035): box(k,(x+xx,y,z+zz),(.025,Y+.018,.025),'silver')

def frame(k,center,ext,beam=.075,glass=True,glass_front=True):
    x,y,z=center;dx,dy,dz=ext
    for ax in (-1,1):
        for az in (-1,1):box(k,(x+ax*(dx-beam)/2,y,z+az*(dz-beam)/2),(beam,dy,beam),'silver')
    for ay in (-1,1):
        for az in (-1,1):box(k,(x,y+ay*(dy-beam)/2,z+az*(dz-beam)/2),(dx,beam,beam),'silver')
        for ax in (-1,1):box(k,(x+ax*(dx-beam)/2,y+ay*(dy-beam)/2,z),(beam,beam,dz),'silver')
    if glass:
        box(k,(x,y,z-dz/2+.04),(dx-.15,dy-.15,.021),'glass')
        if glass_front:box(k,(x,y,z+dz/2-.04),(dx-.15,dy-.15,.021),'glass')
        for ax in (-1,1):box(k,(x+ax*(dx/2-.055),y,z),(.021,dy-.15,dz-.15),'glass')

def grille(k,center,ext,axis='z',n=18):
    x,y,z=center;w,h,d=ext
    box(k,center,ext,'dark')
    for i in range(n):
        yy=y-h*.44+(i+.5)*h*.88/n
        box(k,(x,yy,z+d/2+.014),(w*.91,h*.45/n,.028),'silver')
    for xx in (x-w*.47,x+w*.47):box(k,(xx,y,z+d/2+.028),(.035,h,.035),'light')

def duct(k,pts,r=.13,cc='steel'):
    pipe(k,pts,r,cc,16)
    # couplings/flanges at endpoints
    for p in [pts[0],pts[-1]]:cyl(k,p,r*1.32,r*.23,'silver',axis='y',sec=18)

def compact_screen(k,center,w=.62,h=.37,c='blue'):
    box(k,center,(w,h,.075),'dark')
    box(k,(center[0],center[1],center[2]+.042),(w*.88,h*.8,.012),c)
    for j in range(5):box(k,(center[0]-w*.33+j*w*.17,center[1]-.08+((j*3)%5)*.035,center[2]+.055),(w*.07,.015,.012),'cyan')

def multisensor(k,x,y,z,kind='pressure',size=.26):
    rbox(k,(x,y,z),(size*1.8,size*1.3,size*.64),'steel')
    compact_screen(k,(x,y,z+size*.36),size*1.35,size*.75,'cyan' if kind!='particle' else 'green')
    for j,c in enumerate(('green','amber','red')):knob(k,x-size*.55+j*size*.55,y-size*.45,z+size*.38,c)
    cyl(k,(x,y-size*.74,z),size*.16,size*.46,'silver','y')
    duct(k,[(x-.12,y-size*.80,z),(x-.22,y-size*1.2,z)],.016,'copper')

def filter_pleats(k,x,y,z,w,h,depth=.16,n=29,filtercol='white'):
    box(k,(x,y,z),(w+.1,h+.1,depth+.06),'steel')
    box(k,(x,y,z+depth*.51),(w,h,.036),'dark')
    for i in range(n):
        px=x-w*.485+(i+.5)*(w*.97/n)
        box(k,(px,y,z+depth*.56+.026),(w*.66/n,h*.89,.028),filtercol if i%4 else 'light')
    for xx in (x-w*.49,x+w*.49):box(k,(xx,y,z+depth*.60+.04),(.025,h,.038),'silver')

def coil(k,x,y,z,w,h,heat=False):
    # dense fin pack + sinuous metal capillaries + perimeter frame
    box(k,(x,y,z),(w+.10,h+.13,.16),'dark')
    for i in range(43):
        px=x-w*.48+i*w*.96/42
        box(k,(px,y,z+.095),(.017,h*.9,.055),'copper' if heat and i%5==0 else 'light')
    for j in range(8):
        yy=y-h*.43+j*h*.86/7
        pipe(k,[(x-w*.52,yy,z+.16),(x+w*.52,yy,z+.16)],.023,'copper' if heat else 'blue',12)
    for px in (x-w*.55,x+w*.55):box(k,(px,y,z+.10),(.063,h+.14,.083),'steel')
    for py in (y-h*.55,y+h*.55):box(k,(x,py,z+.10),(w+.13,.052,.084),'steel')

def airfan(k,center,r=.43,axis='z',c='blue'):
    x,y,z=center
    fan(k,center,r,axis)
    for ax in (-1,1):
        for ay in (-1,1):box(k,(x+ax*r*.83,y+ay*r*.83,z),(.055,.055,.13),'silver')
    # protective fan grille with straight wire bars
    for n in range(-4,5):
        if axis=='z':box(k,(x+n*r/5,y,z+.09),(.013,1.79*r,.018),'light')

def concrete(k,center,e):
    box(k,center,e,'steel')
    for i in range(5):box(k,(center[0]-e[0]/2+.2+i*(e[0]-.4)/4,center[1]+e[1]/2+.014,center[2]),(.075,.028,e[2]*.90),'light')

# --------------------------------------------------------------
# ==============================================================
# PROJECT SPARK LEVEL 71 — ETCH THE FUTURE
# Original, modular, scene-aligned 3-D semiconductor equipment.
# Full geometry in meters; FBX exporter serializes centimeter coords.
# ==============================================================

def mechbox(k,p,ext,col='steel'):
    box(k,p,ext,col)
    x,y,z=p;X,Y,Z=ext
    for xx in (x-X*.48,x+X*.48):
        for zz in (z-Z*.45,z+Z*.45):box(k,(xx,y+Y*.49,zz),(.032,.021,.034),'light')
    for a in (-1,1):box(k,(x+a*X*.47,y,z+Z*.506),(.021,Y*.86,.024),'silver')

def controlbox(k,p,ext=(.72,.56,.50),color='steel',monitor='violet',knobs=4):
    mechbox(k,p,ext,color)
    x,y,z=p;w,h,d=ext
    box(k,(x,y+.10*h,z+.515*d),(.83*w,.52*h,.035),'black')
    box(k,(x,y+.10*h,z+.536*d),(.74*w,.44*h,.01),monitor)
    for i in range(8):box(k,(x-.30*w+i*.085*w,y+.03*h+((i*3)%5)*.054*h,z+.556*d),(.048*w,.02*h,.015),'cyan')
    for i in range(knobs):knob(k,x-.33*w+i*.66*w/max(1,knobs-1),y-.29*h,z+.54*d,['green','amber','red','cyan'][i%4])
    for j in range(3):box(k,(x-w*.38+j*.25*w,y+h*.515,z),(.065,.055,.08),'silver')

def vacflange(k,center,r,depth=.11,axis='x',count=12):
    ring(k,center,r,r*.78,depth,axis,'silver',32)
    x,y,z=center
    for i in range(count):
        a=2*math.pi*i/count
        if axis=='x':v=(x,y+r*.89*math.cos(a),z+r*.89*math.sin(a))
        elif axis=='y':v=(x+r*.89*math.cos(a),y,z+r*.89*math.sin(a))
        else:v=(x+r*.89*math.cos(a),y+r*.89*math.sin(a),z)
        cyl(k,v,.036,.035,'dark',axis,8)

def precision_ring(k,c,outer,inner,depth,axis='y',color='silver'):
    ring(k,c,outer,inner,depth,axis,color,32)
    ring(k,c,outer*.90,outer*.86,depth*1.04,axis,'dark',32)

def waferdisc(k,center,r=.58,thick=.035,color='iridescent',grids=True):
    x,y,z=center
    cyl(k,center,r,thick,color,'y',48)
    ring(k,(x,y+thick*.51,z),r*.995,r*.93,.009,'y','silver',48)
    if grids:
        for i in range(-7,8):
            u=i*r*.117
            span=math.sqrt(max(0,r*r-u*u))*.92
            box(k,(x+u,y+thick*.56,z),(min(.010,r*.025),.006,2*span),'cyan')
            box(k,(x,y+thick*.56,z+u),(2*span,.006,min(.010,r*.025)),'cyan')

def sscylinder(k,c,r,ln,axis='y',num=12):
    cyl(k,c,r,ln,'steel',axis,32)
    a={'x':0,'y':1,'z':2}[axis]
    for i in range(num):
        d=(i/(num-1)-.5)*ln*.86
        q=list(c);q[a]+=d
        ring(k,q,r*1.018,r*.98,.038,axis,'light',24)

def wirebundle(k,pts,num=3,sep=.025,col='cyan',r=.009):
    for i in range(num):
        shift=(i-(num-1)/2)*sep
        path=[(p[0]+shift,p[1],p[2]+shift*.5) for p in pts]
        pipe(k,path,r,col,8)

def giantdisplay(k,p,width=3.6,height=1.72):
    x,y,z=p
    box(k,(x,y,z),(width,height,.15),'navy')
    box(k,(x,y,z+.082),(width*.96,height*.90,.014),'black')
    box(k,(x-width*.27,y+.18,z+.100),(width*.37,height*.53,.012),'violet')
    box(k,(x+width*.22,y+.23,z+.100),(width*.34,height*.43,.012),'blue')
    for j in range(4):
        for i in range(12):
            yy=y-height*.28+j*.12+0.022*math.sin(i*.7+j)
            xx=x-width*.44+i*width*.079
            box(k,(xx,yy,z+.112),(.045,.013,.009),'cyan' if j%2 else 'teal')
    for xx in (-width*.46,width*.46):box(k,(x+xx,y,z+.11),(.025,height*.88,.022),'cyan')
    box(k,(x,y-height*.44,z+.11),(width*.89,.025,.022),'cyan')
    box(k,(x,y-height*.58,z-.09),(.12,.43,.18),'silver')

# 00 — large premium industrial fabrication platform, 16x9m.
k=names[0]
box(k,(0,-.31,0),(15.80,.52,8.70),'navy')
box(k,(0,-.034,0),(15.52,.055,8.40),'steel')
for zz in (-4.12,4.12):box(k,(0,.012,zz),(15.40,.058,.090),'cyan')
for xx in (-7.66,7.66):box(k,(xx,.012,0),(.090,.058,8.26),'cyan')
for xx in np.arange(-7.35,7.36,.32):
    box(k,(xx,-.015,4.0),(.16,.012,.025),'amber' if int(abs(xx*7))%7==0 else 'cyan')
for xx in (-7.25,7.25):
    for zz in (-3.7,3.7):cyl(k,(xx,-.62,zz),.20,.18,'dark','y',16)
for xx in np.arange(-6.9,7.0,1.15):box(k,(xx,-.046,-3.94),(.20,.020,.10),'black')
for i in range(44):box(k,(-.1,-.005,-3.7+i*.17),(7.8,.009,.025),'dark')
box(k,(0,-.09,4.14),(8.2,.055,.16),'black')
for i in range(54):
    x=-7.0+i*.26
    cyl(k,(x,.016,4.06),.027,.02,['green','cyan','blue','amber'][i%4],'y',10)

# 01 — central hero vacuum plasma reactor: bolted circular cutaway and steel pedestal.
k=names[1]
rx,ry,rz=(0,2.02,-.90)
mechbox(k,(0,.63,-.90),(3.12,.83,2.70),'steel')
box(k,(0,1.10,-.90),(2.35,.12,2.15),'silver')
for zz in (-1.88,-1.45,.10,.35):
    vacflange(k,(0,ry,zz),1.23,.11,'z',20)
for zz in (-1.72,-1.50):precision_ring(k,(0,ry,zz),1.055,.975,.12,'z','steel')
for angle in np.linspace(0,2*math.pi,20,endpoint=False):
    xx=1.08*math.cos(angle);yy=ry+1.08*math.sin(angle)
    pipe(k,[(xx,yy,-1.73),(xx,yy,.13)],.045,'light',10)
for side in (-1,1):
    box(k,(side*1.36,ry,-.88),(.22,1.45,1.95),'dark')
    for yy in (1.45,2.05,2.70):box(k,(side*1.51,yy,-.86),(.055,.13,1.75),'silver')
for xx in (-.75,.75):box(k,(xx,.80,.43),(.18,.25,.10),'amber')
pipe(k,[(1.23,2.06,-1.03),(1.92,2.06,-1.03),(1.92,1.80,-.75)],.11,'steel')
pipe(k,[(-1.20,2.35,-1.12),(-1.92,2.35,-1.12),(-1.92,3.15,-1.12)],.08,'copper')
for z in (-1.97,.36):
    for x in (-1.01,1.01):box(k,(x,1.04,z),(.09,.35,.17),'dark')

# 02 — removable service lid with rails and interlocks.
k=names[2]
box(k,(0,3.35,-.90),(2.78,.20,2.18),'steel')
for x in (-1.12,1.12):
    for z in (-1.76,-.04):cyl(k,(x,3.45,z),.085,.14,'silver','y',14)
for x in np.linspace(-1.0,1.0,8):box(k,(x,3.482,-.95),(.055,.028,1.68),'light')
box(k,(-1.34,3.35,-.90),(.14,.28,2.12),'dark')
for z in (-1.70,-.09):cyl(k,(-1.36,3.40,z),.13,.19,'silver','z',16)
box(k,(1.15,3.51,-.10),(.22,.08,.22),'red')

# 03 — wide quartz front window with individually framed transparent glass.
k=names[3]
box(k,(0,2.03,.40),(2.13,1.68,.028),'glass')
for x in (-1.09,1.09):box(k,(x,2.03,.43),(.077,1.79,.10),'silver')
for y in (1.16,2.90):box(k,(0,y,.43),(2.25,.075,.10),'silver')
for x in np.linspace(-.97,.97,8):
    for y in (1.17,2.89):cyl(k,(x,y,.49),.023,.05,'dark','z',8)
for zz in (.42,.46):box(k,(0,2.03,zz),(2.06,1.61,.01),'purpleglass')

# 04 — vivid copper helical inductively coupled RF coil, continuous 3D path.
k=names[4]
coilpts=[]
for t in np.linspace(0,2*math.pi*8,270):
    coilpts.append((.83*math.cos(t),3.59+.054*(t/(2*math.pi)), -.92+.83*math.sin(t)))
pipe(k,coilpts,.045,'copper',10)
for i in range(8):
    a=i*math.pi/4
    cyl(k,(.91*math.cos(a),3.78,-.92+.91*math.sin(a)),.085,.23,'ceramic','y',12)
pipe(k,[(.87,4.08,-.90),(1.88,4.08,-.90),(1.88,3.18,-1.50)],.075,'copper',16)
pipe(k,[(-.83,3.59,-.87),(-1.80,3.59,-.87),(-1.80,3.00,-1.58)],.075,'copper',16)

# 05 — precision metal showerhead and dense gas-injection perforations.
k=names[5]
cyl(k,(0,3.16,-.90),.84,.11,'silver','y',48)
ring(k,(0,3.105,-.9),.86,.78,.025,'y','dark',40)
for x in np.linspace(-.66,.66,11):
    for z in np.linspace(-1.56,-.24,11):
        if x*x+(z+.90)**2 < .66**2:cyl(k,(x,3.093,z),.014,.014,'dark','y',8)
pipe(k,[(0,3.23,-.90),(0,3.48,-.90),(-1.47,3.48,-.9)],.075,'silver',12)

# 06 — RF wafer bias electrode.
k=names[6]
cyl(k,(0,1.42,-.90),.70,.15,'steel','y',36)
ring(k,(0,1.50,-.90),.72,.64,.040,'y','copper',36)
for i in range(14):
    a=2*math.pi*i/14
    box(k,(.59*math.cos(a),1.505,-.9+.59*math.sin(a)),(.067,.018,.061),'dark')
pipe(k,[(0,1.42,-1.08),(0,1.15,-1.08),(1.10,1.15,-1.08)],.070,'copper')

# 07 — electrostatic chuck: ceramic face + clamp grooves.
k=names[7]
cyl(k,(0,1.555,-.90),.615,.15,'dark','y',40)
cyl(k,(0,1.640,-.90),.587,.027,'ceramic','y',40)
for r in (.25,.40,.51):ring(k,(0,1.657,-.90),r,r-.018,.007,'y','silver',36)
for a in np.linspace(0,2*math.pi,16,endpoint=False):
    cyl(k,(.54*math.cos(a),1.663,-.90+.54*math.sin(a)),.021,.017,'copper','y',8)

# 08 — wafer lift shafts, lift-pins, guide columns.
k=names[8]
for a in np.linspace(0,2*math.pi,3,endpoint=False):
    x=.40*math.cos(a);z=-.9+.40*math.sin(a)
    cyl(k,(x,1.37,z),.043,.48,'silver','y',12)
    cyl(k,(x,1.64,z),.071,.065,'ceramic','y',12)
box(k,(0,1.12,-.9),(1.30,.13,1.25),'steel')
for x in (-.49,.49):cyl(k,(x,1.12,-.90),.075,.32,'dark','y',12)

# 09 — central silicon wafer with precise micro-grid visual geometry.
k=names[9]
waferdisc(k,(0,1.75,-.90),.54,.024,'iridescent',True)
for a in np.linspace(0,2*math.pi,16,endpoint=False):
    if a>5.8:continue
    cyl(k,(.51*math.cos(a),1.768,-.90+.51*math.sin(a)),.013,.009,'violet','y',8)

# 10 — target material film, physical thin layer with radial assay bands.
k=names[10]
cyl(k,(0,1.778,-.90),.53,.019,'violet','y',48)
for r in (.13,.24,.36,.46):ring(k,(0,1.792,-.90),r,r-.012,.006,'y','teal',40)
for a in np.linspace(0,2*math.pi,10,endpoint=False):
    cyl(k,(.38*math.cos(a),1.795,-.90+.38*math.sin(a)),.026,.006,'plasma','y',10)

# 11 — patterned masking mesh: actual independent pattern geometry.
k=names[11]
for i in range(-7,8):
    for j in range(-7,8):
        x=i*.063;z=-.90+j*.063
        if x*x+(z+.90)**2 < .49**2:
            if (i+j)%4!=0:box(k,(x,1.797,z),(.041,.009,.040),'gold' if (i-j)%3==0 else 'dark')

# 12 — wafer cassette: 15 rack slots and fragile visible wafer slices.
k=names[12]
mechbox(k,(-6.43,.57,-.92),(1.44,.17,1.32),'steel')
for x in (-7.05,-5.81):
    for z in (-1.48,-.37):box(k,(x,1.49,z),(.07,1.75,.08),'silver')
for y in np.linspace(.70,2.35,15):
    box(k,(-6.43,y,-.92),(1.04,.023,1.04),'ceramic')
    cyl(k,(-6.43,y+.021,-.92),.45,.008,'iridescent','y',32)
box(k,(-6.43,2.41,-.92),(1.42,.10,1.32),'steel')
for x in (-6.95,-5.92):box(k,(x,1.52,.0),(.032,1.70,.07),'cyan')

# 13 — loadlock: sealed cuboid vessel with transparent access and thick vacuum flanges.
k=names[13]
mechbox(k,(-4.50,.72,-.85),(2.72,.20,2.50),'steel')
for x in (-5.79,-3.21):
    for z in (-1.96,.23):box(k,(x,1.73,z),(.13,1.95,.14),'silver')
for y in (.82,2.64):
    for z in (-1.96,.23):box(k,(-4.50,y,z),(2.62,.13,.11),'silver')
box(k,(-4.50,1.74,-1.95),(2.47,1.77,.024),'glass')
box(k,(-4.50,1.74,.23),(2.45,1.75,.028),'purpleglass')
box(k,(-4.50,2.71,-.85),(2.73,.19,2.52),'steel')
for x in (-5.55,-3.46):
    for z in (-1.89,.15):cyl(k,(x,2.81,z),.076,.10,'dark','y',12)
pipe(k,[(-4.74,2.70,-1.90),(-4.74,3.07,-1.90),(-3.43,3.07,-1.90)],.065,'steel')

# 14 — industrial inter-chamber gate valve, front face and sliding gate.
k=names[14]
mechbox(k,(-2.57,1.78,-.86),(.43,1.13,1.26),'silver')
box(k,(-2.55,1.80,-.21),(.35,.94,.055),'dark')
for y in (1.34,2.23):
    for z in (-1.46,-.27):cyl(k,(-2.34,y,z),.045,.07,'black','x',12)
box(k,(-2.56,2.56,-.86),(.44,.26,.43),'steel')
cyl(k,(-2.56,2.76,-.86),.09,.20,'copper','y',14)

# 15 — robot articulated links, tool and vacuum wafer blade.
k=names[15]
cx,cy,cz=(-4.51,1.05,-.76)
box(k,(cx,cy-.33,cz),(.82,.24,.76),'steel')
cyl(k,(cx,cy,cz),.32,.58,'blue','y',24)
cyl(k,(cx,cy+.39,cz),.19,.20,'silver','y',20)
pipe(k,[(cx,cy+.45,cz),(cx+.52,cy+1.08,cz)],.13,'steel',20)
cyl(k,(cx+.52,cy+1.08,cz),.22,.33,'dark','z',20)
pipe(k,[(cx+.55,cy+1.10,cz),(cx+1.34,cy+1.10,cz-.05)],.095,'blue',18)
cyl(k,(cx+1.33,cy+1.1,cz-.05),.18,.16,'steel','y',16)
box(k,(cx+1.67,cy+1.1,cz-.04),(.72,.055,.39),'silver')
for dz in (-.15,.15):box(k,(cx+1.77,cy+1.155,cz+dz),(.49,.025,.035),'cyan')
wirebundle(k,[(cx,cy+.35,cz-.32),(cx+.52,cy+.95,cz-.32),(cx+1.33,cy+.95,cz-.35)],4,.025,'copper')

# 16 — turbomolecular vacuum pump: dense radial metallic impeller and 18 ring stages.
k=names[16]
px,py,pz=(4.12,1.31,-1.07)
# Turbomolecular pump with ring-stage impeller elements, vacuum flange & backing port.
mechbox(k,(px,py-.64,pz),(2.10,.20,1.50),'steel')
cyl(k,(px,py,pz),.67,1.62,'steel','x',36)
for x in np.linspace(px-.68,px+.68,13):
    precision_ring(k,(x,py,pz),.67,.60,.050,'x','silver')
    for j in range(9):
        a=j*2*math.pi/9
        cy=py+.32*math.cos(a);cz=pz+.32*math.sin(a)
        b=trimesh.creation.box(extents=(.028,.43,.13))
        b.apply_transform(trimesh.transformations.rotation_matrix(a,[1,0,0]))
        b.apply_translation((x,cy,cz));addmesh(k,b,'light')
for x in (px-.92,px+.92):vacflange(k,(x,py,pz),.76,.12,'x',14)
cyl(k,(px,py+.75,pz),.21,.60,'silver','y',20)
for x in np.linspace(px-.62,px+.62,8):box(k,(x,py+.05,pz+.68),(.04,.11,.04),'cyan')

# 17 — vacuum backing pump, motor, oil level window, tube flanges.
k=names[17]
mechbox(k,(6.38,.55,-1.13),(2.0,.23,1.43),'steel')
motor(k,(6.00,1.22,-1.12),.68)
cyl(k,(6.93,1.23,-1.12),.54,.90,'steel','x',26)
for x in (6.57,6.91,7.25):precision_ring(k,(x,1.23,-1.12),.54,.48,.063,'x','silver')
cyl(k,(6.87,1.84,-1.12),.14,.70,'copper','y')
controlbox(k,(6.55,.91,-.35),(.43,.36,.19),'steel','blue',2)

# 18 — separate manifold foreline: actual 3-D pipe sections, tees and clamps.
k=names[18]
paths=[[(2.04,1.86,-1.20),(2.64,1.86,-1.20),(2.64,1.34,-1.20),(3.10,1.34,-1.20)],[(5.12,1.34,-1.20),(5.58,1.34,-1.20),(5.58,1.88,-2.10),(6.40,1.88,-2.10),(6.40,1.82,-1.12)],[(4.1,2.0,-1.07),(4.1,2.78,-1.07),(2.05,2.78,-1.07)]]
for path in paths:pipe(k,path,.105,'silver',16)
for path in paths:
    for point in (path[0],path[-1]):vacflange(k,point,.15,.063,'x',8)
for x in (3.1,4.9,5.4):
    box(k,(x,.38,-1.30),(.28,.28,.36),'dark');cyl(k,(x,.61,-1.30),.045,.24,'silver','y',10)

# 19 — isolation valve between pump and reactor.
k=names[19]
mechbox(k,(2.53,1.84,-1.20),(.41,.60,.69),'steel')
vacflange(k,(2.28,1.84,-1.20),.33,.08,'x',12)
vacflange(k,(2.78,1.84,-1.20),.33,.08,'x',12)
box(k,(2.53,2.30,-1.20),(.43,.20,.43),'dark')
cyl(k,(2.53,2.48,-1.20),.17,.20,'copper','y',18)
for a in np.linspace(0,2*math.pi,8,endpoint=False):box(k,(2.53+.13*math.cos(a),2.59,-1.20+.13*math.sin(a)),(.055,.036,.043),'amber')

# 20 — vacuum throttle butterfly valve with lever and angular gauge.
k=names[20]
mechbox(k,(2.18,1.82,-.71),(.33,.72,.58),'steel')
for x in (1.97,2.39):vacflange(k,(x,1.82,-.71),.37,.07,'x',12)
cyl(k,(2.18,2.32,-.71),.155,.22,'steel','y',16)
box(k,(2.18,2.47,-.71),(.40,.065,.075),'amber')
for i in range(6):
    cyl(k,(2.18,1.50+i*.13,-.32),.029,.035,'green' if i>2 else 'red','z',9)

# 21 — capacitance manometer, pipe stem, illuminated digital readout.
k=names[21]
controlbox(k,(2.25,3.05,-.20),(.55,.47,.29),'light','cyan',2)
cyl(k,(2.25,2.70,-.29),.12,.36,'silver','y',16)
pipe(k,[(2.25,2.52,-.31),(2.25,2.26,-.31),(1.42,2.26,-.31)],.035,'copper',12)

# 22 — rough vacuum pressure gauge, needle on radial dial.
k=names[22]
cyl(k,(5.85,2.37,-1.20),.34,.20,'steel','z',32)
cyl(k,(5.85,2.37,-1.08),.285,.018,'white','z',32)
for i in range(11):
    a=math.pi*.15+math.pi*.85*i/10
    cyl(k,(5.85+.24*math.cos(a),2.37+.24*math.sin(a),-1.057),.012,.025,'dark','z',10)
pipe(k,[(5.85,2.37,-1.0),(5.76,2.50,-.98)],.018,'red',10)
cyl(k,(5.85,2.37,-1.035),.029,.029,'black','z',12)
pipe(k,[(5.85,2.08,-1.20),(5.85,1.95,-1.2),(5.57,1.95,-1.20)],.036,'silver')

# 23 — high-vacuum gauge head.
k=names[23]
mechbox(k,(3.10,2.65,-1.83),(.49,.58,.38),'steel')
compact_screen(k,(3.10,2.71,-1.59),.36,.26,'blue')
cyl(k,(3.10,2.19,-1.83),.095,.42,'silver','y',16)
pipe(k,[(3.10,2.03,-1.83),(3.10,1.81,-1.83),(2.62,1.81,-1.83)],.043,'copper')

# 24 — residual gas analyzer rack with slender quadrupole stack.
k=names[24]
mechbox(k,(4.86,2.43,-2.55),(.68,.78,.55),'dark')
compact_screen(k,(4.86,2.50,-2.25),.54,.37,'violet')
cyl(k,(4.86,1.87,-2.59),.14,.41,'steel','y',16)
for x in (-.10,.10):
    for z in (-.10,.10):cyl(k,(4.86+x,1.80,-2.59+z),.025,.28,'silver','y',10)
pipe(k,[(4.86,1.69,-2.59),(4.3,1.69,-2.59)],.040,'silver')

# 25, 26 — educational virtual gas cartridges with valve caps and colored bands.
for idx,x,col in [(25,-6.75,'blue'),(26,-5.64,'violet')]:
    k=names[idx]
    cyl(k,(x,2.47,-2.83),.34,1.83,'silver','y',28)
    for y in (1.79,2.17,2.52,3.04):ring(k,(x,y,-2.83),.354,.335,.06,'y','steel',28)
    box(k,(x,2.70,-2.47),(.53,.48,.035),col)
    cyl(k,(x,3.44,-2.83),.15,.15,'copper','y',20)
    cyl(k,(x,3.57,-2.83),.075,.17,'silver','y',12)
    box(k,(x,1.43,-2.83),(.78,.18,.70),'dark')
    for z in (-3.04,-2.60):cyl(k,(x,1.56,z),.07,.12,'silver','y',12)

# 27 & 28 — active gas MFC modules with flow screens and metal microtubing.
for idx,x,col in [(27,-5.77,'blue'),(28,-4.72,'violet')]:
    k=names[idx]
    controlbox(k,(x,2.27,-1.82),(.74,.70,.52),'steel',col,3)
    cyl(k,(x,2.78,-1.83),.085,.29,'silver','y',12)
    pipe(k,[(x,2.93,-1.82),(x,3.31,-1.82),(x+.48,3.31,-1.82)],.045,'copper')
    for dx in (-.18,.18):cyl(k,(x+dx,1.85,-1.82),.055,.18,'steel','y',12)

# 29 — high-density gas distribution manifold and joining flange hardware.
k=names[29]
mechbox(k,(-2.74,3.45,-2.14),(1.55,.36,.51),'steel')
for i in range(8):
    xx=-3.36+i*.18
    cyl(k,(xx,3.66,-2.14),.064,.20,'copper','y',12)
    knob(k,xx,3.77,-1.88,'green' if i%2 else 'amber')
for yy in (3.34,3.51):pipe(k,[(-4.72,yy,-1.83),(-3.95,yy,-1.83),(-3.95,yy,-2.14),(-3.48,yy,-2.14)],.045,'silver')
pipe(k,[(-2.03,3.45,-2.14),(-1.47,3.45,-2.14),(-1.47,3.20,-.90)],.075,'copper')
# 30 — 13.56 MHz RF generator with precision front panel, cooling fins, RF connector.
k=names[30]
controlbox(k,(-6.44,.77,2.55),(1.64,1.10,.86),'steel','green',4)
for j in range(19):box(k,(-7.12+j*.074,.77,2.10),(.026,.68,.034),'dark')
for x in (-7.07,-5.81):cyl(k,(x,.53,3.02),.050,.14,'copper','z',12)
for i in range(7):box(k,(-7.14+i*.21,1.35,2.49),(.10,.08,.56),'steel')
pipe(k,[(-5.70,.92,2.25),(-5.38,.92,2.25),(-5.38,1.50,1.75)],.09,'copper')

# 31 — matching network chassis with two separated resonant components.
k=names[31]
controlbox(k,(-4.57,.77,2.55),(1.64,1.10,.86),'steel','violet',3)
for x in (-4.94,-4.22):
    cyl(k,(x,1.34,2.29),.16,.15,'ceramic','y',18)
    ring(k,(x,1.45,2.29),.19,.16,.045,'y','copper',22)
for j in range(12):box(k,(-5.22+j*.11,.32,2.15),(.03,.035,.050),'dark')
pipe(k,[(-3.70,.86,2.20),(-2.94,.86,2.20),(-2.94,2.80,1.42),(-1.71,2.80,1.42)],.080,'copper')

# 32,33 — independently rotatable variable RF capacitors with dense plate fins.
for idx,x,col in [(32,-4.95,'violet'),(33,-4.20,'cyan')]:
    k=names[idx]
    box(k,(x,.70,3.23),(.55,.18,.56),'steel')
    cyl(k,(x,.88,3.23),.20,.16,'dark','y',28)
    for j in range(24):
        a=j*2*math.pi/24
        box(k,(x+.165*math.cos(a),.91,3.23+.165*math.sin(a)),(.034,.13,.040),'silver' if j%2 else 'copper')
    cyl(k,(x,1.02,3.23),.082,.19,col,'y',20)
    for j in range(7):box(k,(x-.20+j*.066,.52,3.50),(.025,.09,.035),'ceramic')

# 34 — directional coupler for forward/reflected power measurement.
k=names[34]
controlbox(k,(-2.45,.77,2.55),(.86,.80,.62),'steel','cyan',2)
for x in (-2.73,-2.17):cyl(k,(x,.84,2.89),.11,.17,'copper','z',14)
pipe(k,[(-2.86,1.28,2.22),(-2.86,1.50,2.22),(-2.08,1.50,2.22)],.056,'silver')

# 35 — RF V/I sensing module with toroidal coil and front voltage/current bars.
k=names[35]
controlbox(k,(-1.47,.77,2.55),(.78,.77,.58),'dark','blue',3)
ring(k,(-1.47,1.38,2.52),.21,.12,.12,'x','copper',28)
for xx in (-1.65,-1.50,-1.35,-1.20):box(k,(xx,.46,2.90),(.067,.11,.042),'green')

# 36 — RF arc-protection safety relay with disconnect contactors.
k=names[36]
controlbox(k,(-.51,.77,2.55),(.90,.84,.61),'navy','red',3)
for i in range(4):
    box(k,(-.81+i*.18,.49,2.92),(.11,.19,.06),'dark')
    box(k,(-.81+i*.18,.61,2.96),(.055,.09,.04),'amber' if i%2 else 'red')

# 37 — wafer thermal regulation with sensor connectors and setpoint dial.
k=names[37]
controlbox(k,(.60,.76,2.53),(.97,.81,.63),'steel','teal',4)
for i in range(4):cyl(k,(.28+i*.20,1.20,2.48),.050,.07,'silver','y',10)
wirebundle(k,[(.60,.45,2.15),(.6,.30,1.69),(.1,1.15,.68)],3,.040,'blue')

# 38 — compact chiller with finned exchanger, pump and service pipes.
k=names[38]
mechbox(k,(1.79,.77,2.57),(1.28,1.04,.88),'blue')
for j in range(18):box(k,(1.21+j*.07,.80,3.05),(.026,.76,.05),'silver')
for x in (1.53,2.03):cyl(k,(x,1.35,2.34),.13,.24,'copper','y',14)
for x in (1.29,2.23):
    for z in (2.26,2.84):cyl(k,(x,.25,z),.065,.10,'black','y',12)
pipe(k,[(2.1,1.42,2.2),(2.53,1.42,2.2),(2.53,1.67,.78)],.040,'blue')

# 39 — emergency process safety station with recessed STOP and alarm.
k=names[39]
controlbox(k,(2.88,.77,2.62),(.76,.86,.64),'navy','red',2)
cyl(k,(2.88,.68,2.99),.17,.15,'red','z',24)
ring(k,(2.88,.68,3.085),.22,.19,.035,'z','amber',24)
for i in range(3):box(k,(2.62+i*.25,1.21,2.58),(.09,.08,.13),'warning' if i==0 else 'green')

# 40 — optical spectrometer panel with spectral-prism readout and fibers.
k=names[40]
controlbox(k,(3.91,.77,2.58),(1.00,.88,.70),'steel','violet',2)
for i in range(18):
    xx=3.52+i*.044;val=(math.sin(i*1.7)**8 if i%3==0 else math.sin(i*.39)**4)
    box(k,(xx,.90+.15*val,2.98),(.025,.03+.25*val,.018),'plasma' if i%3==0 else 'cyan')
for x in (3.64,4.08):cyl(k,(x,.44,2.99),.045,.075,'silver','z',12)

# 41 — optical fiber port on reactor + physically routed slender optical fiber.
k=names[41]
cyl(k,(1.19,2.43,.35),.18,.12,'steel','x',18)
cyl(k,(1.33,2.43,.35),.095,.20,'violet','x',20)
pipe(k,[(1.43,2.43,.35),(1.76,2.43,.56),(1.76,1.16,2.18),(3.92,1.16,2.18)],.022,'purpleglass',12)
for pt in [(1.46,2.43,.35),(1.76,1.16,2.18),(3.92,1.16,2.18)]:cyl(k,pt,.058,.085,'silver','y',12)

# 42 — endpoint signal processing rack.
k=names[42]
controlbox(k,(5.03,.78,2.54),(.96,.88,.68),'dark','violet',4)
for i in range(20):
    x=4.62+i*.043
    v=.10*math.sin(i*.47)+.15*math.exp(-((i-13)/2)**2)
    box(k,(x,.95+v,2.90),(.028,.020,.016),'cyan' if v<.16 else 'amber')

# 43 — wafer uniformity monitor, wafer-shaped touch-screen disk.
k=names[43]
controlbox(k,(6.07,.78,2.56),(.84,.87,.65),'steel','blue',3)
cyl(k,(6.07,.88,2.93),.23,.034,'violet','z',24)
for i in range(8):
    a=i*math.pi/4
    cyl(k,(6.07+.14*math.cos(a),.88+.14*math.sin(a),2.959),.036,.014,['green','amber','cyan','violet'][i%4],'z',10)

# 44 — independent wafer metrology head on stage, small probes.
k=names[44]
mechbox(k,(6.90,.61,1.18),(1.13,.66,.98),'steel')
cyl(k,(6.90,1.23,1.15),.11,.63,'dark','y',18)
cyl(k,(6.90,1.57,1.15),.28,.21,'steel','y',22)
cyl(k,(6.90,1.69,1.15),.19,.025,'cyan','y',24)
waferdisc(k,(6.90,1.02,1.23),.32,.026,'iridescent',True)
for x in (6.44,7.36):box(k,(x,1.14,1.18),(.09,.47,.10),'silver')

# 45 — pressure PID controller, digital display with dial.
k=names[45]
controlbox(k,(7.00,.74,2.61),(.83,.79,.61),'steel','cyan',3)
ring(k,(7.00,1.12,2.60),.14,.10,.055,'y','copper',18)

# 46 — main process PLC rack with 10 vertical modules and lit status LEDs.
k=names[46]
mechbox(k,(5.55,1.29,-3.08),(2.70,2.02,.66),'navy')
box(k,(5.55,1.23,-2.72),(2.50,1.78,.07),'dark')
for i in range(10):
    x=4.42+i*.25
    box(k,(x,1.28,-2.65),(.21,1.68,.10),'steel' if i%3 else 'blue')
    for j in range(4):cyl(k,(x,1.87-j*.13,-2.57),.029,.026,'green' if (i+j)%4 else 'amber','z',10)
    for j in range(4):box(k,(x-.04+j*.028,.63,-2.58),(.018,.058,.028),'silver')
box(k,(5.55,2.32,-3.07),(2.7,.14,.70),'steel')
for i in range(6):cyl(k,(4.65+i*.36,2.4,-2.91),.023,.027,'cyan','y',10)

# 47 — smaller PLC I/O module bank.
k=names[47]
mechbox(k,(3.60,.75,-3.11),(1.22,1.05,.66),'steel')
for i in range(7):
    x=3.12+i*.16
    box(k,(x,.79,-2.72),(.13,.81,.080),'dark' if i%2 else 'blue')
    for j in range(4):cyl(k,(x,1.03-j*.14,-2.64),.020,.020,'green' if j<2 else 'amber','z',8)

# 48 — giant visual telemetry display on rear gantry, 3-panel SCADA.
k=names[48]
giantdisplay(k,(4.92,3.68,-3.29),4.25,2.03)
for x in (3.3,6.5):
    box(k,(x,2.39,-3.43),(.20,.95,.27),'steel')
    box(k,(x,1.86,-3.43),(.58,.14,.58),'dark')
for i in range(7):box(k,(3.14+i*.57,4.78,-3.35),(.29,.040,.12),'cyan')

# 49 — stable educational 5V control PSU.
k=names[49]
controlbox(k,(7.06,1.10,-2.27),(.85,.70,.55),'steel','green',2)
for x in (6.80,7.04,7.27):
    cyl(k,(x,.78,-1.975),.059,.10,'copper','z',14)
    cyl(k,(x,.78,-1.89),.033,.043,'red' if x<7 else 'blue','z',10)
for i in range(8):box(k,(6.72+i*.10,1.47,-2.27),(.036,.12,.28),'light')

# Make all equipment models nonempty and model dimensions finite.
assert len(names)==50, f'Expected 50 models, got {len(names)}'
for i,k in enumerate(names):
    assert k in M and len(M[k])>0, (i,k,'missing geometry')
    for mesh,col in M[k]:
        assert np.isfinite(mesh.vertices).all(),(i,k,'nonfinite geometry')

# Verified, scene-space animation pivot references (NOT completed 3D skeleton rigs).
pivots=[
    ('ReactorServiceLid','ANIM_REACTOR_LID',(0.0,3.35,-.90)),
    ('LoadLockGateValve','ANIM_CHAMBER_GATE',(-2.57,1.78,-.86)),
    ('AutomatedWaferTransferRobot','ANIM_WAFER_ROBOT_BASE',(-4.51,1.05,-.76)),
    ('AutomatedWaferTransferRobot','ANIM_WAFER_ROBOT_ARM',(-3.99,2.13,-.76)),
    ('AutomatedWaferTransferRobot','ANIM_WAFER_ROBOT_TOOL',(-2.84,2.15,-.80)),
    ('PrecisionWaferLiftAssembly','ANIM_WAFER_LIFT',(0.0,1.37,-.90)),
    ('ElectrostaticWaferChuck','ANIM_WAFER_CLAMP',(0.0,1.64,-.90)),
    ('TurbomolecularVacuumPump','ANIM_TURBO_ROTOR',(4.12,1.31,-1.07)),
    ('VacuumBackingPump','ANIM_BACKING_PUMP',(6.38,1.22,-1.12)),
    ('AutomaticVacuumThrottleValve','ANIM_THROTTLE_VALVE',(2.18,1.82,-.71)),
    ('MassFlowControllerA','ANIM_MFC_A',(-5.77,2.27,-1.82)),
    ('MassFlowControllerB','ANIM_MFC_B',(-4.72,2.27,-1.82)),
    ('RFVariableCapacitorA','ANIM_RF_TUNER_A',(-4.95,.88,3.23)),
    ('RFVariableCapacitorB','ANIM_RF_TUNER_B',(-4.20,.88,3.23)),
    ('OpticalFiberViewportModule','ANIM_OES_APERTURE',(1.33,2.43,.35)),
    ('VacuumIsolationValve','ANIM_VACUUM_ISOLATION',(2.53,1.84,-1.20)),
    ('HolographicPlasmaSCADAMonitor','ANIM_PLASMA_SCADA',(4.92,3.68,-3.29)),
    ('SiliconWafer','ANIM_WAFER_TRANSFER',(0.,1.75,-.90)),
    ('AutomaticRFMatchingNetwork','ANIM_MATCHING_LIVE_DISPLAY',(-4.57,.77,2.55)),
    ('TransparentPlasmaEtchReactor','ANIM_PLASMA_VFX_CENTER',(0.,2.23,-.90)),
    ('ThinFilmThicknessMetrology','ANIM_METROLOGY_PROBE',(6.90,1.57,1.15)),
]
assert len(pivots)==21

# FBX binary 7400 exporter; standard Nodes/Objects/Connections
class N:
 def __init__(self,name,*p,ch=None):self.name=name;self.p=p;self.ch=ch or []
def prop(v):
 if isinstance(v,bool):return b'C'+struct.pack('<?',v)
 if isinstance(v,int):return b'L'+struct.pack('<q',v)
 if isinstance(v,float):return b'D'+struct.pack('<d',v)
 if isinstance(v,str):
  b=v.encode('utf8');return b'S'+struct.pack('<I',len(b))+b
 if isinstance(v,bytes):return b'R'+struct.pack('<I',len(v))+v
 if isinstance(v,np.ndarray):
  if v.dtype.kind=='f':v=v.astype('<f8');t=b'd'
  elif v.dtype.kind in ('i','u'):v=v.astype('<i4');t=b'i'
  else:raise ValueError(v.dtype)
  raw=v.tobytes();comp=zlib.compress(raw,6)
  return t+struct.pack('<III',v.size,1,len(comp))+comp
 raise TypeError(type(v))
def encnode(node,start):
 name=node.name.encode('ascii');ps=b''.join(prop(x) for x in node.p)
 body=bytearray();p0=start+13+len(name)+len(ps)
 for child in node.ch:
  b=encnode(child,p0+len(body));body.extend(b)
 if node.ch:body.extend(bytes(13))
 end=start+13+len(name)+len(ps)+len(body)
 return struct.pack('<III',end,len(node.p),len(ps))+struct.pack('<B',len(name))+name+ps+body

def fbx(k,path):
 meshes=M[k];nobj=[];con=[];uid=100000
 def getid():
  nonlocal uid;uid+=1;return uid
 root=getid()
 props70=N('Properties70',ch=[N('P','Lcl Translation','Lcl Translation','','A',0.0,0.0,0.0),N('P','Lcl Rotation','Lcl Rotation','','A',0.0,0.0,0.0),N('P','Lcl Scaling','Lcl Scaling','','A',1.0,1.0,1.0)])
 nobj.append(N('Model',root,k+'\x00\x01Model','Null',ch=[N('Version',232),N('Properties70',ch=props70.ch),N('Shading','Y'),N('Culling','CullingOff')]))
 con.append(N('C','OO',root,0))
 colorMat={}
 for idx,(mesh,color) in enumerate(meshes):
  # vertex coordinates in meters scaled 100 for FBX centimeter convention, importer scale .01 -> meters
  vertices=np.array(mesh.vertices,dtype=np.float64)*100.0
  tris=np.array(mesh.faces,dtype=np.int32)
  faceindices=tris.copy();faceindices[:,-1]=-(faceindices[:,-1]+1)
  gid=getid();mid=getid();geo=N('Geometry',gid,f'{k}_Geom_{idx:03d}\x00\x01Geometry','Mesh',ch=[N('GeometryVersion',124),N('Vertices',vertices.reshape(-1)),N('PolygonVertexIndex',faceindices.reshape(-1)),N('LayerElementMaterial',0,ch=[N('Version',101),N('Name',''),N('MappingInformationType','AllSame'),N('ReferenceInformationType','IndexToDirect'),N('Materials',np.array([0],dtype=np.int32))]),N('Layer',0,ch=[N('Version',100),N('LayerElement',ch=[N('Type','LayerElementMaterial'),N('TypedIndex',0)])])])
  nobj.append(geo)
  nobj.append(N('Model',mid,f'{k}_Part_{idx:03d}\x00\x01Model','Mesh',ch=[N('Version',232),N('Properties70',ch=[N('P','Lcl Translation','Lcl Translation','','A',0.0,0.0,0.0),N('P','Lcl Rotation','Lcl Rotation','','A',0.0,0.0,0.0),N('P','Lcl Scaling','Lcl Scaling','','A',1.0,1.0,1.0)]),N('Shading','Y'),N('Culling','CullingOff')]))
  con.extend([N('C','OO',gid,mid),N('C','OO',mid,root)])
  if color not in colorMat:
   matid=getid();rgb=[q/255 for q in P[color][:3]]
   nobj.append(N('Material',matid,f'PS_{color}\x00\x01Material','',ch=[N('Version',102),N('ShadingModel','phong'),N('MultiLayer',0),N('Properties70',ch=[N('P','DiffuseColor','Color','','A',*rgb),N('P','AmbientColor','Color','','A',*(v*.28 for v in rgb)),N('P','SpecularColor','Color','','A',.6,.65,.68),N('P','Shininess','Number','','A',55.0),N('P','Opacity','Number','','A',P[color][3]/255.)])]))
   colorMat[color]=matid
  con.append(N('C','OO',colorMat[color],mid))
 top=[N('FBXHeaderExtension',ch=[N('FBXHeaderVersion',1003),N('FBXVersion',7400),N('Creator','Project Spark Procedural 3D Asset Builder')]),N('GlobalSettings',ch=[N('Version',1000),N('Properties70',ch=[N('P','UpAxis','int','Integer','',1),N('P','UpAxisSign','int','Integer','',1),N('P','FrontAxis','int','Integer','',2),N('P','FrontAxisSign','int','Integer','',1),N('P','CoordAxis','int','Integer','',0),N('P','CoordAxisSign','int','Integer','',1),N('P','UnitScaleFactor','double','Number','',1.0),N('P','OriginalUnitScaleFactor','double','Number','',1.0)])]),N('Definitions',ch=[N('Version',100),N('Count',len(nobj))]),N('Objects',ch=nobj),N('Connections',ch=con)]
 header=b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400)
 blob=bytearray(header)
 for node in top:blob.extend(encnode(node,len(blob)))
 blob.extend(bytes(13));blob.extend(bytes(160))
 path.write_bytes(blob)

def glb(k,path):
 sc=trimesh.Scene()
 for i,(m,c) in enumerate(M[k]):sc.add_geometry(m,geom_name=f'{k}_Part_{i:03d}')
 path.write_bytes(sc.export(file_type='glb'))



# -------------------- export model collection --------------------
manifest=[]
for i,k in enumerate(names):
    bn=f'{i:02d}_L71_{k}'
    fbx(k,MD/(bn+'.fbx'))
    glb(k,GD/(bn+'.glb'))
    triangles=sum(len(mesh.faces) for mesh,c in M[k])
    vv=np.concatenate([mesh.vertices for mesh,c in M[k]])
    manifest.append(dict(index=i,file=bn+'.fbx',glb=bn+'.glb',name='L71_'+k,triangle_count=triangles,mesh_parts=len(M[k]),bbox_min=np.round(vv.min(axis=0),4).tolist(),bbox_max=np.round(vv.max(axis=0),4).tolist(),animation_pivots={p:list(coord) for label,p,coord in pivots if label==k}))
    print(f'[{i:02d}/49] {k:39s} {triangles:6d} triangles {len(M[k]):4d} pieces',flush=True)

# Assembled showcase is reference only; avoid double-instantiating with individual parts.
M['Level71_Complete_ArtKit_Showcase']=[p for k in names for p in M[k]]
fbx('Level71_Complete_ArtKit_Showcase',MD/'Level71_Complete_ArtKit_Showcase.fbx')
glb('Level71_Complete_ArtKit_Showcase',GD/'Level71_Complete_ArtKit_Showcase.glb')
total=sum(item['triangle_count'] for item in manifest)
parts=sum(item['mesh_parts'] for item in manifest)

with (ROOT/'Animation_Rigs.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['Model','Pivot','X','Y','Z','Notes'])
    for name,p,coords in pivots:w.writerow(['L71_'+name,p,*coords,'World-space reference; split/rig moving submeshes in Unity. Does not confer gameplay physics.'])
with (ROOT/'Art_Assembly.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['Model','FBX','PositionX','PositionY','PositionZ','RotationX','RotationY','RotationZ','Scale','Notes'])
    for model in manifest:w.writerow([model['name'],model['file'],0,0,0,0,0,0,1,'Common world coordinate origin. Verify FBX importer unit scaling.'])

palette={}
for col,rgba in P.items():
    palette['PS_'+col]={'rgba_255':list(rgba),'metallic':(.84 if col in ('steel','light','silver','copper','gold') else .1 if col in ('navy','dark','black') else .28),'smoothness':(.86 if col in ('steel','silver','copper','gold','glass','purpleglass') else .48),'transparent':col in ('glass','purpleglass','plasma')}
(ROOT/'Material_Palette.json').write_text(json.dumps({'level':'71','description':'Suggested appearance parameters; no baked texture atlas or hand-painted PBR maps','materials':palette},indent=2),encoding='utf-8')
(ROOT/'Model_Manifest.json').write_text(json.dumps({'level_id':'level_71','display_name':'Etch the Future','asset_kind':'Original procedural 3D geometry: HD/AAA-inspired but not artist-finished PBR','individual_models':50,'individual_triangle_count':total,'individual_mesh_parts':parts,'planned_player_wires':90,'planned_unique_functional_terminals':140,'actual_player_wires_included':False,'functional_spark_terminals_included':False,'rf_or_vacuum_physics_included':False,'glb_scale':'numeric meters','fbx_numeric_scale':'numeric centimeters with UnitScaleFactor 1; verify Unity importer scaling','coordinate_system':'X=workstation width, Y=up, Z=front, model construction in meters','approx_workbench_width_m':15.8,'assembled_showcase':'Models/Level71_Complete_ArtKit_Showcase.fbx','animation_pivot_reference_count':len(pivots),'models':manifest},indent=2),encoding='utf-8')

with (ROOT/'Gameplay_Wiring_Budget.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['Group','ProposedPlayerWires','Responsibility','Status'])
    rows=[('Control power and returns',10,'Educational 5V supplies, return paths and I/O enables'),('Vacuum pumps valves pressure',14,'Vacuum pump commands and pressure feedback'),('Virtual gas delivery',12,'Fictional virtual gases and MFC feedback'),('RF generator matching protection',18,'RF command, reflected measurement, interlocks'),('Wafer transfer chuck temperature',10,'Wafer mover, chuck and thermal monitoring'),('Optical endpoint and metrology',12,'OES feedback, etch endpoint and product measurement'),('Emergency safety interlocks',8,'Door, fault trip, stop and reset'),('PLC controllers SCADA',6,'Automation supervisory signals')]
    for name,count,role in rows:w.writerow([name,count,role,'PLANNED_ONLY_NOT_IMPLEMENTED'])
    assert sum(a for _,a,_ in rows)==90

(ROOT/'Gameplay_Integration_Plan.md').write_text('''# Level 71 — Art package vs planned gameplay\n\nThis pack contains **50 actual 3D equipment FBX meshes** and matching GLBs, not a playable Unity level.\n\n## Approved conceptual target\n- 90 player-created wires — **NOT INCLUDED**\n- 140 unique functional `SparkTerminal` anchors — **NOT INCLUDED**\n- Six authoritative objectives — **NOT IMPLEMENTED**\n- Process pressure, virtual gas flow, RF matching, plasma, wafer film, OES and safety — **NOT IMPLEMENTED**\n\nThe file `Gameplay_Wiring_Budget.csv` allocates 90 future player wires across eight design groups, **not** exact W01-W90 endpoint definitions. Do not treat it as a functional manifest.\n\n## Artwork only\nThe FBX/GLB surfaces and material labels are procedural illustration geometry. Pivots in `Animation_Rigs.csv` are reference points for artist/Unity rigging; no animated skeleton or clips are included. Check FBX scale and model hierarchy before attaching gameplay components.\n\n## Future Unity integrations\nInspect actual project APIs for SparkTerminal, SparkElectricalSolver, SparkLevelEvaluator and LevelGamePlayManager before writing runtime code. The illustrative vapor-vacuum / RF scenario is a *virtual educational simulator* and is not a recipe or hardware control design for real reactive plasma equipment.\n''',encoding='utf-8')

# Source list with friendly functional roles; all are independently imported visual art.
with (ROOT/'Component_Roles.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['Index','Model','FBX','Triangles','MeshParts','AnimationRefs'])
    for model in manifest:w.writerow([model['index'],model['name'],model['file'],model['triangle_count'],model['mesh_parts'],';'.join(model['animation_pivots'])])

print('EXPORTED',len(manifest),'models + assembled',total,'triangles',parts,'mesh parts',len(pivots),'pivot references',flush=True)
