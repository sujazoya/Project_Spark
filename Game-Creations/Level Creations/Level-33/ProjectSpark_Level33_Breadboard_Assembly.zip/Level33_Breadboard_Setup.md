# Level 33 — Jam Guard

Open **Jam Guard – Delayed Trip and Manual Reset** in the level picker. Wire the labeled rings on the breadboard. The workbench monitor shows live timer voltage, and the modeled parcel, sensor beam, motor contact, belt, and alarm follow the circuit.

| Wire | Start | End |
|---|---|---|
| W01 | Supply + | JAM IN |
| W02 | JAM OUT | 4.7 kΩ Charge IN |
| W03 | 4.7 kΩ Charge OUT | Timer + |
| W04 | Timer − | Supply − |
| W05 | Timer + | 1 kΩ CLEAR resistor IN |
| W06 | 1 kΩ CLEAR resistor OUT | CLEAR switch IN |
| W07 | CLEAR OUT | Supply − |
| W08 | Supply + | Motor Contact IN |
| W09 | Motor Contact OUT | Motor A |
| W10 | Motor B | Supply − |

1. Select **START TEST** with the timer discharged. The conveyor starts.
2. Select **BRIEF BLOCK**. The timer rises during the half-second blockage, then discharges while the conveyor keeps moving.
3. Select **JAM** and leave the obstruction in place. At 3 V the motor contact opens and the alarm lights.
4. Select **RESET** while the obstruction is still present. The conveyor stays stopped.
5. Select **CLEAR JAM**. Wait for the timer to fall below 1 V. The conveyor stays stopped.
6. Select **RESET**. The conveyor restarts and the alarm clears.

The 16 wire sockets sit directly on the MainMenu breadboard over separate grid holes. The visible TextMesh labels use local scale `0.25` on X and Y. The fitted export uses the project's breadboard and preserves the original Level 33 prefab and definition references.

The ZIP mirrors the Unity `Assets` folder. In Edit Mode, **Tools → Project Spark → Level 33 → Fit Breadboard Assembly** refits the models and sockets. The level uses the existing Project Spark capacitor and motor solver registrations and requires transient device simulation.
