PROJECT SPARK / LEVEL 33 / JAM GUARD
Polished semi-HD 3D asset kit — Unity Y-up, socket-facing side local -Z
====================================================================

CONTENTS
--------
12 individual FBX models (one per file), 12 matching GLB reference backups,
1 optional full-showcase FBX/GLB, 13 actual mesh preview PNGs, contact sheet,
exact 10-wire circuit manifest, 16 terminal anchor coordinates, build sources.

The models are original 3D geometry with separate named groups for motion.
They are VISUAL ASSETS. They do not contain SparkElectricalComponent,
SparkTerminal, solver registration, collision, scripted signal processing,
or prefab binding setup. Keep your existing Level 33 electrical/gameplay systems.

MODEL LIST
----------
01_5V_Supply                     5 V DC PSU; 2 sockets
02_JAM_Charge_Switch             JAM charge/start rocker; 2 sockets
03_4p7kOhm_Charge_Resistor       4.7 kOhm charging resistor; 2 sockets
04_470uF_Timer_Capacitor         470 uF timer capacitor, visible can; 2 sockets
05_1kOhm_Clear_Resistor          1 kOhm clear path; 2 sockets
06_CLEAR_Discharge_Switch        CLEAR manual push button; 2 sockets
07_Motor_Protection_Contact      Motor trip/contact module; 2 sockets
08_DC_Motor_33Ohm                Polished metallic 33 Ohm DC motor; 2 sockets
09_JamGuard_Industrial_Conveyor  Belt, rollers, jam cube; NO sockets
10_Overhead_Jam_Sensor           Jam detector arch; NO sockets
11_Jam_Alarm_Beacon              Visible trip alert; NO sockets
12_Jam_Timer_Trip_Monitor        Timer / trip / reset status; NO sockets

RECOMMENDED UNITY IMPORT
-------------------------
1. Import individual .fbx files into:
   Assets/My_Assets/_Project_Spark/Models/Level33/
2. Use the separate FBX files as visuals for your existing layout,
   not the full assembled showcase (showcase is for inspection).
3. In FBX import Inspector, check Y-up orientation, scale, mesh normals,
   and material colors. For URP/HDRP create appropriate Lit materials;
   FBX material colors may require reassignment depending on pipeline.
4. Front socket faces local -Z. Look at the model from local -Z,
   or orient its parent prefab until socket faces are visible.
5. For a model with electrical sockets, create/assign actual
   SparkTerminal components in Unity at the points in Terminal_Anchors.csv.
   Model meshes and metallic socket rings alone are NOT SparkTerminals.
6. Assign electrical runtime aliases based on your existing Level 33 binding
   schema. The IDs below are suggested for the art kit; don't rename existing
   valid scene IDs to match this package without reconciling your evaluator.
7. Add child colliders to switch caps and relevant motor/conveyor parts as
   required by your Project Spark interaction or animation system.
8. Reuse your current JAM trip logic; do not replace the shared electrical
   solver or time integration with anything from this art-only package.

THE 16 SOCKETS / THE 10 PLAYER WIRES
------------------------------------
W01 Battery_positive    -> JAM_IN
W02 JAM_OUT             -> R47_IN
W03 R47_OUT             -> TIMER_POS
W04 TIMER_NEG           -> Battery_negative
W05 TIMER_POS           -> R1K_IN
W06 R1K_OUT             -> CLEAR_IN
W07 CLEAR_OUT           -> Battery_negative
W08 Battery_positive    -> MOTOR_CONTACT_IN
W09 MOTOR_CONTACT_OUT   -> Motor_A
W10 Motor_B             -> Battery_negative

A terminal can accept more than one electrical wire. TIMER_POS has both the
4.7k output and 1k input; Battery + and Battery - have multiple wires.
The drawing's motor contact is a controlled safety element; the visual
model does NOT implement trip behavior on its own.

SEPARATE ANIMATION GROUPS IN FBX
--------------------------------
RockerPivot_ANIMATE        02 charging/simulated JAM switch
ButtonCap_ANIMATE         06 manual CLEAR push button
ContactArmature_ANIMATE   07 safety motor contact
RotorShaft_ANIMATE        08 brushed DC motor shaft
MovingBelt_ANIMATE        09 conveyor belt + grooves
JamPart_ANIMATE           09 jam block / sample part
DetectorBeam_VISUAL       10 jam sensor scan glow
AlarmBeacon_VISUAL        11 warning light

When animating moving groups, make your own GameObject pivot as necessary;
mesh names distinguish animated pieces from static chassis. Animating the
whole FBX GameObject will also move static housing, which is not intended.

PRESENTATION / TECHNICAL NOTES
------------------------------
- Graphite/silver machined metal, neon cyan status, amber safety trim.
- Polarity-coded sockets, text meshes, gold contacts, metal fasteners.
- The 470 uF time-delay capacitor remains a physical visual until an
  actual SparkCapacitor and your level controller are added in Unity.
- The red sensor cone/beam is a visual cue, not a detection algorithm.
- The open conveyor jam cube may be animated or hidden during normal run.
- No Unity editor import or Play Mode animation was executed here.
- Source scripts are included so colors, labels or proportions can be
  modified and the meshes re-exported. GLB files are inspection backups.

See Model_Manifest.json and Terminal_Anchors.csv for precise model-local
coordinates and names. Exact_Wiring.csv provides the matching 10 wires.

DESIGN REFERENCES
-----------------
Based on the user's Level 33 / Jam Guard exact workbench wiring diagram.
For subsequent Level 34 assets, keep Level 33 art on its own prefabs.
