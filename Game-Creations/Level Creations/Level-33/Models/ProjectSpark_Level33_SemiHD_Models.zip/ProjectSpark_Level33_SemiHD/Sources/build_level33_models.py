"""PROJECT SPARK / LEVEL 33 / JAM GUARD — 3D semi-HD model generator.

12 actual separately exported FBX/GLB models + optional assembled 3D showcase.
Electrical art: 16 front sockets, 10 circuit connections, Unity Y up and -Z fronts.
Important: visual 3D meshes only. Existing Project Spark components own the electricity.
"""
from __future__ import annotations
from spark_model_core import *
from pathlib import Path
import json,csv,math
import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models';PREV=ROOT/'Previews'
MODELS.mkdir(parents=True,exist_ok=True);PREV.mkdir(parents=True,exist_ok=True)
PALETTE.update({
 'capacitor_black':(16,20,31,255), 'capacitor_blue':(43,91,145,255),
 'belt':(23,31,40,255), 'safety_orange':(242,134,34,255),
 'acrylic':(92,186,220,55), 'acrylic_edge':(140,231,249,255),
 'alarm_red':(255,35,74,255), 'dark_tile':(55,68,78,255),
 'part_white':(204,215,220,255), 'hazard_black':(13,18,24,255),
})

def port_pair(m,t,ids,labels=('IN','OUT'),colors=('red','cyan'),w=2.52,d=1.63,y=.47):
    z=-d/2-.09
    for idx,(pid,label,mat,x) in enumerate(zip(ids,labels,colors,(.73,-.73))):
        m.cyl(t+'_'+pid+'_ChromeSocketSleeve',.157,.06,(x,y,z),'chrome',axis='z',sections=36)
        m.cyl(t+'_'+pid+'_PolarityRing',.127,.061,(x,y,z-.033),mat,axis='z',sections=36)
        m.cyl(t+'_'+pid+'_DeepSocketRecess',.088,.074,(x,y,z-.073),'void',axis='z',sections=30)
        m.cyl(t+'_'+pid+'_GoldSocketContact',.030,.018,(x,y,z-.101),'gold',axis='z',sections=16)
        m.text(t+'_'+pid+'_SocketLabel',label,.117,x,y+.253,z-.105,'white',maxwidth=.61)
        m.anchors[pid]=[round(float(x),4),round(float(y),4),round(float(z-.102),4)]

def strip(m,p,x,y,z,width=.6,color='cyan'):
    m.bevel(p+'_LED_Base',(width+.12,.047,.055),(x,y,z+.012),'void',.018)
    m.box(p+'_Glow_Cyan',(width,.031,.058),(x,y+.019,z),'cyan')

def screw(m,p,x,y,z):
    m.cyl(p+'_Chrome_Screw',.05,.024,(x,y,z),'chrome',axis='z',sections=18)
    m.box(p+'_Screw_Drive',(.046,.008,.006),(x,y,z-.014),'graphite')

def switch(m,t,pid,actuator='rocker',color='red'):
    m.base(t,w=2.52,d=1.63,bodyh=1.16,fronttext=pid,status='SAFETY CONTROL')
    if actuator=='rocker':
        m.bevel(t+'_Selector_Chrome_Bezel',(1.11,.12,.84),(0,1.64,.16),'chrome',.055)
        m.bevel(t+'_Selector_Dark_Bevel',(1.00,.09,.70),(0,1.71,.16),'rubber',.055)
        m.bevel(t+'_Switch_Rocker_ANIMATE',(.83,.20,.55),(0,1.80,.16),color,.065,group='RockerPivot_ANIMATE')
        m.box(t+'_On_Off_Highlight_ANIMATE',(.48,.023,.035),(0,1.92,-.10),'white',group='RockerPivot_ANIMATE')
    elif actuator=='push':
        m.cyl(t+'_ButtonMount',.46,.15,(0,1.65,.12),'chrome',sections=48)
        m.cyl(t+'_ButtonNeck',.37,.17,(0,1.73,.12),'rubber',sections=44)
        m.cyl(t+'_Pushbutton_Cap_ANIMATE',.344,.17,(0,1.84,.12),color,sections=48,group='ButtonCap_ANIMATE')
        m.torus(t+'_ButtonStatusRing_ANIMATE',.336,.025,(0,1.946,.12),'white',axis='y',segments=40,group='ButtonCap_ANIMATE')
    return m

def make_supply():
    m=Model('01_5V_Supply'); t='L33_SUPPLY'
    m.base(t,w=2.75,d=1.67,bodyh=1.43,fronttext='5 V SUPPLY',status='REGULATED DC')
    port_pair(m,t,('Battery_positive','Battery_negative'),labels=('+','-'),colors=('red','blue'),w=2.75,d=1.67)
    m.bevel(t+'_DigitalVoltagePanel',(1.38,.32,.057),(0,1.275,-.856),'bezel',.03)
    m.text(t+'_DigitalVoltage_5V','5.00 V',.224,0,1.273,-.89,'green',maxwidth=1.27)
    m.box(t+'_SupplyPowerStatusGreen',(.85,.046,.06),(0,1.83,-.45),'green')
    for i,x in enumerate(np.linspace(-1.02,1.02,12)):
        m.box(t+f'_CoolingVent_{i:02}',(.066,.014,.41),(float(x),1.82,.21),'void')
    for x in (-1.01,1.01):
        m.bevel(t+f'_BrushedSteelCorner_{x}',(.11,.34,.36),(x,1.4,.48),'chrome',.025)
    return m

def make_jam_charge():
    m=Model('02_JAM_Charge_Switch');t='L33_JAM'
    switch(m,t,'JAM CHARGE',actuator='rocker',color='red')
    port_pair(m,t,('JAM_IN','JAM_OUT'),labels=('IN','OUT'),colors=('red','amber'))
    m.text(t+'_Safety_Inscription','JAM SIM',.126,0,1.31,-.852,'amber',maxwidth=.96)
    return m

def resistor_body(m,t,ohms,mat3='red'):
    m.bevel(t+'_HardenedIsolationCradle',(1.54,.11,.70),(0,1.57,.14),'rubber',.07)
    m.cyl(t+'_CeramicResistorBody',.227,1.24,(0,1.84,.13),'gold',axis='x',sections=52)
    for j,(x,color) in enumerate(zip((-.37,-.18,.04,.38),('orange','orange',mat3,'gold'))):
        m.torus(t+f'_ToleranceColorBand_{j}',.226,.027,(x,1.84,.13),color,axis='x',segments=40,tube_segs=8)
    for sign in [-1,1]:
        m.cyl(t+f'_SilverEndCap_{sign}',.236,.07,(sign*.64,1.84,.13),'chrome',axis='x',sections=44)
        m.rod(t+f'_NickelWire_{sign}',(sign*.67,1.84,.13),(sign*.93,1.84,.13),.040,'chrome')
        m.rod(t+f'_WireAnchor_{sign}',(sign*.93,1.84,.13),(sign*.93,1.57,.13),.037,'chrome')
    m.text(t+'_TopRatingMini','RATED',.135,0,1.15,-.835,'fog',maxwidth=.7)

def make_4k7():
    m=Model('03_4p7kOhm_Charge_Resistor');t='L33_R47'
    m.base(t,w=2.52,d=1.63,bodyh=1.12,fronttext='4.7 kOhm',status='JAM RC CHARGE')
    port_pair(m,t,('R47_IN','R47_OUT'),labels=('IN','OUT'),colors=('red','green'))
    resistor_body(m,t,'4.7k','red')
    return m

def make_timer():
    m=Model('04_470uF_Timer_Capacitor');t='L33_TIMER'
    m.base(t,w=2.53,d=1.63,bodyh=1.08,fronttext='470 uF TIMER',status='DELAY STORAGE')
    port_pair(m,t,('TIMER_POS','TIMER_NEG'),labels=('+','-'),colors=('green','blue'))
    m.cyl(t+'_CapacitorMountChrome',.51,.09,(0,1.50,.11),'chrome',sections=60)
    m.cyl(t+'_CapacitorCan_470uF_16V',.425,1.20,(0,2.12,.11),'capacitor_black',sections=64)
    m.cyl(t+'_BlueTopCap',.424,.057,(0,2.748,.11),'capacitor_blue',sections=64)
    m.cyl(t+'_AluminumVentTop',.376,.013,(0,2.782,.11),'chrome',sections=60)
    m.torus(t+'_SafetyBlueTopRing',.425,.017,(0,2.733,.11),'cyan',axis='y',segments=56)
    m.box(t+'_CapacitorStripe',(.09,.83,.018),(.337,2.10,-.151),'blue')
    m.bevel(t+'_CapacitorTextBlackPlate',(.63,.60,.025),(0,2.22,-.36),'deep_steel',.02)
    m.text(t+'_CapacityLarge','470 uF',.158,0,2.31,-.39,'white',maxwidth=.57)
    m.text(t+'_CapVoltage','16 V',.14,0,2.10,-.39,'white',maxwidth=.42)
    m.text(t+'_TimerCharge','RC TIMER',.106,0,1.90,-.39,'cyan',maxwidth=.54)
    for x in [-.25,.25]:m.cyl(t+f'_CeramicTerminal_{x}',.077,.10,(x,1.54,.11),'gold',sections=28)
    return m

def make_1k():
    m=Model('05_1kOhm_Clear_Resistor');t='L33_R1K'
    m.base(t,w=2.52,d=1.63,bodyh=1.12,fronttext='1 kOhm',status='CLEAR PATH')
    port_pair(m,t,('R1K_IN','R1K_OUT'),labels=('IN','OUT'),colors=('green','amber'))
    resistor_body(m,t,'1k','red')
    return m

def make_clear():
    m=Model('06_CLEAR_Discharge_Switch');t='L33_CLEAR'
    switch(m,t,'CLEAR DISCHARGE',actuator='push',color='green')
    port_pair(m,t,('CLEAR_IN','CLEAR_OUT'),labels=('IN','OUT'),colors=('amber','blue'))
    m.text(t+'_ResetDesignation','MANUAL CLEAR',.123,0,1.27,-.852,'green',maxwidth=1.18)
    return m

def make_motor_contact():
    m=Model('07_Motor_Protection_Contact');t='L33_MCONTACT'
    m.base(t,w=2.52,d=1.63,bodyh=.87,fronttext='MOTOR CONTACT',status='TRIP / LATCH')
    port_pair(m,t,('MOTOR_CONTACT_IN','MOTOR_CONTACT_OUT'),labels=('IN','OUT'),colors=('red','amber'))
    m.bevel(t+'_Contact_InsulatingFrame',(1.51,.18,.79),(0,1.36,.12),'rubber',.055)
    for x in [-.49,.49]:
        m.cyl(t+f'_SolidGoldFixedPost_{x}',.11,.51,(x,1.67,.12),'gold',sections=28)
        m.cyl(t+f'_ContactSilverPad_{x}',.14,.10,(x,1.96,.12),'chrome',sections=28)
    m.bevel(t+'_Pivoting_Armature_Contact_ANIMATE',(1.03,.074,.185),(0,2.05,.12),'copper',.025,group='ContactArmature_ANIMATE')
    m.cyl(t+'_ArmaturePivot_ANIMATE',.15,.065,(-.44,2.08,.12),'chrome',sections=32,group='ContactArmature_ANIMATE')
    m.box(t+'_FaultRedStatusStrip',(.6,.05,.06),(0,1.23,-.82),'red')
    return m

def make_motor():
    m=Model('08_DC_Motor_33Ohm');t='L33_MOTOR'
    m.base(t,w=2.90,d=1.77,bodyh=.78,fronttext='DC MOTOR',status='33 Ohm / PROTECTED')
    port_pair(m,t,('Motor_A','Motor_B'),labels=('A','B'),colors=('amber','blue'),d=1.77,y=.42)
    m.cyl(t+'_StainlessCylindricalMotorCan',.49,1.77,(0,1.26,.11),'titanium',axis='x',sections=68)
    m.cyl(t+'_FrontChromeStampedPlate',.517,.175,(-.93,1.26,.11),'steel',axis='x',sections=58)
    m.cyl(t+'_BrassBearing',.198,.18,(-1.05,1.26,.11),'gold',axis='x',sections=44)
    m.cyl(t+'_SpinningSteelShaft_ANIMATE',.090,.77,(-1.40,1.26,.11),'chrome',axis='x',sections=34,group='RotorShaft_ANIMATE')
    m.cyl(t+'_ShaftCollar_ANIMATE',.149,.09,(-1.17,1.26,.11),'chrome',axis='x',sections=34,group='RotorShaft_ANIMATE')
    m.cyl(t+'_BlueInsulatorRear',.52,.23,(.91,1.26,.11),'blue',axis='x',sections=56)
    m.cyl(t+'_RedBrushEndcap',.47,.23,(1.10,1.26,.11),'red',axis='x',sections=56)
    m.cyl(t+'_RearBrassPad',.26,.06,(1.25,1.26,.11),'gold',axis='x',sections=34)
    for i,x in enumerate(np.linspace(-.53,.53,9)):
        m.box(t+f'_VentSlots_{i:02}',(.074,.048,.11),(float(x),1.75,.11),'void')
    for x in (-.71,.67):m.torus(t+f'_SteelMachinedRing_{x:.2f}',.50,.018,(x,1.26,.11),'chrome',axis='x',segments=48)
    m.bevel(t+'_MotorRatingPlate',(.83,.25,.044),(0,1.00,-.394),'bezel',.02)
    m.text(t+'_Resistance3DText','33 Ohm',.145,0,1.005,-.426,'white',maxwidth=.79)
    return m

def make_conveyor():
    m=Model('09_JamGuard_Industrial_Conveyor');t='L33_CONVEYOR'
    m.bevel(t+'_HeavyRubberFootpad',(7.35,.17,2.65),(0,.10,0),'rubber',.10)
    m.bevel(t+'_AluminumDeck',(7.24,.25,2.58),(0,.30,0),'steel',.10)
    m.bevel(t+'_DarkMachineHousing',(7.05,.34,2.43),(0,.60,0),'graphite',.10)
    m.box(t+'_SoftMatteMovingBelt_ANIMATE',(6.45,.076,1.76),(0,1.06,0),'belt',group='MovingBelt_ANIMATE')
    for j,x in enumerate(np.linspace(-3.05,3.05,52)):
        m.box(t+f'_PolymerBeltGroove_{j:02}_ANIMATE',(.027,.022,1.70),(float(x),1.106,0),'mid_steel',group='MovingBelt_ANIMATE')
    for x in (-3.23,3.23):
        m.cyl(t+f'_StainlessRoller_{x}',.32,1.90,(x,.92,0),'titanium',axis='z',sections=60)
        m.cyl(t+f'_RollerBlueAxle_{x}',.11,2.05,(x,.92,0),'blue',axis='z',sections=32)
        m.torus(t+f'_FrontRollerCyanHalo_{x}',.33,.031,(x,.92,-1.08),'cyan',axis='z',segments=48)
    for i,z in enumerate((-.99,.99)):
        m.bevel(t+f'_SteelSideRail_{i}',(6.93,.20,.13),(0,1.14,z),'chrome',.04)
        m.box(t+f'_SideRailCyanGlow_{i}',(5.42,.034,.025),(0,1.23,z-.018),'cyan')
    for i,x in enumerate((-2.85,-2.1,-1.35,1.35,2.1,2.85)):
        m.bevel(t+f'_AmberDangerStripes_{i}',(.36,.04,.13),(x,.46,-1.297),'amber',.018)
    m.bevel(t+'_FrontInfoPanel',(3.46,.38,.07),(0,.48,-1.34),'bezel',.05)
    m.text(t+'_IndustrialEquipmentLabel','JAM-GUARD CONVEYOR',.22,0,.47,-1.39,'white',maxwidth=3.22)
    # Removable/animated jam block
    m.bevel(t+'_BlockedPart_JamCube_ANIMATE',(.64,.37,.70),(.43,1.32,0),'part_white',.045,group='JamPart_ANIMATE')
    m.box(t+'_JammedPartRedWarningEmissive',(.60,.018,.04),(.43,1.52,-.32),'red',group='JamPart_ANIMATE')
    return m

def make_sensor():
    m=Model('10_Overhead_Jam_Sensor');t='L33_SENSOR'
    m.bevel(t+'_BaseFoot',(2.44,.18,1.86),(0,.12,0),'rubber',.06)
    m.bevel(t+'_MachinedBase',(2.39,.22,1.83),(0,.33,0),'steel',.06)
    for x in (-.89,.89):
        m.cyl(t+f'_StainlessPillar_{x}',.105,1.22,(x,1.07,0),'titanium',sections=34)
        m.torus(t+f'_WarningRedRing_{x}',.107,.028,(x,1.46,0),'red',axis='y',segments=30)
    m.bevel(t+'_CompactTopBeam',(2.42,.43,1.16),(0,1.84,0),'graphite',.08)
    m.bevel(t+'_SensorHousing',(1.11,.34,.92),(0,1.64,0),'mid_steel',.05)
    m.cyl(t+'_RedOpticalScannerEmitter',.228,.15,(0,1.41,0),'chrome',sections=40)
    m.cyl(t+'_BrightRedScanLens',.178,.04,(0,1.317,0),'red',sections=40,group='DetectorBeam_VISUAL')
    for i,y in enumerate(np.linspace(.67,1.18,6)):
        m.torus(t+f'_PulsingRedBeamRing_{i:02}',.130,.011,(0,float(y),0),'alarm_red',axis='y',segments=30,group='DetectorBeam_VISUAL')
    m.bevel(t+'_WarningLabelPlate',(1.55,.20,.047),(0,1.93,-.606),'bezel',.022)
    m.text(t+'_WarningScannerLabel','JAM SENSOR',.15,0,1.93,-.632,'white',maxwidth=1.40)
    m.box(t+'_DetectorWarningLED',(.46,.037,.032),(0,2.087,-.44),'red')
    return m

def make_warning():
    m=Model('11_Jam_Alarm_Beacon');t='L33_ALARM'
    m.bevel(t+'_BeaconBase',(1.16,.18,1.13),(0,.12,0),'rubber',.04)
    m.bevel(t+'_BeaconMachinedPedestal',(1.14,.23,1.10),(0,.32,0),'steel',.07)
    m.cyl(t+'_DiecastMetalMount',.35,.17,(0,.53,0),'chrome',sections=40)
    m.cyl(t+'_RotatingLampBase',.29,.12,(0,.63,0),'rubber',sections=38)
    m.cyl(t+'_RedStrobeGlass_ANIMATE',.27,.51,(0,.96,0),'red',sections=48,group='AlarmBeacon_VISUAL')
    m.cyl(t+'_FrostedWarningDiffuser_ANIMATE',.17,.49,(0,.97,0),'orange',sections=32,group='AlarmBeacon_VISUAL')
    m.cyl(t+'_AluminumLampCap',.29,.046,(0,1.24,0),'chrome',sections=44)
    m.bevel(t+'_LabelPanel',(.91,.25,.036),(0,.35,-.572),'bezel',.02)
    m.text(t+'_LabelText','JAM TRIP',.15,0,.35,-.595,'white',maxwidth=.82)
    return m

def make_status():
    m=Model('12_Jam_Timer_Trip_Monitor');t='L33_MONITOR'
    m.base(t,w=2.70,d=1.62,bodyh=1.24,fronttext='JAM GUARD',status='TIMER / TRIP / RESET')
    m.bevel(t+'_Screen_Rubber',(2.16,.61,.065),(0,1.22,-.843),'void',.04)
    m.bevel(t+'_Screen_OLED',(1.98,.47,.067),(0,1.23,-.888),'screen',.03)
    m.text(t+'_ThreePointZero','3.0 V TRIP',.183,0,1.36,-.933,'red',maxwidth=1.85)
    m.text(t+'_OnePointZero','1.0 V RESET',.143,0,1.13,-.933,'green',maxwidth=1.86)
    for i,(x,color,lab) in enumerate(zip((-.75,0,.75),('green','amber','red'),('RUN','WAIT','TRIP'))):
        m.cyl(t+f'_LED_{lab}',.089,.028,(x,1.62,-.79),color,axis='z',sections=26)
    m.box(t+'_CyanOLEDTopStatus',(.91,.036,.031),(0,1.69,-.70),'cyan')
    return m

BUILDERS=[make_supply,make_jam_charge,make_4k7,make_timer,make_1k,make_clear,
          make_motor_contact,make_motor,make_conveyor,make_sensor,make_warning,make_status]
STAGING={
 '01_5V_Supply':(10.2,.55,3.28),
 '02_JAM_Charge_Switch':(7.25,.55,3.28),
 '03_4p7kOhm_Charge_Resistor':(4.3,.55,3.28),
 '04_470uF_Timer_Capacitor':(1.35,.55,3.28),
 '05_1kOhm_Clear_Resistor':(-1.6,.55,3.28),
 '06_CLEAR_Discharge_Switch':(-4.55,.55,3.28),
 '07_Motor_Protection_Contact':(-7.5,.55,3.28),
 '08_DC_Motor_33Ohm':(-10.45,.55,3.28),
 '09_JamGuard_Industrial_Conveyor':(6.5,.55,-2.48),
 '10_Overhead_Jam_Sensor':(-.99,.55,-2.55),
 '11_Jam_Alarm_Beacon':(-2.1,.55,-2.55),
 '12_Jam_Timer_Trip_Monitor':(-5.55,.55,-2.48),
 '00_Optional_Showcase_Board':(0,0,0),
}
CONNECTIONS=[
 ('W01','Battery_positive','JAM_IN'),
 ('W02','JAM_OUT','R47_IN'),
 ('W03','R47_OUT','TIMER_POS'),
 ('W04','TIMER_NEG','Battery_negative'),
 ('W05','TIMER_POS','R1K_IN'),
 ('W06','R1K_OUT','CLEAR_IN'),
 ('W07','CLEAR_OUT','Battery_negative'),
 ('W08','Battery_positive','MOTOR_CONTACT_IN'),
 ('W09','MOTOR_CONTACT_OUT','Motor_A'),
 ('W10','Motor_B','Battery_negative'),
]

def build_board():
    m=Model('00_Optional_Showcase_Board');t='L33_SHOWCASE'
    m.bevel(t+'_RubberSubstrate',(27.4,.14,10.96),(0,.07,0),'rubber',.12)
    m.bevel(t+'_ChromeRim',(27.36,.20,10.91),(0,.24,0),'steel',.13)
    m.bevel(t+'_AnodizedBlackPerforatedWorkbench',(27.05,.084,10.63),(0,.419,0),'graphite',.11)
    for x in (-13.49,13.49):m.box(t+f'_SideNeon_{x}',(.05,.032,10.25),(x,.48,0),'cyan')
    for z in (-5.25,5.25):m.box(t+f'_HorizontalNeon_{z}',(26.7,.03,.05),(0,.481,z),'cyan')
    dots=[]
    for x in np.linspace(-13.12,13.12,60):
        for z in np.linspace(-4.94,4.94,21):
            p=trimesh.creation.cylinder(radius=.011,height=.004,sections=6)
            p.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
            p.apply_translation((float(x),.482,float(z)));dots.append(p)
    m.add(t+'_BatchedPegboardDots',trimesh.util.concatenate(dots),'mid_steel')
    return m

def main():
    mods=[f() for f in BUILDERS]
    assert len(mods)==12
    terminal_names=[k for mod in mods for k in mod.anchors]
    assert len(terminal_names)==16,terminal_names
    assert len(set(terminal_names))==16
    assert len(CONNECTIONS)==10
    for w,a,b in CONNECTIONS: assert a in terminal_names and b in terminal_names,(w,a,b)
    manifest={}
    for model in mods:
        fbx=MODELS/(model.key+'.fbx');glb=MODELS/(model.key+'.glb')
        export_fbx(fbx,[model]);export_glb(glb,[model])
        manifest[model.key]={
            'fbx':fbx.name,'glb':glb.name,'mesh_objects':len(model.parts),
            'triangles':int(sum(len(p.mesh.faces) for p in model.parts)),
            'terminals':model.anchors,
            'animation_groups':list(dict.fromkeys(p.group for p in model.parts if 'ANIMATE' in p.group or 'VISUAL' in p.group)),
        }
        print('BUILT',model.key,manifest[model.key]['triangles'],'triangles',flush=True)
    board=build_board();allmods=[board]+mods
    export_fbx(MODELS/'Level33_Complete_ArtKit_Showcase.fbx',allmods,positions=STAGING)
    export_glb(MODELS/'Level33_Complete_ArtKit_Showcase.glb',allmods,positions=STAGING)
    tris=sum(len(p.mesh.faces) for mod in allmods for p in mod.parts)
    manifest['Level33_Complete_ArtKit_Showcase']={
       'fbx':'Level33_Complete_ArtKit_Showcase.fbx','glb':'Level33_Complete_ArtKit_Showcase.glb',
       'triangles':int(tris),'mesh_objects':sum(len(x.parts) for x in allmods)}
    (ROOT/'Model_Manifest.json').write_text(json.dumps({
        'level':33,'title':'Jam Guard — Delayed Trip and Manual Reset',
        'project':'Project Spark',
        'model_count':len(mods),'socket_count':16,'wire_count':10,
        'coordinate_system':'Y-up, front sockets on negative local Z. Local coordinates in units of model geometry; adapt Unity scale.',
        'wiring':[{'wire':w,'from':a,'to':b} for w,a,b in CONNECTIONS],
        'items':manifest,'showcase_positions':STAGING,
    },indent=2),encoding='utf8')
    with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf8') as f:
        wr=csv.writer(f);wr.writerow(['Model FBX','Runtime Terminal ID','local_X','local_Y','local_Z','Suggested GameObject'])
        for model in mods:
            for id,(x,y,z) in model.anchors.items():wr.writerow([model.key+'.fbx',id,x,y,z,id])
    with (ROOT/'Exact_Wiring.csv').open('w',newline='',encoding='utf8') as f:
        wr=csv.writer(f);wr.writerow(['Wire','From terminal ID','To terminal ID']);wr.writerows(CONNECTIONS)
    print('EXPORT COMPLETE:',len(mods),'models, 16 terminals, 10 wires; showcase',tris,'triangles',flush=True)

if __name__=='__main__':main()
