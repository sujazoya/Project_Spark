import os,sys,math,csv,json,pathlib
import numpy as np,trimesh
sys.path.insert(0,'/mnt/data/ProjectSpark_Level57_HD_AAA/Source')
import l57_core as c
from l57_core import box,cyl,tor,ann,beam,bolt,led,text_geo,cable
ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level64_HD_AAA')
for s in ['Models','GLB','Previews','Unity_Optional','Source']:(ROOT/s).mkdir(parents=True,exist_ok=True)
c.ROOT=ROOT;c.assets=[]
names=['IndustrialTransientStabilityBase','SynchronousGeneratorA','SynchronousGeneratorB','PrimeMoverA','PrimeMoverB','GeneratorBreakerA','GeneratorBreakerB','ThreePhaseBusA','ThreePhaseBusB','TransmissionFeederA','TransmissionFeederB','FeederBreakerA_In','FeederBreakerA_Out','FeederBreakerB_In','FeederBreakerB_Out','GeneratorEncoderA','GeneratorEncoderB','SynchrophasorMeasurementUnitA','SynchrophasorMeasurementUnitB','CurrentTransformerBankA','CurrentTransformerBankB','DistanceProtectionRelayA','DistanceProtectionRelayB','DifferentialProtectionRelay','OutOfStepProtectionRelay','FaultInjectionChamber','CriticalClearingTimeAnalyzer','PowerAngleAnalyzer','GeneratorExcitationController','GeneratorGovernorController','PowerSystemStabilizer','IndustrialLoadBank','TransientStabilityMasterController','HolographicStabilityMonitor','TransparentSafetyEnclosure','Regulated5VControlSupply']
c.MODELS=['L64_'+n for n in names]
def b(n,x,y,z,w,h,d,mat='blue_steel',group=None):box(n,(x,y,z),(w,h,d),mat,group)
def txt(n,s,x,y,z,w=1,size=.065,mat='white',group=None):text_geo(n,s,(x,y,z),w,size,mat,group)
def jack(n,x,y,z,col='cyan'):
 cyl(n+'Bezel',(x,y,z),.055,.019,'z','chrome',14);cyl(n+'Ins',(x,y,z+.015),.036,.017,'z',col,12);cyl(n+'Pin',(x,y,z+.026),.012,.012,'z','dark',12)
def case(n,x,y,z,w,h,d,ttl,accent='cyan',ports=4):
 b(n+'Body',x,y,z,w,h,d,'blue_steel');b(n+'Face',x,y,z+d/2+.012,w-.06,h-.08,.025,'navy');b(n+'Crown',x,y+h/2+.015,z,w+.02,.04,d+.025,'titanium');b(n+'Light',x,y+h/2+.042,z+d*.32,w-.13,.016,.026,accent)
 for sx in [-1,1]:
  for sy in [-1,1]:bolt(n+'Bolt'+str(sx)+str(sy),(x+sx*(w/2-.068),y+sy*(h/2-.069),z+d/2+.034),'z',.018)
 txt(n+'Title',ttl,x-w*.43,y+h*.31,z+d/2+.038,w*.86,.071)
 b(n+'ScreenFrame',x,y+.04,z+d/2+.038,w*.63,h*.34,.018,'silver_dark');b(n+'Screen',x,y+.04,z+d/2+.053,w*.57,h*.29,.012,'display')
 for j in range(9):b(n+'Graph'+str(j),x-w*.25+j*w*.061,y+.03+math.sin(j*.75)*h*.065,z+d/2+.065,w*.031,.009,.007,accent)
 for j in range(ports):jack(n+'Terminal'+str(j),x+(j-(ports-1)/2)*(w-.23)/max(1,ports-1),y-h*.31,z+d/2+.054,['red','amber','electric','cyan','green','violet'][j%6])
 led(n+'Status',(x-w*.38,y+.07,z+d/2+.062),'green',.027)
def mini(i,x,y,z,ttl,accent='cyan',w=1.03,h=.85):
 c.start(i);case(names[i],x,y,z,w,h,.64,ttl,accent,4)
def motor(n,x,y,z,length=1.55,r=.53,pivot=None,reverse=False):
 b(n+'Foundation',x,y-r-.18,z,length+.38,.18,1.34,'titanium');cyl(n+'Body',(x,y,z),r,length,'x','electric',44)
 for k in range(20):b(n+'CoolingFin'+str(k),x-length*.46+k*length*.048,y+r+.025,z,.039,.10,r*1.83,'silver_dark')
 for xx in [-length*.43,length*.43]:
  ann(n+'WindingRing'+str(xx),(x+xx,y,z),r*.85,r*.62,.10,'x','copper',48,pivot)
  tor(n+'ChromeFlange'+str(xx),(x+xx,y,z),r*.86,.045,'x','chrome',44,8)
 cyl(n+'RotorShaft',(x+(length*.57 if not reverse else -length*.57),y,z),.092,.49,'x','chrome',22,pivot)
 for j in range(14):
  a=math.tau*j/14;beam(n+'Screw'+str(j),(x+length*.47,y+math.cos(a)*r*.73,z+math.sin(a)*r*.73),(x+length*.52,y+math.cos(a)*r*.73,z+math.sin(a)*r*.73),.024,'gold',8)
def breaker(i,x,y,z,title):
 c.start(i);case(names[i],x,y,z,.81,.78,.62,title,'amber',3);gp='ANIM_BREAKER_HANDLE';b('SwitchHandle',x,y+.005,z+.39,.16,.23,.13,'red',gp)
 for k in range(3):b('CopperContact'+str(k),x-.19+k*.19,y-.18,z+.39,.10,.14,.044,'chrome',gp)
 c.current.pivot(gp,(x,y,z+.39))
# main chassis 0
c.start(0)
b('CNCPrecisionDeck',0,.06,0,14.9,.32,7.6,'titanium');b('GraphiteMachinedWorktop',0,.28,0,14.55,.06,7.25,'carbon')
b('FrontConsole',0,.56,3.43,14.45,.49,.49,'navy');b('ConsoleLED',0,.84,3.53,14.28,.022,.06,'cyan')
for x in [-7.10,7.10]:
 for z in [-3.42,3.42]:cyl('MountFoot',(x,-.17,z),.18,.18,'y','rubber',16)
for j in range(62):
 x=-7.02+j*.23;cyl('SocketBezel'+str(j),(x,.51,3.70),.040,.015,'z','chrome',12);cyl('SocketInsulator'+str(j),(x,.51,3.718),.025,.013,'z',['red','amber','electric','cyan','green'][j%5],12)
txt('Plate','PROJECT SPARK - LEVEL 64 / TRANSIENT STABILITY',-5.27,.82,3.72,10.5,.16)
for j in range(48):b('CoolingDeckSlot'+str(j),-6.92+j*.292,.31,2.65,.045,.017,.25,'silver_dark')
# generators & prime movers
for i,x,pivot,ttl in [(1,-5.20,'ANIM_GENERATOR_A','SYNCHRONOUS GENERATOR A'),(2,5.20,'ANIM_GENERATOR_B','SYNCHRONOUS GENERATOR B')]:
 c.start(i);motor(names[i],x,1.49,-2.22,1.82,.57,pivot,reverse=i==2);c.current.pivot(pivot,(x,1.49,-2.22));txt('Identity',ttl,x-1.10,2.31,-1.52,2.19,.086)
 for k in range(10):
  ang=k*math.tau/10
  beam('VentCoil'+str(k),(x+.68,1.49+math.cos(ang)*.41,-2.22+math.sin(ang)*.41),(x+.75,1.49+math.cos(ang)*.41,-2.22+math.sin(ang)*.41),.031,'copper',10,pivot)
for i,x,piv in [(3,-3.30,'ANIM_PRIME_MOVER_A'),(4,3.30,'ANIM_PRIME_MOVER_B')]:
 c.start(i);motor(names[i],x,1.38,-2.28,1.14,.37,piv);c.current.pivot(piv,(x,1.38,-2.28))
 for k in range(6):cyl('Cylinder'+str(k),(x-.44+k*.17,1.88,-2.28),.081,.32,'y','silver_dark',12)
# breaker source
breaker(5,-6.32,1.11,-.60,'GEN A BRK');breaker(6,6.32,1.11,-.60,'GEN B BRK')
# 2 bus assemblies left/right
for i,x in [(7,-5.50),(8,5.50)]:
 c.start(i)
 for k,(y,mat) in enumerate([(2.45,'red'),(2.20,'amber'),(1.95,'electric')]):
  b('BusPhase'+str(k),x,y,-.12,2.70,.095,.10,'copper')
  for j in range(6):b('BusSupport'+str(k)+'_'+str(j),x-1.21+j*.49,y-.12,-.12,.1,.21,.18,'rubber')
 for j in range(10):bolt('TerminalBolt'+str(j),(x-1.22+j*.265,2.52,-.05),'y',.033)
# feeder A/B visual line assemblies
for i,z,mat,title in [(9,-.40,'red','FAULTABLE FEEDER A'),(10,.92,'green','HEALTHY FEEDER B')]:
 c.start(i)
 b('FeederRail',0,.87,z,6.85,.16,.76,'silver_dark')
 for k,color in enumerate(['red','amber','electric']):
  yy=1.74-k*.18
  b('ThreePhaseCopper'+str(k),0,yy,z,6.40,.058,.057,'copper')
  for j in range(13):
   xx=-3.02+j*.50;b('PorcelainInsulator'+str(k)+'_'+str(j),xx,yy-.13,z,.075,.22,.11,'rubber')
 for j in range(8):b('LineJoint'+str(j),-2.73+j*.78,1.39,z+.32,.12,.22,.08,'silver_dark')
 txt('FeederLabel',title,-2.06,2.06,z+.41,4.12,.108,mat)
# feeder breakers 11-14
for i,x,z,t in [(11,-3.58,-.44,'CB-A1'),(12,3.58,-.44,'CB-A2'),(13,-3.58,.88,'CB-B1'),(14,3.58,.88,'CB-B2')]:breaker(i,x,1.16,z+1.04,t)
# encoders
for i,x,piv in [(15,-4.06,'ANIM_ENCODER_A'),(16,4.06,'ANIM_ENCODER_B')]:
 c.start(i);case(names[i],x,1.67,-1.40,.72,.66,.59,'ANGLE ENCODER','green',3)
 cyl('EncoderDisc',(x,1.62,-1.08),.22,.055,'z','chrome',32,piv)
 for j in range(32):
  a=math.tau*j/32;beam('EncoderMark'+str(j),(x+math.cos(a)*.172,1.62+math.sin(a)*.172,-1.035),(x+math.cos(a)*.208,1.62+math.sin(a)*.208,-1.035),.011,'dark',6,piv)
 c.current.pivot(piv,(x,1.62,-1.08))
# PMUs
mini(17,-6.68,2.73,-2.64,'SYNCHROPHASOR A','cyan',1.15,.82)
mini(18,6.68,2.73,-2.64,'SYNCHROPHASOR B','cyan',1.15,.82)
# current transformer banks
for i,x in [(19,-2.35),(20,2.35)]:
 c.start(i);b('CTBase',x,.78,2.06,1.18,.20,.72,'blue_steel')
 for j,mat in enumerate(['red','amber','electric']):
  xx=x-.31+j*.31;tor('CTRings'+str(j),(xx,1.08,2.06),.15,.059,'z','silver_dark',36,9);cyl('CTPrimary'+str(j),(xx,1.08,2.06),.031,.48,'z',mat,12)
 txt('CTLabel',names[i].replace('L64_','').upper(),x-.52,1.39,2.40,1.04,.065)
# protection banks front
mini(21,-5.95,.89,1.80,'DISTANCE A','amber',1.07,.94)
mini(22,5.95,.89,1.80,'DISTANCE B','amber',1.07,.94)
mini(23,-4.65,.89,1.80,'DIFFERENTIAL','cyan',1.16,.94)
mini(24,4.65,.89,1.80,'OUT OF STEP','red',1.16,.94)
# fault injector center luminous chamber
c.start(25);b('FaultPlatform',0,1.14,-.42,1.23,.25,.85,'titanium');b('FaultEnclosure',0,1.68,-.42,1.17,.86,.67,'navy')
for xx in [-.46,.46]:
 for yy in [1.35,1.99]:led('FaultWarning'+str(xx)+str(yy),(xx,yy,-.063),'red',.045)
for j in range(9):
 a=math.tau*j/9;beam('FaultArcSymbol'+str(j),(.03,1.74,-.04),(.34*math.cos(a),1.74+.31*math.sin(a),-.04),.019,'violet',9)
txt('FaultLabel','THREE-PHASE FAULT',-.53,2.17,-.04,1.05,.083,'red')
# analytics controls
mini(26,-3.20,.93,2.15,'CLEARING TIME','amber',1.28,.92)
mini(27,-1.73,.93,2.15,'POWER ANGLE','cyan',1.23,.92)
mini(28,-.34,.93,2.15,'EXCITATION','cyan',1.21,.92)
mini(29,1.05,.93,2.15,'GOVERNOR','green',1.20,.92)
mini(30,2.44,.93,2.15,'PSS DAMPER','violet',1.21,.92)
# industrial load bank
c.start(31);case('IndustrialLoadBank',6.75,1.27,.76,1.14,1.11,.82,'LOAD BANK','amber',4)
for k in range(4):b('ResistorBank'+str(k),6.36+k*.26,1.98,.76,.16,.23,.48,'silver_dark')
# master controller
mini(32,3.82,.94,2.18,'STABILITY CTRL','cyan',1.18,.94)
# holographic stability monitor raised behind center
c.start(33)
b('MonitorStem',0,2.95,-2.96,.22,.91,.35,'silver_dark')
b('MonitorOuterFrame',0,3.74,-3.03,6.24,1.85,.23,'blue_steel')
b('MonitorScreen',0,3.74,-2.901,6.00,1.61,.012,'display','ANIM_MONITOR_TILT')
for row in range(6):b('MonitorGridH'+str(row),-.60,3.28+row*.17,-2.885,4.44,.005,.008,'grid','ANIM_MONITOR_TILT')
for j in range(13):b('MonitorGridV'+str(j),-2.73+j*.37,3.70,-2.882,.006,1.14,.008,'grid','ANIM_MONITOR_TILT')
for series in range(2):
 for j in range(140):
  t=j/139
  if series==0: yy=3.74+.60*(1-math.exp(-t*2.5))*math.sin(t*2.8+1.4)
  else: yy=3.61+.24*math.sin(t*5.7)*math.exp(-t*2.3)
  b('RotorAngleTrace'+str(series)+'_'+str(j),-2.76+j*.033,yy,-2.864,.025,.010,.010,'red' if series==0 else 'green','ANIM_MONITOR_TILT')
txt('MonitorHeader','ROTOR-ANGLE TRANSIENT STABILITY',-2.75,4.46,-2.862,5.48,.132,'white','ANIM_MONITOR_TILT')
for j,mat in enumerate(['red','green','amber','cyan','violet']):b('StatusMetric'+str(j),-2.55+j*1.14,3.03,-2.867,.90,.12,.016,mat,'ANIM_MONITOR_TILT')
c.current.pivot('ANIM_MONITOR_TILT',(0,3.74,-3.03))
# safety enclosure, around line region
c.start(34)
for xx in [-3.80,3.80]:
 for zz in [-1.16,1.55]:beam('SafetyPost'+str(xx)+str(zz),(xx,.45,zz),(xx,2.79,zz),.047,'acrylic_rim',10)
for yy in [.45,2.79]:
 for zz in [-1.16,1.55]:beam('SafetyCrossbar'+str(yy)+str(zz),(-3.80,yy,zz),(3.80,yy,zz),.041,'acrylic_rim',10)
 for xx in [-3.80,3.80]:beam('SafetySidebar'+str(yy)+str(xx),(xx,yy,-1.16),(xx,yy,1.55),.041,'acrylic_rim',10)
b('SafetyTransparentDoor',0,1.58,1.565,7.47,2.20,.013,'acrylic','ANIM_SAFETY_DOOR');c.current.pivot('ANIM_SAFETY_DOOR',(-3.80,2.79,1.56))
led('EnclosureSafetyIndicator',(-3.52,2.54,1.591),'green',.037)
# control supply
mini(35,6.69,.83,2.60,'5V CONTROL','green',1.11,.80)
# export
manifest={'level_id':'level_64','display_name':'Hold the Synchronism','subtitle':'Transient rotor-angle stability and critical fault clearing','asset_kind':'procedural modular art, AAA-inspired; not authored PBR texture polished','individual_models':36,'planned_player_wires':62,'planned_unique_terminals':96,'functional_terminals_included':False,'transient_stability_physics_included':False,'unity_play_mode_tested':False,'coordinate_system':'X workstation width; Y vertical; Z front electronics; 1 unit=1 meter','models':[]}
assert len(c.assets)==36,len(c.assets)
for i,a in enumerate(c.assets):
 stem=f'{i:02d}_{a.name}';fbx=ROOT/'Models'/(stem+'.fbx');glb=ROOT/'GLB'/(stem+'.glb')
 c.fbx_export([a],fbx,a.name);c.glb_export(a,glb)
 triangles=sum(len(p.mesh.faces) for p in a.parts)
 manifest['models'].append({'index':i,'name':a.name,'file':fbx.name,'glb':glb.name,'triangle_count':triangles,'mesh_parts':len(a.parts),'animation_pivots':{k:v.tolist() for k,v in a.groups.items()}})
 print('EXPORTED',i,stem,triangles,flush=True)
c.fbx_export(c.assets,ROOT/'Models'/'Level64_Complete_ArtKit_Showcase.fbx','showcase')
scene=trimesh.Scene()
for a in c.assets:
 for p in a.parts:
  m=p.mesh.copy();m.visual.vertex_colors=np.tile((np.array(c.C[p.mat])*255).astype('uint8'),(len(m.vertices),1));scene.add_geometry(m,geom_name=a.name+'__'+p.name)
(ROOT/'GLB'/'Level64_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
manifest['triangle_count']=sum(x['triangle_count'] for x in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with open(ROOT/'Animation_Rigs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['model','pivot','x','y','z'])
 for a in c.assets:
  for k,v in a.groups.items():w.writerow([a.name,k,*v.tolist()])
print('COMPLETE',len(c.assets),manifest['triangle_count'],flush=True)
