PROJECT SPARK - LEVEL 58 / ISOLATE THE FAULT
VISUAL ASSET PACK (24 procedural 3D models)

CONTENTS
Models/       24 standalone FBX 7.4 models + 1 assembled showcase FBX
GLB/          24 standalone GLB backups + 1 assembled showcase GLB
Previews/     Level 58 assembled 3D render + 24-model contact sheet
Model_Manifest.json     Mesh counts and animation pivots
Animation_Rigs.csv      Named transform pivots
Unity_Optional/         Unity Editor art placement utility (art only)
Source/                 Python generator and VTK preview source

UNITY IMPORT
1. Copy Models/00_*.fbx through Models/23_*.fbx into Assets/ProjectSpark/Level58/Art/.
2. Import the ArtPlacementEditor C# script into an Editor folder.
3. Select the Level 58 layout parent in Unity Hierarchy.
4. Use Tools > Project Spark > Levels > 58 > Place HD Art Under Selected Layout.
5. All models use a common bench coordinate system (X width, Y up, Z front) and common origin.
6. Validate actual Unity import dimensions and material appearance. Set scale consistently.
7. Don't show the full assembled showcase along with the 24 individual models.
8. FBX materials use color regions / Phong; configure URP/HDRP lit shaders as desired.
9. For acrylic, set transparent mode/alpha as necessary in your render pipeline.
10. Hook up animation pivots using real simulated breaker and control state.

IMPORTANT
These are 3D VISUAL ART assets, not a playable Level 58.
The art does not provide 38 real wires, 60 circuit terminals, electrical topology,
three-phase fault simulation, relay coordination, CT calibration, six objectives,
or Project Spark evaluator integration. Those require implementing and testing
against the real Unity codebase. Decorative sockets are NOT SparkTerminal components.
Individual FBXs use the same local bench origin so instantiate all at zero.
The generator is procedurally modeled and AAA-inspired, not artist-authored
photorealistic PBR assets. Some labeling and surface materials need Unity refinement.
No Unity Editor import, Play Mode, or compilation test was performed here.
