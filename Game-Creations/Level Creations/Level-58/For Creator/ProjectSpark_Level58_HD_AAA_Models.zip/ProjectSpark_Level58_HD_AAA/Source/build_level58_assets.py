import sys,os,math,json,csv,pathlib,shutil,zipfile,hashlib
import numpy as np, trimesh
sys.path.insert(0,'/mnt/data/ProjectSpark_Level57_HD_AAA/Source')
import l57_core as c
ROOT=pathlib.Path('/mnt/data/ProjectSpark_Level58_HD_AAA')
for d in ['Models','GLB','Previews','Unity_Optional','Source']:(ROOT/d).mkdir(parents=True,exist_ok=True)
c.ROOT=ROOT;c.assets=[]
NAMES=['IndustrialProtectionBase','ThreePhaseGridSource','MainIncomingBreaker','ThreePhaseDistributionBus','FeederBreakerA','FeederBreakerB','FeederBreakerC','MainCurrentTransformer','FeederCurrentTransformerA','FeederCurrentTransformerB','FeederCurrentTransformerC','MainProtectionRelay','FeederProtectionRelayA','FeederProtectionRelayB','FeederProtectionRelayC','VoltageMonitoringModule','SmartLoadBankA','MotorLoadB','PriorityLoadC','FaultInjectionUnit','ProtectionCoordinationController','HolographicProtectionMonitor','TransparentSafetyEnclosure','Regulated5VSupply']
c.MODELS=['L58_'+v for v in NAMES]
from l57_core import box,cyl,ann,tor,beam,bolt,led,text_geo,cable

def b(n,x,y,z,w,h,d,mat='blue_steel',group=None):box(n,(x,y,z),(w,h,d),mat,group)
def label(n,s,x,y,z,span=.8,size=.065):text_geo(n,s,(x,y,z),span,size,'white')
def jacks(n,x,y,z,nj=5,accent='cyan',span=.7):
 for i in range(nj):
  xx=x+(i-(nj-1)/2)*span/max(1,nj-1)
  cyl(f'{n}_Ring{i}',(xx,y,z),.065,.026,'z','silver',18)
  cyl(f'{n}_Colored{i}',(xx,y,z+.018),.044,.016,'z',['red','amber','electric','cyan','green'][i%5],18)
  cyl(f'{n}_Core{i}',(xx,y,z+.030),.017,.008,'z','dark',12)
def cabinet(n,x,y,z,w,h,d,accent='cyan',toptext='',sockets=5):
 b(n+'_Housing',x,y,z,w,h,d,'blue_steel');b(n+'_Front',x,y,z+d/2+.015,w-.075,h-.08,.035,'navy')
 b(n+'_TopLip',x,y+h/2+.022,z,w+.05,.05,d+.04,'silver_dark')
 b(n+'_Accent',x,y+h/2+.056,z+d*.28,w-.12,.015,.028,accent)
 for sx in [-1,1]:
  for sy in [-1,1]:bolt(n+f'_Screw{sx}{sy}',(x+sx*(w/2-.1),y+sy*(h/2-.11),z+d/2+.045),'z',.025)
 if toptext:label(n+'_Label',toptext,x-w*.43,y+h*.26,z+d/2+.042,w*.86,.07)
 led(n+'_Power',(x-w*.37,y+.04,z+d/2+.04),'green',.037,'z')
 jacks(n+'_Sockets',x,y-h*.22,z+d/2+.045,sockets,accent,w-.20)
def screen(n,x,y,z,w=.7,h=.28):
 b(n+'_Screen',x,y,z,w,h,.022,'display')
 for q in range(7):
  xx=x-w*.39+q*w*.13
  beam(f'{n}_Trace{q}',(xx,y-.06,z+.022),(xx,y-.02+.045*math.sin(q*.9),z+.022),.008,'cyan',7)
def relay(idx,x,z,title,accent='cyan'):
 c.start(idx);cabinet(title.replace(' ','_'),x,1.08,z,1.13,.70,.58,accent,title,4)
 screen('TripCurveLCD',x,1.12,z+.318,.48,.19)
 for q in range(3):led(f'Status_{q}',(x-.36+q*.16,1.0,z+.335),['green','amber','red'][q],.032,'z')
 for q in range(4):
  cx=x-.40+q*.26
  cyl('SettingKnob', (cx,.84,z+.35),.052,.030,'z','silver',12)
def breaker(idx,x,z,n,accent='green',main=False):
 c.start(idx)
 cabinet(n,x,1.12,z,1.00 if not main else 1.18,1.03,.74,accent,n,3)
 b('BreakerMechanism',x,1.11,z+.411,.48,.40,.10,'silver_dark')
 b('BreakerHandle',x,1.11,z+.49,.14,.30,.14,'chrome','ANIM_BREAKER_HANDLE')
 b('BreakerHandleGrip',x,1.25,z+.55,.21,.075,.13,'red','ANIM_BREAKER_HANDLE')
 c.current.pivot('ANIM_BREAKER_HANDLE',(x,1.10,z+.49))
 b('TripBadge',x,.88,z+.47,.45,.10,.026,'red' if 'B' in n else 'green')
 for i in range(3):
  xx=x+(i-1)*.20
  cyl(f'BusContact{i}',(xx,1.7,z-.15),.055,.16,'y',['red','amber','electric'][i],16)
def ct(idx,x,z,n):
 c.start(idx)
 b(n+'_CTPlinth',x,.61,z,.83,.25,.68,'carbon')
 for k in range(3):
  xx=x+(k-1)*.23
  ann(n+f'_ToroidalCore{k}',(xx,1.08,z),.19,.105,.10,'z','silver_dark',48)
  ann(n+f'_CopperWinding{k}',(xx,1.08,z+.065),.155,.130,.07,'z','copper',40)
  for j in range(8):
   a=j*math.tau/8
   cyl(n+f'_WindingStud{k}_{j}',(xx+.144*math.cos(a),1.08+.144*math.sin(a),z+.10),.014,.052,'z','amber',8)
 jacks(n+'_CTFeed',x,.62,z+.38,3,'cyan',.5)
def load(idx,x,z,n,color='cyan',motor=False):
 c.start(idx)
 cabinet(n,x,.95,z,1.1,.72,.72,color,n,4)
 if motor:
  cyl('MotorBody',(x,1.63,z-.15),.28,.80,'x','blue_steel',40,'ANIM_MOTOR_SPIN')
  for i in range(12):b('MotorCoolingFin',x-.30+i*.052,1.88,z-.15,.027,.08,.50,'silver')
  cyl('MotorShaft',(x+.48,1.63,z-.15),.095,.40,'x','chrome',24,'ANIM_MOTOR_SPIN')
  c.current.pivot('ANIM_MOTOR_SPIN',(x,1.63,z-.15))
 else:
  for i in range(8):b(f'{n}_ResistorFin{i}',x-.39+i*.11,1.54,z-.15,.042,.35,.52,'silver')
  b(f'{n}_LoadHeatbar',x,1.70,z-.15,.95,.035,.55,color)

# 00 base
c.start(0)
b('MachinedTitaniumBench',0,.10,0,9.9,.36,5.9,'titanium');b('InsetGraphiteDeck',0,.32,0,9.7,.08,5.70,'carbon')
b('FrontConnectionRail',0,.65,2.35,9.66,.54,.56,'navy')
for q in range(14):
 x=-4.5+q*.69;b('VentSlot',x,.69,2.64,.035,.20,.015,'silver_dark')
for z in [-2.77,2.77]:b('EdgeLight',0,.36,z,9.60,.025,.034,'cyan')
for x in [-4.65,4.65]:b('SideEdge',x,.36,0,.045,.055,5.8,'chrome')
for x in [-4.5,4.5]:
 for z in [-2.55,2.55]:cyl('RubberIsolationFoot',(x,-.21,z),.16,.23,'y','rubber',20)
label('Brand','PROJECT SPARK - PROTECTION LAB',-2.60,.62,2.67,5.4,.12)
for k in range(28):cyl('FrontSocketBezel',(-4.56+k*.33,.64,2.71),.068,.02,'z','chrome',16)
# 01 source
c.start(1);cabinet('ThreePhaseGridGenerator',-4.05,1.21,-1.70,1.35,1.54,.78,'cyan','GRID SOURCE',5)
screen('PowerWaveMonitor',-4.05,1.45,-1.28,.84,.34)
for i,col in enumerate(['red','amber','electric']):cyl('PhaseOutput',(-4.37+i*.30,.95,-1.25),.075,.06,'z',col,22)
# 02 main breaker
breaker(2,-2.85,-.65,'MAIN CB','cyan',True)
# 03 busbars
c.start(3)
b('PolycarbonateBackplate',0,1.52,-.60,6.2,1.70,.075,'acrylic')
for k,(dy,col,ph) in enumerate([(1.98,'red','A'),(1.64,'amber','B'),(1.30,'electric','C')]):
 beam('CopperBus'+ph,(-3.25,dy,-.30),(3.25,dy,-.30),.09,col,20)
 for x in [-3,-1.5,0,1.5,3]:
  b('CeramicStandoff',x,dy-.15,-.43,.18,.30,.17,'white')
  bolt('BusClamp',(x,dy+.08,-.21),'y',.045)
 label('PhaseName'+ph,ph,-3.30,dy+.065,-.18,.25,.12)
for x in [-3.3,3.3]:b('BusSupport',x,1.52,-.45,.14,1.80,.28,'titanium')
# 04-06 feeder breakers
for i,x,n in [(4,-1.45,'FEEDER A'),(5,.05,'FEEDER B'),(6,1.55,'FEEDER C')]:breaker(i,x,.45,n,'red' if i==5 else 'green')
# 07-10 CT
ct(7,-2.8,1.43,'MAIN_CT')
for i,x,n in [(8,-1.45,'CT_A'),(9,.05,'CT_B'),(10,1.55,'CT_C')]:ct(i,x,1.42,n)
# 11-14 relays positioned front
relay(11,-3.25,1.90,'MAIN RELAY','cyan')
for idx,x,nam in [(12,-1.42,'RELAY A'),(13,.05,'RELAY B'),(14,1.52,'RELAY C')]:relay(idx,x,1.90,nam,'red' if idx==13 else 'green')
# 15 monitor
c.start(15);cabinet('ThreePhaseVoltageSensor',-4.05,.87,.15,1.26,.94,.74,'cyan','VOLTAGE MONITOR',5)
screen('PhaseVoltageTrace',-4.05,.96,.55,.82,.31)
for k in range(3):led('PhaseValid',(-4.47,.68+k*.11,.57),'green',.034,'z')
# 16-18 loads located back around bus
load(16,-1.4,-1.63,'LOAD A','cyan')
load(17,.05,-1.63,'MOTOR B','amber',motor=True)
load(18,1.55,-1.63,'PRIORITY C','green')
# 19 fault injection unit
c.start(19);cabinet('ControlledFaultInjection',3.50,1.75,-1.58,1.66,.98,.79,'red','SIMULATED FAULT',5)
for i,(col,name) in enumerate([('amber','OVERLOAD'),('red','SHORT'),('red','FAIL')]):
 xx=3.07+i*.43
 cyl('FaultButton'+name,(xx,1.75,-1.12),.12,.08,'z',col,30)
 label('FaultTag'+name,name,xx-.17,1.50,-1.13,.36,.048)
# 20 coordination controller
c.start(20);cabinet('SelectivityController',0,2.76,-1.74,2.08,.86,.70,'cyan','PROTECTION CTRL',6)
screen('SettingsDisplay',0,2.78,-1.35,1.35,.37)
for k in range(3):led('ControllerStatus',( -.65+k*.37,2.48,-1.35),['green','amber','cyan'][k],.047,'z')
# 21 monitor right rear on stand
c.start(21)
b('MonitorPedestal',3.52,1.14,-.36,.19,1.27,.22,'silver_dark')
b('MonitorStand',3.52,1.87,-.36,1.43,.14,.75,'titanium')
b('HolographicFrame',3.54,2.65,-.52,2.50,1.48,.20,'blue_steel')
b('MainDisplay',3.54,2.65,-.38,2.31,1.31,.03,'display','ANIM_MONITOR_TILT')
for k in range(14):
 x=2.65+k*.14;beam('GraphSample',(x,2.42,-.348),(x,2.42+.10+.17*math.sin(k*.66),-.348),.009,'cyan',8,'ANIM_MONITOR_TILT')
for k in range(3):
 x=2.85+k*.67;b('FeederStatusBar',x,2.97,-.348,.42,.10,.018,['green','red','green'][k],'ANIM_MONITOR_TILT')
c.current.pivot('ANIM_MONITOR_TILT',(3.52,2.65,-.52))
label('ScreenTitle','FAULT LOCATION / TIME CURVES',2.45,3.22,-.342,2.2,.073)
# 22 enclosure transparent skeleton
c.start(22)
for x in [-3.35,2.48]:
 for z in [-.91,.82]:beam('VerticalSafetyUpright',(x,.51,z),(x,2.35,z),.029,'acrylic_rim',10)
for y in [.51,2.35]:
 for z in [-.91,.82]:beam('SafetyHorizontal',( -3.35,y,z),(2.48,y,z),.028,'acrylic_rim',10)
 for x in [-3.35,2.48]:beam('SafetyCross',(x,y,-.91),(x,y,.82),.028,'acrylic_rim',10)
b('FrontSafetyDoor',-.44,1.41,.84,5.64,1.74,.018,'acrylic','ANIM_SAFETY_DOOR')
c.current.pivot('ANIM_SAFETY_DOOR',(-3.35,2.35,.84))
for xx in [-3.20,2.35]:led('GuardStatus',(xx,2.29,.87),'green',.025,'z')
# 23 supply
c.start(23);cabinet('Regulated5VSupply',-4.08,.88,1.50,1.23,.84,.80,'cyan','5V SUPPLY',2)
screen('SupplyReadout',-4.08,.94,1.93,.65,.26)
label('Supply5V','5.00 V',-4.33,.90,1.952,.53,.09)

manifest={'level_id':'level_58','display_name':'Isolate the Fault','asset_kind':'procedural 3D visual art only','individual_models':24,'planned_player_wires':38,'planned_unique_sockets':60,'terminals_implemented':False,'physics_implemented':False,'coordinate_system':'X bench width; Y up; Z front. 1 art unit = 1 Unity meter when import scale=1','models':[]}
for i,asset in enumerate(c.assets):
 prefix=f'{i:02d}_{asset.name}'
 fbx=ROOT/'Models'/f'{prefix}.fbx';glb=ROOT/'GLB'/f'{prefix}.glb'
 c.fbx_export([asset],fbx,asset.name)
 c.glb_export(asset,glb)
 faces=sum(len(p.mesh.faces) for p in asset.parts)
 manifest['models'].append({'file':fbx.name,'glb':glb.name,'name':asset.name,'triangle_count':faces,'mesh_parts':len(asset.parts),'animation_pivots':{k:v.tolist() for k,v in asset.groups.items()}})
 print(prefix,'faces',faces,'parts',len(asset.parts),flush=True)
c.fbx_export(c.assets,ROOT/'Models'/'Level58_Complete_ArtKit_Showcase.fbx','showcase')
scene=trimesh.Scene()
for a in c.assets:
 for p in a.parts:
  m=p.mesh.copy();m.visual.vertex_colors=np.tile((np.array(c.C[p.mat])*255).astype('uint8'),(len(m.vertices),1))
  scene.add_geometry(m,geom_name=a.name+'__'+p.name)
(ROOT/'GLB'/'Level58_Complete_ArtKit_Showcase.glb').write_bytes(scene.export(file_type='glb'))
manifest['triangle_count']=sum(m['triangle_count'] for m in manifest['models'])
(ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2))
with open(ROOT/'Animation_Rigs.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['model','pivot','x','y','z'])
 for a in c.assets:
  for name,p in a.groups.items():w.writerow([a.name,name,*p.tolist()])
print('MODELS EXPORTED',manifest['triangle_count'],flush=True)
