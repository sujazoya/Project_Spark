# Project Spark — Level 43: Hold the Line (Unity art integration)

The nine models in this pack are **visual geometry**; electrical solving, motor reversal, sensor readings, and objective completion must remain under your existing Level 43 gameplay scripts.

## Workbench composition

Import the *individual* FBXs into your active layout prefab. The assembled showcase is a visual example only. Place `L43_CommandModule` and `L43_Controller` across the rear; put `L43_RailBase` and `L43_Carriage` centrally, the `L43_MotorAssembly` at the drive end, the `L43_PositionSensor` along the rear edge of the rail, and `L43_MotorDriver` in the front row. Place Station A and B markers adjacent to the ruler at 25% and 75% of carriage travel. The source supply remains your existing 5 V prefab.

You must scale/align each individual mesh to your Project Spark breadboard, then create **real `SparkTerminal` components at verified socket locations**. The supplied `Terminal_Anchors.csv` contains 17 illustrative art-facing sockets, *not* the missing authoritative runtime binding IDs. These positions cannot automatically guarantee alignment with a user-specific workbench.

## Moving pieces

| Model | Named FBX group | Gameplay feed |
|---|---|---|
| Carriage | `Carriage_Move_X_ANIMATE` | measured carriage position |
| Position pointer | `CarriagePointer_VISUAL_MOVE_X` | same displacement as carriage |
| DC motor | `MotorShaft_ROTATE_X` | actual signed motor drive; no rotation when stopped |
| Position sensor | `SensorWiper_Move_X_ANIMATE` | measured carriage position |
| Command module | `StationSelector_A_PRESS_ANIMATE`, `StationSelector_B_PRESS_ANIMATE` | command state / button press |
| Command module | `Button_JOGL_PRESS_ANIMATE`, `Button_JOGR_PRESS_ANIMATE`, `Button_NUDGEL_PRESS_ANIMATE`, `Button_NUDGER_PRESS_ANIMATE` | button input animation |
| Controller | `DriveStatus_DRIVELEFT_Lamp_VISUAL`, `DriveStatus_STOP_Lamp_VISUAL`, `DriveStatus_DRIVERIGHT_Lamp_VISUAL` | actual controller state |
| Motor driver | `Driver_LEFT_Lamp_VISUAL`, `Driver_SAFESTOP_Lamp_VISUAL`, `Driver_RIGHT_Lamp_VISUAL` | actual driver state |
| Station markers | `StationBeacon_VISUAL` | arrival/highlight state |

Art preview travel uses `x=-5.2` to `x=+5.2`; Station A `x=-2.6` and Station B `x=+2.6`. Use scene-space transforms after any scaling/mirroring. The motor and pointer positions are not force-connected to those coordinates until you assign an actual Unity rig. As an illustration, a linear 0–5 V position sensor would read about 1.25 V and 3.75 V at those two fractions, respectively; solver values take precedence.

The included `SparkLevel43VisualMotionRig.cs` is an **optional visual adapter**, not a functional controller. In its Inspector, assign the named animation groups to the matching Transform fields. Pass authoritative position `0..1` through `SetNormalizedPosition`, and pass signed motor direction through `SetDriveDirection`. If the game has a different axis or travel length, adjust the art range. Its default initialization uses 50% travel; disable that when gameplay initializes position itself.

## Level objectives and art reaction

| Objective | Visual reaction |
|---|---|
| 1. Wire the loop | terminal rings and system status become ready |
| 2. Verify feedback | jog right; carriage, sensor wiper, and pointer travel together |
| 3. Station A | selected A lamp on, readout converges to 25%, drive stops |
| 4. Station B | B lamp on, readout converges to 75%, drive stops and holds |
| 5. Reversed-leads fault | motor-direction warning; safe-stop indication, no uncontrolled motion |
| 6. Disturbance recovery | nudge controls displace carriage; closed-loop drive returns it to B |

Use dynamic TextMeshPro for COMMAND, POSITION, and ERROR fields. **Set TMPro X/Y scale to 0.20** as requested, then adjust world offset and font size so text remains visible without intersecting its screen. The screen meshes are intentionally blank.

## Cautions

- Do not use the showcase FBX as a circuit solver.
- Do not rename existing project electrical IDs to match the illustrative socket names.
- Do not add real sockets to Station A/B visual-only markers.
- Do not simulate position by moving a model independently from its authoritative feedback state.
- The user supplied no exact wire-to-terminal list for Level 43, so this package does not claim to include a working wiring definition or controller system.
