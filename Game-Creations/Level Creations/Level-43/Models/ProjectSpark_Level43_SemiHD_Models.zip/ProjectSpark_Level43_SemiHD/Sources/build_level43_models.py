"""Project Spark — LEVEL 43: HOLD THE LINE
Premium semi-HD procedural mechanical/electronics 3D art.
Y up, X is carriage travel, front faces -Z. FBX 7.4 and GLB exports.
Hardware visual models only: no hidden electrical simulation or official binding claims.
Dependencies: numpy, trimesh, shapely, matplotlib.
"""
from __future__ import annotations
import math, json, csv, copy
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb

ROOT=Path(__file__).resolve().parents[1]
MODELS=ROOT/'Models'; PREV=ROOT/'Previews'
for p in (MODELS,PREV):p.mkdir(parents=True,exist_ok=True)

PALETTE.update({
 'ceramic':(229,210,172,255),'brass':(244,187,70,255),
 'mint':(44,234,191,255),'electric':(62,133,255,255),
 'violet':(173,99,255,255),'warning_yellow':(255,214,95,255),
 'orange_hi':(255,144,55,255), 'icy':(188,242,255,255),
 'darkglass':(44,131,163,89),'glass_body':(96,191,213,88),
 'polymer':(35,48,60,255),'polymer_light':(68,85,102,255),
 'silverblue':(122,167,205,255), 'aluminum':(150,176,192,255),
 'cobalt':(18,73,143,255),'orange_rubber':(192,91,29,255),
 'warning_dark':(95,64,24,255), 'dark_copper':(108,63,36,255),
 'screen_green':(80,246,173,255), 'tick':(121,192,210,255),
 'purple':(140,97,227,255), 'rubbergrey':(41,45,51,255),
 'polished':(216,226,234,255), 'green_dim':(18,100,75,255)
})

TRAVEL_MIN=-5.2
TRAVEL_MAX=5.2
STATION_A=-2.6
STATION_B=2.6


def label(m,t,s,x,y,z,sz=.15,color='white',mw=None,group='Static'):
 m.text(t,s,sz,x,y,z,color,maxwidth=mw,group=group)

def strip(m,t,a,b,w,col,group='Static'):
 m.rod(t,a,b,w,col,sections=12,group=group)

def bolts(m,t,xs,zs,y,rad=.066):
 for i,x in enumerate(xs):
  for j,z in enumerate(zs):
   m.cyl(f'{t}_CaptiveBolt_{i}_{j}',rad,.034,(x,y,z),'chrome',sections=15)
   m.box(f'{t}_BoltDrive_{i}_{j}',(.055,.009,.017),(x,y+.023,z),'mid_steel')

def socket(m,t,sid,title,x,y=.54,front=-1.17,col='cyan'):
 """Front-mounted, visual only socket, orientation Y up, -Z front."""
 group='Socket_RingDecor_VISUAL'
 tag=f'{t}_{sid}'
 m.cyl(tag+'_ThreadedBoss',.185,.08,(x,y,front-.025),'chrome',axis='z',sections=40)
 m.cyl(tag+'_InsulatingCollar',.150,.098,(x,y,front-.063),col,axis='z',sections=36)
 m.cyl(tag+'_HollowSocket',.104,.108,(x,y,front-.110),'void',axis='z',sections=32)
 m.cyl(tag+'_GoldContact',.034,.037,(x,y,front-.160),'gold',axis='z',sections=20)
 m.torus(tag+'_LuminousSocketRing',.160,.012,(x,y,front-.104),col,axis='z',segments=36,tube_segs=7,group=group)
 label(m,tag+'_Name',title,x,y+.273,front-.183,.119,'white',.86)
 m.anchors[sid]=[round(x,4),round(y,4),round(front-.180,4)]

def housing(m,t,title,w=3.8,d=2.22,h=1.37,accent='cyan',subtitle=None):
 m.base(t,w=w,d=d,bodyh=h)
 face=-d/2-.082
 m.bevel(t+'_BlackTitleBezel',(w-.30,.35,.032),(0,1.16,face-.014),'void',.039)
 label(m,t+'_FrontTitle',title,0,1.168,face-.066,.235,'white',w-.40)
 if subtitle:label(m,t+'_FrontSub',subtitle,0,.901,face-.071,.128,accent,w-.4)
 m.box(t+'_TopStatusBlade',(w-.65,.029,.042),(0,.32+h+.126,-d/2+.23),accent,group='AccentLights_VISUAL')
 m.box(t+'_FrontBottomUnderlight',(w-.61,.042,.032),(0,.364,face-.016),accent,group='AccentLights_VISUAL')
 # side angled metallic brackets + chamfered covers
 for i,x in enumerate([-w/2+.24,w/2-.24]):
  m.bevel(t+f'_CornerArmor_{i}',(.21,.24,d-.24),(x,.53+h/2,.0),'mid_steel',.04)
  m.box(t+f'_CornerGleam_{i}',(.055,.45,.045),(x,.67+h/2,face+.02), 'orange')
 bolts(m,t,[-w/2+.18,w/2-.18],[-d/2+.2,d/2-.2],.32+h+.10,.055)
 return face

def indicator(m,t,center,col,name=None,group='Indicator_VISUAL',radius=.12,axis='z'):
 x,y,z=center
 m.cyl(t+'_Rim',radius*1.27,.047,(x,y,z),'chrome',axis=axis,sections=28,group=group)
 m.cyl(t+'_Lens',radius,.075,(x,y,z-.025 if axis=='z' else z),col,axis=axis,sections=30,group=group)
 if name:label(m,t+'_Label',name,x,y+.235,z-.055,.105,'fog',.91)

def torus_on(m,t,major,minor,center,axis,color,group='Static'):
 return m.torus(t,major,minor,center,color,axis=axis,segments=46,tube_segs=9,group=group)

def build_rail():
 m=Model('01_L43_RailBase');t='L43_RAIL'
 # dark linear motion stage, ~14.9 x 3.7; rails along X
 m.bevel(t+'_IsolatingFoot',(15.45,.18,3.72),(0,.105,0),'rubber',.13)
 m.bevel(t+'_MilledAluminumBed',(15.30,.28,3.55),(0,.285,0),'titanium',.125)
 m.bevel(t+'_GraphiteRailDeck',(15.08,.16,3.37),(0,.49,0),'graphite',.10)
 m.box(t+'_CenterGutter',(14.60,.065,1.35),(0,.606,0),'void')
 m.box(t+'_CentralMachinedLine',(14.20,.042,.048),(0,.650,0),'cyan_soft')
 for z in [-1.31,1.31]:
  m.bevel(t+f'_PrecisionRailSeat_{z:+.2f}',(14.50,.16,.43),(0,.695,z),'deep_steel',.04)
  m.box(t+f'_SlideGuideGroove_{z:+.2f}',(14.3,.029,.07),(0,.793,z),'silverblue')
  m.rod(t+f'_CHROME_LINEAR_RAIL_{z:+.2f}',(-6.77,.98,z),(6.77,.98,z),.132,'chrome',sections=28)
  for x in np.arange(-6.1,6.15,1.55):
   m.cyl(t+f'_RailStand_{x:.2f}_{z:.2f}',.13,.14,(x,.826,z),'titanium',sections=14)
   m.cyl(t+f'_RailScrew_{x:.2f}_{z:.2f}',.041,.028,(x,.799,z),'gold',sections=10)
 # central threaded lead screw, mechanically plausible visible silver helix
 m.rod(t+'_LeadScrew_Core',(-6.81,.88,0),(6.81,.88,0),.074,'chrome',sections=22)
 # spiral as short curved rod segments, pitch 0.32
 pitch=.32; n=300
 for k in range(n):
  x0=-6.57+13.14*k/n;x1=-6.57+13.14*(k+1)/n
  p0=(x0,.88+.105*math.cos(math.tau*x0/pitch),.105*math.sin(math.tau*x0/pitch))
  p1=(x1,.88+.105*math.cos(math.tau*x1/pitch),.105*math.sin(math.tau*x1/pitch))
  m.rod(t+f'_LeadScrew_Thread_{k:03d}',p0,p1,.022,'chrome',sections=6)
 for s in (-1,1):
  x=s*7.05
  m.bevel(t+f'_EndStop_{s}',(.30,1.18,2.93),(x,1.03,0),'mid_steel',.065)
  for z in (-1.3,1.3):
   m.cyl(t+f'_StopImpactBumper_{s}_{z}',.19,.17,(x-s*.15,1.00,z),'rubber',axis='x',sections=30)
  m.box(t+f'_EndStopWarning_{s}',(.06,.07,2.32),(x,1.615,0),'amber')
  bolts(m,t+f'_EndPad_{s}',[x],[-1.24,1.24],.665)
 # ruler, zero marker, ruler hash marks (rail real physical reference)
 m.box(t+'_PositionRuler_Backplate',(13.60,.044,.36),(0,.63,-1.63),'polymer')
 for k in range(81):
  x=-6.56+k*(13.12/80)
  hh=.29 if k%20==0 else .20 if k%10==0 else .09
  m.box(t+f'_RulerTick_{k:02d}',(.018,.014,hh),(x,.659,-1.70),'icy' if k%10==0 else 'tick')
 for x,c,txt in ((-5.2,'cyan','0%'),(-2.6,'mint','25%'),(0,'amber','50%'),(2.6,'mint','75%'),(5.2,'cyan','100%')):
  m.box(t+'_PositionRulerMark_'+txt,(.046,.038,.10),(x,.684,-1.51),c)
 # edge lighting along bed
 for z in (-1.75,1.75):m.box(t+f'_NeonEdge_{z}',(14.83,.046,.045),(0,.526,z),'cyan')
 # heavy anchoring feet
 for x in (-6.56,6.56):
  for z in (-1.48,1.48):
   m.bevel(t+f'_AntiVibrationPad_{x:.1f}_{z:.1f}',(.65,.17,.55),(x,.045,z),'rubber',.043)
 # travel anchors for animation and scene placement, not electrical sockets
 m.group_pivots['STATIC_RAIL']=(0,0,0)
 return m


def build_carriage():
 m=Model('02_L43_Carriage');t='L43_CARRIAGE'; g='Carriage_Move_X_ANIMATE'; pg='CarriagePointer_VISUAL_MOVE_X'
 # relative to rail origin at x=0; all moving geometry group so one parent rig controls it
 m.bevel(t+'_LinearBearing_Carriage',(2.24,.30,2.67),(0,1.16,0),'steel',.095,group=g)
 m.bevel(t+'_UnderBearingMat',(2.13,.12,2.51),(0,1.00,0),'rubber',.08,group=g)
 for x in (-.75,.75):
  for z in (-1.20,1.20):
   m.cyl(t+f'_BearingSleeve_{x}_{z}',.245,.47,(x,1.0,z),'chrome',axis='x',sections=29,group=g)
   m.torus(t+f'_BearingBlueRing_{x}_{z}',.225,.028,(x,1.0,z),'blue',axis='x',segments=34,tube_segs=9,group=g)
 m.bevel(t+'_OrangeInspectionDeck',(2.65,.30,2.22),(0,1.45,-.09),'orange',.075,group=g)
 m.bevel(t+'_TopBrushedFixture',(2.30,.10,1.95),(0,1.62,-.07),'titanium',.07,group=g)
 m.bevel(t+'_InspectedPart_Platform',(1.25,.11,1.10),(0,1.75,-.13),'graphite',.04,group=g)
 m.cyl(t+'_PrecisionSamplePuck',.37,.28,(0,1.93,-.13),'aluminum',sections=45,group=g)
 m.cyl(t+'_SampleOpticalScanGlass',.27,.045,(0,2.096,-.13),'cyan_soft',sections=40,group=g)
 m.torus(t+'_SampleInspectionNeon',.31,.034,(0,2.114,-.13),'cyan',axis='y',segments=48,group=g)
 # High visibility local position pointer, points down to ruler at negative Z
 m.bevel(t+'_PointerBase',(.68,.12,.36),(0,1.63,-1.29),'void',.04,group=pg)
 m.box(t+'_PositionPointerLED',(.18,.031,.51),(0,1.705,-1.34),'cyan',group=pg)
 strip(m,t+'_PointerStylus',(0,1.43,-1.43),(0,.77,-1.43),.037,'gold',group=pg)
 m.cyl(t+'_PointerRedDot',.073,.024,(0,.740,-1.43),'amber',sections=18,group=pg)
 for x in (-1.06,1.06):
  m.box(t+f'_GripPad_{x:+.1f}',(.14,.20,1.13),(x,1.73,-.06),'polymer_light',group=g)
  for z in (-.70,.70):m.cyl(t+f'_Screw_{x}_{z}',.058,.025,(x,1.72,z),'gold',sections=12,group=g)
 # underside nut follows lead screw
 m.cyl(t+'_LeadScrewNut',.21,.58,(0,.91,0),'brass',axis='x',sections=28,group=g)
 m.group_pivots[g]=(0,0,0)
 m.group_pivots[pg]=(0,0,0)
 return m


def build_motor():
 m=Model('03_L43_MotorAssembly');t='L43_MOTOR';g='MotorShaft_ROTATE_X'
 m.bevel(t+'_MotorIsolationBase',(3.53,.18,2.02),(0,.16,0),'rubber',.06)
 m.bevel(t+'_MotorMountingPlate',(3.45,.20,1.98),(0,.315,0),'mid_steel',.074)
 for x in (-1.31,1.31):
  m.bevel(t+f'_PillowBlock_{x}',(.36,.52,1.33),(x,.64,0),'titanium',.035)
  m.cyl(t+f'_PillowBolt_{x}',.068,.035,(x,.915,-.48),'gold',sections=12)
 # major motor axis is X; center y=1.11
 m.cyl(t+'_BrushedMotorCan',.66,1.79,(-.17,1.11,0),'aluminum',axis='x',sections=60)
 for x in np.linspace(-.97,.58,13):
  m.torus(t+f'_CoolingFin_{x:+.3f}',.663,.017,(x,1.11,0),'titanium',axis='x',segments=52,tube_segs=8)
 for x in (-1.0,.68):
  m.cyl(t+'_SiliconGasket_'+str(x),.68,.074,(x,1.11,0),'rubber',axis='x',sections=50)
 m.cyl(t+'_CobaltRearCap',.69,.23,(-1.17,1.11,0),'cobalt',axis='x',sections=52)
 m.cyl(t+'_Gearbox_FrontCap',.59,.24,(.81,1.11,0),'chrome',axis='x',sections=48)
 m.cyl(t+'_FrontBearing',.27,.17,(1.02,1.11,0),'steel',axis='x',sections=42)
 for a in range(12):
  ang=math.tau*a/12
  # vents on rear cap radial face
  m.box(t+f'_RearVent_{a:02d}',(.015,.16,.045),(-1.302,1.11+.43*math.cos(ang),.43*math.sin(ang)),'void')
 # brass rotating shaft + toothed drive pulley; rotation is local X axis
 m.rod(t+'_RotatingSteelShaft',(1.02,1.11,0),(1.76,1.11,0),.128,'chrome',sections=35,group=g)
 for x in (1.31,1.67):m.cyl(t+f'_MovingPulleyLip_{x}',.37,.065,(x,1.11,0),'brass',axis='x',sections=40,group=g)
 m.cyl(t+'_MovingPulleyCore',.285,.33,(1.49,1.11,0),'gold',axis='x',sections=42,group=g)
 for k in range(22):
  a=math.tau*k/22
  m.cyl(t+f'_PulleyGearTooth_{k:02d}',.044,.30,(1.49,1.11+.295*math.cos(a),.295*math.sin(a)),'brass',axis='x',sections=10,group=g)
 m.group_pivots[g]=(1.49,1.11,0)
 for a,sid,txt,color in [(0,'MOTOR_A','A','red'),(1,'MOTOR_B','B','blue')]:
  xx=(-.65 if a==0 else .65)
  # Terminal face behind motor base (negative Z) same accessibility as module
  socket(m,t,sid,txt,xx,.37,-1.04,color)
 # nameplate fitted on the front face of motor can
 m.bevel(t+'_PrintedMotorPlate',(1.12,.37,.065),(-.18,1.10,-.662),'void',.04)
 label(m,t+'_Nameplate','REV DC MOTOR',-.18,1.11,-.709,.142,'white',1.02)
 m.box(t+'_AxisArrowLED',(.48,.042,.038),(-.16,.79,-.71),'cyan')
 return m


def build_sensor():
 m=Model('04_L43_PositionSensor');t='L43_POS';g='SensorWiper_Move_X_ANIMATE'
 # fixed slim 12-unit contactless potentiometer/linear encoder across rail
 m.bevel(t+'_FeedbackSensorMount',(12.16,.20,.82),(0,.72,0),'rubber',.045)
 m.bevel(t+'_EncoderAluminumTrack',(12.03,.25,.77),(0,.90,0),'steel',.04)
 m.box(t+'_LinearResistiveStrip',(10.61,.032,.18),(0,1.049,-.10),'polymer')
 m.box(t+'_FeedbackDataRibbon',(10.42,.021,.065),(0,1.075,.105),'mint')
 for x in np.linspace(-5.0,5.0,41):
  n=int(round((x+5)*4));sz=.22 if n%10==0 else .105
  m.box(t+f'_Scale_Rule_{n:02d}',(.018,.018,sz),(x,1.08,.24),'white' if n%10==0 else 'tick')
 for x,n in [(-5.2,'0'),(-2.6,'25'),(0,'50'),(2.6,'75'),(5.2,'100')]:
  m.box(t+f'_ScaleMark_{n}',(.034,.04,.24),(x,1.13,.09),'amber')
 # shell frame guard
 for z in (-.35,.35):m.box(t+f'_EncasedGuide_{z}',(11.16,.063,.046),(0,1.15,z),'cyan_soft')
 for x in (-5.9,5.9):
  m.bevel(t+f'_SensorEndCap_{x}',(.26,.45,.80),(x,1.04,0),'mid_steel',.03)
  m.cyl(t+f'_SensorCoverFastener_{x}',.058,.025,(x,1.27,-.28),'gold',sections=14)
 # moving carrier and contact wiper, kept under its own pivot
 m.bevel(t+'_WiperSlideBlock',(.61,.20,.63),(0,1.23,0),'chrome',.04,group=g)
 m.bevel(t+'_WiperCeramicBridge',(.33,.10,.46),(0,1.40,0),'polymer',.03,group=g)
 m.box(t+'_SensorMotionHighlight',(.17,.026,.48),(0,1.47,-.014),'green',group=g)
 m.rod(t+'_GoldContactArm',(0,1.31,-.16),(0,1.08,-.16),.046,'gold',group=g)
 m.group_pivots[g]=(0,0,0)
 # 3 terminals at the right end, on front surface in separate enlarged access block
 m.bevel(t+'_ConnectorDock',(2.18,.83,.81),(5.19,1.15,-.59),'graphite',.055)
 for k,(sid,txt,col) in enumerate([('SENSOR_5V','5V','red'),('SENSOR_GND','GND','blue'),('SENSOR_FEEDBACK','FBK','mint')]):
  socket(m,t,sid,txt,5.90-k*.71,1.08,-1.05,col)
 label(m,t+'_SensorName','POSITION FEEDBACK',0,1.40,-.42,.173,'white',3.7)
 return m


def build_command():
 m=Model('05_L43_CommandModule');t='L43_CMD';f=housing(m,t,'POSITION COMMAND',w=4.51,d=2.55,h=1.53,accent='mint',subtitle='STATION SELECT + MANUAL / AUTO')
 for x,text,col in [(.97,'A 25%','cyan'),(-.97,'B 75%','amber')]:
  group='StationSelector_'+ ('A' if text.startswith('A') else 'B')+'_PRESS_ANIMATE'
  m.bevel(t+f'_StationKey_Bezel_{x}',(1.30,.16,.81),(x,1.98,-.31),'titanium',.08)
  m.bevel(t+f'_StationKey_{x}',(1.09,.26,.64),(x,2.10,-.31),col,.065,group=group)
  # engraved station ID on top is replaced by lit face strip instead of text on hidden XY plane
  m.box(t+f'_StationKeyLight_{x}',(.74,.028,.035),(x,2.245,-.50), 'white',group=group)
  m.group_pivots[group]=(x,2.09,-.31)
 for name,x,col in [('MANUAL',-1.49,'blue'),('AUTO',1.49,'green')]:
  m.bevel(t+f'_{name}_ModePad',(.56,.12,.56),(x,1.985,.70),'polymer',.045)
  indicator(m,t+f'_{name}_Status',(x,2.09,.70),col,group='Mode_'+name+'_Lamp_VISUAL',radius=.09,axis='y')
 label(m,t+'_A_StationLabel','A  /  25%',.97,1.57,f-.03,.128,'cyan',1.16)
 label(m,t+'_B_StationLabel','B  /  75%',-.97,1.57,f-.03,.128,'amber',1.16)
 # physically separate jog buttons + disturbance controls on lid for controller interactions
 for x,name,col in [(-1.5,'JOG L','blue'),(-.50,'JOG R','blue'),(.50,'NUDGE L','orange'),(1.5,'NUDGE R','orange')]:
  group='Button_'+name.replace(' ','')+'_PRESS_ANIMATE'
  m.cyl(t+'_'+name+'_Bezel',.179,.12,(x,1.94,.21),'chrome',sections=27)
  m.cyl(t+'_'+name+'_Button',.137,.16,(x,2.05,.21),col,sections=27,group=group)
  m.group_pivots[group]=(x,2.04,.21)
 socket(m,t,'COMMAND_OUT','CMD',-1.10,.53,f,'mint')
 socket(m,t,'MODE_OUT','MODE',1.10,.53,f,'cyan')
 return m


def build_controller():
 m=Model('06_L43_Controller');t='L43_CTRL';f=housing(m,t,'CLOSED LOOP  /  PID',w=5.55,d=2.88,h=1.58,accent='cyan',subtitle='COMMAND  >  POSITION  >  DRIVE')
 # broad angled display — blank values. physically angled toward top-down game camera
 face_z=-1.02
 start=len(m.parts)
 m.bevel(t+'_AngledChromeScreenFrame',(4.75,.93,.11),(0,2.02,face_z),'chrome',.08,group='ControllerScreen_BLANK')
 m.bevel(t+'_AngledOLEDGlass',(4.51,.75,.064),(0,2.02,face_z-.087),'screen',.071,group='ControllerScreen_BLANK')
 for x,name,col in [(1.35,'COMMAND','amber'),(0,'POSITION','cyan'),(-1.35,'ERROR','mint')]:
  m.bevel(t+f'_{name}_BlankValueZone',(1.23,.39,.035),(x,1.99,face_z-.136),'void',.035,group='ControllerScreen_BLANK')
  label(m,t+f'_{name}_Title',name,x,2.258,face_z-.165,.128,col,1.11,'ControllerScreen_BLANK')
  m.box(t+f'_{name}_LiveUnderline',(1.03,.026,.021),(x,1.75,face_z-.17),col,group='ControllerScreen_BLANK')
 # tilt by +17 deg to player; all screen geometry and text angled consistently
 pivot=(0,2.02,face_z)
 T=trimesh.transformations.rotation_matrix(math.radians(16),[1,0,0],point=pivot)
 for p in m.parts[start:]:p.mesh.apply_transform(T)
 for x,name,col in [(1.39,'DRIVE LEFT','electric'),(0,'STOP','green'),(-1.39,'DRIVE RIGHT','amber')]:
  group='DriveStatus_'+name.replace(' ','')+'_Lamp_VISUAL'
  indicator(m,t+'_'+name.replace(' ','')+'_Indicator',(x,1.70,-1.485),col,name,group,radius=.154)
 # decorative processor + heat-sink below display
 m.bevel(t+'_ProcessorShield',(2.00,.13,.81),(0,2.04,.82),'mid_steel',.05)
 m.bevel(t+'_ControlChip',(1.47,.18,.56),(0,2.18,.82),'void',.042)
 for k in range(12):m.box(t+f'_ProcessorPin_{k}',(.062,.03,.21),(-.66+k*.12,2.14,1.18),'gold')
 # 4 signal input/output sockets along lower front, logical placeholders
 for x,sid,txt,col in [(1.93,'CTRL_COMMAND','CMD','amber'),(.63,'CTRL_FEEDBACK','FBK','mint'),(-.63,'CTRL_DIRECTION','DIR','cyan'),(-1.93,'CTRL_ENABLE','EN','green')]:
  socket(m,t,sid,txt,x,.49,f,col)
 return m


def build_driver():
 m=Model('07_L43_MotorDriver');t='L43_DRIVER';f=housing(m,t,'REVERSIBLE MOTOR DRIVER',w=5.10,d=2.57,h=1.50,accent='orange',subtitle='H-BRIDGE  /  FAULT-CUT DRIVE')
 m.bevel(t+'_PowerStage_Plate',(4.39,.12,1.49),(0,1.93,.19),'mid_steel',.065)
 m.bevel(t+'_Heatsink_Central',(2.50,.22,1.21),(0,2.08,.18),'aluminum',.062)
 for k in range(13):
  x=-1.13+k*.19
  m.box(t+f'_AluminumCoolingFin_{k:02d}',(.091,.40,.95),(x,2.37,.19),'chrome')
 for x,name,col in [(1.75,'LEFT','cyan'),(0,'SAFE STOP','green'),(-1.75,'RIGHT','amber')]:
  group='Driver_'+name.replace(' ','')+'_Lamp_VISUAL'
  indicator(m,t+'_Drive_'+name.replace(' ','')+'_Lens',(x,2.03,-.78),col,group=group,radius=.129,axis='z')
 for x,tag in [(-1.65,'MOSFET_A'),(1.65,'MOSFET_B')]:
  m.bevel(t+'_'+tag+'_Case',(.77,.19,.66),(x,2.09,.47),'void',.042)
  m.text(t+'_'+tag+'_Text','H-BRIDGE',.10,x,2.09,.109,'white',maxwidth=.64)
  for i in range(3):m.box(t+'_'+tag+f'_Pin_{i}',(.09,.10,.18),(x-.18+.18*i,2.13,.93),'gold')
 # 6 plugs at two vertical rows — independent end point anchors, not extra electrical APIs
 for i,(sid,txt,col) in enumerate([('DRIVE_5V','5V','red'),('DRIVE_GND','GND','blue'),('DRIVE_ENABLE','EN','green'),('DRIVE_DIRECTION','DIR','cyan'),('DRIVE_MOTOR_A','M A','orange'),('DRIVE_MOTOR_B','M B','electric')]):
  x=(1.80,1.08,.36,-.36,-1.08,-1.80)[i]
  socket(m,t,sid,txt,x,.49,f,col)
 return m


def build_station(which):
 A=(which=='A');m=Model('08_L43_StationA' if A else '09_L43_StationB')
 t='L43_STATION_'+which;accent='cyan' if A else 'amber';loc=25 if A else 75
 # separate floor-mounted tracking flags, no sockets; same across levels
 m.bevel(t+'_AntiVibrationPad',(.74,.12,1.05),(0,.11,0),'rubber',.045)
 m.bevel(t+'_SensorPedestal',(.62,.18,.87),(0,.24,0),'steel',.05)
 for x in (-.21,.21):
  m.rod(t+f'_FlagTower_{x:+.2f}',(x,.30,.10),(x,2.10,.10),.056,'chrome',sections=14)
 m.bevel(t+'_LitStationHeader',(.99,.46,.22),(0,2.12,-.09),'graphite',.05)
 m.box(t+'_NeonTopMarker',(.79,.04,.03),(0,2.35,-.24),accent)
 label(m,t+'_Name',which,0,2.17,-.255,.27,'white',.41)
 label(m,t+'_Percent',str(loc)+'%',0,1.93,-.255,.125,accent,.73)
 m.bevel(t+'_OpticalLimitGlass',(.45,.45,.19),(0,1.38,-.07),'darkglass',.05)
 m.cyl(t+'_OpticalBeamCore',.132,.12,(0,1.38,-.197),accent,axis='z',sections=27,group='StationBeacon_VISUAL')
 m.torus(t+'_OpticalBeamHalo',.175,.014,(0,1.38,-.249),accent,axis='z',group='StationBeacon_VISUAL')
 for z in (-.36,.36):
  m.cyl(t+f'_MountBolt_{z:+.1f}',.052,.023,(0,.35,z),'gold',sections=13)
 return m


def build_base_display():
 m=Model('00_ArtKit_DisplayBoard');t='L43_BENCH'
 m.bevel(t+'_RubberShockBase',(22.3,.21,14.25),(0,.10,0),'rubber',.17)
 m.bevel(t+'_TitaniumEdgeTray',(22.12,.24,14.00),(0,.24,0),'steel',.15)
 m.bevel(t+'_GraphitePanel',(21.87,.065,13.72),(0,.395,0),'graphite',.08)
 for x in (-10.82,10.82):m.box(t+f'_LongEmissiveEdge_{x}',(.056,.042,13.3),(x,.446,0),'cyan')
 for z in (-6.78,6.78):m.box(t+f'_ShortEmissiveEdge_{z}',(21.0,.042,.058),(0,.445,z),'cyan')
 # hole grid matches visual board only. Unity project breadboard can override origin/scale.
 for i,x in enumerate(np.linspace(-10.38,10.38,43)):
  for j,z in enumerate(np.linspace(-6.40,6.40,27)):
   m.cyl(t+f'_Perforation_{i:02d}_{j:02d}',.014,.006,(x,.433,z),'mid_steel',sections=6)
 # visual traffic lanes, no conductor connections
 for z,col in [(5.40,'cyan'),(2.50,'mint'),(-2.96,'electric')]:
  m.box(t+f'_RowAccent_{z}',(19.35,.015,.046),(0,.438,z),col,group='BoardGuideOnly_VISUAL')
 for x in (-9.5,9.5):
  m.bevel(t+f'_StandingMount_{x}',(.8,.18,.8),(x,.26,-4.82),'polymer',.06)
 # front labelplate, not an entire environment
 m.bevel(t+'_GameLevelLabelPlate',(5.16,.047,.68),(0,.44,-6.28),'void',.04)
 # top-facing labels not visible from straight-on but excellent in angled model preview
 return m

BUILDERS=[build_rail,build_carriage,build_motor,build_sensor,build_command,build_controller,build_driver,lambda:build_station('A'),lambda:build_station('B')]
POSITIONS={
 '00_ArtKit_DisplayBoard':(0,0,0),
 '01_L43_RailBase':(0,0,-.27),
 '02_L43_Carriage':(0,0,-.27),
 '03_L43_MotorAssembly':(-8.80,0,-.28),
 '04_L43_PositionSensor':(0,0,2.63),
 '05_L43_CommandModule':(-5.35,0,5.14),
 '06_L43_Controller':(3.65,0,5.16),
 '07_L43_MotorDriver':(0,0,-4.60),
 '08_L43_StationA':(STATION_A,0,-2.38),
 '09_L43_StationB':(STATION_B,0,-2.38)
}
# At build-time, these aliases describe MODEL_ART SOCKETS ONLY, not authoritative Unity binding IDs.
# Positioning uses local board/world X axis in exported art; actual Scene needs manual snap.


def build():
 models=[fn() for fn in BUILDERS]
 assert len(models)==9
 assert len(set(m.key for m in models))==9
 assert set([s for m in models for s in m.anchors]) == set([s for m in models if m.anchors for s in m.anchors])
 assets={}
 for m in models:
  fbx=MODELS/(m.key+'.fbx');glb=MODELS/(m.key+'.glb')
  export_fbx(fbx,[m]);export_glb(glb,[m])
  scene=trimesh.load_scene(str(glb));assert len(scene.geometry)>0
  assert fbx.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  if not m.parts:raise ValueError(m.key+' empty')
  assets[m.key]={
    'fbx':fbx.name,'glb':glb.name,'mesh_parts':len(m.parts),
    'triangles':int(sum(len(p.mesh.faces) for p in m.parts)),
    'sockets':m.anchors,
    'groups':list(dict.fromkeys(p.group for p in m.parts if p.group!='Static')),
    'animation_group_pivots':m.group_pivots
  }
  print('EXPORTED',m.key,'meshes=',len(m.parts),'tris=',assets[m.key]['triangles'], 'sockets=',len(m.anchors),flush=True)
 assembled=[build_base_display()]+models
 name='Level43_Complete_ArtKit_Showcase'
 export_fbx(MODELS/(name+'.fbx'),assembled,positions=POSITIONS)
 export_glb(MODELS/(name+'.glb'),assembled,positions=POSITIONS)
 assert len(trimesh.load_scene(str(MODELS/(name+'.glb'))).geometry)>0
 manifest={
 'level':43,'name':'Hold the Line','gameplay':'Closed-loop positioning motorized inspection carriage',
 'model_count':9,'extra_background_world_environments':0,
 'official_level43_terminal_ids':'NOT PROVIDED. Names below are visual art socket guides only. Do not assume they match game bindings.',
 'coordinate_system':'Y UP / X horizontal travel / player sees front on -Z / model units are not automatically Unity board units',
 'rail_travel_visual_local_x':[TRAVEL_MIN,TRAVEL_MAX],
 'station_a_local_x':STATION_A,'station_b_local_x':STATION_B,
 'station_a_percent':25,'station_b_percent':75,
 'theoretical_feedback_of_5V_sensor_at_A':1.25,'theoretical_feedback_of_5V_sensor_at_B':3.75,
 'art_socket_count':int(sum(len(m.anchors) for m in models)),
 'models':assets,'showcase':{'file':name+'.fbx','glb':name+'.glb','triangles':sum(a['triangles'] for a in assets.values())+sum(len(p.mesh.faces) for p in assembled[0].parts)},
 'positions':POSITIONS,
 'notes':['Nine requested standalone models; the existing project 5V supply prefab is reused. No duplicate power-source model was invented.',
          'Animated carriage root and sensor wiper must follow the SAME normalized travel fraction.',
          'Motor shaft rotational animation is visual; motor reversibility and motion physics must be driven by your existing runtime.',
          'The MotorDriver sockets are illustrative; exact connection IDs and wire list were NOT supplied.',
          'Station models have no gameplay sockets. Station A and B at 25% and 75% on -5.2 to +5.2 travel.',
          'Blank controller displays are intended for live TextMeshPro driven by Project Spark gameplay.',
          'Sockets are mesh decals only. Build and assign actual SparkTerminal objects separately, then snap them to the player circuit board.']
 }
 (ROOT/'Model_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['FBX Model','Illustrative Socket ID (NOT authoritative)','Local X','Local Y','Local Z','Model/Unity Notes'])
  for m in models:
   for sid,c in m.anchors.items():w.writerow([m.key+'.fbx',sid,*c,'ART anchor; create and bind your own SparkTerminal at this 3D local position'])
 with (ROOT/'Animation_Rigs.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['FBX Model','FBX Animation Group','Pivot X','Pivot Y','Pivot Z','Motion'])
  for m in models:
   for group in dict.fromkeys(p.group for p in m.parts if 'ANIMATE' in p.group or 'VISUAL' in p.group):
    p=m.group_pivots.get(group,(0,0,0))
    motion=('Translate X with normalized carriage position' if 'Move_X' in group else
            'Rotate around local X axis with motor angular velocity' if 'MotorShaft' in group else
            'Animate visual indicators or small press offset; no electrical API' )
    w.writerow([m.key+'.fbx',group,*p,motion])
 return models

if __name__=='__main__':build()
