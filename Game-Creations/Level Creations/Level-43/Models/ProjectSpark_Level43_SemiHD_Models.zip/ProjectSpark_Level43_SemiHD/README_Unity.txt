PROJECT SPARK — LEVEL 43: HOLD THE LINE
Polished semi-HD 3D art pack (Y-up FBX 7.4 binary + GLB backups)

PACKAGE CONTENTS
- Nine individual Level43 .fbx files with separate named animation hierarchy groups.
- Nine matching .glb backups for inspection/conversion.
- One Level43_Complete_ArtKit_Showcase.fbx + .glb with nine parts installed.
- Previews: assembled hero, nine actual-geometry model renders, contact sheet.
- Terminal_Anchors.csv: 17 MODEL-ART socket positions. These names are not official gameplay binding IDs.
- Animation_Rigs.csv: pivot positions and animation group names.
- Model_Manifest.json: parts, triangle counts, placement and limitations.
- Sources/: reproducible procedural model builder + FBX writer + VTK preview renderer.
- Unity_Optional/: isolated visual-motion adapter and Unity Editor anchor creator.

MODELS
01_L43_RailBase.fbx        Fixed twin linear guide rails, lead screw, end stops, ruler
02_L43_Carriage.fbx        Animated orange inspection platform + optical sample fixture
03_L43_MotorAssembly.fbx   Brushed DC motor, shaft, geared drive pulley, A/B jacks
04_L43_PositionSensor.fbx  Feedback track, moving wiper, illustrated power/signal jacks
05_L43_CommandModule.fbx  Station A/B buttons, manual/auto display, jog/nudge buttons
06_L43_Controller.fbx     PID/control instrument, blank 3-field screen, directional lamps
07_L43_MotorDriver.fbx    Reversible H-bridge driver, heatsink, six illustrated sockets
08_L43_StationA.fbx       Fixed Station A marker (25% travel)
09_L43_StationB.fbx       Fixed Station B marker (75% travel)

ELECTRICAL PARTS
The existing Project Spark 5 V supply prefab is intentionally reused rather than adding
an unrequested tenth object. Your game must own the valid power/return topology.
No real SparkTerminal components, wires, solver stamps, controls or objective logic are
embedded in an FBX. The model artist cannot determine real binding IDs from this brief.

IMPORT INTO UNITY (2021+, standard and URP)
1) Unzip. Copy individual files from Models/ to:
   Assets/My_Assets/_Project_Spark/Models/Level43/
2) For each FBX, import Meshes / Normals = Import, import Materials as needed.
   Inspect +Y up and front -Z; adapt Model Scale in your art prefab before fitting.
   Rendered colors are basic material colors. For AAA URP look, set metallic/smoothness,
   emission on cyan, mint and orange trim. Configure real emission in your URP setup.
3) MAKE a new Level43 art prefab under your existing Level_43_Layout hierarchy.
   Use nine individual FBXs for gameplay, not the combined showcase. The showcase is
   an example placement preview and is not a functional level.
4) Place the command and PID controller at the back, rail in the middle, motor at the
   rail end and motor-driver toward the front. Leave wire-drawing space at the front.
5) Use Terminal_Anchors.csv as local ART SOCKET offsets; create actual SparkTerminal
   objects with IDs supplied by YOUR authentic Level43_SceneBindings. You may use
   Tools > Project Spark > Level 43 > Create Art Socket Anchors after selecting a single
   instantiated model. The tool creates helpers only (never actual SparkTerminal).
6) Align the gameplay SparkTerminal anchor precisely with each visible socket and
   breadboard snapping point. Calibration depends on your board holes and model scale.
   The brief did not provide breadboard world-to-local transforms; cannot pre-snap exactly.
7) Use TextMeshPro objects at X/Y scale 0.20 on each dynamic label (as requested).
   Blank controller display is intentionally reserved for live COMMAND / POSITION /
   ERROR text. Avoid burning dynamic readings into a model material.

SCENE PLACEMENT (ASSEMBLED SHOWCASE, IN ART UNITS)
Rail center:             (0, 0, -0.27)
Carriage center:         (0, 0, -0.27)
Motor body:              (-8.80, 0, -0.28)
Position sensor:         (0, 0, +2.63)
Command module:          (-5.35, 0, +5.14)
PID controller:          (+3.65, 0, +5.16)
Motor driver:            (0, 0, -4.60)
Station A marker:        (-2.60, 0, -2.38)
Station B marker:        (+2.60, 0, -2.38)
The front is -Z. In cameras looking toward +Z from the front, visual left/right
may appear reversed; use the Scene gizmo and your game's camera convention.

CARRIAGE ANIMATION
- Rail remains stationary (01_L43_RailBase)
- Move the 02_L43_Carriage / Carriage_Move_X_ANIMATE group along LOCAL X.
- Move sibling group CarriagePointer_VISUAL_MOVE_X by exactly the same offset.
- The named Carriage_Move_X_ANIMATE group contains all moving parts.
- Move 04_L43_PositionSensor / SensorWiper_Move_X_ANIMATE in lockstep with the carriage.
- Normalized u = clamp((actualX - minX)/(maxX - minX), 0..1)
- Preview travel limits: minX=-5.2, maxX=+5.2 art units
- Station A=25%=>x=-2.6. Station B=75%=>x=+2.6.
- Feedback for 5 V ratiometric position sensor: ideal Vfb = u*5 V.
  Thus A ~1.25V, B ~3.75V. These are conceptual values, not the solver output.
- Animate 03_L43_MotorAssembly / MotorShaft_ROTATE_X about LOCAL X.
- STOP the visual rotor when the actual level motor drive state stops.
- Use game authoritative motor state for motion; don't animate independent physics.
- Use paired NUDGE controls to perturb the authoritative position; visual follows
  the updated measured feedback. This pack DOES NOT simulate a disturbance.

ANIMATION GROUPS
Carriage_Move_X_ANIMATE        02_L43_Carriage (body and platform)
CarriagePointer_VISUAL_MOVE_X   02_L43_Carriage (position pointer, same offset)
MotorShaft_ROTATE_X            03_L43_MotorAssembly (pivot at 1.49, 1.11, 0)
SensorWiper_Move_X_ANIMATE     04_L43_PositionSensor
StationSelector_A_PRESS_ANIMATE, StationSelector_B_PRESS_ANIMATE
Button_JOGL_PRESS_ANIMATE / JOGR / NUDGEL / NUDGER
ControllerScreen_BLANK         blank live display surface
DriveStatus_DRIVELEFT_Lamp_VISUAL / STOP / DRIVERIGHT
Driver_LEFT_Lamp_VISUAL, Driver_SAFESTOP_Lamp_VISUAL, Driver_RIGHT_Lamp_VISUAL
StationBeacon_VISUAL          station optical beam emitters

WARNING / LIMITATIONS
- FBX is material-colored semi-HD geometry. There are no fully texture-baked PBR maps.
- All supplied electrical-port labels are ILLUSTRATIVE ART IDs, not official runtime IDs.
- Exact wiring count, wire IDs, supply terminals, and the Level 43 circuit bindings
  were not supplied, so this pack does not invent a wiring list or a working controller.
- Do not replace SparkElectricalSolver or completed level definitions with art scripts.
- Unity imports, material appearance, animation and breadboard alignment remain to be
  tested and adjusted in your own scene. FBX/GLB binary and mesh exports were checked.
