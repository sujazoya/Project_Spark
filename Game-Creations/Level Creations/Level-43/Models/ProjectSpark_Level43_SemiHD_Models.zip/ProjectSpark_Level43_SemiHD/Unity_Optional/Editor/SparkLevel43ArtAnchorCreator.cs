#if UNITY_EDITOR
using System;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ProjectSpark.Gameplay.Editor
{
    /// <summary>
    /// Creates ART-ONLY anchor GameObjects from Level43's Terminal_Anchors.csv.
    /// Never creates SparkTerminal, registers runtime binding IDs or edits circuits.
    /// Select an instance of ONE individual FBX model before invoking the menu.
    /// </summary>
    public static class SparkLevel43ArtAnchorCreator
    {
        [MenuItem("Tools/Project Spark/Level 43/Create Art Socket Anchors")]
        private static void Create()
        {
            var selected = Selection.activeGameObject;
            if (selected == null)
            {
                EditorUtility.DisplayDialog("Level 43", "Select an instantiated Level 43 component first.", "OK");
                return;
            }

            var csv = EditorUtility.OpenFilePanel("Open Level 43 Terminal_Anchors.csv", "", "csv");
            if (string.IsNullOrEmpty(csv)) return;

            var targetName = selected.name.Replace("(Clone)", "").Trim();
            var count = 0;
            var lines = File.ReadAllLines(csv);
            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("FBX Model", StringComparison.Ordinal))
                    continue;

                var values = line.Split(',');
                if (values.Length < 5) continue;
                var model = Path.GetFileNameWithoutExtension(values[0].Trim().Trim('"'));
                if (!targetName.StartsWith(model, StringComparison.OrdinalIgnoreCase) &&
                    !model.StartsWith(targetName, StringComparison.OrdinalIgnoreCase))
                    continue;

                if (!float.TryParse(values[2].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float x) ||
                    !float.TryParse(values[3].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float y) ||
                    !float.TryParse(values[4].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float z))
                    continue;

                var id = values[1].Trim().Trim('"');
                var childName = "ART_SOCKET_" + id;
                if (selected.transform.Find(childName) != null) continue;

                var anchor = new GameObject(childName);
                Undo.RegisterCreatedObjectUndo(anchor, "Create Level 43 art socket anchor");
                anchor.transform.SetParent(selected.transform, false);
                anchor.transform.localPosition = new Vector3(x, y, z);
                anchor.transform.localRotation = Quaternion.identity;
                count++;
            }

            EditorUtility.DisplayDialog("Level 43 Art Anchors",
                count + " art-only socket anchors created.\n" +
                "Use your own SparkTerminal prefabs and authoritative runtime binding IDs.\n" +
                "Verify orientation/scale before snapping to the breadboard.", "OK");
        }

        [MenuItem("Tools/Project Spark/Level 43/Create Art Socket Anchors", true)]
        private static bool Validate() => Selection.activeGameObject != null;
    }
}
#endif
