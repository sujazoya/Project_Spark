PROJECT SPARK — LEVEL 53 "THE HIDDEN COUPLE"
AAA-INSPIRED POLISHED SEMI-HD 3D ART KIT — TWO-PLANE DYNAMIC ROTOR BALANCING
==========================================================================

THIS IS ACTUAL 3D GEOMETRY — NOT JUST A CONCEPT IMAGE.

WHAT IS INCLUDED
----------------
Models/            17 individual Autodesk FBX 7.4 binary files
                   17 matching GLB backups
                   1 complete assembled reference FBX + 1 GLB
Previews/          Rendered screenshots of the generated 3D geometry
                   Plus all-model contact sheet and machinery details
Sources/           Reproducible Python geometry + FBX/GLB exporters + VTK renders
Unity_Optional/    SparkLevel53VisualRig.cs (visual animation ONLY)
                   SparkLevel53_Animation_Setup.md
Terminal_Anchors.csv            40 local decorative socket ring positions
World_Terminal_Anchors.csv      40 assembled art-reference socket coordinates
Exact_Wiring.csv               Intended connections W01–W24
Animation_Rigs.csv             Named hierarchy transforms + pivot coordinates
Model_Manifest.json            Models, art placements and animation groups
Material_Palette.csv           Base metallic colors / shader hints
VALIDATION.txt                 Programmatic export checks

UNITY INSTALLATION
------------------
1. Extract ZIP. Import individual Models/*.fbx into e.g.
   Assets/My_Assets/_Project_Spark/Models/Level53/
2. In Unity import settings, preserve hierarchy and materials. Scale uniformly.
   Use URP Lit or HDRP Lit materials to achieve metallic/shader polish.
3. Arrange imported individual model instances using `showcase_positions`
   from Model_Manifest.json. Those are ART UNIT local placements, NOT exact
   terminal-world positions. The assembled FBX is provided as reference only.
4. Attach visual-only SparkLevel53VisualRig to a level-art root.
5. Assign Transform references for shaft, Plane A disc, Plane B disc,
   their two separately movable weight pivots, A/B/Z encoder and guard.
6. Display real vibration, phase and matrix values using TextMeshPro on
   the BLANK HMI screen surfaces; no hard-coded success values are included.
7. Register real SparkTerminal endpoints using your existing Project Spark
   binding bridge. Art connector rings are NOT actual circuit components.
   Align real terminals flush with breadboard holes as in prior levels.
8. Connect the authoritative motor, vibration, encoder and actuation systems
   to the visual helper. DO NOT infer gameplay success from visual transforms.
9. Run original Unity Play Mode tests before shipping or claiming 6/6.

MODELED MACHINE GROUPS
----------------------
00_L53_IndustrialBase          Extended titanium rail chassis, breadboard holes
01_L53_DCMotor                 5V motor, independent rotating drive shaft
02_L53_LongRotorShaft          One continuous stepped hardened-steel rotor
03_L53_CorrectionPlaneA        Cyan machined disc + individually orbiting mass
04_L53_CorrectionPlaneB        Amber machined disc + individually orbiting mass
05_L53_LeftBearing             Bearing housing and vibration pickup
06_L53_RightBearing            Bearing housing and vibration pickup
07_L53_LeftVibrationSensor     Cyan left-channel signal instrument
08_L53_RightVibrationSensor    Amber right-channel signal instrument
09_L53_EncoderABZ             80 count rotary disc with distinct Z mark
10_L53_BalanceDriver           Seven ports incl. independent A/B actuation
11_L53_MotorDriver             Five-port PWM driver and aluminum heatsink
12_L53_BalanceController       Ten-port controller + buttons + BLANK screen
13_L53_VectorMonitor           Wide dual-channel BLANK live readout screen
14_L53_SafetyEnclosure         Clear guard, swinging front door, NC art jack
15_L53_TrialWeightTray         Ten removable calibration weights + tools
16_L53_5VSupply                Regulated educational power source

WIRING
------
24 exact player wire routes, 40 distinct decorative socket anchors.
Supply + and supply return each support FIVE player connections.
Encoder A, B and Z are separate.
Place W15 LAST to allow Undo Last for the intended right-sensor fault test.

ANIMATION PIVOTS
----------------
Motor:       MOTOR_SHAFT_ROTATE_X
Rotor:       LONG_ROTOR_SHAFT_ROTATE_X
Disc A:      PLANE_A_ROTOR_ROTATE_X
Mass A:      PLANE_A_CORRECTION_WEIGHT_ORBIT_X
Disc B:      PLANE_B_ROTOR_ROTATE_X
Mass B:      PLANE_B_CORRECTION_WEIGHT_ORBIT_X
Encoder:     ENCODER_ABZ_DISC_ROTATE_X
Guard door:  SAFETY_FRONT_GUARD_DOOR_HINGE_Y
Other detachable service weights are named in Animation_Rigs.csv.

ENGINEERING / GAMEPLAY SCOPE
----------------------------
This package does NOT implement the Unity electrical solver, physics,
actual vibratory signal phase, 2x2 influence coefficient identification,
correction control, encoder wiring, circuit graph, safety runtime, six
level objectives, authoritative LevelGamePlayManager completion or
level-definition asset. These must be built using existing verified
Project Spark APIs. FBX visual sockets do not automatically become
SparkTerminal components. Unity importer and shaders are not yet tested.

OPTIONAL ONE-CLICK ART PLACEMENT
--------------------------------
Place Unity_Optional/SparkLevel53ArtPlacementEditor.cs in a Unity Editor
folder (e.g. Assets/Editor). After importing the FBXs, select the target
Level_53_Layout root in the Hierarchy and use:
Tools > Project Spark > Levels > 53 > Place AAA Visual Models
This creates/updates only an L53_VisualArt child and the 17 FBX instances.
It is safe to rerun: existing art instances are left in place.
No electrical or gameplay scripting is added by the placement utility.
