"""Project Spark Level 53 - The Hidden Couple: procedural polished 3D visual art collection.
17 separate Unity-ready FBX 7.4 binary models and GLB backups, assembled reference.
All electrical terminals are modeled art anchors ONLY, not SparkTerminal components.
Runtime balancing/circuit/evaluator functionality is not implemented by this model pack.
"""
from __future__ import annotations
import os,math,csv,json
from pathlib import Path
import numpy as np
import trimesh
from spark_model_core import Model, PALETTE, export_fbx, export_glb
ROOT=Path(__file__).resolve().parents[1]
MOD=ROOT/'Models';MOD.mkdir(exist_ok=True)
PALETTE.update({
 'nickel':(145,167,189,255),'aluminum':(183,200,215,255),'mirror':(227,239,247,255),
 'darksteel':(36,54,76,255),'carbon':(16,31,46,255),'coal':(8,20,32,255),
 'aqua':(45,221,249,255),'mint':(62,255,191,255),'electric':(43,132,247,255),
 'scarlet':(249,68,90,255),'safety':(255,174,49,255),'amberlit':(255,205,107,255),
 'brass':(212,169,74,255),'bronze':(170,111,61,255),'gunmetal':(67,92,115,255),
 'glassblue':(116,207,244,53),'screenback':(7,29,44,255),'smokeglass':(81,143,183,47),
 'pale':(234,244,251,255),'copperlight':(227,145,83,255),'teal':(35,153,171,255),
 'violet':(182,133,248,255),'orange_hi':(255,126,53,255),'steelblue':(49,110,149,255),
 'warningstripe':(255,195,66,255)
})

def label(m,n,t,x,y,z,s=.145,c='pale',mw=None,g='Static'):
 return m.text(n,t,s,x,y,z,c,maxwidth=mw,group=g)
def screw(m,n,x,y,z):
 m.cyl(n+'_Head',.068,.032,(x,y,z),'mirror','y',16)
 m.box(n+'_Recess',(.077,.008,.012),(x,y+.018,z),'darksteel')
def jack(m,n,k,txt,x,y,z,c='aqua'):
 g='SOCKET_'+k
 m.cyl(n+'_'+k+'_ChromeRim',.155,.062,(x,y,z),'mirror','z',32,g)
 m.cyl(n+'_'+k+'_Insulator',.128,.068,(x,y,z-.042),c,'z',32,g)
 m.cyl(n+'_'+k+'_JackHole',.082,.075,(x,y,z-.083),'coal','z',26,g)
 m.cyl(n+'_'+k+'_GoldContact',.026,.025,(x,y,z-.110),'brass','z',16,g)
 label(m,n+'_'+k+'_Text',txt,x,y+.205,z-.137,.115,'pale',.75)
 assert k not in m.anchors,(m.key,k)
 m.anchors[k]=(round(x,4),round(y,4),round(z-.139,4))
def led(m,n,x,y,z,c='mint'):
 g=n+'_LED'
 m.cyl(n+'_Bezel',.132,.045,(x,y,z),'chrome','z',26,g)
 m.cyl(n+'_Lens',.099,.049,(x,y,z-.041),c,'z',26,g)
 m.torus(n+'_Halo',.133,.014,(x,y,z-.064),c,'z',32,7,g)
 m.group_pivots[g]=(x,y,z)
def foot(m,n,w=5,d=4,accent='aqua'):
 m.bevel(n+'_RubberMount',(w+.15,.15,d+.14),(0,.14,0),'rubber',.09)
 m.bevel(n+'_AlloyFoot',(w,.31,d),(0,.40,0),'darksteel',.13)
 m.bevel(n+'_MetalTop',(w-.16,.07,d-.17),(0,.59,0),'nickel',.07)
 m.box(n+'_EdgeGlow',(w-.40,.03,.05),(0,.67,-d/2-.048),accent)
 for xx in (-w/2+.35,w/2-.35):
  for zz in (-d/2+.4,d/2-.4):screw(m,n+f'_Bolt_{xx:+.1f}_{zz:+.1f}',xx,.647,zz)
def cabinet(m,n,title,w=5.5,d=2.9,h=1.95,sub='',accent='aqua'):
 m.base(n,w,d,h)
 front=-d/2-.09
 m.box(n+'_HeaderBand',(w-.32,.30,.035),(0,.32+h*.84,front-.040),'coal')
 label(m,n+'_MainTitle',title,0,.32+h*.84,front-.075,.194,'pale',w-.48)
 if sub:label(m,n+'_SubTitle',sub,0,.32+h*.65,front-.078,.113,accent,w-.52)
 m.box(n+'_FrontStatusTrim',(w-.65,.038,.022),(0,.32+h+.072,-d/2+.11),accent)
 return front

def make_base():
 m=Model('00_L53_IndustrialBase');n='L53_TWIN_PLANE_TITANIUM_FRAME'
 m.bevel(n+'_IsolatedShockBase',(54,.26,24.6),(0,.17,0),'rubber',.21)
 m.bevel(n+'_MultiRibChassis',(53.45,.63,24.0),(0,.51,0),'graphite',.26)
 m.box(n+'_BlackSatinWorkSurface',(52.8,.068,23.55),(0,.859,0),'darksteel')
 for xx in (-26.25,26.25):
  m.box(n+f'_PolishedSideBeam_{xx}',(.31,.34,23.2),(xx,1.04,0),'nickel')
  m.box(n+f'_CyanEdge_{xx}',(.055,.036,23.0),(xx,1.24,0),'aqua')
 for zz in (-11.72,11.72):
  m.box(n+f'_BrushedEndBeam_{zz}',(52.3,.33,.24),(0,1.03,zz),'gunmetal')
  m.box(n+f'_FrontNeon_{zz}',(51.8,.037,.05),(0,1.24,zz),'amberlit' if zz<0 else 'mint')
 for x in np.linspace(-24.9,24.9,33):
  for z in (-10.92,-10.46):m.cyl(n+f'_BreadboardHole_{x:.2f}_{z}',.046,.012,(float(x),.899,z),'coal','y',8)
 for x in (-24.8,24.8):
  for z in (-11.15,11.15):m.bevel(n+f'_RubberIsolator_{x}_{z}',(1.15,.31,1.15),(x,.16,z),'rubber',.09)
 for k,x in enumerate(np.linspace(-24,24,17)):
  m.box(n+f'_BlackSafetyStripe_{k}',(.74,.026,.45),(float(x),.899,-11.44),'safety' if k%2 else 'coal')
 for x in (-22.5,22.5):
  for z in (-8,0,8):
   m.bevel(n+f'_PrecisionMount_{x}_{z}',(.95,.19,.95),(x,.92,z),'gunmetal',.08)
 label(m,n+'_Engraving','PROJECT SPARK  //  LEVEL 53  //  THE HIDDEN COUPLE',0,1.29,-11.83,.32,'pale',26)
 return m

def make_motor():
 m=Model('01_L53_DCMotor');n='L53_5V_MOTOR';foot(m,n,6.15,4.75,'aqua');y=3.30
 for x in (-1.86,1.86):
  m.box(n+f'_Saddle_{x}',(.43,1.76,2.0),(x,1.60,0),'gunmetal')
  m.bevel(n+f'_AnchorFoot_{x}',(.84,.23,2.55),(x,.77,0),'mirror',.09)
 m.cyl(n+'_RibbedMotorCan',1.23,4.03,(0,y,0),'nickel','x',76)
 for k in range(36):
  a=math.tau*k/36
  m.rod(n+f'_LongRib_{k:02d}',(-1.83,y+1.23*math.cos(a),1.23*math.sin(a)),(1.79,y+1.23*math.cos(a),1.23*math.sin(a)),.053,'aluminum',9)
 for xx,c in [(-2.1,'gunmetal'),(2.11,'carbon')]:
  m.cyl(n+f'_Endplate_{xx}',1.28,.22,(xx,y,0),c,'x',64)
  m.torus(n+f'_EndcapRim_{xx}',1.24,.055,(xx,y,0),'aqua','x',64,10)
 for k in range(8):
  a=math.tau*k/8;m.cyl(n+f'_CapFastener_{k}',.077,.042,(2.24,y+1.00*math.cos(a),1.00*math.sin(a)),'mirror','x',14)
 gr='MOTOR_SHAFT_ROTATE_X'
 m.cyl(n+'_HardenedDriveShaft',.24,2.70,(2.63,y,0),'mirror','x',38,gr)
 m.cyl(n+'_SplineCoupler',.39,.69,(3.39,y,0),'brass','x',40,gr)
 m.torus(n+'_CouplerCyanRim',.37,.038,(3.73,y,0),'mint','x',36,8,gr)
 m.group_pivots[gr]=(2.45,y,0)
 m.bevel(n+'_CableDock',(3.2,.73,.75),(0,.64,-2.78),'carbon',.07)
 jack(m,n,'MOTOR_POS','MOTOR +',-.73,.75,-3.20,'scarlet')
 jack(m,n,'MOTOR_NEG','MOTOR -',.73,.75,-3.20,'coal')
 label(m,n+'_DeckName','5 V DC PRECISION DRIVE',0,.99,-2.86,.156,'pale',3.05)
 return m

def make_shaft():
 m=Model('02_L53_LongRotorShaft');n='L53_LONG_ROTOR';foot(m,n,31.4,3.45,'mint')
 y=3.3;g='LONG_ROTOR_SHAFT_ROTATE_X'
 m.cyl(n+'_ContinuousChromeShaft',.248,31.4,(0,y,0),'mirror','x',50,g)
 m.cyl(n+'_SteppedHollowRotorSleeve',.51,20.4,(0,y,0),'gunmetal','x',54,g)
 for xx in (-14,-12,-9,-3,3,9,12,14):
  m.torus(n+f'_CalibratedRing_{xx}',.52,.065,(xx,y,0),'nickel','x',48,8,g)
 for xx in (-10,10):
  m.cyl(n+f'_ShaftCoupling_{xx}',.60,.85,(xx,y,0),'brass','x',40,g)
  for k in range(8):
   a=math.tau*k/8;m.cyl(n+f'_CouplingBolt_{xx}_{k}',.075,.075,(xx+.43,y+.43*math.cos(a),.43*math.sin(a)),'mirror','x',12,g)
 for xx in np.linspace(-11,11,11):
  m.cyl(n+f'_LongitudinalRotorRib_{xx:.1f}',.59,.10,(float(xx),y,0),'carbon','x',36,g)
 m.group_pivots[g]=(0,y,0)
 label(m,n+'_DeckLabel','LONG ROTOR  /  TWO-PLANE DYNAMIC BALANCING',0,.94,-1.96,.15,'pale',20)
 return m

def plane(k,code,color):
 m=Model(f'{k:02d}_L53_CorrectionPlane{code}');n=f'L53_PRECISION_PLANE_{code}';foot(m,n,5.65,6.10,color)
 y=3.30;g=f'PLANE_{code}_ROTOR_ROTATE_X'
 m.tube(n+'_MassiveMachinedAnnulus',2.32,.68,.54,(0,y,0),'nickel','x',90,g)
 m.cyl(n+'_InnerCarbonDisc',1.46,.60,(0,y,0),'gunmetal','x',76,g)
 for x in (-.32,.32):
  m.torus(n+f'_OuterMirrorRim_{x}',2.20,.084,(x,y,0),'mirror','x',88,10,g)
  m.torus(n+f'_ColorPrecisionArc_{x}',1.87,.044,(x,y,0),color,'x',80,9,g)
  m.torus(n+f'_InnerRim_{x}',.62,.066,(x,y,0),'chrome','x',64,8,g)
 for idx in range(60):
  a=math.tau*idx/60
  m.cyl(n+f'_AngularTick_{idx:02d}',.027 if idx%5 else .051,.032,(.37,y+2.02*math.cos(a),2.02*math.sin(a)),color if idx%5==0 else 'pale','x',12,g)
 for j in range(12):
  a=math.tau*j/12
  m.cyl(n+f'_HubFastener_{j:02d}',.085,.043,(.37,y+.83*math.cos(a),.83*math.sin(a)),'mirror','x',16,g)
 m.group_pivots[g]=(0,y,0)
 wgrp=f'PLANE_{code}_CORRECTION_WEIGHT_ORBIT_X'
 ang=math.radians(35 if code=='A' else 225)
 xx=.49;cy=y+1.81*math.cos(ang);cz=1.81*math.sin(ang)
 m.bevel(n+'_WeightSlidingSaddle',(.52,.58,.67),(xx,cy,cz),'carbon',.07,wgrp)
 m.cyl(n+'_GoldCorrectionMass',.36,.44,(xx+.31,cy,cz),'brass','x',34,wgrp)
 m.torus(n+'_WeightIdentificationRing',.335,.038,(xx+.53,cy,cz),color,'x',30,9,wgrp)
 m.cyl(n+'_WeightFastener',.095,.07,(xx+.59,cy,cz),'mirror','x',16,wgrp)
 m.group_pivots[wgrp]=(0,y,0)
 for j,x in enumerate((-2.3,2.3)):
  m.box(n+f'_MechanicalSupport_{j}',(.35,1.97,1.20),(x,1.64,0),'gunmetal')
  m.tube(n+f'_ShaftSupport_{j}',.56,.27,.50,(x,y,0),'mirror','x',48)
 m.bevel(n+'_ActuatorDock',(3.90,.80,.83),(0,.66,-3.12),'carbon',.07)
 jack(m,n,f'PLANE_{code}_PLUS',f'{code} +',-.77,.74,-3.60,'aqua' if code=='A' else 'safety')
 jack(m,n,f'PLANE_{code}_NEG',f'{code} -',.77,.74,-3.60,'coal')
 label(m,n+'_Caption',f'PLANE {code}  /  ACTIVE CORRECTION',0,1.08,-3.20,.16,'pale',5.15)
 return m

def make_bearing(k,side,color):
 m=Model(f'{k:02d}_L53_{side}Bearing');n=f'L53_{side.upper()}_PRECISION_BEARING';foot(m,n,4.00,4.3,color)
 y=3.3
 m.bevel(n+'_HeavyFoundation',(3.15,.40,3.1),(0,.82,0),'gunmetal',.12)
 for x in (-1.11,1.11):
  m.box(n+f'_BearingVerticalSupport_{x}',(.34,1.62,1.35),(x,1.66,0),'nickel')
 m.tube(n+'_ReplaceableSteelBearingOuter',.82,.33,.66,(0,y,0),'mirror','x',64)
 m.tube(n+'_InnerRace',.49,.30,.70,(0,y,0),'brass','x',48)
 for idx in range(12):
  a=math.tau*idx/12
  m.cyl(n+f'_BearingElement_{idx}',.135,.25,(0,y+.60*math.cos(a),.60*math.sin(a)),'aluminum','x',18)
 m.bevel(n+'_SensorMount',(1.25,.60,.95),(0,4.18,0),'carbon',.08)
 m.cyl(n+'_VibrationPickup',.23,.50,(0,4.62,0),color,'y',32)
 m.cyl(n+'_SensorCrystal',.18,.12,(0,4.96,0),'mirror','y',24)
 for i,z in enumerate((-.97,.97)):
  m.bevel(n+f'_Flange_{i}',(.84,.22,.63),(0,.90,z),'mirror',.06)
 label(m,n+'_Caption',f'{side.upper()}  /  BEARING SUPPORT',0,.89,-2.34,.142,'pale',3.76)
 return m

def vib(k,side,color):
 m=Model(f'{k:02d}_L53_{side}VibrationSensor');n=f'L53_{side.upper()}_VIB_MONITOR';front=cabinet(m,n,side.upper()+' BEARING SENSOR',4.95,2.8,1.78,'SYNCHRONOUS VIBRATION PICKUP',color)
 m.bevel(n+'_TriaxialPickup',(.90,.62,.74),(0,3.03,.17),'gunmetal',.09)
 m.cyl(n+'_PiezoBase',.46,.16,(0,2.58,.17),'brass','y',28)
 m.cyl(n+'_StatusLens',.13,.14,(0,3.39,-.10),color,'y',22)
 for x,code,txt,c in [(-1.44,f'VIB_{side.upper()}_PLUS','+5V','scarlet'),(0,f'VIB_{side.upper()}_GND','GND','coal'),(1.44,f'VIB_{side.upper()}_OUT','OUT',color)]:
  jack(m,n,code,txt,x,.75,front,c)
 return m

def encoder():
 m=Model('09_L53_EncoderABZ');n='L53_PHASE_ENCODER';foot(m,n,4.5,4.5,'mint');y=3.3;g='ENCODER_ABZ_DISC_ROTATE_X'
 m.cyl(n+'_Shaft',.26,2.1,(0,y,0),'mirror','x',36,g)
 m.cyl(n+'_Disc',1.40,.12,(0,y,0),'coal','x',82,g)
 m.torus(n+'_BlueTrack',1.31,.032,(.078,y,0),'aqua','x',80,9,g)
 for j in range(80):
  a=math.tau*j/80
  m.cyl(n+f'_EncoderGraduation_{j:02d}',.024 if j%5 else .040,.025,(.093,y+1.18*math.cos(a),1.18*math.sin(a)),'pale' if j%2 else 'mint','x',9,g)
 m.cyl(n+'_IndexZOnly',.099,.032,(.095,y+1.20,0),'safety','x',22,g)
 m.group_pivots[g]=(0,y,0)
 m.box(n+'_FixedEncoderArch',(1.35,.42,.78),(0,4.40,0),'nickel')
 for i,(x,c) in enumerate([(-.36,'aqua'),(0,'mint'),(.36,'safety')]):
  m.cyl(n+f'_HeadABZ_{i}',.11,.18,(x,4.14,-.07),c,'y',20)
 m.bevel(n+'_InterfaceSocketDock',(3.83,.75,.77),(0,.63,-2.60),'carbon',.09)
 for x,code,c,short in [(-1.18,'ENCODER_A','aqua','A'),(0,'ENCODER_B','mint','B'),(1.18,'ENCODER_Z','safety','Z')]:
  jack(m,n,code,short,x,.75,-3.04,c)
 label(m,n+'_Name','80 COUNT ABZ + PHASE INDEX',0,1.02,-2.75,.147,'pale',4.22)
 return m

def balance_driver():
 m=Model('10_L53_BalanceDriver');n='L53_DUAL_PLANE_DRIVER'
 f=cabinet(m,n,'PLANE A / B ACTUATOR DRIVER',9.40,3.2,2.08,'INDEPENDENT CORRECTION CHANNELS','amberlit')
 for i in range(14):m.box(n+f'_CopperHeatsinkFin_{i}',(.15,.55,1.54),(-3.55+i*.545,2.55,.24),'brass')
 ports=[('BDRV_PLUS','+5V','scarlet'),('BDRV_GND','GND','coal'),('BDRV_CMD','CMD','safety'),('BDRV_AP','A+','aqua'),('BDRV_AN','A-','coal'),('BDRV_BP','B+','safety'),('BDRV_BN','B-','coal')]
 for i,(code,lab,col) in enumerate(ports):
  jack(m,n,code,lab,-3.57+i*1.19,.76,f,col)
 for x,c in [(-2.1,'aqua'),(2.1,'safety')]:led(m,n+'_Status'+str(x),x,1.50,f,c)
 return m

def motor_driver():
 m=Model('11_L53_MotorDriver');n='L53_ROTATION_MOTOR_DRIVER'
 f=cabinet(m,n,'ROTOR PWM MOTOR DRIVER',6.75,3.05,2.06,'5 V / CLOSED LOOP DRIVE','aqua')
 for i in range(11):m.box(n+f'_AlloyCoolingFin_{i}',(.12,.50,1.41),(-2.65+i*.53,2.54,.19),'aluminum')
 ports=[('MDRV_PLUS','+5V','scarlet'),('MDRV_GND','GND','coal'),('MDRV_PWM','PWM','safety'),('MDRV_MP','M+','scarlet'),('MDRV_MN','M-','coal')]
 for i,(code,txt,col) in enumerate(ports):jack(m,n,code,txt,-2.48+i*1.24,.76,f,col)
 led(m,n+'_PWR',2.70,1.49,f,'mint');return m

def controller():
 m=Model('12_L53_BalanceController');n='L53_COUPLED_BALANCE_CONTROLLER'
 f=cabinet(m,n,'TWO PLANE BALANCE CONTROLLER',11.9,3.5,2.60,'CALIBRATE A + B  /  SOLVE INFLUENCE  /  APPLY','aqua')
 m.bevel(n+'_HMIBezel',(8.62,.95,.064),(0,1.98,f-.081),'gunmetal',.08)
 g='CONTROLLER_BLANK_DYNAMIC_SCREEN'
 m.box(n+'_HMIBlank',(8.32,.74,.026),(0,1.98,f-.137),'screenback',g)
 m.group_pivots[g]=(0,1.98,f-.137)
 buttons=[('BASELINE','mint'),('TRIAL A','aqua'),('TRIAL B','safety'),('SOLVE','electric'),('APPLY','mint')]
 for i,(txt,col) in enumerate(buttons):
  x=-4.34+i*2.17;gr=f'CTRL_{txt.replace(" ","_")}_BUTTON'
  m.bevel(n+f'_BUTTON_{i}',(1.68,.26,.12),(x,1.33,f-.135),'carbon',.07,gr)
  m.box(n+f'_LED_{i}',(1.32,.026,.017),(x,1.43,f-.207),col,gr)
  label(m,n+f'_ButtonText_{i}',txt,x,1.33,f-.208,.10,'pale',1.55,gr)
  m.group_pivots[gr]=(x,1.33,f-.135)
 ports=[('CTRL_PLUS','+5V','scarlet'),('CTRL_GND','GND','coal'),('CTRL_PWM','PWM','safety'),('CTRL_VIB_L','VIB L','aqua'),('CTRL_VIB_R','VIB R','safety'),('CTRL_ENC_A','ENC A','mint'),('CTRL_ENC_B','ENC B','mint'),('CTRL_ENC_Z','ENC Z','amberlit'),('CTRL_BAL','BAL CMD','aqua'),('CTRL_SAFE','SAFE','mint')]
 for i,(code,txt,col) in enumerate(ports):
  jack(m,n,code,txt,-5.09+i*1.13,.72,f,col)
 return m

def monitor():
 m=Model('13_L53_VectorMonitor');n='L53_INFLUENCE_MATRIX_MONITOR'
 f=cabinet(m,n,'DUAL CHANNEL / INFLUENCE MATRIX',13.0,3.4,2.72,'VIBRATION L+R  /  POLAR PHASE  /  CORRECTION SOLVER','mint')
 m.bevel(n+'_ScreenFrame',(12.14,1.42,.075),(0,1.92,f-.085),'gunmetal',.08)
 g='BLANK_LIVE_VECTOR_SCREEN'
 m.box(n+'_BlankLiveHMI',(11.86,1.19,.024),(0,1.93,f-.136),'screenback',g)
 m.group_pivots[g]=(0,1.93,f-.136)
 # Fine subtle etched grid on monitor surface, intended purely as decorative art.
 for y in (1.54,1.82,2.10,2.32):m.box(n+f'_GridH_{y}',(11.2,.009,.010),(0,y,f-.160),'darksteel')
 for j in range(21):
  x=-5.48+j*.548;m.box(n+f'_GridV_{j}',(.008,.92,.010),(x,1.95,f-.162),'darksteel')
 label(m,n+'_LabPrint','L BEARING   |   R BEARING   |   H MATRIX   |   TWO PLANE SOLVE',0,.95,f-.085,.134,'aqua',11.8)
 return m

def guard():
 m=Model('14_L53_SafetyEnclosure');n='L53_TRANSPARENT_BALANCING_GUARD';w=37.0;d=9.0
 for x in (-w/2,w/2):
  for z in (-d/2,d/2):m.box(n+f'_VerticalChromePost_{x}_{z}',(.19,5.24,.19),(x,3.44,z),'mirror')
 for yy in (.85,6.02):
  for z in (-d/2,d/2):m.box(n+f'_FrontRail_{yy}_{z}',(w+.24,.20,.20),(0,yy,z),'nickel')
  for x in (-w/2,w/2):m.box(n+f'_SideRail_{yy}_{x}',(.20,.20,d+.22),(x,yy,0),'nickel')
 for x in (-w/2,w/2):m.box(n+f'_ClearSideWall_{x}',(.045,4.68,d-.22),(x,3.43,0),'glassblue')
 for i in range(11):
  xx=-w/2+1.1+i*(w-2.2)/10
  m.box(n+f'_TopGuardSlat_{i}',(.063,.070,d),(xx,6.11,0),'mirror')
 g='SAFETY_FRONT_GUARD_DOOR_HINGE_Y'
 m.box(n+'_ClearFrontAccessDoor',(w-.72,4.46,.047),(0,3.43,-d/2),'glassblue',g)
 m.box(n+'_FrontDoorHandle',(.27,.87,.23),(w/2-1.10,3.08,-d/2-.22),'mirror',g)
 m.group_pivots[g]=(-w/2+.36,3.43,-d/2)
 m.bevel(n+'_SafetyFeedback',(2.10,.73,.91),(w/2-.95,.65,-d/2-.43),'carbon',.08)
 jack(m,n,'GUARD_NC','SAFE NC',w/2-.95,.76,-d/2-.99,'mint')
 led(m,n+'_DoorHealthy',w/2-2.27,1.49,-d/2-.12,'mint')
 label(m,n+'_SafetyLabel','GUARDED TWO PLANE ROTOR TEST CELL',0,6.25,-d/2-.13,.246,'safety',15.4)
 return m

def tray():
 m=Model('15_L53_TrialWeightTray');n='L53_INFLUENCE_CALIBRATION_KIT';foot(m,n,6.2,4.35,'amberlit')
 m.bevel(n+'_RubberizedToolkit',(5.73,.35,3.54),(0,.94,0),'coal',.11)
 for j in range(10):
  x=-2.28+(j%5)*1.13;z=-.74+(j//5)*1.32
  m.cyl(n+f'_Slot_{j:02d}',.40,.026,(x,1.18,z),'darksteel','y',28)
  g=f'TRIAL_WEIGHT_{j:02d}_DETACH_Y'
  m.cyl(n+f'_CalibrationMass_{j:02d}',.23+.014*(j%3),.20,(x,1.30,z),'brass' if j<5 else 'nickel','y',26,g)
  m.cyl(n+f'_WeightCenterHole_{j:02d}',.074,.22,(x,1.35,z),'coal','y',14,g)
  m.group_pivots[g]=(x,1.30,z)
 for j in range(3):
  m.rod(n+f'_AllenKey_{j}',(-2.21+j*1.66,.96,1.89),(-1.68+j*1.66,1.0,1.36),.050,'mirror',12)
 label(m,n+'_PrintedName','PLANE A / B TRIAL WEIGHTS',0,.92,-2.35,.155,'pale',5.82)
 return m

def supply():
 m=Model('16_L53_5VSupply');n='L53_REGULATED_POWER'
 f=cabinet(m,n,'REGULATED 5 V DC',5.15,3.0,1.97,'PRECISION BALANCING SUPPLY','aqua')
 m.box(n+'_ScreenBezel',(2.52,.54,.042),(0,1.63,f-.080),'gunmetal')
 m.box(n+'_BlankLivePowerScreen',(2.28,.39,.024),(0,1.63,f-.12),'screenback')
 label(m,n+'_NominalVoltage','5.00 V',0,1.63,f-.154,.265,'mint',2.18)
 for k in range(11):m.box(n+f'_CoolingSlot_{k}',(.064,.025,1.28),(-1.83+k*.362,2.69,.29),'coal')
 led(m,n+'_Power',1.96,1.62,f,'mint')
 jack(m,n,'SUPPLY_PLUS','+5V',-1.08,.78,f,'scarlet')
 jack(m,n,'SUPPLY_RETURN','RETURN',1.08,.78,f,'coal')
 return m

BUILDERS=[make_base,make_motor,make_shaft,lambda:plane(3,'A','aqua'),lambda:plane(4,'B','safety'),
          lambda:make_bearing(5,'Left','aqua'),lambda:make_bearing(6,'Right','safety'),
          lambda:vib(7,'Left','aqua'),lambda:vib(8,'Right','safety'),encoder,balance_driver,motor_driver,
          controller,monitor,guard,tray,supply]
POS={
 '00_L53_IndustrialBase':(0,0,0),
 '01_L53_DCMotor':(-20.80,0,1.75),
 '02_L53_LongRotorShaft':(0,0,1.75),
 '03_L53_CorrectionPlaneA':(-7.1,0,1.75),
 '04_L53_CorrectionPlaneB':(7.1,0,1.75),
 '05_L53_LeftBearing':(-13.9,0,1.75),
 '06_L53_RightBearing':(13.9,0,1.75),
 '07_L53_LeftVibrationSensor':(-21.7,0,6.9),
 '08_L53_RightVibrationSensor':(21.2,0,6.9),
 '09_L53_EncoderABZ':(20.0,0,1.75),
 '10_L53_BalanceDriver':(-5.10,0,-8.2),
 '11_L53_MotorDriver':(-16.4,0,-8.2),
 '12_L53_BalanceController':(4.40,0,9.1),
 '13_L53_VectorMonitor':(-12.8,0,9.1),
 '14_L53_SafetyEnclosure':(0,0,1.75),
 '15_L53_TrialWeightTray':(18.8,0,-8.1),
 '16_L53_5VSupply':(21.6,0,9.15)
}
WIRES=[
 ('W01','SUPPLY_PLUS','CTRL_PLUS','Supply +5V -> Balancing Controller +5V'),
 ('W02','SUPPLY_RETURN','CTRL_GND','Supply RETURN -> Controller GND'),
 ('W03','SUPPLY_PLUS','MDRV_PLUS','Supply +5V -> Motor Driver +5V'),
 ('W04','SUPPLY_RETURN','MDRV_GND','Supply RETURN -> Motor Driver GND'),
 ('W05','SUPPLY_PLUS','VIB_LEFT_PLUS','Supply +5V -> Left Sensor +5V'),
 ('W06','SUPPLY_RETURN','VIB_LEFT_GND','Supply RETURN -> Left Sensor GND'),
 ('W07','SUPPLY_PLUS','VIB_RIGHT_PLUS','Supply +5V -> Right Sensor +5V'),
 ('W08','SUPPLY_RETURN','VIB_RIGHT_GND','Supply RETURN -> Right Sensor GND'),
 ('W09','SUPPLY_PLUS','BDRV_PLUS','Supply +5V -> Balance Driver +5V'),
 ('W10','SUPPLY_RETURN','BDRV_GND','Supply RETURN -> Balance Driver GND'),
 ('W11','CTRL_PWM','MDRV_PWM','Controller MOTOR PWM -> Motor Driver PWM'),
 ('W12','MDRV_MP','MOTOR_POS','Motor Driver M+ -> DC Motor +'),
 ('W13','MDRV_MN','MOTOR_NEG','Motor Driver M- -> DC Motor -'),
 ('W14','VIB_LEFT_OUT','CTRL_VIB_L','Left Sensor OUT -> Controller VIB L'),
 ('W15','VIB_RIGHT_OUT','CTRL_VIB_R','Right Sensor OUT -> Controller VIB R (install LAST for fault test)'),
 ('W16','ENCODER_A','CTRL_ENC_A','Encoder A -> Controller ENC A'),
 ('W17','ENCODER_B','CTRL_ENC_B','Encoder B -> Controller ENC B'),
 ('W18','ENCODER_Z','CTRL_ENC_Z','Encoder Z -> Controller ENC Z'),
 ('W19','CTRL_BAL','BDRV_CMD','Controller BAL CMD -> Balance Driver CMD'),
 ('W20','BDRV_AP','PLANE_A_PLUS','Balance Driver A+ -> Plane A Actuator +'),
 ('W21','BDRV_AN','PLANE_A_NEG','Balance Driver A- -> Plane A Actuator -'),
 ('W22','BDRV_BP','PLANE_B_PLUS','Balance Driver B+ -> Plane B Actuator +'),
 ('W23','BDRV_BN','PLANE_B_NEG','Balance Driver B- -> Plane B Actuator -'),
 ('W24','GUARD_NC','CTRL_SAFE','Guard NC -> Controller SAFE IN')]

def build():
 models=[]
 for fn in BUILDERS:
  m=fn();models.append(m)
  fb=MOD/(m.key+'.fbx');gl=MOD/(m.key+'.glb')
  export_fbx(fb,[m]);export_glb(gl,[m])
  assert fb.read_bytes().startswith(b'Kaydara FBX Binary  \x00')
  assert len(trimesh.load_scene(gl).geometry)>0
  print('MODEL',m.key,'TRIS',sum(len(p.mesh.faces) for p in m.parts),'PARTS',len(m.parts),'SOCKETS',len(m.anchors),flush=True)
 all_sockets={s for m in models for s in m.anchors}
 assert len(models)==17 and sum(len(m.anchors) for m in models)==40 and len(all_sockets)==40
 wired={s for _,a,b,_ in WIRES for s in (a,b)}
 assert len(WIRES)==24 and wired==all_sockets, ('WIRING INVALID',wired^all_sockets)
 assert set(POS)=={m.key for m in models}
 assembled='Level53_Complete_ArtKit_Showcase'
 export_fbx(MOD/(assembled+'.fbx'),models,positions=POS)
 export_glb(MOD/(assembled+'.glb'),models,positions=POS)
 partinfo={m.key:{'fbx':m.key+'.fbx','glb':m.key+'.glb','triangles':sum(len(p.mesh.faces) for p in m.parts),
                   'submesh_count':len(m.parts),'local_socket_anchors':m.anchors,'animation_pivots':m.group_pivots}
           for m in models}
 tris=sum(d['triangles'] for d in partinfo.values())
 data={'level':53,'name':'The Hidden Couple','theme':'Two-Plane Dynamic Rotor Balancing Facility',
       'scope':'VISUAL 3D ASSETS ONLY. No Unity physics, electrical components, evaluator or gameplay.',
       'individual_models':17,'player_wires':24,'art_socket_count':40,'triangle_count':tris,
       'assembled_fbx':assembled+'.fbx','parts':partinfo,'showcase_positions':POS,'wires':WIRES,
       'coordinate_system':'Y up; front -Z; art units; scale/align to Unity workbench',
       'note':'The two correction mass groups orbit independently. Controller must combine shaft phase with each correction angle.',
       'safety_note':'Actual safety guard mesh is cosmetic; interlock and circuit must use Project Spark runtime.',
       'ordering_note':'Install W15 (right sensor OUT -> Controller VIB R) last for the deliberate sensor fault test.'}
 (ROOT/'Model_Manifest.json').write_text(json.dumps(data,indent=2))
 with (ROOT/'Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','SocketID','LocalX','LocalY','LocalZ','Note'])
  for m in models:
   for k,xyz in m.anchors.items():w.writerow([m.key+'.fbx',k,*xyz,'Visual marker only; snap SparkTerminal to scene hole'])
 with (ROOT/'World_Terminal_Anchors.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','SocketID','ShowcaseX','ShowcaseY','ShowcaseZ'])
  for m in models:
   for k,xyz in m.anchors.items():w.writerow([m.key+'.fbx',k,*[round(a+b,4) for a,b in zip(xyz,POS[m.key])]])
 with (ROOT/'Exact_Wiring.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Wire','FromArtSocketID','ToArtSocketID','Description']);w.writerows(WIRES)
 with (ROOT/'Animation_Rigs.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Model','FBXTransformGroup','PivotX','PivotY','PivotZ','DrivenBy'])
  for m in models:
   for gr,xyz in m.group_pivots.items():w.writerow([m.key+'.fbx',gr,*xyz,'External authoritative gameplay state; visual ONLY'])
 with (ROOT/'Material_Palette.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['Material','Red','Green','Blue','Alpha','UnityShaderHint'])
  for name,v in PALETTE.items():w.writerow([name,*v,'URP/Lit or HDRP/Lit; retune metallic, emission, glass transparency'])
 (ROOT/'VALIDATION.txt').write_text('PROJECT SPARK LEVEL 53 - THE HIDDEN COUPLE\n'+
  f'17 individual FBXs + 17 GLBs; one assembled FBX + GLB.\n{tris:,} triangles.\n'+
  '24 exact player wiring routes. 40 unique art socket anchors.\n'+
  'FBX pointer checks completed, GLBs loaded as geometry, referenced socket IDs validated.\n'+
  'Unity imports, physics, binding IDs and authoritative 6/6 gameplay NOT tested.\n')
 print('SUCCESS',tris,'TRIANGLES',len(models),'FBX',len(all_sockets),'SOCKETS',len(WIRES),'WIRES',flush=True)
 return models
if __name__=='__main__':build()
