"""Project Spark L53: VTK offscreen renders of the ACTUAL procedural FBX meshes."""
from __future__ import annotations
from pathlib import Path
import math
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from PIL import Image,ImageDraw,ImageFont
from build_level53_models import BUILDERS, POS,PALETTE,ROOT
P=ROOT/'Previews';P.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def actor_for(part,offset):
 mesh=part.mesh;poly=vtk.vtkPolyData()
 xyz=np.ascontiguousarray(mesh.vertices.astype('float32')+np.array(offset,dtype=np.float32),dtype=np.float32)
 pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(xyz,deep=1));poly.SetPoints(pts)
 faces=np.asarray(mesh.faces,dtype=np.int64)
 arr=np.column_stack((np.full(len(faces),3,dtype=np.int64),faces)).flatten()
 cc=vtk.vtkCellArray();cc.SetCells(len(faces),numpy_to_vtkIdTypeArray(np.ascontiguousarray(arr),deep=1));poly.SetPolys(cc)
 norm=vtk.vtkPolyDataNormals();norm.SetInputData(poly);norm.SplittingOff();norm.ConsistencyOn()
 mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norm.GetOutputPort())
 actor=vtk.vtkActor();actor.SetMapper(mapper)
 rgb=np.array(PALETTE[part.mat][:3],dtype=float)/255.
 prop=actor.GetProperty();prop.SetColor(*rgb);prop.SetAmbient(.48);prop.SetDiffuse(.54)
 reflect=part.mat in ('chrome','nickel','mirror','titanium','aluminum','brass','gold','copper','gunmetal','copperlight')
 prop.SetSpecular(.77 if reflect else .26);prop.SetSpecularPower(93 if reflect else 35)
 if part.mat in ('aqua','cyan','mint','green','electric','amberlit','safety','scarlet','blue','violet'):
  prop.SetAmbient(.84);prop.SetDiffuse(.30)
 if any(s in part.name for s in ('_Label','_Text','_Name','_Title','_Printed','_MainTitle','_Caption','_Engraving')):
  prop.SetAmbient(.96);prop.SetDiffuse(.02);prop.SetSpecular(0)
 if part.mat in ('glassblue','smokeglass','glass'):
  prop.SetOpacity(.12 if part.mat=='glassblue' else .24)
 prop.SetBackfaceCulling(False)
 return actor

def render(models,path,positions=None,eye=(21,25,-40),look=(0,1.5,0),scale=18,size=(2500,1480)):
 positions=positions or {}
 ren=vtk.vtkRenderer();ren.SetBackground(.041,.060,.083);ren.SetBackground2(.005,.015,.027);ren.GradientBackgroundOn()
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(2);win.AddRenderer(ren)
 for m in models:
  for p in m.parts:ren.AddActor(actor_for(p,positions.get(m.key,(0,0,0))))
 for light_pos,col,intensity in [((-17,27,-12),(1.0,.95,.87),1.0),((16,19,14),(.45,.77,1),1.2),((3,11,-18),(.65,.96,1),.78)]:
  lt=vtk.vtkLight();lt.SetLightTypeToSceneLight();lt.SetPosition(*light_pos);lt.SetFocalPoint(0,0,0)
  lt.SetColor(*col);lt.SetIntensity(intensity);ren.AddLight(lt)
 cam=ren.GetActiveCamera();cam.SetPosition(*eye);cam.SetFocalPoint(*look);cam.SetViewUp(0,1,0)
 cam.ParallelProjectionOn();cam.SetParallelScale(scale)
 win.Render()
 im=vtk.vtkWindowToImageFilter();im.SetInput(win);im.SetInputBufferTypeToRGB();im.ReadFrontBufferOff();im.Update()
 writer=vtk.vtkPNGWriter();writer.SetFileName(str(path));writer.SetInputConnection(im.GetOutputPort());writer.Write()
 win.Finalize()
 print('RENDER',path.name,round(path.stat().st_size/1024),'KB',flush=True)

def title(path,t,sub,badge=None):
 im=Image.open(path).convert('RGBA');w,h=im.size;dr=ImageDraw.Draw(im,'RGBA')
 maxw=min(w-36,int(w*.85));dr.rounded_rectangle((16,14,maxw,129),radius=14,fill=(4,17,29,236),outline=(41,223,250,255),width=2)
 tf=ImageFont.truetype(BOLD,39 if w>1900 else 25);sf=ImageFont.truetype(FONT,20 if w>1800 else 15)
 dr.text((43,35),t,font=tf,fill=(237,248,255));dr.text((43,98),sub,font=sf,fill=(136,218,240))
 if badge and w>1500:
  a=w-530;dr.rounded_rectangle((a,21,w-25,77),radius=9,fill=(7,24,40,240),outline=(250,181,83),width=2)
  dr.text((a+14,38),badge,font=ImageFont.truetype(BOLD,18),fill=(255,216,159))
 dr.text((w-18,h-16),'PROJECT SPARK  /  LEVEL 53  /  ACTUAL 3D GEOMETRY',anchor='ra',font=ImageFont.truetype(BOLD,13),fill=(138,226,240))
 im.convert('RGB').save(path)

def contact(models,previews):
 cols=4;tw,th=560,422;rows=math.ceil(len(models)/cols)
 canvas=Image.new('RGB',(cols*tw,rows*th),(7,18,29));dr=ImageDraw.Draw(canvas)
 for i,(m,p) in enumerate(zip(models,previews)):
  x=i%cols*tw+5;y=i//cols*th+5
  im=Image.open(p).convert('RGB');im.thumbnail((tw-12,th-64),Image.Resampling.LANCZOS);canvas.paste(im,(x,y))
  dr.rounded_rectangle((x,y+th-66,x+tw-14,y+th-12),radius=8,fill=(10,34,51),outline=(62,196,230),width=2)
  short=m.key[3:].replace('_',' ').upper()
  if len(short)>27:short=short[:27]
  dr.text((x+10,y+th-49),short,font=ImageFont.truetype(BOLD,18),fill=(242,248,253))
 out=P/'Level53_All_17_Models_ContactSheet.png';canvas.save(out)
 print('CONTACT',out.name,flush=True)

if __name__=='__main__':
 models=[fn() for fn in BUILDERS]
 p=P/'Level53_Complete_17Piece_Kit_Preview.png'
 render(models,p,POS,eye=(21,31,-49),look=(0,2.1,0),scale=19,size=(2800,1680))
 title(p,'LEVEL 53  /  THE HIDDEN COUPLE','TWO-PLANE DYNAMIC BALANCING  |  17 POLISHED AAA-STYLE FBX MODEL ASSETS', '24 WIRES  /  40 SOCKETS')
 p=P/'Level53_Hero_Polished_Preview.png'
 render(models,p,POS,eye=(15,23,-40),look=(0,2.35,.60),scale=17.8,size=(2600,1510))
 title(p,'LEVEL 53  /  TWIN-PLANE PRECISION BALANCING','COUPLED ROTOR  /  LEFT + RIGHT VIBRATION  /  DUAL CORRECTION WEIGHTS','ACTUAL EXPORTED MESHES')
 p=P/'Level53_Rotor_Engineering_Detail.png'
 render(models,p,POS,eye=(8,13,-19),look=(0,3.2,1.7),scale=9.6,size=(2240,1390))
 title(p,'LEVEL 53  /  MECHANICAL BALANCE CELL','SEPARATE PLANE A + B WEIGHTS  |  CHROME SHAFT  |  DUAL SENSOR BEARINGS')
 thumbs=[]
 for i,m in enumerate(models):
  dest=P/(m.key+'_Preview.png')
  if i==0:eye=(20,26,-36);look=(0,1.1,0);sc=18
  elif i==2:eye=(18,9,-24);look=(0,2.6,0);sc=6.8
  elif i==14:eye=(17,17,-28);look=(0,3,0);sc=11
  elif i==12:eye=(5,7,-15);look=(0,1.5,0);sc=5.3
  elif i==13:eye=(5,8,-16);look=(0,1.5,0);sc=5.7
  elif i in [1,3,4,5,6,9]:eye=(5.5,7.0,-12);look=(0,2,0);sc=4.8
  else:eye=(5,7,-12);look=(0,1.5,0);sc=4.25
  render([m],dest,eye=eye,look=look,scale=sc,size=(930,715))
  title(dest,m.key.split('_',2)[-1].replace('_',' ').upper(),'LEVEL 53 / INDIVIDUAL UNITY FBX MODEL')
  thumbs.append(dest)
 contact(models,thumbs)
 print('DONE RENDERING',flush=True)
