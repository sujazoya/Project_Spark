"""
Project Spark — Level 53 The Hidden Couple — polished industrial art hardware.
Dependencies: numpy, trimesh, shapely, matplotlib; VTK optional for previews.
Exports Autodesk FBX 7.4 binary, GLB alternatives, Unity-ready meshes.
One unit is a relative game model unit. Y up, -Z toward connector fronts.
"""
from __future__ import annotations
import math, os, struct, zlib, json, re
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import trimesh
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
from shapely.geometry import Polygon
from shapely.ops import triangulate

OUT=Path(__file__).resolve().parents[1]
MODELS=OUT/'Models'; PREV=OUT/'Previews'
MODELS.mkdir(exist_ok=True,parents=True); PREV.mkdir(exist_ok=True,parents=True)

PALETTE={
 'graphite': (18,29,43,255), 'deep_steel': (27,42,60,255), 'mid_steel': (56,76,101,255),
 'steel':(112,137,162,255), 'titanium':(159,179,200,255), 'chrome':(210,225,237,255),
 'void':(7,13,24,255), 'bezel':(12,24,38,255), 'screen':(9,31,44,255),
 'cyan':(35,218,253,255), 'cyan_soft':(69,160,210,255), 'blue':(22,113,226,255),
 'green':(44,252,143,255), 'amber':(255,168,43,255), 'orange':(249,113,38,255),
 'red':(255,65,88,255), 'gold':(237,184,70,255), 'copper':(194,103,47,255),
 'warning':(255,200,66,255), 'white':(231,245,251,255), 'fog':(169,192,206,255),
 'glass':(87,188,218,86), 'glass_edge':(111,223,246,255),
 'water':(19,153,227,125), 'water_hi':(57,220,244,210),
 'rubber':(24,30,37,255), 'woodbrown':(79,55,40,255)
}

@dataclass
class Part:
 name: str
 mesh: trimesh.Trimesh
 mat: str
 group: str = 'Static'

class Model:
 def __init__(self,key):self.key=key;self.parts=[];self.anchors={};self.group_pivots={}
 def add(self,name,mesh,material,group='Static'):
  if not isinstance(mesh,trimesh.Trimesh):raise TypeError(name)
  if len(mesh.vertices)==0:return mesh
  m=mesh.copy()
  m.visual.face_colors=np.tile(np.array(PALETTE[material],dtype=np.uint8),(len(m.faces),1))
  self.parts.append(Part(name,m,material,group)); return m
 def box(self,name,ext,center,mat,group='Static'):
  m=trimesh.creation.box(extents=ext);m.apply_translation(center);return self.add(name,m,mat,group)
 def bevel(self,name,ext,center,mat,chamfer=.08,group='Static'):
  w,h,d=ext;x0,y0,z0=center
  b=min(chamfer, w*.18, h*.40, d*.18)
  def contour(ww,dd):
   # clockwise looking from above; vertices in X,Z plane
   x,z=ww/2,dd/2;c=min(b, x*.4,z*.4)
   return [(-x+c,-z),(x-c,-z),(x,-z+c),(x,z-c),(x-c,z),(-x+c,z),(-x,z-c),(-x,-z+c)]
  rings=[(y0+h/2, w-2*b,d-2*b), (y0+h/2-b,w,d),
         (y0-h/2+b,w,d),(y0-h/2,w-2*b,d-2*b)]
  verts=[]
  for yy,ww,dd in rings:
   for xx,zz in contour(ww,dd):verts.append((xx+x0,yy,zz+z0))
  top=len(verts);verts.append((x0,y0+h/2,z0));bottom=len(verts);verts.append((x0,y0-h/2,z0))
  faces=[]
  for r in range(3):
   for k in range(8):
    k2=(k+1)%8; a=r*8+k; bb=r*8+k2;c=(r+1)*8+k2;dd=(r+1)*8+k
    faces += [[a,bb,c],[a,c,dd]]
  for k in range(8):faces.extend([[top,(k+1)%8,k],[bottom,24+k,24+(k+1)%8]])
  return self.add(name,trimesh.Trimesh(vertices=verts,faces=faces,process=False),mat,group)
 def cyl(self,name,radius,height,at,mat,axis='y',sections=32,group='Static'):
  m=trimesh.creation.cylinder(radius=radius,height=height,sections=sections)
  if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
  elif axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
  elif axis!='z':raise ValueError(axis)
  m.apply_translation(at);return self.add(name,m,mat,group)
 def torus(self,name,major,minor,at,mat,axis='x',segments=48,tube_segs=8,group='Static'):
  verts=[]; faces=[]
  for u in range(segments):
   a=2*math.pi*u/segments
   for v in range(tube_segs):
    theta=2*math.pi*v/tube_segs
    radial=major+minor*math.cos(theta)
    if axis=='x':p=(minor*math.sin(theta),radial*math.cos(a),radial*math.sin(a))
    elif axis=='y':p=(radial*math.cos(a),minor*math.sin(theta),radial*math.sin(a))
    else:p=(radial*math.cos(a),radial*math.sin(a),minor*math.sin(theta))
    verts.append(np.array(at)+np.array(p))
  for u in range(segments):
   for v in range(tube_segs):
    a=u*tube_segs+v;b=((u+1)%segments)*tube_segs+v
    c=((u+1)%segments)*tube_segs+(v+1)%tube_segs;d=u*tube_segs+(v+1)%tube_segs
    faces += [[a,b,c],[a,c,d]]
  return self.add(name,trimesh.Trimesh(vertices=verts,faces=faces,process=False),mat,group)
 def tube(self,name,ro,ri,length,at,mat,axis='z',segments=40,group='Static'):
  verts=[];faces=[]
  for s in [-length/2,length/2]:
   for r in [ro,ri]:
    for j in range(segments):
     t=math.tau*j/segments;u=r*math.cos(t);v=r*math.sin(t)
     if axis=='x':p=(s,u,v)
     elif axis=='y':p=(u,s,v)
     else:p=(u,v,s)
     verts.append(np.array(at)+np.array(p))
  for k in range(segments):
   kk=(k+1)%segments
   for a,b,c,d in ((k,kk,2*segments+kk,2*segments+k),
                   (segments+k,3*segments+k,3*segments+kk,segments+kk),
                   (k,segments+k,segments+kk,kk),
                   (2*segments+k,2*segments+kk,3*segments+kk,3*segments+k)):
    faces.extend([[a,b,c],[a,c,d]])
  return self.add(name,trimesh.Trimesh(vertices=verts,faces=faces,process=False),mat,group)
 def rod(self,name,a,b,radius,mat,sections=12,group='Static'):
  a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);vec=b-a;length=np.linalg.norm(vec)
  if length<1e-6:return
  m=trimesh.creation.cylinder(radius=radius,height=length,sections=sections)
  T=trimesh.geometry.align_vectors([0,0,1],vec/length)
  m.apply_transform(T);m.apply_translation((a+b)/2)
  return self.add(name,m,mat,group)
 def text(self,name,label,size,x,y,z,mat,maxwidth=None,group='Static', bold=True):
  # Decal on -Z facing front, meshes live in the XY plane
  font=FontProperties(family='DejaVu Sans',weight='bold' if bold else 'normal')
  tpath=TextPath((0,0),label,size=size,prop=font)
  lines=tpath.to_polygons(); geom=None
  for ln in lines:
   poly=Polygon(ln)
   if not poly.is_valid: poly=poly.buffer(0)
   if poly.is_empty or poly.area < 1e-8:continue
   geom=poly if geom is None else geom.symmetric_difference(poly)
  if geom is None or geom.is_empty:return
  x0,y0,x1,y1=geom.bounds
  scale=1 if maxwidth is None or x1-x0<maxwidth else maxwidth/(x1-x0)
  verts=[];faces=[]
  polys=list(geom.geoms) if hasattr(geom,'geoms') else [geom]
  for poly in polys:
   if poly.geom_type!='Polygon':continue
   for tri in triangulate(poly):
    if not poly.covers(tri.representative_point()):continue
    points=np.asarray(tri.exterior.coords)[:3]
    base=len(verts)
    for xx,yy in points:verts.append((x-(xx-(x0+x1)/2)*scale,y+(yy-(y0+y1)/2)*scale,z))
    faces.extend([[base,base+2,base+1],[base,base+1,base+2]])
  if faces:return self.add(name,trimesh.Trimesh(vertices=verts,faces=faces,process=False),mat,group)
 def jacks(self,name,left,right,port_left,port_right, y=.40,front=-.785,w=.67):
  for pos,role,col in [(w,port_left[0],port_left[1]),(-w,port_right[0],port_right[1])]:
   self.cyl(f'{name}_{role}_Socket_MetalRim',.161,.056,(pos,y,front-.008),'chrome',axis='z',sections=36)
   self.cyl(f'{name}_{role}_Socket_ColoredRing',.132,.061,(pos,y,front-.043),col,axis='z',sections=36)
   self.cyl(f'{name}_{role}_Socket_Recess',.088,.07,(pos,y,front-.080),'void',axis='z',sections=30)
   self.cyl(f'{name}_{role}_InnerContact',.029,.025,(pos,y,front-.090),'gold',axis='z',sections=18)
   self.text(f'{name}_{role}_Label',role,.110,pos,y+.250,front-.110,'fog',maxwidth=.56)
   self.anchors[role]=(pos,y,front-.10)
 def screws(self,prefix,w=1.0,z=-.77,ylist=(.24,1.25)):
  for x in [-w,w]:
   for y in ylist:
    tag=f'{prefix}_Fastener_{x:+.1f}_{y:.2f}'
    self.cyl(tag,.054,.03,(x,y,z-.025),'chrome',axis='z',sections=16)
    self.box(tag+'_Slot',(.055,.010,.003),(x,y,z-.046),'mid_steel')
 def base(self,key,w=2.35,d=1.55,bodyh=1.15,fronttext='',status=''):
  # y=0 ground, front face is negative Z
  self.bevel(key+'_Footpad_Rubber',(w+.15,.105,d+.12),(0,.075,0),'rubber',.06)
  self.bevel(key+'_Aluminum_Base',(w+.12,.20,d+.1),(0,.21,0),'titanium',.06)
  self.bevel(key+'_Chassis',(w,bodyh,d),(0,.32+bodyh/2,0),'graphite',.12)
  self.bevel(key+'_Front_Console_Plate',(w-.14,bodyh-.16,.06),(0,.32+bodyh/2,-d/2-.007),'deep_steel',.042)
  self.bevel(key+'_Top_Lid',(w-.055,.11,d-.08),(0,.32+bodyh+.035,0),'mid_steel',.04)
  self.box(key+'_Neon_Sill',(w*.56,.036,.033),(0,.31,-d/2-.063),'cyan')
  self.box(key+'_Top_Status_Light',(w*.45,.033,.033),(0,.32+bodyh+.082,-d/2+.14),'cyan')
  self.box(key+'_Left_Orange_Edge',(.035,.38,.034),(-w/2+.035,.83,-d/2-.028),'orange')
  self.box(key+'_Right_Orange_Edge',(.035,.38,.034),(w/2-.035,.83,-d/2-.028),'orange')
  self.screws(key,w/2-.18,z=-d/2-.06,ylist=(.29,.32+bodyh-.18))
  if fronttext:
   self.text(key+'_Main_Label',fronttext,.175,0,.32+bodyh*.66,-d/2-.049,'white',maxwidth=w-.34)
  if status:
   self.text(key+'_Sub_Label',status,.118,0,.32+bodyh*.43,-d/2-.049,'cyan',maxwidth=w-.42)


def add_panel_text(m,key,label,at,size=.135,col='white',maxwidth=None):
 m.text(key,label,size,*at,col,maxwidth=maxwidth)


# FBX WRITER ----------------------------------------------------
class FBXNode:
 def __init__(self,name,*props,children=None):self.name=name;self.props=list(props);self.children=children or []
def fs(v):return ('S',str(v))
def fl(v):return ('L',int(v))
def fi(v):return ('I',int(v))
def fd(v):return ('D',float(v))
def fa(t,x):return ('array'+t,x)
def encode_prop(prop):
 typ,val=prop
 if typ=='S':
  b=val.encode('utf-8');return b'S'+struct.pack('<I',len(b))+b
 if typ=='L':return b'L'+struct.pack('<q',val)
 if typ=='I':return b'I'+struct.pack('<i',val)
 if typ=='D':return b'D'+struct.pack('<d',val)
 if typ=='C':return b'C'+bytes([int(bool(val))])
 if typ.startswith('array'):
  dt=typ[-1];v=list(val);binary=struct.pack('<'+str(len(v))+{'d':'d','i':'i','f':'f'}[dt],*v)
  zipped=zlib.compress(binary,6);encoding=1 if len(zipped)<len(binary) else 0
  payload=zipped if encoding else binary
  return dt.encode('ascii')+struct.pack('<III',len(v),encoding,len(payload))+payload
 raise ValueError(typ)
FBX_NULL=b'\0'*13
def encode_node(n,offset):
 name=n.name.encode('utf-8');pr=b''.join(map(encode_prop,n.props))
 head=13+len(name);body=bytearray();start=offset+head+len(pr)
 for child in n.children:body.extend(encode_node(child,start+len(body)))
 if n.children:body.extend(FBX_NULL)
 end=offset+head+len(pr)+len(body)
 return struct.pack('<III',end,len(n.props),len(pr))+struct.pack('<B',len(name))+name+pr+body

def property_vec(k,a,b,c,kind='Vector3D'):
 return FBXNode('P',fs(k),fs(kind),fs('Vector' if kind=='Vector3D' else ''),fs(''),fd(a),fd(b),fd(c))
def property_num(k,val):return FBXNode('P',fs(k),fs('double'),fs('Number'),fs(''),fd(val))

def export_fbx(destination,models,assembled=False,positions=None):
 positions=positions or {};materials=[];geoms=[];objects=[];conns=[];ids=10000
 def getid():
  nonlocal ids;ids+=1;return ids
 mats={}
 for mat in sorted({p.mat for m in models for p in m.parts}):
  mid=getid();mats[mat]=mid;rgb=[x/255 for x in PALETTE[mat][:3]]
  rough=.13 if mat in ('chrome','titanium','gold','copper') else .35
  props=[property_vec('DiffuseColor',*rgb,kind='Color'),property_vec('SpecularColor',.55,.57,.62,kind='Color'),property_num('Shininess',65 if rough<.3 else 28)]
  if PALETTE[mat][3]<255:props.append(property_num('Opacity',max(.15,PALETTE[mat][3]/255)))
  materials.append(FBXNode('Material',fl(mid),fs('Material::'+mat),fs(''),children=[FBXNode('Version',fi(102)),FBXNode('ShadingModel',fs('phong')),FBXNode('MultiLayer',fi(0)),FBXNode('Properties70',children=props)]))
 # group null models at offset positions; grouped meshes under Static, Sensor, Lever_ANIMATE etc.
 rootid=getid()
 objects.append(FBXNode('Model',fl(rootid),fs('Model::LEVEL53_ART_ROOT'),fs('Null'),children=[FBXNode('Version',fi(232))]))
 conns.append(FBXNode('C',fs('OO'),fl(rootid),fl(0)))
 for model in models:
  modid=getid()
  pt=positions.get(model.key,(0,0,0))
  objects.append(FBXNode('Model',fl(modid),fs('Model::'+model.key),fs('Null'),children=[FBXNode('Version',fi(232)),FBXNode('Properties70',children=[property_vec('Lcl Translation',*pt),property_vec('Lcl Rotation',0,0,0),property_vec('Lcl Scaling',1,1,1)])]))
  conns.append(FBXNode('C',fs('OO'),fl(modid),fl(rootid)))
  groups={}
  for grp in dict.fromkeys(p.group for p in model.parts):
   gid=getid();groups[grp]=gid
   objects.append(FBXNode('Model',fl(gid),fs('Model::'+model.key+'_'+grp),fs('Null'),children=[FBXNode('Version',fi(232)),FBXNode('Properties70',children=[property_vec('Lcl Translation',*model.group_pivots.get(grp,(0,0,0)))])]))
   conns.append(FBXNode('C',fs('OO'),fl(gid),fl(modid)))
  for part in model.parts:
   m=part.mesh.copy();m.apply_translation(-np.asarray(model.group_pivots.get(part.group,(0,0,0)),dtype=float));geomid=getid();objid=getid();name=model.key+'__'+part.name
   face=np.asarray(m.faces,dtype=np.int32).copy();face[:,-1]=-face[:,-1]-1
   xyz=np.asarray(m.vertices,dtype=np.float64).flatten().tolist()
   tri=m.triangles;norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm=norm/np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-10)
   norms=np.repeat(norm,3,axis=0).flatten().tolist()
   le=FBXNode('LayerElementNormal',fi(0),children=[FBXNode('Version',fi(101)),FBXNode('Name',fs('')),FBXNode('MappingInformationType',fs('ByPolygonVertex')),FBXNode('ReferenceInformationType',fs('Direct')),FBXNode('Normals',fa('d',norms))])
   geoms.append(FBXNode('Geometry',fl(geomid),fs('Geometry::'+name),fs('Mesh'),children=[FBXNode('GeometryVersion',fi(124)),FBXNode('Vertices',fa('d',xyz)),FBXNode('PolygonVertexIndex',fa('i',face.reshape(-1).tolist())),le,FBXNode('Layer',fi(0),children=[FBXNode('Version',fi(100)),FBXNode('LayerElement',children=[FBXNode('Type',fs('LayerElementNormal')),FBXNode('TypedIndex',fi(0))])])]))
   objects.append(FBXNode('Model',fl(objid),fs('Model::'+name),fs('Mesh'),children=[FBXNode('Version',fi(232)),FBXNode('Properties70',children=[property_vec('Lcl Translation',0,0,0),property_vec('Lcl Rotation',0,0,0),property_vec('Lcl Scaling',1,1,1)]),FBXNode('Shading',('C',True)),FBXNode('Culling',fs('CullingOff'))]))
   conns.extend([FBXNode('C',fs('OO'),fl(geomid),fl(objid)),FBXNode('C',fs('OO'),fl(objid),fl(groups[part.group])),FBXNode('C',fs('OO'),fl(mats[part.mat]),fl(objid))])
 roots=[
  FBXNode('FBXHeaderExtension',children=[FBXNode('FBXHeaderVersion',fi(1003)),FBXNode('FBXVersion',fi(7400)),FBXNode('Creator',fs('Project Spark Level 53 The Hidden Couple Art Builder'))]),
  FBXNode('GlobalSettings',children=[FBXNode('Version',fi(1000)),FBXNode('Properties70',children=[FBXNode('P',fs('UpAxis'),fs('int'),fs('Integer'),fs(''),fi(1)),FBXNode('P',fs('UpAxisSign'),fs('int'),fs('Integer'),fs(''),fi(1)),FBXNode('P',fs('FrontAxis'),fs('int'),fs('Integer'),fs(''),fi(2)),FBXNode('P',fs('FrontAxisSign'),fs('int'),fs('Integer'),fs(''),fi(1)),FBXNode('P',fs('CoordAxis'),fs('int'),fs('Integer'),fs(''),fi(0)),FBXNode('P',fs('CoordAxisSign'),fs('int'),fs('Integer'),fs(''),fi(1)),FBXNode('P',fs('UnitScaleFactor'),fs('double'),fs('Number'),fs(''),fd(1))])]),
  FBXNode('Definitions',children=[FBXNode('Version',fi(100)),FBXNode('Count',fi(len(materials)+len(geoms)+len(objects))),FBXNode('ObjectType',fs('Model'),children=[FBXNode('Count',fi(len(objects)))]),FBXNode('ObjectType',fs('Geometry'),children=[FBXNode('Count',fi(len(geoms)))]),FBXNode('ObjectType',fs('Material'),children=[FBXNode('Count',fi(len(materials)))])]),
  FBXNode('Objects',children=materials+geoms+objects),FBXNode('Connections',children=conns)]
 header=b'Kaydara FBX Binary  \x00\x1a\x00'+struct.pack('<I',7400)
 data=bytearray(header)
 for root in roots:data.extend(encode_node(root,len(data)))
 data.extend(FBX_NULL);data.extend(b'\0'*16);data.extend(struct.pack('<I',7400));data.extend(b'\0'*120)
 Path(destination).write_bytes(data)
 # recursively verify pointer integrity
 def check(pos,depth=0):
  end,num,nb,nl=struct.unpack_from('<IIIB',data,pos)
  assert end>pos and end<=len(data),(pos,end)
  cursor=pos+13+nl+nb
  while cursor+13<end:
   e,n,p,l=struct.unpack_from('<IIIB',data,cursor)
   if e==n==p==l==0:break
   check(cursor,depth+1);cursor=e
  return end
 cursor=len(header)
 for root in roots:cursor=check(cursor)
 assert bytes(data).startswith(b'Kaydara FBX Binary')
 return len(data)

def export_glb(destination,models,positions=None):
 s=trimesh.Scene();positions=positions or {}
 for model in models:
  offset=np.array(positions.get(model.key,(0,0,0)))
  for p in model.parts:
   mesh=p.mesh.copy();mesh.apply_translation(offset)
   mesh.metadata['material_name']=p.mat
   s.add_geometry(mesh,geom_name=model.key+'__'+p.name,node_name=model.key+'__'+p.name)
 s.export(destination)
 return Path(destination).stat().st_size

